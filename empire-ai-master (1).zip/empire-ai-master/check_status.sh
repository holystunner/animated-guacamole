#!/bin/bash

# Empire AI - Status Check Script
# Comprehensive health check for running services

REPO_ROOT="/home/lin/Documents/empire-ai"
API_URL="http://localhost:8000"
FRONTEND_URL="http://localhost:3000"

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "\n${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}EMPIRE AI - STATUS CHECK${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}\n"

# Check API service
echo "Checking API Service..."
if ps aux | grep -q "[p]ython3 src/admin_ui.py"; then
  echo -e "${GREEN}✓${NC} API process is running"
  API_PID=$(cat "$REPO_ROOT/.api.pid" 2>/dev/null)
  echo "  PID: $API_PID"
else
  echo -e "${RED}✗${NC} API process is NOT running"
fi

if curl -s "$API_URL/health" > /dev/null 2>&1; then
  HEALTH=$(curl -s "$API_URL/health")
  echo -e "${GREEN}✓${NC} API is responding"
  echo "  Response: $HEALTH"
else
  echo -e "${RED}✗${NC} API is NOT responding on $API_URL"
fi

# Check Frontend service
echo ""
echo "Checking Frontend Service..."
if ps aux | grep -q "[p]ython3 -m http.server 3000"; then
  echo -e "${GREEN}✓${NC} Frontend process is running"
  FRONTEND_PID=$(cat "$REPO_ROOT/.frontend.pid" 2>/dev/null)
  echo "  PID: $FRONTEND_PID"
else
  echo -e "${RED}✗${NC} Frontend process is NOT running"
fi

if curl -s "$FRONTEND_URL" > /dev/null 2>&1; then
  echo -e "${GREEN}✓${NC} Frontend is responding"
  TITLE=$(curl -s "$FRONTEND_URL" | grep -o "<title>[^<]*</title>" | sed 's/<[^>]*>//g')
  echo "  Title: $TITLE"
else
  echo -e "${RED}✗${NC} Frontend is NOT responding on $FRONTEND_URL"
fi

# Check Database
echo ""
echo "Checking Database..."
if [ -f "$REPO_ROOT/data/empire.db" ]; then
  echo -e "${GREEN}✓${NC} Database file exists"
  SIZE=$(du -h "$REPO_ROOT/data/empire.db" | cut -f1)
  echo "  Size: $SIZE"
  MTIME=$(stat -c %y "$REPO_ROOT/data/empire.db" 2>/dev/null | cut -d' ' -f1)
  echo "  Last modified: $MTIME"
else
  echo -e "${RED}✗${NC} Database file NOT found"
fi

# Check Ports
echo ""
echo "Checking Network Ports..."
if netstat -tlnp 2>/dev/null | grep -q ":8000"; then
  echo -e "${GREEN}✓${NC} Port 8000 is in use (API)"
else
  echo -e "${YELLOW}⚠${NC} Port 8000 is NOT in use"
fi

if netstat -tlnp 2>/dev/null | grep -q ":3000"; then
  echo -e "${GREEN}✓${NC} Port 3000 is in use (Frontend)"
else
  echo -e "${YELLOW}⚠${NC} Port 3000 is NOT in use"
fi

# Check Logs
echo ""
echo "Checking Logs..."
if [ -f "/tmp/api.log" ]; then
  LINES=$(wc -l < /tmp/api.log)
  echo -e "${GREEN}✓${NC} API log exists ($LINES lines)"
  LAST_ERROR=$(grep -i error /tmp/api.log | tail -1)
  if [ -n "$LAST_ERROR" ]; then
    echo -e "  ${YELLOW}Last error:${NC} $(echo $LAST_ERROR | cut -c1-80)..."
  fi
else
  echo -e "${YELLOW}⚠${NC} API log not found"
fi

if [ -f "/tmp/frontend.log" ]; then
  LINES=$(wc -l < /tmp/frontend.log)
  echo -e "${GREEN}✓${NC} Frontend log exists ($LINES lines)"
else
  echo -e "${YELLOW}⚠${NC} Frontend log not found"
fi

# Test Results
echo ""
echo "Running Quick Tests..."
PASS=0
FAIL=0

# Test 1: API Health
if curl -s "$API_URL/health" | grep -q "healthy"; then
  echo -e "${GREEN}✓${NC} API health check: PASS"
  PASS=$((PASS + 1))
else
  echo -e "${RED}✗${NC} API health check: FAIL"
  FAIL=$((FAIL + 1))
fi

# Test 2: API Docs
if curl -s "$API_URL/docs" | grep -q "swagger"; then
  echo -e "${GREEN}✓${NC} API documentation: PASS"
  PASS=$((PASS + 1))
else
  echo -e "${YELLOW}⚠${NC} API documentation: NOT AVAILABLE"
fi

# Test 3: Frontend Title
if curl -s "$FRONTEND_URL" | grep -q "EmpireAI\|Admin"; then
  echo -e "${GREEN}✓${NC} Frontend title: PASS"
  PASS=$((PASS + 1))
else
  echo -e "${RED}✗${NC} Frontend title: FAIL"
  FAIL=$((FAIL + 1))
fi

# Test 4: Auth endpoint exists
if curl -s -X POST "$API_URL/api/v1/auth/login" -H "Content-Type: application/json" -d '{}' > /dev/null 2>&1; then
  echo -e "${GREEN}✓${NC} Auth endpoint: PASS"
  PASS=$((PASS + 1))
else
  echo -e "${YELLOW}⚠${NC} Auth endpoint: NOT RESPONDING"
fi

# Summary
echo ""
echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo "Summary:"
echo -e "  Passed: ${GREEN}$PASS${NC}"
echo -e "  Failed: ${RED}$FAIL${NC}"

if [ $FAIL -eq 0 ] && [ $PASS -ge 3 ]; then
  echo -e "\nStatus: ${GREEN}✓ ALL SYSTEMS OPERATIONAL${NC}"
  exit 0
else
  echo -e "\nStatus: ${YELLOW}⚠ CHECK REQUIRED${NC}"
  exit 1
fi
