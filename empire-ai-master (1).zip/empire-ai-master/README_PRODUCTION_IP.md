# Empire AI Production Deployment with Public IP

This guide provides complete instructions for deploying Empire AI using your public IP address `49.12.230.179` as the domain.

## 🚀 Quick Start

### 1. Server Setup

```bash
# Connect to your Hetzner server
ssh root@49.12.230.179

# Create empire-ai user and setup environment
sudo useradd -m -s /bin/bash empire-ai
sudo usermod -aG sudo empire-ai
sudo su - empire-ai

# Clone and setup the environment
git clone <your-empire-ai-repo>
cd empire-ai
./scripts/setup-hetzner.sh
```

### 2. Deploy Empire AI

```bash
# Deploy with production configuration
./scripts/deploy-production.sh deploy

# Or deploy with Helm
./scripts/deploy-production.sh helm-deploy

# Check deployment status
./scripts/deploy-production.sh status

# Run health checks
./scripts/deploy-production.sh health
```

## 🌐 Access URLs

After deployment, you can access the application at:

- **Frontend**: https://49.12.230.179
- **API**: https://49.12.230.179/api
- **Keycloak**: https://49.12.230.179/auth
- **Keycloak Admin**: https://49.12.230.179/auth/admin

## 🔑 Default Credentials

- **Keycloak Admin**: `admin` / `EmpireAI@2024!Admin`
- **Database**: `empire` / `EmpireAI@2024!User`
- **PostgreSQL**: `postgres` / `EmpireAI@2024!SecureDB`

⚠️ **Important**: Change these passwords immediately after deployment!

## 📋 Configuration Files

### Production-Specific Files Created:

1. **`helm/empire-ai/values-production.yaml`** - Helm values optimized for public IP
2. **`k8s/configmaps-production.yaml`** - ConfigMaps with public IP configuration
3. **`k8s/secrets-production.yaml`** - Secure secrets for production
4. **`k8s/ingress-production.yaml`** - Ingress configured for public IP
5. **`scripts/deploy-production.sh`** - Automated production deployment script

### Key Configuration Changes:

#### Domain Configuration
- All services configured to use `49.12.230.179` as the domain
- CORS settings allow access from the public IP
- Keycloak configured with edge proxy mode

#### Security Settings
- Strong passwords for all services
- TLS/SSL encryption enabled
- Rate limiting configured
- Security headers implemented

#### Resource Optimization
- Optimized for Hetzner cax31 (8 vCPU, 16GB RAM)
- Proper resource limits and requests
- Horizontal pod autoscaling enabled

## 🔧 Management Commands

### Basic Operations

```bash
# Check all pods
kubectl get pods -n empire-ai

# Check services
kubectl get services -n empire-ai

# Check ingress
kubectl get ingress -n empire-ai

# View application logs
kubectl logs -f deployment/empire-ai -n empire-ai

# Access application shell
kubectl exec -it deployment/empire-ai -n empire-ai -- bash
```

### Scaling

```bash
# Scale backend
kubectl scale deployment empire-ai --replicas=3 -n empire-ai

# Scale frontend
kubectl scale deployment nginx --replicas=3 -n empire-ai
```

### Updates

```bash
# Update with latest changes
./scripts/deploy-production.sh deploy

# Or with Helm
helm upgrade empire-ai ./helm/empire-ai \
  --namespace empire-ai \
  --values helm/empire-ai/values-production.yaml
```

## 🔒 Security Considerations

### Immediate Actions Required:

1. **Change Default Passwords**
   ```bash
   # Update Keycloak admin password via UI or CLI
   # Update database passwords in secrets
   ```

2. **Replace Self-Signed Certificates**
   ```bash
   # Obtain proper SSL certificates for your domain
   # Update the empire-ai-tls secret
   ```

3. **Configure Firewall**
   ```bash
   # Ensure only necessary ports are open
   sudo ufw status
   sudo ufw allow ssh
   sudo ufw allow 80
   sudo ufw allow 443
   ```

### Recommended Security Measures:

1. **Enable Network Policies**
   ```yaml
   # Uncomment network policies in ingress-production.yaml
   security:
     networkPolicy:
       enabled: true
   ```

2. **Set Up Monitoring**
   ```bash
   # Install Prometheus/Grafana for monitoring
   # Set up alerting for critical issues
   ```

3. **Regular Updates**
   ```bash
   # Keep Kubernetes and applications updated
   # Regular security patches
   ```

## 📊 Monitoring

### Basic Monitoring

```bash
# Check resource usage
kubectl top nodes
kubectl top pods -n empire-ai

# Check node exporter metrics
curl http://49.12.230.179:9100/metrics
```

### Health Checks

```bash
# Run comprehensive health checks
./scripts/deploy-production.sh health

# Test individual endpoints
curl -k https://49.12.230.179/health
curl -k https://49.12.230.179/api/health
curl -k https://49.12.230.179/auth/
```

## 🗄️ Database Management

### Access PostgreSQL

```bash
# Access PostgreSQL pod
kubectl exec -it postgres-0 -n empire-ai -- psql -U empire -d empire

# Create backup
kubectl exec postgres-0 -n empire-ai -- pg_dump -U empire empire > backup.sql

# Restore backup
kubectl exec -i postgres-0 -n empire-ai -- psql -U empire empire < backup.sql
```

### Access Redis

```bash
# Access Redis pod
kubectl exec -it redis-master-0 -n empire-ai -- redis-cli

# Create backup
kubectl exec redis-master-0 -n empire-ai -- redis-cli BGSAVE
```

## 🔧 Troubleshooting

### Common Issues

1. **Pods Not Starting**
   ```bash
   kubectl describe pod <pod-name> -n empire-ai
   kubectl logs <pod-name> -n empire-ai
   ```

2. **Ingress Not Working**
   ```bash
   kubectl get ingress -n empire-ai
   kubectl logs -n ingress-nginx deployment/ingress-nginx-controller
   ```

3. **Certificate Issues**
   ```bash
   kubectl get secret empire-ai-tls -n empire-ai -o yaml
   # Regenerate certificates if needed
   ```

4. **Database Connection Issues**
   ```bash
   kubectl get endpoints postgres-service -n empire-ai
   kubectl exec -it postgres-0 -n empire-ai -- psql -U empire -d empire
   ```

### Performance Issues

```bash
# Check resource usage
kubectl top pods -n empire-ai
htop
iotop

# Check system resources
df -h
free -h
```

## 🔄 Backup and Recovery

### Automated Backups

```bash
# Backup script is automatically configured
# Check backup schedule
crontab -l

# Manual backup
./backup.sh

# Check backup directory
ls -la /var/lib/empire-ai/backups/
```

### Disaster Recovery

```bash
# Restore from backup
kubectl exec -i postgres-0 -n empire-ai -- psql -U empire empire < backup.sql

# Redeploy if needed
./scripts/deploy-production.sh cleanup
./scripts/deploy-production.sh deploy
```

## 📈 Performance Optimization

### Resource Tuning

The deployment is optimized for your Hetzner cax31 server:

- **CPU Usage**: ~6-8 vCPU out of 8 available
- **Memory Usage**: ~14-16GB out of 16GB available
- **Storage**: ~110GB used, ~50GB free for growth

### Scaling Recommendations

```yaml
# For higher load, adjust these values in values-production.yaml:
empire-ai:
  replicaCount: 3-4  # Increase based on load
  resources:
    requests:
      memory: "3Gi"   # Increase if needed
      cpu: "1500m"
```

## 🌍 DNS Configuration (Optional)

If you want to use a domain name instead of the IP:

1. **DNS Records**
   ```
   empire-ai.yourdomain.com     -> 49.12.230.179
   api.empire-ai.yourdomain.com -> 49.12.230.179
   keycloak.empire-ai.yourdomain.com -> 49.12.230.179
   ```

2. **Update Configuration**
   ```yaml
   # Update values-production.yaml with your domain
   ingress:
     hosts:
       main:
         host: "empire-ai.yourdomain.com"
   ```

3. **Redeploy**
   ```bash
   ./scripts/deploy-production.sh deploy
   ```

## 📞 Support

### Getting Help

1. **Check Logs**: Always check pod logs first
2. **Health Checks**: Run `./scripts/deploy-production.sh health`
3. **Documentation**: Refer to `KUBERNETES_DEPLOYMENT.md`
4. **Community**: Check GitHub issues for common problems

### Emergency Procedures

```bash
# Quick restart of all services
kubectl rollout restart deployment --all -n empire-ai

# Emergency shutdown
kubectl scale deployment --all --replicas=0 -n empire-ai

# Complete redeployment
./scripts/deploy-production.sh cleanup
./scripts/deploy-production.sh deploy
```

---

## 🎉 Summary

Your Empire AI platform is now configured to run on your public IP `49.12.230.179` with:

- ✅ **Production-ready security** with strong passwords and TLS
- ✅ **Optimized performance** for your Hetzner c31 server
- ✅ **High availability** with multiple replicas
- ✅ **Automated backups** and monitoring
- ✅ **Easy management** with deployment scripts
- ✅ **Scalable architecture** ready for growth

The platform is accessible immediately at https://49.12.230.179 - just remember to change the default passwords and configure proper SSL certificates for production use!
