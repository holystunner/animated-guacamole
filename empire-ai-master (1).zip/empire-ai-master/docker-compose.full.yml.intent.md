# docker-compose.full.yml.intent.md

**Purpose**: Production Docker Compose with security hardening
**Authorizing Plan**: ATLAS_FULLSTACK_E2E_DEPLOYMENT_AND_FIXES_BLUEPRINT.md - Phase FS-2
**Phase**: FS-2 Infrastructure Hardening

## Inputs
- Development docker-compose.yml
- Production security requirements from authority plan

## Outputs
- Production Docker Compose with hardened Nginx configuration
- Container security options (no-new-privileges, read-only)
- Temporary filesystems for writable directories
- Port alignment with Nginx configuration

## Invariants
- Nginx container runs with minimal privileges
- Filesystem mounted read-only where possible
- Temporary filesystems used for logs/cache
- Ports aligned with Nginx configuration
- No fallback to development configurations

## Failure Modes
- If container runs with elevated privileges: Security violation, execution halt
- If filesystem not read-only: Security violation, execution halt
- If ports misaligned: Service failure, execution halt
- If security options missing: Security violation, execution halt

## Debug Signals
- Docker container startup failures
- Port binding conflicts
- Permission denied errors
- Volume mounting issues

## Out-of-Scope Behavior
- Container image building (handled by Dockerfile)
- SSL certificate management (external)
- Database performance tuning (separate systems)
