#!/bin/bash

# Empire AI Full Stack Deployment Script
# Deploys the complete production-ready stack

set -e

echo "🚀 Starting Empire AI Full Stack Deployment"
echo "=========================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if podman is running
if ! podman info > /dev/null 2>&1; then
    print_error "Podman is not running. Please start Podman first."
    exit 1
fi

# Check if podman-compose is available
if ! command -v podman-compose > /dev/null 2>&1; then
    print_error "podman-compose is not installed. Please install it first."
    exit 1
fi

# Stop any existing containers
print_status "Stopping any existing containers..."
podman-compose -f docker-compose.full.yml down -v 2>/dev/null || true

# Clean up old containers and images
print_status "Cleaning up old containers..."
podman system prune -f

# Build the frontend
# print_status "Building the frontend..."
# cd src/admin_ui_frontend
# npm run build
# cd ../..

# Pull latest images
print_status "Pulling latest Docker images..."
podman-compose -f docker-compose.full.yml pull

# Build the application image
print_status "Building Empire AI application image..."
podman-compose -f docker-compose.full.yml build empire-ai

# Start the services
print_status "Starting all services..."
podman-compose -f docker-compose.full.yml up -d

# Wait for services to be healthy
print_status "Waiting for services to be healthy..."
sleep 10

# Check service health
check_service_health() {
    local service=$1
    local url=$2
    local curl_flags=$3
    local max_attempts=90
    local attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        if curl -f -s $curl_flags $url > /dev/null 2>&1; then
            print_status "$service is healthy!"
            return 0
        fi
        
        print_warning "Attempt $attempt/$max_attempts: $service not ready yet..."
        sleep 5
        ((attempt++))
    done
    
    print_error "$service failed to become healthy after $max_attempts attempts"
    return 1
}

# Check each service
print_status "Checking service health..."

# Check PostgreSQL
if podman-compose -f docker-compose.full.yml exec -T postgres pg_isready -U empire > /dev/null 2>&1; then
    print_status "PostgreSQL is healthy!"
else
    print_error "PostgreSQL is not healthy"
fi

# Check Redis
if podman-compose -f docker-compose.full.yml exec -T redis redis-cli ping > /dev/null 2>&1; then
    print_status "Redis is healthy!"
else
    print_error "Redis is not healthy"
fi

# Check Keycloak
check_service_health "Keycloak" "http://localhost:8080/realms/master"

# Check Empire AI
check_service_health "Empire AI" "http://localhost:8000/health"

# Check Nginx
check_service_health "Nginx" "https://localhost:3000/health" "-k"

# Display service URLs
echo ""
echo "=========================================="
echo "🎉 Empire AI Full Stack Deployed Successfully!"
echo "=========================================="
echo ""
print_status "Service URLs:"
echo "  • Empire AI API:       http://localhost:8000"
echo "  • Empire AI UI:        http://localhost:8081"
echo "  • Keycloak Admin:      http://localhost:8080/admin"
echo "  • API Documentation:   http://localhost:8000/docs"
echo "  • Health Check:        http://localhost:8000/health"
echo ""
print_status "Authentication:"
echo "  • Keycloak Realm:      atlas"
echo "  • Admin Console:       http://localhost:8080/admin"
echo "  • Username:           admin"
echo "  • Password:           admin"
echo ""
print_status "Database Access:"
echo "  • PostgreSQL:          localhost:5432"
echo "  • Database:           empire"
echo "  • Username:           empire"
echo "  • Password:           password"
echo ""
print_status "Redis Access:"
echo "  • Redis:               localhost:6379"
echo ""
echo "=========================================="
echo "📊 Monitoring Commands:"
echo "  • View logs:           podman-compose -f docker-compose.full.yml logs -f"
echo "  • Check status:        podman-compose -f docker-compose.full.yml ps"
echo "  • Stop services:       podman-compose -f docker-compose.full.yml down"
echo "  • Restart services:    podman-compose -f docker-compose.full.yml restart"
echo "=========================================="

# Show running containers
echo ""
print_status "Running containers:"
podman-compose -f docker-compose.full.yml ps

echo ""
print_status "Deployment complete! 🚀"
