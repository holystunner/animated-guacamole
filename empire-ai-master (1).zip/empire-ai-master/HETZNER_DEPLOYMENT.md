# Empire AI Hetzner Server Deployment Guide

## Server Specifications

- **Server**: cax31 #118322021
- **Location**: nbg1 (Nuremberg, Germany)
- **IP Address**: 49.12.230.179
- **IPv6**: 2a01:4f8:1c19:3f40::/64
- **CPU**: 8 vCPU
- **RAM**: 16 GB
- **Storage**: 160 GB local disk
- **Traffic**: 20 TB/month

## Prerequisites Setup

### 1. Initial Server Setup

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install essential packages
sudo apt install -y curl wget git htop vim nano unzip

# Create empire-ai user
sudo useradd -m -s /bin/bash empire-ai
sudo usermod -aG sudo empire-ai

# Switch to empire-ai user
sudo su - empire-ai
```

### 2. Install Docker and Docker Compose

```bash
# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Add user to docker group
sudo usermod -aG docker empire-ai

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Verify installation
docker --version
docker-compose --version
```

### 3. Install Kubernetes (k3s - Lightweight Kubernetes)

```bash
# Install k3s (recommended for single-server setup)
curl -sfL https://get.k3s.io | sh -s - --write-kubeconfig-mode 644

# Add user to k3s group
sudo usermod -aG docker empire-ai

# Setup kubectl for empire-ai user
mkdir -p ~/.kube
sudo cp /etc/rancher/k3s/k3s.yaml ~/.kube/config
sudo chown empire-ai:empire-ai ~/.kube/config
chmod 600 ~/.kube/config

# Export KUBECONFIG
echo 'export KUBECONFIG=$HOME/.kube/config' >> ~/.bashrc
source ~/.bashrc

# Verify kubectl
kubectl get nodes
```

### 4. Install Helm

```bash
# Install Helm
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash

# Verify installation
helm version
```

### 5. Install NGINX Ingress Controller

```bash
# Install NGINX Ingress Controller
helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
helm repo update

# Install ingress controller
helm install ingress-nginx ingress-nginx/ingress-nginx \
  --namespace ingress-nginx \
  --create-namespace

# Wait for ingress controller to be ready
kubectl wait --for=condition=ready pod -l app.kubernetes.io/component=controller -n ingress-nginx --timeout=300s
```

## Network Configuration

### 1. Configure DNS

Add the following DNS records for your domain:

```
# A Records
empire-ai.yourdomain.com     -> 49.12.230.179
api.empire-ai.yourdomain.com -> 49.12.230.179
keycloak.empire-ai.yourdomain.com -> 49.12.230.179

# Or use local /etc/hosts for testing:
echo "49.12.230.179 empire-ai.local api.empire-ai.local keycloak.empire-ai.local" | sudo tee -a /etc/hosts
```

### 2. Configure Firewall

```bash
# Configure UFW firewall
sudo ufw --force reset
sudo ufw default deny incoming
sudo ufw default allow outgoing

# Allow SSH
sudo ufw allow ssh

# Allow HTTP/HTTPS
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Allow Kubernetes NodePort range (if needed)
sudo ufw allow 30000:32767/tcp

# Enable firewall
sudo ufw --force enable
```

### 3. Configure Floating IP (if using)

```bash
# Configure floating IP on Hetzner dashboard
# Then configure it on the server:
sudo ip addr add 49.12.230.179/32 dev eth0

# Make it persistent
echo "sudo ip addr add 49.12.230.179/32 dev eth0" | sudo tee -a /etc/rc.local
sudo chmod +x /etc/rc.local
```

## Storage Configuration

### 1. Setup Storage Classes

Create a custom storage class for local storage:

```yaml
# local-storage-class.yaml
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: local-ssd
provisioner: rancher.io/local-path
reclaimPolicy: Retain
volumeBindingMode: WaitForFirstConsumer
```

```bash
# Apply storage class
kubectl apply -f local-storage-class.yaml
```

### 2. Optimize Disk Usage

```bash
# Check disk usage
df -h

# Create directories for persistent storage
sudo mkdir -p /var/lib/empire-ai/{postgres,redis,backups,logs}
sudo chown -R empire-ai:empire-ai /var/lib/empire-ai

# Setup log rotation
sudo tee /etc/logrotate.d/empire-ai << EOF
/var/lib/empire-ai/logs/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 empire-ai empire-ai
}
EOF
```

## Empire AI Deployment

### 1. Clone and Prepare Repository

```bash
# Clone the repository (replace with your actual repo)
git clone <your-empire-ai-repo>
cd empire-ai

# Build Docker images
docker build -t empire-ai:latest .
docker build -t empire-ai-frontend:latest -f Dockerfile.frontend .
```

### 2. Update Configuration for Hetzner

Update the values in `helm/empire-ai/values.yaml`:

```yaml
# Hetzner-specific configuration
global:
  storageClass: "local-ssd"

empire-ai:
  replicaCount: 2  # Adjust based on your 8 vCPU server
  resources:
    requests:
      memory: "2Gi"
      cpu: "1000m"
    limits:
      memory: "4Gi"
      cpu: "2000m"

postgresql:
  primary:
    resources:
      requests:
        memory: "2Gi"
        cpu: "1000m"
      limits:
        memory: "4Gi"
        cpu: "2000m"
    persistence:
      size: "30Gi"  # Adjust based on your 160GB disk

redis:
  master:
    resources:
      requests:
        memory: "1Gi"
        cpu: "500m"
      limits:
        memory: "2Gi"
        cpu: "1000m"
    persistence:
      size: "10Gi"

ingress:
  className: "nginx"
  hosts:
    main:
      host: "empire-ai.yourdomain.com"  # Replace with your domain
    api:
      host: "api.empire-ai.yourdomain.com"
    keycloak:
      host: "keycloak.empire-ai.yourdomain.com"
```

### 3. Deploy Empire AI

```bash
# Deploy using the automated script
./scripts/deploy-k8s.sh deploy

# Or deploy with Helm
helm install empire-ai ./helm/empire-ai \
  --namespace empire-ai \
  --create-namespace \
  --values helm/empire-ai/values.yaml

# Wait for deployment to complete
kubectl wait --for=condition=available deployment --all -n empire-ai --timeout=600s
```

### 4. Verify Deployment

```bash
# Check all pods
kubectl get pods -n empire-ai

# Check services
kubectl get services -n empire-ai

# Check ingress
kubectl get ingress -n empire-ai

# Access logs
kubectl logs -f deployment/empire-ai -n empire-ai
```

## SSL/TLS Configuration

### 1. Using Let's Encrypt (Recommended)

```bash
# Install cert-manager
helm repo add jetstack https://charts.jetstack.io
helm repo update

helm install cert-manager jetstack/cert-manager \
  --namespace cert-manager \
  --create-namespace \
  --set installCRDs=true

# Create ClusterIssuer for Let's Encrypt
kubectl apply -f - <<EOF
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: letsencrypt-prod
spec:
  acme:
    server: https://acme-v02.api.letsencrypt.org/directory
    email: your-email@yourdomain.com
    privateKeySecretRef:
      name: letsencrypt-prod
    solvers:
    - http01:
        ingress:
          class: nginx
EOF
```

### 2. Update Ingress for SSL

Update `k8s/ingress.yaml` to use cert-manager:

```yaml
# Add to ingress annotations
cert-manager.io/cluster-issuer: "letsencrypt-prod"
cert-manager.io/issue-temporary-certificate: "true"
```

## Monitoring and Maintenance

### 1. Basic Monitoring Setup

```bash
# Install node exporter for system metrics
docker run -d \
  --name=node-exporter \
  --restart=unless-stopped \
  -p 9100:9100 \
  -v "/:/host:ro,rslave" \
  quay.io/prometheus/node-exporter

# Check system metrics
curl http://localhost:9100/metrics
```

### 2. Log Management

```bash
# Setup centralized logging
sudo mkdir -p /var/log/empire-ai
sudo chown empire-ai:empire-ai /var/log/empire-ai

# View application logs
kubectl logs -f deployment/empire-ai -n empire-ai > /var/log/empire-ai/backend.log &
kubectl logs -f deployment/nginx -n empire-ai > /var/log/empire-ai/frontend.log &
```

### 3. Backup Strategy

```bash
# Create backup script
cat > backup.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/var/backups/empire-ai"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# Backup PostgreSQL
kubectl exec -n empire-ai postgres-0 -- pg_dump -U empire empire > $BACKUP_DIR/postgres_$DATE.sql

# Backup Redis
kubectl exec -n empire-ai redis-master-0 -- redis-cli BGSAVE
kubectl cp empire-ai/redis-master-0:/data/dump.rdb $BACKUP_DIR/redis_$DATE.rdb

# Compress old backups
find $BACKUP_DIR -name "*.sql" -mtime +7 -exec gzip {} \;
find $BACKUP_DIR -name "*.rdb" -mtime +7 -exec gzip {} \;

echo "Backup completed: $DATE"
EOF

chmod +x backup.sh

# Add to crontab for daily backups
echo "0 2 * * * /home/empire-ai/empire-ai/backup.sh" | crontab -
```

## Performance Optimization

### 1. System Tuning

```bash
# Optimize system limits for Kubernetes
echo 'vm.max_map_count=262144' | sudo tee -a /etc/sysctl.conf
echo 'fs.file-max=65536' | sudo tee -a /etc/sysctl.conf
sudo sysctl -p

# Optimize Docker daemon
sudo mkdir -p /etc/docker
sudo tee /etc/docker/daemon.json <<EOF
{
  "storage-driver": "overlay2",
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  }
}
EOF

sudo systemctl restart docker
```

### 2. Kubernetes Resource Limits

Based on your server specs (8 vCPU, 16GB RAM):

```yaml
# Recommended resource allocation:
# Empire AI Backend: 2 replicas, 2GB RAM each
# Frontend: 2 replicas, 512MB RAM each  
# PostgreSQL: 4GB RAM
# Redis: 1GB RAM
# Keycloak: 2GB RAM
# System/Overhead: 4.5GB RAM
# Total: ~16GB RAM
```

## Security Hardening

### 1. SSH Security

```bash
# Harden SSH configuration
sudo cp /etc/ssh/sshd_config /etc/ssh/sshd_config.backup
sudo tee /etc/ssh/sshd_config <<EOF
Port 22
Protocol 2
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
ChallengeResponseAuthentication no
UsePAM yes
X11Forwarding no
PrintMotd no
AcceptEnv LANG LC_*
Subsystem sftp /usr/lib/openssh/sftp-server
EOF

sudo systemctl restart sshd
```

### 2. Fail2Ban Setup

```bash
# Install fail2ban
sudo apt install -y fail2ban

# Configure fail2ban
sudo tee /etc/fail2ban/jail.local <<EOF
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 3

[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 3
EOF

sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

## Troubleshooting

### Common Issues and Solutions

1. **Pods stuck in Pending state**
   ```bash
   # Check node resources
   kubectl describe nodes
   kubectl top nodes
   ```

2. **Storage issues**
   ```bash
   # Check storage classes
   kubectl get storageclass
   kubectl get pv
   kubectl get pvc -n empire-ai
   ```

3. **Network issues**
   ```bash
   # Check ingress controller
   kubectl get pods -n ingress-nginx
   kubectl logs -n ingress-nginx deployment/ingress-nginx-controller
   ```

4. **Performance issues**
   ```bash
   # Check resource usage
   kubectl top pods -n empire-ai
   htop
   iotop
   ```

## Access Information

After successful deployment, you can access:

- **Frontend**: https://empire-ai.yourdomain.com
- **API**: https://api.empire-ai.yourdomain.com
- **Keycloak Admin**: https://keycloak.empire-ai.yourdomain.com/admin
  - Username: admin
  - Password: admin (change immediately)

## Support and Maintenance

### Regular Tasks

1. **Weekly**: Check system updates and security patches
2. **Monthly**: Review resource usage and optimize
3. **Quarterly**: Update Kubernetes and application versions
4. **Annually**: Review and update security configurations

### Emergency Contacts

- Hetzner Support: For hardware/network issues
- Empire AI Documentation: For application issues
- Kubernetes Documentation: For cluster issues

---

**Note**: This guide is tailored for your specific Hetzner cax31 server. Adjust configurations based on your actual domain names and security requirements.
