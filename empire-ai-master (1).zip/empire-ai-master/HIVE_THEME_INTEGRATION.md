# Hive UI Theme Integration Guide

This guide documents the complete integration of the Hive UI theme across the Empire AI full-stack application, including auth screen, login screen, and main UI.

## 🎯 Overview

The Hive UI theme brings a sophisticated, organic design system inspired by bee colonies and royal aesthetics to the Empire AI platform. It features:

- **Royal Core Color Palette**: Amber/gold accents on dark backgrounds
- **Organic Components**: BioPanels with wax-drip effects
- **Animated Elements**: Worker bees, hexagons, and glowing effects
- **Consistent Typography**: Serif headers, mono data, sans body text
- **Status Indicators**: Glowing orbs for system health

## 🏗️ Architecture

### Theme System Structure

```
src/
├── theme/
│   └── HiveTheme.ts          # Core theme tokens and utilities
├── components/
│   └── ui/
│       ├── HiveButton.tsx     # Primary button component
│       ├── BioPanel.tsx       # Organic container panels
│       ├── StatusOrb.tsx      # Status indicator orbs
│       ├── WorkerBee.tsx      # Animated bee decorations
│       └── index.ts           # Component exports
├── pages/
│   ├── LoginPage.tsx          # Hive-themed login screen
│   └── DashboardPage.tsx     # Hive-themed main dashboard
└── App.tsx                    # Theme integration and routing
```

## 🎨 Design Tokens

### Color Palette

```typescript
const THEME = {
  colors: {
    bg: "#050300",              // Void Black - Background
    panel: "#0f0800",           // Wax Black - Panels
    panelHighlight: "#1f1200",  // Highlight panels
    border: "rgba(255, 170, 0, 0.3)",  // Border color
    borderBright: "#ffaa00",   // Royal Amber
    textMain: "#eecba1",        // Pale Pollen - Primary text
    textMuted: "#8a6a4b",       // Dried Husk - Secondary text
    accent: "#ffaa00",          // Royal Amber - Primary accent
    danger: "#ff3300",           // Danger red
    success: "#ffd700",          // Success gold
    warning: "#ff6600",          // Warning orange
  }
};
```

### Typography

- **Serif**: `font-serif tracking-tight` - Headers and titles
- **Sans**: `font-sans tracking-wide` - Body text
- **Mono**: `font-mono uppercase tracking-widest` - Data and labels

### Animations

- `fly-figure8`: Organic floating animation
- `spin-slow`: Slow rotation for decorative elements
- `pulse-glow`: Pulsing glow effect for status indicators

## 🔧 Components

### HiveButton

The primary button component with organic drip decoration:

```typescript
<HiveButton 
  variant="primary" 
  icon={Crown}
  loading={false}
  disabled={false}
  size="md"
>
  Enter Hive
</HiveButton>
```

**Variants:**
- `primary`: Royal amber with glow effect
- `ghost`: Subtle hover effect
- `danger`: Red for destructive actions
- `success`: Green for positive actions

### BioPanel

Organic container with wax-drip decoration:

```typescript
<BioPanel 
  title="SECURITY_CORE" 
  active={true}
  onClick={handleClick}
>
  <p>Panel content here</p>
</BioPanel>
```

**Features:**
- Gradient background when active
- SVG wax overlay decoration
- Smooth transitions
- Click handling support

### StatusOrb

Glowing status indicator:

```typescript
<StatusOrb 
  status="good" 
  label="System Nominal" 
  size="md" 
  pulse={true}
/>
```

**Status Types:**
- `good`: Amber glow
- `warn`: Orange glow
- `bad`: Red glow
- `neutral`: Dim glow

### WorkerBee

Animated decorative bee element:

```typescript
<WorkerBee 
  size="md" 
  animate={true}
  className="custom-class"
/>
```

## 📱 Pages Integration

### Login Page (`LoginPage.tsx`)

Features a complete Hive-themed authentication experience:

- **Background**: Animated bees and hexagons
- **Form**: Hive-themed input fields with icons
- **Branding**: Empire AI with royal styling
- **Security**: Password visibility toggle
- **Loading**: Themed loading states

### Dashboard Page (`DashboardPage.tsx`)

Comprehensive Hive-themed dashboard:

- **Header**: Empire AI branding with status indicators
- **Sidebar**: Navigation with Hive styling
- **Panels**: BioPanels for different sections
- **Stats**: Animated progress bars with glow effects
- **Activity**: Recent events with status indicators

## 🔄 Theme Integration

### Global Styles Injection

The theme automatically injects global styles:

```typescript
import { injectGlobalStyles } from './theme/HiveTheme';

useEffect(() => {
  injectGlobalStyles();
}, []);
```

### CSS Variables

Theme colors are available as CSS variables:

```css
.my-component {
  background: var(--panel-color);
  color: var(--text-main);
  border: 1px solid var(--border-color);
  box-shadow: var(--glow-shadow);
}
```

## 🚀 Usage Examples

### Creating a New Component

```typescript
import { HiveButton, BioPanel, StatusOrb, THEME } from '../components/ui';

const MyComponent = () => {
  return (
    <BioPanel title="MY_COMPONENT" active={true}>
      <div style={{ color: THEME.colors.textMain }}>
        <StatusOrb status="good" label="Active" />
        <HiveButton variant="primary" icon={SomeIcon}>
          Action
        </HiveButton>
      </div>
    </BioPanel>
  );
};
```

### Styling with Theme

```typescript
const StyledComponent = styled.div`
  background: ${THEME.colors.panel};
  border: 1px solid ${THEME.colors.border};
  color: ${THEME.colors.textMain};
  padding: 1rem;
  border-radius: 0.75rem;
  
  &:hover {
    box-shadow: ${THEME.shadows.glow};
    border-color: ${THEME.colors.borderBright};
  }
`;
```

## 🎭 Customization

### Adding New Colors

```typescript
// In HiveTheme.ts
const THEME = {
  colors: {
    // ... existing colors
    newColor: "#custom-hex",
  }
};
```

### Creating New Animations

```typescript
// In HiveTheme.ts global styles
@keyframes custom-animation {
  0% { transform: scale(1); }
  50% { transform: scale(1.1); }
  100% { transform: scale(1); }
}
```

## 🔍 Troubleshooting

### Common Issues

1. **Theme not applying**: Ensure `injectGlobalStyles()` is called in App.tsx
2. **Component styles not working**: Check Tailwind class names and theme imports
3. **Animations not playing**: Verify CSS variables are properly injected
4. **Color inconsistencies**: Use theme constants instead of hardcoded values

### Debug Mode

Enable theme debugging:

```typescript
// In development
console.log('Theme colors:', THEME.colors);
console.log('CSS variables:', getComputedStyle(document.documentElement));
```

## 📋 Best Practices

### Do's

- ✅ Use theme constants instead of hardcoded colors
- ✅ Import components from the centralized index
- ✅ Follow the established naming conventions
- ✅ Use semantic status indicators
- ✅ Maintain consistent spacing and typography

### Don'ts

- ❌ Hardcode color values
- ❌ Override theme styles with !important
- ❌ Mix different design systems
- ❌ Use inline styles for theme properties
- ❌ Break the established component hierarchy

## 🔄 Migration Guide

### From Existing UI

1. **Replace buttons**: Use `HiveButton` instead of standard buttons
2. **Update panels**: Use `BioPanel` for containers
3. **Add status indicators**: Use `StatusOrb` for system status
4. **Apply theme colors**: Use THEME constants
5. **Update typography**: Use theme font classes

### Component Mapping

| Old Component | New Hive Component |
|---------------|-------------------|
| Button | HiveButton |
| Card/Panel | BioPanel |
| Status Badge | StatusOrb |
| Loading Spinner | WorkerBee (animated) |
| Alert | BioPanel with StatusOrb |

## 🎯 Performance Considerations

### Optimization Tips

1. **Lazy load components**: Use React.lazy for large components
2. **CSS optimization**: Theme styles are injected once
3. **Animation performance**: Use CSS transforms instead of layout changes
4. **Bundle size**: Import only needed components

### Monitoring

Track theme performance:

```typescript
// Performance monitoring
const observer = new PerformanceObserver((list) => {
  list.getEntries().forEach((entry) => {
    if (entry.name.includes('theme')) {
      console.log('Theme performance:', entry);
    }
  });
});

observer.observe({ entryTypes: ['measure', 'navigation'] });
```

## 🔮 Future Enhancements

### Planned Features

- **Dark/Light mode toggle**: Adaptive theme switching
- **Custom themes**: User-selectable color schemes
- **Accessibility**: Enhanced contrast and screen reader support
- **Animations library**: Reusable animation presets
- **Component library**: Storybook documentation

### Extension Points

The theme system is designed to be extensible:

```typescript
// Custom theme extension
const CustomTheme = {
  ...THEME,
  colors: {
    ...THEME.colors,
    customBrand: "#custom-color",
  },
  components: {
    ...THEME.components,
    customComponent: CustomComponent,
  }
};
```

---

## 🎉 Summary

The Hive UI theme provides a cohesive, sophisticated design system for Empire AI with:

- **Complete component library** with Hive styling
- **Consistent design tokens** across all interfaces
- **Smooth animations** and micro-interactions
- **Easy integration** with existing React components
- **Extensible architecture** for future enhancements

The theme creates a unique, memorable user experience that reinforces the Empire AI brand while maintaining excellent usability and performance.
