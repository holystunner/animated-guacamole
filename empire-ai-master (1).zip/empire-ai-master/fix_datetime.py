import os
import re

files_to_fix = [
    "src/agents/base_agent.py",
    "src/agents/verifier_agent.py",
    "src/agents/compliance_agent.py",
    "src/agents/writer_agent.py",
    "src/agents/scout_agent.py",
    "src/agents/growth_agent.py",
    "src/core/audit.py",
    "src/governor/main_governor.py"
]

for file_path in files_to_fix:
    if not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        continue
        
    with open(file_path, "r") as f:
        content = f.read()
        
    # Replace utcnow
    new_content = content.replace("datetime.utcnow()", "datetime.now(UTC)")
    
    # Ensure UTC is imported
    if "datetime.now(UTC)" in new_content:
        # Check if UTC is already in imports
        import_match = re.search(r"from datetime import .*", new_content)
        if import_match:
            import_line = import_match.group(0)
            if "UTC" not in import_line:
                new_import = import_line.replace("import ", "import UTC, ")
                new_content = new_content.replace(import_line, new_import)
        else:
            # Maybe it's 'import datetime'
            if "import datetime" in new_content and "from datetime import" not in new_content:
                new_content = new_content.replace("import datetime", "from datetime import datetime, UTC")
            elif "from datetime import datetime" in new_content:
                new_content = new_content.replace("from datetime import datetime", "from datetime import datetime, UTC")

    if new_content != content:
        with open(file_path, "w") as f:
            f.write(new_content)
        print(f"Fixed {file_path}")
    else:
        print(f"No changes needed for {file_path}")
