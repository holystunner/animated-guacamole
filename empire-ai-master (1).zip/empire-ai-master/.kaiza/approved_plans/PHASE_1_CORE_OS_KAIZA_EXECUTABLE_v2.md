---
status: APPROVED
plan_id: phase-1-core-os-2025-01-12-v2
title: Phase 1 - Core OS Completion (Dependency-Ordered)
created_by: AMP
created_date: 2025-01-12
---

# PHASE 1: CORE OS COMPLETION (KAIZA-EXECUTABLE - DEPENDENCY ORDERED)

**Objective:** Governor enforces policies on ALL job execution. System cannot run without policy clearance.

**Key Principle:** Files created in strict dependency order. No forward references. Each file complete on first write.

**Prerequisite:** PHASE_0_REALITY_LOCK_KAIZA_EXECUTABLE_v2 must be complete

**Duration:** 5-6 weeks

**Success Criteria:**
- ✅ All jobs routed through Governor
- ✅ No job executes without policy clearance
- ✅ Budget limits enforced (hard)
- ✅ Approval queue works
- ✅ Kill switch works
- ✅ All tests pass 100%

---

## IMPLEMENTATION ORDER (Strict Sequence)

### STEP 1: Create Registry (Depends on: universal_ledger from Phase 0)

**File:** `src/registry.py` (600 lines)

**Purpose:** Single source of truth for system state (assets, agents, config, health).

**Complete Implementation:**
- Assets table with lifecycle states (draft → active → scaling → paused → retired)
- Agents table with permission definitions
- Configuration table (versioned, immutable snapshots)
- Health status table
- Portfolio state table
- All query methods fully implemented (no stubs)
- Ledger integration on all state changes

**Database Schema:**
```sql
CREATE TABLE assets (
    asset_id TEXT PRIMARY KEY,
    asset_type TEXT NOT NULL,
    owner TEXT,
    state TEXT NOT NULL CHECK (state IN ('draft', 'active', 'scaling', 'paused', 'retired')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deployed_at TIMESTAMP,
    paused_at TIMESTAMP,
    retired_at TIMESTAMP,
    total_revenue REAL DEFAULT 0,
    total_cost REAL DEFAULT 0,
    monthly_revenue REAL DEFAULT 0,
    monthly_cost REAL DEFAULT 0,
    roi REAL DEFAULT 0,
    metadata TEXT NOT NULL
);

CREATE TABLE agents (
    agent_id TEXT PRIMARY KEY,
    agent_type TEXT NOT NULL,
    permissions TEXT NOT NULL,
    budget_daily REAL NOT NULL,
    budget_monthly REAL NOT NULL,
    enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE configuration (
    config_key TEXT NOT NULL,
    version INTEGER NOT NULL,
    value TEXT NOT NULL,
    set_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (config_key, version)
);

CREATE TABLE health_status (
    asset_id TEXT PRIMARY KEY,
    last_check TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    uptime_percent REAL DEFAULT 100.0,
    error_rate REAL DEFAULT 0,
    response_time_ms REAL DEFAULT 0,
    FOREIGN KEY (asset_id) REFERENCES assets(asset_id)
);

CREATE TABLE portfolio_state (
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total_revenue REAL DEFAULT 0,
    total_cost REAL DEFAULT 0,
    total_profit REAL DEFAULT 0,
    active_assets INTEGER DEFAULT 0,
    scaling_assets INTEGER DEFAULT 0
);

CREATE INDEX idx_asset_state ON assets(state);
CREATE INDEX idx_agent_enabled ON agents(enabled);
CREATE INDEX idx_config_key ON configuration(config_key);
```

**Exports:**
```python
class Registry:
    def __init__(self, repo_path: str)
    def register_asset(self, asset_id: str, asset_type: str, metadata: Dict) -> str
    def get_asset(self, asset_id: str) -> Dict
    def get_all_assets(self, state: str = None) -> List[Dict]
    def update_asset_state(self, asset_id: str, new_state: str) -> bool
    def register_agent(self, agent_id: str, agent_type: str, permissions: Dict) -> str
    def get_agent(self, agent_id: str) -> Dict
    def set_config(self, key: str, value: Any, version: int) -> bool
    def get_config(self, key: str) -> Any
    def get_config_history(self, key: str) -> List[Dict]
    def restore_config(self, key: str, version: int) -> bool
    def get_portfolio_state(self) -> Dict
```

**Dependencies:** universal_ledger (Phase 0), sqlite3 (stdlib)

**Error Handling:**
- Invalid state transition → ValueError with message
- Duplicate asset_id → IntegrityError (propagate, don't catch)
- Ledger write failure → Logged but non-blocking
- All state changes logged to ledger BEFORE commit

**Success Criteria:**
- Create asset, verify in registry
- Transition asset: draft → active → scaling → paused → retired (all valid)
- Try invalid transition (retired → active) → ValueError
- Create agent with permissions, retrieve
- Set config v1, v2, restore v1 → v1 restored
- Test: `python3 -m pytest tests/test_registry.py -v` → 100% pass

---

### STEP 2: Create Kill Switch (Depends on: registry + universal_ledger)

**File:** `src/kill_switch.py` (200 lines)

**Purpose:** Emergency stop mechanism. Pauses all running jobs instantly.

**Complete Implementation:**
- Maintain kill_switch_state table
- Implement activate(), deactivate(), is_active(), get_state()
- All state changes logged to ledger
- Thread-safe (atomic operations)

**Database Schema:**
```sql
CREATE TABLE kill_switch_state (
    id INTEGER PRIMARY KEY,
    global_active BOOLEAN DEFAULT FALSE,
    triggered_at TIMESTAMP,
    triggered_by TEXT,
    reason TEXT,
    released_at TIMESTAMP,
    released_by TEXT
);
```

**Exports:**
```python
class KillSwitch:
    def __init__(self, repo_path: str)
    def activate(self, triggered_by: str, reason: str) -> bool
    def deactivate(self, released_by: str) -> bool
    def is_active(self) -> bool
    def get_state(self) -> Dict
```

**Dependencies:** universal_ledger, sqlite3

**Error Handling:**
- If already active: return False (idempotent, safe)
- Ledger write failure → Logged but non-blocking

**Success Criteria:**
- Activate kill switch → is_active() returns True
- Deactivate kill switch → is_active() returns False
- Get state → returns all fields
- Test: `python3 -m pytest tests/test_kill_switch.py -v` → 100% pass

---

### STEP 3: Create Job Executor (Depends on: governor + registry + kill_switch + universal_ledger)

**File:** `src/job_executor.py` (900 lines)

**Purpose:** Central job execution engine. All jobs routed through Governor.

**Complete Implementation:**
- JobRequest, JobExecution, JobStatus enum, JobType enum
- `submit_job()`: Routes through Governor immediately
- `execute_approved_job()`: Runs after approval
- `approve_job()`: Owner approval path
- `reject_job()`: Owner rejection path
- `get_job_status()`: Query job state
- `get_pending_approvals()`: List approval queue
- Full ledger integration on all events
- No stubs in execute methods (raise NotImplementedError with message)

**Database Schema:**
```sql
CREATE TABLE jobs (
    job_id TEXT PRIMARY KEY,
    job_type TEXT NOT NULL,
    actor TEXT NOT NULL,
    resource_id TEXT NOT NULL,
    input_data TEXT NOT NULL,
    required_budget REAL DEFAULT 0,
    status TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    policy_result TEXT,
    policy_reason TEXT,
    approval_request_id TEXT,
    approved_by TEXT,
    approved_at TIMESTAMP,
    result TEXT,
    error TEXT
);

CREATE INDEX idx_job_status ON jobs(status);
CREATE INDEX idx_job_actor ON jobs(actor);
CREATE INDEX idx_job_resource ON jobs(resource_id);
```

**Key Method: submit_job()**
```python
def submit_job(self, request: JobRequest) -> Dict[str, Any]:
    # 1. Validate request schema
    # 2. Create execution record (status=PENDING)
    # 3. Log submission to ledger
    # 4. Call Governor.evaluate_action() IMMEDIATELY (no bypass possible)
    # 5. Route based on result:
    #    - ALLOW: Call execute_approved_job()
    #    - DENY: Log denial, return error
    #    - OVERRIDE_REQUIRED: Queue for approval, wait
    # 6. Return status dict
```

**Key Method: execute_approved_job()**
```python
def execute_approved_job(self, job_id: str) -> Dict[str, Any]:
    # 1. Get job from database
    # 2. Check status is APPROVED or AWAITING_APPROVAL
    # 3. Mark status = EXECUTING
    # 4. Execute based on job_type:
    #    - For unimplemented types: raise NotImplementedError
    # 5. Log every step to ledger
    # 6. Mark status = SUCCEEDED
    # 7. Return result
```

**Exports:**
```python
class JobExecutor:
    def __init__(self, repo_path: str)
    def submit_job(self, request: JobRequest) -> Dict[str, Any]
    def execute_approved_job(self, job_id: str) -> Dict[str, Any]
    def approve_job(self, job_id: str, approved_by: str, reason: str = None) -> Dict[str, Any]
    def reject_job(self, job_id: str, rejected_by: str, reason: str = None) -> Dict[str, Any]
    def get_job_status(self, job_id: str) -> Dict[str, Any]
    def get_pending_approvals(self) -> List[Dict]

class JobRequest:
    job_id: str
    job_type: JobType
    actor: str
    resource_id: str
    input_data: Dict[str, Any]
    required_budget: float = 0.0
    
class JobExecution:
    job_id: str
    status: JobStatus
    created_at: datetime
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    # ... other fields

class JobStatus(Enum):
    PENDING = "pending"
    AWAITING_APPROVAL = "awaiting_approval"
    APPROVED = "approved"
    EXECUTING = "executing"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"

class JobType(Enum):
    SCOUT = "scout"
    BUILD = "build"
    PUBLISH = "publish"
    MEASURE = "measure"
    SCALE = "scale"
    KILL = "kill"
```

**Dependencies:** governor, registry, kill_switch, universal_ledger

**Error Handling:**
- Governor unavailable → RuntimeError (fail-fast)
- Policy denial → Return error dict (not exception)
- Ledger write failure → Log warning, continue
- Job execution failure → Catch exception, mark failed, log error
- Unimplemented job type → Raise NotImplementedError("Scout execution in Phase 2")

**Success Criteria:**
- Submit 50 jobs → All routed through Governor
- 50 policy evaluations logged → Verify in ledger
- Try to bypass Governor → Fails (not possible)
- Test: `python3 -m pytest tests/test_job_executor.py -v` → 100% pass

---

### STEP 4: Update Governor.freeze() and .unfreeze() (Depends on: job_executor + kill_switch)

**File:** `src/governor.py` (Modified - ADD freeze/unfreeze)

**Changes:**
1. Import: `from kill_switch import KillSwitch`
2. In `__init__()`: `self.kill_switch = KillSwitch(str(self.repo_path))`
3. Implement `freeze()`: Call kill_switch.activate()
4. Implement `unfreeze()`: Call kill_switch.deactivate()
5. In job execution path: Check kill_switch.is_active() BEFORE executing

**Key Logic:**
```python
def freeze(self, triggered_by: str, reason: str) -> bool:
    # Activate kill switch
    result = self.kill_switch.activate(triggered_by, reason)
    if result:
        # Pause all running jobs (update status to PAUSED)
        self._pause_all_running_jobs()
    return result

def unfreeze(self, released_by: str) -> bool:
    # Deactivate kill switch
    result = self.kill_switch.deactivate(released_by)
    if result:
        # Resume all paused jobs (update status back to original)
        self._resume_all_paused_jobs()
    return result
```

**Success Criteria:**
- Activate freeze → All running jobs paused
- Try to submit job while frozen → Rejected
- Deactivate freeze → Jobs resume
- Test: `python3 -m pytest tests/test_governor.py -v` → 100% pass

---

### STEP 5: Create Integration Tests (Depends on: All of above)

**File:** `tests/test_job_flow.py` (300 lines)

**Purpose:** End-to-end workflow verification.

**Tests:**
1. `test_full_job_flow()`: Submit → Allow → Execute → Complete
2. `test_denied_job()`: Submit → Denied → Not executed
3. `test_approval_flow()`: Submit → Override Required → Approve → Execute
4. `test_freeze_unfreeze()`: Freeze → Reject submissions → Unfreeze → Accept
5. `test_ledger_integrity()`: All operations logged with unbroken hash chain

**Dependencies:** All Phase 1 modules

**Success Criteria:**
- All 5 tests pass
- No mocks in tests
- Real database operations

---

## SUCCESS VERIFICATION (Binary Checkpoints)

### Checkpoint 1: Registry Operational
```bash
python3 << 'EOF'
from src.registry import Registry
reg = Registry(".")
asset_id = reg.register_asset("test-asset", "content", {"test": "data"})
asset = reg.get_asset(asset_id)
print("Registry OK" if asset else "Registry FAILED")
EOF
```

Expected: ✅ Asset registered and retrieved

### Checkpoint 2: Kill Switch Working
```bash
python3 << 'EOF'
from src.kill_switch import KillSwitch
ks = KillSwitch(".")
ks.activate("test_user", "test")
print("Active" if ks.is_active() else "FAILED")
ks.deactivate("test_user")
print("Inactive" if not ks.is_active() else "FAILED")
EOF
```

Expected: ✅ Activate/deactivate works

### Checkpoint 3: Job Executor Routing
```bash
python3 << 'EOF'
from src.job_executor import JobExecutor, JobRequest, JobType
je = JobExecutor(".")
req = JobRequest(
    job_id="test-1",
    job_type=JobType.SCOUT,
    actor="test",
    resource_id="test-asset",
    input_data={}
)
result = je.submit_job(req)
print("Routed to Governor" if result else "FAILED")
EOF
```

Expected: ✅ Job submitted and routed

### Checkpoint 4: Governor Freeze
```bash
python3 << 'EOF'
from src.governor import Governor
gov = Governor(".")
gov.freeze("test", "testing")
print("Frozen OK" if gov.kill_switch.is_active() else "FAILED")
gov.unfreeze("test")
print("Unfrozen OK" if not gov.kill_switch.is_active() else "FAILED")
EOF
```

Expected: ✅ Freeze/unfreeze works

### Checkpoint 5: All Tests Pass
```bash
python3 -m pytest tests/test_registry.py \
                   tests/test_kill_switch.py \
                   tests/test_job_executor.py \
                   tests/test_job_flow.py \
                   -v
```

Expected: ✅ 100% pass rate

---

## WHAT NOT TO DO

❌ **Don't create forward references:**
- Don't call job_executor before creating it
- Don't reference methods in kill_switch that don't exist yet

❌ **Don't use stubs:**
- No placeholder job execution methods
- No `return None` for actual returns

❌ **Don't skip dependencies:**
- Don't skip registry just to get job_executor faster
- Order matters because of imports

---

## APPROVED BY

**Name:** AMP  
**Authority:** Governance and recovery planning  
**Date:** 2025-01-12  

---

**STATUS: READY FOR EXECUTION BY WINDSURF**

**Strict Order:** STEP 1 → STEP 2 → STEP 3 → STEP 4 → STEP 5

Each step produces complete, functional code. No stubs. No placeholders. No nulls.
