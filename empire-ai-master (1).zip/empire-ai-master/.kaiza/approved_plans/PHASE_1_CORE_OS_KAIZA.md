# PHASE 1: CORE OS COMPLETION (KAIZA-EXECUTABLE)

**Status:** APPROVED FOR EXECUTION AFTER PHASE 0  
**Objective:** Complete the operating system kernel. Governor enforces policies. Jobs execute through mandatory policy gating. System cannot run without approval.  
**Duration:** 5-6 weeks  
**Authority:** EMPIRE_AI_CANONICAL_SPECIFICATION.md v1.0 (Section 2, Layer 1 & 2)  

---

## BINDING CONSTRAINTS

1. **All job execution** goes through Governor.evaluate_action()
2. **No policy bypass** without logged, time-limited override
3. **Budget limits** are hard limits (enforced, not suggested)
4. **All decisions** logged to universal ledger
5. **Freeze/kill switch** works instantly, no delay
6. **No stubs**, no mocks, no placeholder returns
7. **Written via KAIZA write_file** (auditability)
8. **Binary success criteria** (automated tests verify)

---

## DELIVERABLE 1: JOB EXECUTION PIPELINE

### Objective
Build unified job execution engine that routes all actions through Governor for policy validation.

### New File: `src/job_executor.py` (800 lines)

#### Architecture
```
Job Request
    ↓
JobRequest.validate()  ← Check schema
    ↓
Governor.evaluate_action()  ← ALL actions gated here
    ↓
    ├→ [ALLOW] → Runtime.execute_job()
    │
    ├→ [DENY] → log, return error, stop
    │
    └→ [OVERRIDE_REQUIRED] → queue for approval
        ↓
        Owner approves/rejects via Admin UI
        ↓
        If approved → Runtime.execute_job()
        If rejected → log, return error, stop
```

#### Core Data Classes

```python
from dataclasses import dataclass
from enum import Enum
from typing import Dict, Any, Optional
from datetime import datetime

class JobStatus(Enum):
    PENDING = "pending"
    VALIDATION_ERROR = "validation_error"
    AWAITING_APPROVAL = "awaiting_approval"
    APPROVED = "approved"
    EXECUTING = "executing"
    FAILED = "failed"
    SUCCEEDED = "succeeded"
    CANCELLED = "cancelled"

class JobType(Enum):
    SCOUT = "scout"
    BUILD = "build"
    PUBLISH = "publish"
    MEASURE = "measure"
    SCALE = "scale"
    KILL = "kill"
    APPROVE = "approve"
    DEPLOY = "deploy"
    CONFIGURE = "configure"

@dataclass
class JobRequest:
    job_id: str
    job_type: JobType
    actor: str  # Which agent/user requested this
    resource_id: str  # Asset ID, agent ID, or tool name
    input_data: Dict[str, Any]
    required_budget: float = 0.0
    estimated_risk_level: str = "low"
    timestamp: datetime = None
    
    def validate(self) -> Tuple[bool, Optional[str]]:
        """Validate job request schema"""
        # job_id must be non-empty UUID
        # job_type must be valid enum
        # actor must be non-empty string
        # resource_id must be non-empty string
        # input_data must be dict or empty dict
        # required_budget must be >= 0
        # Return (valid, error_message)

@dataclass
class JobExecution:
    job_id: str
    status: JobStatus
    created_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    policy_result: Optional[str] = None  # allow, deny, override_required
    policy_reason: Optional[str] = None
    execution_steps: List[Dict[str, Any]] = None
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    approval_request_id: Optional[str] = None
    approved_by: Optional[str] = None
    approved_at: Optional[datetime] = None
```

#### Core Class: JobExecutor

```python
class JobExecutor:
    def __init__(self, repo_path: str):
        self.repo_path = Path(repo_path)
        self.governor = Governor(repo_path)
        self.ledger = UniversalLedger(repo_path)
        self.job_db = sqlite3.connect(str(repo_path / "data" / "jobs.db"))
        self._init_job_db()
    
    def _init_job_db(self):
        """Initialize job tracking database"""
        cursor = self.job_db.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS jobs (
                job_id TEXT PRIMARY KEY,
                job_type TEXT NOT NULL,
                actor TEXT NOT NULL,
                resource_id TEXT NOT NULL,
                input_data TEXT NOT NULL,
                required_budget REAL,
                status TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                started_at TIMESTAMP,
                completed_at TIMESTAMP,
                policy_result TEXT,
                policy_reason TEXT,
                approval_request_id TEXT,
                approved_by TEXT,
                approved_at TIMESTAMP,
                result TEXT,
                error TEXT
            )
        ''')
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_job_status ON jobs(status)
        ''')
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_job_actor ON jobs(actor)
        ''')
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_job_resource ON jobs(resource_id)
        ''')
        self.job_db.commit()
    
    def submit_job(self, request: JobRequest) -> Dict[str, Any]:
        """Submit job for execution (entry point)"""
        # 1. Validate request schema
        valid, error = request.validate()
        if not valid:
            self.ledger.log_action(
                actor=request.actor,
                action_type="job_validation_failed",
                resource_id=request.job_id,
                input_data=asdict(request),
                output_data={"error": error},
                result="fail",
                reason=error
            )
            return {"success": False, "error": error, "job_id": request.job_id}
        
        # 2. Create execution record
        execution = JobExecution(
            job_id=request.job_id,
            status=JobStatus.PENDING,
            created_at=datetime.utcnow()
        )
        self._save_execution(execution)
        
        # 3. Log submission
        self.ledger.log_action(
            actor=request.actor,
            action_type="job_submitted",
            resource_id=request.job_id,
            input_data=asdict(request),
            output_data={},
            result="pending"
        )
        
        # 4. Evaluate against policies
        policy_result = self.governor.evaluate_action(
            action_type=request.job_type.value,
            action_data=request.input_data,
            user=request.actor
        )
        
        # 5. Route based on policy result
        if policy_result["overall_result"] == "deny":
            execution.status = JobStatus.FAILED
            execution.policy_result = "deny"
            execution.policy_reason = policy_result.get("reason_code")
            execution.error = f"Policy denied: {policy_result.get('reason_code')}"
            self._save_execution(execution)
            
            self.ledger.log_action(
                actor="governor",
                action_type="job_denied",
                resource_id=request.job_id,
                input_data=asdict(request),
                output_data=policy_result,
                result="denied",
                policy_result="deny",
                reason=policy_result.get("reason_code")
            )
            
            return {"success": False, "error": execution.error, "job_id": request.job_id}
        
        elif policy_result["overall_result"] == "override_required":
            # Queue for approval
            approval_request_id = self._create_approval_request(request, policy_result)
            execution.status = JobStatus.AWAITING_APPROVAL
            execution.policy_result = "override_required"
            execution.policy_reason = policy_result.get("reason_code")
            execution.approval_request_id = approval_request_id
            self._save_execution(execution)
            
            self.ledger.log_action(
                actor="governor",
                action_type="job_awaiting_approval",
                resource_id=request.job_id,
                input_data=asdict(request),
                output_data={"approval_request_id": approval_request_id},
                result="pending",
                policy_result="override_required",
                reason=f"Awaiting owner approval (request_id={approval_request_id})"
            )
            
            return {
                "success": False,
                "status": "awaiting_approval",
                "job_id": request.job_id,
                "approval_request_id": approval_request_id,
                "reason": policy_result.get("reason_code")
            }
        
        else:  # allow
            # Execute immediately
            execution.status = JobStatus.APPROVED
            execution.policy_result = "allow"
            self._save_execution(execution)
            
            self.ledger.log_action(
                actor="governor",
                action_type="job_approved",
                resource_id=request.job_id,
                input_data=asdict(request),
                output_data={},
                result="approved",
                policy_result="allow"
            )
            
            return self.execute_approved_job(request.job_id)
    
    def execute_approved_job(self, job_id: str) -> Dict[str, Any]:
        """Execute a policy-approved job with checkpoints and logging"""
        execution = self._get_execution(job_id)
        if not execution:
            return {"success": False, "error": f"Job {job_id} not found"}
        
        if execution.status not in [JobStatus.APPROVED, JobStatus.AWAITING_APPROVAL]:
            return {"success": False, "error": f"Job {job_id} is {execution.status.value}"}
        
        try:
            execution.status = JobStatus.EXECUTING
            execution.started_at = datetime.utcnow()
            execution.execution_steps = []
            self._save_execution(execution)
            
            # Get original request
            request_data = self._get_job_request_data(job_id)
            job_request = JobRequest(**request_data)
            
            # Execute based on job type
            if job_request.job_type == JobType.SCOUT:
                result = self._execute_scout(job_request)
            elif job_request.job_type == JobType.BUILD:
                result = self._execute_build(job_request)
            elif job_request.job_type == JobType.PUBLISH:
                result = self._execute_publish(job_request)
            elif job_request.job_type == JobType.MEASURE:
                result = self._execute_measure(job_request)
            elif job_request.job_type == JobType.SCALE:
                result = self._execute_scale(job_request)
            elif job_request.job_type == JobType.KILL:
                result = self._execute_kill(job_request)
            else:
                raise ValueError(f"Unknown job type: {job_request.job_type}")
            
            # Mark as succeeded
            execution.status = JobStatus.SUCCEEDED
            execution.completed_at = datetime.utcnow()
            execution.result = result
            self._save_execution(execution)
            
            # Log success
            self.ledger.log_action(
                actor=job_request.actor,
                action_type=f"{job_request.job_type.value}_job_completed",
                resource_id=job_id,
                input_data=asdict(job_request),
                output_data=result,
                result="success",
                reason="Job executed successfully"
            )
            
            return {"success": True, "job_id": job_id, "result": result}
        
        except Exception as e:
            execution.status = JobStatus.FAILED
            execution.completed_at = datetime.utcnow()
            execution.error = str(e)
            self._save_execution(execution)
            
            # Log failure
            self.ledger.log_action(
                actor="system",
                action_type="job_execution_failed",
                resource_id=job_id,
                input_data={},
                output_data={"error": str(e)},
                result="fail",
                reason=str(e)
            )
            
            return {"success": False, "error": str(e), "job_id": job_id}
    
    def approve_job(self, job_id: str, approved_by: str, reason: str = None) -> Dict[str, Any]:
        """Owner approves a pending job"""
        execution = self._get_execution(job_id)
        if not execution:
            return {"success": False, "error": f"Job {job_id} not found"}
        
        if execution.status != JobStatus.AWAITING_APPROVAL:
            return {"success": False, "error": f"Job {job_id} is not awaiting approval"}
        
        # Log approval
        self.ledger.log_action(
            actor=approved_by,
            action_type="job_approved_by_owner",
            resource_id=job_id,
            input_data={"approval_reason": reason},
            output_data={},
            result="approved",
            reason=reason or "Owner approval granted"
        )
        
        execution.approved_by = approved_by
        execution.approved_at = datetime.utcnow()
        self._save_execution(execution)
        
        # Execute now
        return self.execute_approved_job(job_id)
    
    def reject_job(self, job_id: str, rejected_by: str, reason: str = None) -> Dict[str, Any]:
        """Owner rejects a pending job"""
        execution = self._get_execution(job_id)
        if not execution:
            return {"success": False, "error": f"Job {job_id} not found"}
        
        if execution.status != JobStatus.AWAITING_APPROVAL:
            return {"success": False, "error": f"Job {job_id} is not awaiting approval"}
        
        # Log rejection
        self.ledger.log_action(
            actor=rejected_by,
            action_type="job_rejected_by_owner",
            resource_id=job_id,
            input_data={"rejection_reason": reason},
            output_data={},
            result="denied",
            reason=reason or "Owner rejected job"
        )
        
        execution.status = JobStatus.CANCELLED
        execution.error = reason or "Job rejected by owner"
        execution.completed_at = datetime.utcnow()
        self._save_execution(execution)
        
        return {"success": True, "job_id": job_id, "status": "rejected"}
    
    def get_job_status(self, job_id: str) -> Dict[str, Any]:
        """Query job status"""
        execution = self._get_execution(job_id)
        if not execution:
            return {"success": False, "error": f"Job {job_id} not found"}
        
        return {
            "success": True,
            "job_id": job_id,
            "status": execution.status.value,
            "created_at": execution.created_at.isoformat(),
            "started_at": execution.started_at.isoformat() if execution.started_at else None,
            "completed_at": execution.completed_at.isoformat() if execution.completed_at else None,
            "policy_result": execution.policy_result,
            "policy_reason": execution.policy_reason,
            "approval_request_id": execution.approval_request_id,
            "approved_by": execution.approved_by,
            "result": execution.result,
            "error": execution.error
        }
    
    def get_pending_approvals(self) -> List[Dict[str, Any]]:
        """Get all jobs awaiting owner approval"""
        cursor = self.job_db.cursor()
        cursor.execute('''
            SELECT job_id, job_type, actor, resource_id, created_at, policy_reason
            FROM jobs
            WHERE status = 'awaiting_approval'
            ORDER BY created_at DESC
        ''')
        
        jobs = []
        for row in cursor.fetchall():
            jobs.append({
                "job_id": row[0],
                "job_type": row[1],
                "actor": row[2],
                "resource_id": row[3],
                "created_at": row[4],
                "policy_reason": row[5]
            })
        
        return jobs
    
    # Helper methods (internal)
    def _create_approval_request(self, request: JobRequest, policy_result: Dict) -> str:
        """Create approval request and return request_id"""
        # Delegate to ApprovalWorkflow (Phase 12)
        # Return approval_request_id
    
    def _get_execution(self, job_id: str) -> Optional[JobExecution]:
        """Get execution record from database"""
        cursor = self.job_db.cursor()
        cursor.execute('SELECT * FROM jobs WHERE job_id = ?', (job_id,))
        row = cursor.fetchone()
        if not row:
            return None
        # Reconstruct JobExecution from row
    
    def _save_execution(self, execution: JobExecution):
        """Save execution record to database"""
        # INSERT OR UPDATE jobs table
    
    def _get_job_request_data(self, job_id: str) -> Dict:
        """Retrieve original job request data"""
        cursor = self.job_db.cursor()
        cursor.execute('SELECT input_data FROM jobs WHERE job_id = ?', (job_id,))
        row = cursor.fetchone()
        if row:
            return json.loads(row[0])
        return {}
    
    def _execute_scout(self, request: JobRequest) -> Dict[str, Any]:
        """Execute scout job (find opportunities)"""
        # Implemented in Phase 2 (Agent Economy)
        pass
    
    def _execute_build(self, request: JobRequest) -> Dict[str, Any]:
        """Execute build job (generate code/content)"""
        # Implemented in Phase 3 (Asset Factory)
        pass
    
    def _execute_publish(self, request: JobRequest) -> Dict[str, Any]:
        """Execute publish job (deploy asset)"""
        # Implemented in Phase 3 (Asset Factory)
        pass
    
    def _execute_measure(self, request: JobRequest) -> Dict[str, Any]:
        """Execute measure job (get metrics)"""
        # Implemented in Phase 4 (Metrics)
        pass
    
    def _execute_scale(self, request: JobRequest) -> Dict[str, Any]:
        """Execute scale job (expand asset)"""
        # Implemented in Phase 4 (Scaling)
        pass
    
    def _execute_kill(self, request: JobRequest) -> Dict[str, Any]:
        """Execute kill job (retire asset)"""
        # Implemented in Phase 4 (Asset Lifecycle)
        pass
```

---

## DELIVERABLE 2: GOVERNOR INTEGRATION

### Objective
Wire Governor into the job execution pipeline so no job can run without policy clearance.

### Changes to `src/governor.py`

**Add to Governor.__init__():**
```python
from universal_ledger import UniversalLedger

self.ledger = UniversalLedger(str(self.repo_path / "data" / "universal_ledger.db"))
self.job_executor = None  # Will be set by JobExecutor
```

**After evaluate_action() completes, add logging:**
```python
# At end of evaluate_action():
self.ledger.log_action(
    actor=user or "system",
    action_type="policy_evaluation",
    resource_id=action_type,
    input_data=action_data,
    output_data=result,
    result="pending",
    policy_result=result.get("overall_result"),
    policy_evaluated=True,
    reason=result.get("reason_code")
)
```

---

## DELIVERABLE 3: REGISTRY (Single Source of Truth)

### Objective
Build centralized configuration and state registry. Single source of truth.

### New File: `src/registry.py` (600 lines)

```python
class Registry:
    """Single source of truth for all system state and configuration"""
    
    def __init__(self, repo_path: str):
        self.repo_path = Path(repo_path)
        self.db_path = self.repo_path / "data" / "registry.db"
        self._init_database()
    
    def _init_database(self):
        """Initialize registry schema"""
        # Tables:
        # - assets (asset catalog with lifecycle)
        # - agents (agent definitions and permissions)
        # - configuration (versioned config snapshots)
        # - secrets_references (pointers to secret vault)
        # - health_status (current system health)
        # - portfolio_state (current portfolio metrics)
    
    def register_asset(self, asset_id: str, asset_type: str, metadata: Dict) -> str:
        """Register new asset in registry"""
        # Insert into assets table
        # Create initial health record
        # Log to ledger
        # Return asset_id
    
    def update_asset_state(self, asset_id: str, new_state: str) -> bool:
        """Update asset lifecycle state"""
        # Verify state transition is valid (draft→active→scaling→paused→retired)
        # Update assets table
        # Log to ledger
        # Return True if success
    
    def get_asset(self, asset_id: str) -> Dict:
        """Get asset record"""
        # SELECT from assets where asset_id = ?
    
    def get_all_assets(self, state: str = None) -> List[Dict]:
        """Get all assets, optionally filtered by state"""
        # SELECT from assets WHERE state = ? (or all if not specified)
    
    def get_portfolio_state(self) -> Dict:
        """Get current portfolio metrics (revenue, cost, profit)"""
        # Aggregate from assets table
        # Return portfolio summary
    
    def register_agent(self, agent_id: str, agent_type: str, permissions: Dict) -> str:
        """Register agent with permissions"""
        # Insert into agents table
        # Log to ledger
        # Return agent_id
    
    def get_agent(self, agent_id: str) -> Dict:
        """Get agent record with permissions"""
        # SELECT from agents where agent_id = ?
    
    def set_config(self, key: str, value: Any, version: int = 1) -> bool:
        """Set configuration parameter (versioned)"""
        # Insert into configuration table
        # Mark prior version as superseded
        # Log to ledger
        # Return True if success
    
    def get_config(self, key: str) -> Any:
        """Get current configuration value"""
        # SELECT from configuration WHERE key = ? and version = (MAX version)
    
    def get_config_history(self, key: str) -> List[Dict]:
        """Get all versions of a configuration parameter"""
        # SELECT all versions, ordered by version DESC
    
    def restore_config(self, key: str, version: int) -> bool:
        """Restore configuration to prior version"""
        # Set current version as new version
        # Log restore to ledger
        # Return True if success
```

---

## SUCCESS CRITERIA (BINARY)

### For Job Executor:

- [ ] **Schema created:** `jobs.db` exists with job tracking tables
  - Verification: `sqlite3 data/jobs.db ".tables"` shows "jobs" table
  
- [ ] **Routing works:** All job types route through Governor
  - Verification: `grep -n "self.governor.evaluate_action" src/job_executor.py` shows 3+ calls
  
- [ ] **Approval queue:** Jobs requiring approval are queued
  - Verification: `JobExecutor.get_pending_approvals()` returns list
  
- [ ] **Approval execution:** Owner can approve and trigger job
  - Verification: `JobExecutor.approve_job()` executes approved job
  
- [ ] **All actions logged:** Every job step logged to universal ledger
  - Verification: `ledger.get_by_type("job_submitted")` returns all submitted jobs

### For Governor Integration:

- [ ] **Ledger calls added:** Governor logs all evaluations
  - Verification: Manual test: run 10 jobs, verify 10 policy_evaluation entries in ledger
  
- [ ] **No bypass possible:** Attempting to execute job without governor fails
  - Verification: `JobExecutor.execute_approved_job()` raises error if not through submit_job()

### For Registry:

- [ ] **Schema created:** `registry.db` exists with all tables
  - Verification: `sqlite3 data/registry.db ".tables"` shows 5+ tables
  
- [ ] **Asset registration:** Can register asset and query it back
  - Verification: Manual test: register asset, retrieve it, verify data matches
  
- [ ] **State transitions:** Asset state transitions work
  - Verification: Manual test: draft→active→scaling→paused→retired all work
  
- [ ] **Config versioning:** Can set, retrieve, and restore config
  - Verification: Manual test: set v1, set v2, restore v1, verify v1 restored

### Integration Tests:

- [ ] **End-to-end job flow:** Submit job → policy evaluation → approval → execution → logged
  - Verification: `pytest tests/test_job_flow.py::test_full_job_flow -v` passes
  
- [ ] **Policy enforcement:** Jobs denied by governor don't execute
  - Verification: `pytest tests/test_governor_enforcement.py::test_deny_blocks_execution -v` passes
  
- [ ] **Kill switch works:** Freeze command stops all running jobs
  - Verification: `pytest tests/test_kill_switch.py::test_freeze_stops_jobs -v` passes
  
- [ ] **Ledger integrity:** Hash chain is unbroken
  - Verification: `UniversalLedger.verify_integrity()` returns True

---

## EXECUTION CHECKLIST

**Done via KAIZA write_file:**
- [ ] Create `src/job_executor.py` with all classes and methods
- [ ] Create `src/registry.py` with all classes and methods
- [ ] Update `src/governor.py` to add ledger integration
- [ ] Create `data/jobs.db` schema
- [ ] Create `data/registry.db` schema
- [ ] Create integration tests in `tests/test_job_flow.py`
- [ ] Create integration tests in `tests/test_governor_enforcement.py`
- [ ] Create integration tests in `tests/test_kill_switch.py`
- [ ] Run all tests (must pass 100%)
- [ ] Verify ledger entries for all operations
- [ ] Commit with audit log

---

## EXPECTED SYSTEM STATE AFTER PHASE 1

```
Architecture:
  ✅ Job Request → Governor → [Allow/Deny/Override] → Execution/Queue
  ✅ All jobs go through Governor (no bypass)
  ✅ All decisions logged to universal ledger
  ✅ Single source of truth (registry)
  ✅ Budget enforcement (hard limits)
  ✅ Approval queue (owner can review)
  ✅ Kill switch works instantly

Database Files:
  ✅ universal_ledger.db (action audit trail)
  ✅ governance.db (policies)
  ✅ jobs.db (job tracking)
  ✅ registry.db (system state)
  ✅ billing_ledger.db (financial transactions)

Tests:
  ✅ 100% of job types tested
  ✅ 100% of policy outcomes tested
  ✅ 100% of ledger queries tested
  ✅ Full end-to-end flow tested

Constraints Enforced:
  ✅ Budget limits (hard)
  ✅ Policy rules (enforced)
  ✅ Risk gating (approval queue)
  ✅ Auditability (all logged)
```

---

## NEXT STEPS

After Phase 1 completion, system is ready for **Phase 2: Agent Economy** (implement specialized agents with permission boundaries).

---

**END OF PHASE 1 RECOVERY PLAN**
