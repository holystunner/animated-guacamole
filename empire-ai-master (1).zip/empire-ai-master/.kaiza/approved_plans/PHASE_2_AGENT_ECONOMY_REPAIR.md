# PHASE 2: AGENT ECONOMY REPAIR

**Objective:** Build the agent framework where specialized AI workers operate within strict permission boundaries.

**Current State:** Loop scripts exist (`discovery-loop.py`, `content-factory.py`, `growth-loop.py`). **Not agents. No permission model.**

**Goal:** Transform loops into proper agents with enforceable permission envelopes.

**Duration:** 6–8 weeks  
**Complexity:** High (framework + 7 implementations)

---

## NON-NEGOTIABLE CONSTRAINTS

1. **All 7 agent types implemented** (Scout, Builder, Writer, QA/Verifier, Growth, Finance, Compliance)
2. **Each agent has explicit permission envelope** (cannot exceed)
3. **No agent can escalate its own permissions**
4. **Every agent action is attributed and logged**
5. **No agent can sabotage or interfere with another agent**
6. **All agents use central job submission** (go through Governor)

---

## PHASE 2 DELIVERABLES

### D1: Agent Framework & Permission Model

**Objective:** Build extensible agent base class and permission enforcement.

**New File:** `src/agent_framework.py` (~700 lines)

**Core Classes:**
```python
class Permission(Enum):
    READ = "read"
    WRITE = "write"
    DEPLOY = "deploy"
    PAY = "pay"
    KILL = "kill"

class AgentPermissionEnvelope:
    """Immutable permission boundary for an agent"""
    
    def __init__(self, agent_id: str, agent_type: str):
        self.agent_id = agent_id
        self.agent_type = agent_type
        self.allowed_tools: Set[str] = set()  # e.g., {web_fetch, git_ops, deploy}
        self.allowed_asset_domains: Set[str] = set()  # e.g., {content_cluster, tool}
        self.allowed_actions: Set[Permission] = set()
        self.monthly_budget: float = 0.0
        self.daily_budget: float = 0.0
        self.budget_used_today: float = 0.0
        self.budget_reset_at: datetime = None
        self.created_at: datetime = datetime.now()
        self.immutable: bool = False  # Once set, cannot change
    
    def can_perform(self, action: Permission) -> bool:
        """Check if agent can perform action"""
        if self.immutable:
            return action in self.allowed_actions
        return False  # Default deny
    
    def can_access_asset_domain(self, asset_domain: str) -> bool:
        """Check if agent can access asset domain"""
        return asset_domain in self.allowed_asset_domains
    
    def can_use_tool(self, tool: str) -> bool:
        """Check if agent can use tool"""
        return tool in self.allowed_tools
    
    def has_budget(self, cost: float) -> bool:
        """Check if agent has budget for action"""
        if cost > self.daily_budget - self.budget_used_today:
            return False
        if cost > self.monthly_budget:
            return False
        return True
    
    def lock(self) -> bool:
        """Lock permissions (cannot escalate after)"""
        self.immutable = True
        return True

class BaseAgent:
    """Base class for all agents"""
    
    def __init__(self, agent_id: str, agent_type: str, registry: Registry, 
                 governor: Governor, job_executor: JobExecutor):
        self.agent_id = agent_id
        self.agent_type = agent_type
        self.registry = registry
        self.governor = governor
        self.job_executor = job_executor
        self.permissions = AgentPermissionEnvelope(agent_id, agent_type)
        self.status = "idle"  # idle, working, paused, disabled
    
    def submit_job(self, job_type: str, input_data: Dict[str, Any], 
                   required_budget: float) -> str:
        """Submit job to executor (goes through Governor)"""
        
        # Check permissions
        if not self._verify_permissions(job_type, input_data):
            raise PermissionDeniedError(f"Agent {self.agent_id} lacks permissions for {job_type}")
        
        # Check budget
        if not self.permissions.has_budget(required_budget):
            raise BudgetExceededError(f"Agent {self.agent_id} insufficient budget")
        
        # Create job request
        job_request = JobRequest(
            job_id=str(uuid.uuid4()),
            job_type=job_type,
            resource_id=self.agent_id,
            actor=self.agent_id,
            input_data=input_data,
            required_budget=required_budget,
            risk_level=self._calculate_risk(job_type, input_data)
        )
        
        # Submit to executor (Governor validation happens there)
        try:
            job_id = self.job_executor.submit_job(job_request)
            self.permissions.budget_used_today += required_budget
            return job_id
        except JobBlockedException as e:
            raise JobRejectedError(f"Governor rejected job: {e.reason}")
    
    def _verify_permissions(self, job_type: str, input_data: Dict[str, Any]) -> bool:
        """Verify agent has permissions for this action"""
        # Subclasses override
        return False
    
    def _calculate_risk(self, job_type: str, input_data: Dict[str, Any]) -> RiskLevel:
        """Calculate risk level of action"""
        # Subclasses override
        return RiskLevel.MEDIUM
```

**Acceptance Criteria:**
- [ ] Agent base class complete
- [ ] Permission envelope immutable once set
- [ ] Budget enforcement active
- [ ] Cannot escalate permissions
- [ ] All agent actions go through job executor

---

### D2: Scout Agent Implementation

**Objective:** Agent that discovers opportunities without autonomously executing them.

**Update/New File:** `src/scout_agent.py` (~400 lines, replace `discovery-loop.py`)

**Responsibilities:**
- Find high-intent keywords
- Discover niche opportunities
- Research competitor gaps
- **Propose** new asset opportunities (not execute)

**Permissions:**
- `read` only (no write, deploy, pay, kill)
- Tools: `web_fetch`, `analytics_read`
- Asset domains: can view all, cannot modify any
- Budget: $10/day (API calls, crawl quota)

**Key Methods:**
```python
class ScoutAgent(BaseAgent):
    def discover_opportunities(self, market_segment: str) -> List[Opportunity]:
        """Discover opportunities in market segment"""
        # Check if has permission to read
        if not self.permissions.can_perform(Permission.READ):
            raise PermissionDeniedError()
        
        # Submit job to executor
        job_id = self.submit_job(
            job_type="discover",
            input_data={"segment": market_segment},
            required_budget=0.50  # Cost of API calls
        )
        
        # Wait for completion
        result = self.job_executor.get_job_result(job_id)
        return [Opportunity.from_dict(o) for o in result["opportunities"]]
    
    def propose_asset(self, opportunity: Opportunity) -> str:
        """Propose new asset (not execute)"""
        job_id = self.submit_job(
            job_type="propose_asset",
            input_data=opportunity.to_dict(),
            required_budget=0.01
        )
        return job_id  # This goes to approval queue
```

**Acceptance Criteria:**
- [ ] Scout can discover opportunities
- [ ] Scout cannot deploy or pay
- [ ] Scout cannot modify existing assets
- [ ] All Scout actions logged
- [ ] Proposals are queued, not auto-executed

---

### D3: Builder Agent Implementation

**Objective:** Agent that generates code and deploys infrastructure.

**Update/New File:** `src/builder_agent.py` (~500 lines, replace `product-factory.py`)

**Responsibilities:**
- Generate code for new assets
- Deploy infrastructure
- Commit to git repositories
- Create hosting/domains
- **Cannot** modify content or kill assets

**Permissions:**
- `read`, `write`, `deploy` (not `pay`, not `kill`)
- Tools: `git_ops`, `code_gen`, `deploy`, `domain_registry`
- Asset domains: only `draft` and `active` (cannot touch `paused` or `retired`)
- Budget: $100/day (infrastructure costs)

**Key Methods:**
```python
class BuilderAgent(BaseAgent):
    def generate_asset(self, template: str, parameters: Dict[str, Any]) -> AssetBuild:
        """Generate asset from template"""
        job_id = self.submit_job(
            job_type="generate",
            input_data={"template": template, "parameters": parameters},
            required_budget=5.00
        )
        return self.job_executor.get_job_result(job_id)
    
    def deploy_asset(self, asset_id: str) -> str:
        """Deploy asset to infrastructure"""
        if not self.permissions.can_access_asset_domain("active"):
            raise PermissionDeniedError()
        
        job_id = self.submit_job(
            job_type="deploy",
            input_data={"asset_id": asset_id},
            required_budget=10.00
        )
        return job_id
```

**Acceptance Criteria:**
- [ ] Builder can generate code
- [ ] Builder can deploy
- [ ] Builder cannot kill or pause assets
- [ ] Builder cannot write content
- [ ] Infrastructure deployment is logged

---

### D4: Writer Agent Implementation

**Objective:** Agent that generates and updates content.

**New File:** `src/writer_agent.py` (~400 lines, refactor `content-factory.py`)

**Responsibilities:**
- Generate articles, landing pages, product descriptions
- Optimize existing content for SEO
- Create metadata and titles
- **Cannot** deploy, cannot kill assets

**Permissions:**
- `read`, `write` (not `deploy`, not `pay`, not `kill`)
- Tools: `content_gen`, `seo_tools`, `markdown`
- Asset domains: `content_cluster`, `tool`, `lead_gen`
- Budget: $50/day (LLM API calls)

**Key Methods:**
```python
class WriterAgent(BaseAgent):
    def generate_content(self, asset_id: str, content_type: str) -> str:
        """Generate content for asset"""
        job_id = self.submit_job(
            job_type="generate_content",
            input_data={"asset_id": asset_id, "content_type": content_type},
            required_budget=1.00
        )
        return job_id
    
    def optimize_content(self, asset_id: str, target_keywords: List[str]) -> str:
        """Optimize existing content"""
        job_id = self.submit_job(
            job_type="optimize_content",
            input_data={"asset_id": asset_id, "keywords": target_keywords},
            required_budget=0.50
        )
        return job_id
```

**Acceptance Criteria:**
- [ ] Writer can generate content
- [ ] Writer cannot deploy
- [ ] Writer cannot modify asset status
- [ ] All content generation logged

---

### D5: QA/Verifier Agent Implementation

**Objective:** Agent that validates quality and compliance before publishing.

**New File:** `src/qa_agent.py` (~450 lines, replace `validator-bot.py`)

**Responsibilities:**
- Verify content quality
- Check affiliate disclosure compliance
- Validate claims against sources
- Approve or reject asset publication

**Permissions:**
- `read`, `write` (for approval annotations)
- Tools: `compliance_check`, `content_analysis`
- Asset domains: all domains (read-only except marking as reviewed)
- Budget: $20/day

**Key Methods:**
```python
class QAAgent(BaseAgent):
    def verify_asset(self, asset_id: str) -> VerificationResult:
        """Verify asset quality and compliance"""
        job_id = self.submit_job(
            job_type="verify",
            input_data={"asset_id": asset_id},
            required_budget=1.00
        )
        result = self.job_executor.get_job_result(job_id)
        return VerificationResult.from_dict(result)
    
    def approve_publication(self, asset_id: str, findings: str = "") -> str:
        """Approve asset for publication"""
        job_id = self.submit_job(
            job_type="approve",
            input_data={"asset_id": asset_id, "findings": findings},
            required_budget=0.10
        )
        return job_id
    
    def reject_asset(self, asset_id: str, reason: str) -> str:
        """Reject asset with reason"""
        job_id = self.submit_job(
            job_type="reject",
            input_data={"asset_id": asset_id, "reason": reason},
            required_budget=0.05
        )
        return job_id
```

**Acceptance Criteria:**
- [ ] QA can verify assets
- [ ] QA cannot deploy or kill
- [ ] Approval is required before publishing
- [ ] Rejections are logged with reason

---

### D6: Growth Agent Implementation

**Objective:** Agent that optimizes and scales profitable assets.

**New File:** `src/growth_agent.py` (~450 lines, refactor `growth-loop.py`)

**Responsibilities:**
- Optimize existing assets (links, CTR, SEO)
- Run A/B tests on content/layout
- Scale winners by duplicating or expanding
- **Cannot** modify asset code, cannot kill assets (only propose killing)

**Permissions:**
- `read`, `write` (minor updates only)
- Tools: `analytics`, `a_b_testing`, `optimization`
- Asset domains: only `active` or `scaling`
- Budget: $75/day

**Key Methods:**
```python
class GrowthAgent(BaseAgent):
    def optimize_asset(self, asset_id: str) -> str:
        """Run optimization on asset"""
        job_id = self.submit_job(
            job_type="optimize",
            input_data={"asset_id": asset_id},
            required_budget=5.00
        )
        return job_id
    
    def scale_asset(self, asset_id: str, expansion_type: str) -> str:
        """Expand asset (add keywords, content, links)"""
        job_id = self.submit_job(
            job_type="scale",
            input_data={"asset_id": asset_id, "expansion_type": expansion_type},
            required_budget=10.00
        )
        return job_id
```

**Acceptance Criteria:**
- [ ] Growth can optimize assets
- [ ] Growth cannot deploy infrastructure
- [ ] Growth cannot kill assets
- [ ] Scaling actions are logged

---

### D7: Finance Agent Implementation

**Objective:** Agent that analyzes ROI and recommends capital allocation.

**New File:** `src/finance_agent.py` (~400 lines, replace `portfolio-manager.py` logic)

**Responsibilities:**
- Calculate ROI for each asset
- Recommend budget shifts
- Propose killing underperformers
- Track capital allocation

**Permissions:**
- `read` only (analytics only, no execution)
- Tools: `analytics`, `financial_models`
- Asset domains: all (read-only)
- Budget: $5/day

**Key Methods:**
```python
class FinanceAgent(BaseAgent):
    def analyze_roi(self, asset_id: str) -> ROIAnalysis:
        """Analyze ROI of asset"""
        job_id = self.submit_job(
            job_type="analyze_roi",
            input_data={"asset_id": asset_id},
            required_budget=0.50
        )
        return self.job_executor.get_job_result(job_id)
    
    def recommend_kill(self, asset_id: str, reason: str) -> str:
        """Recommend killing underperformer"""
        job_id = self.submit_job(
            job_type="recommend_kill",
            input_data={"asset_id": asset_id, "reason": reason},
            required_budget=0.10
        )
        return job_id  # Goes to approval queue
```

**Acceptance Criteria:**
- [ ] Finance can analyze ROI
- [ ] Finance cannot execute budget changes
- [ ] Recommendations are proposals, not actions
- [ ] All analysis logged

---

### D8: Compliance Agent Implementation

**Objective:** Agent that enforces policy and prevents violations.

**New File:** `src/compliance_agent.py` (~400 lines, integrate from governance_loop.py`)

**Responsibilities:**
- Enforce affiliate disclosure rules
- Check for forbidden content
- Flag policy violations
- Block violating assets

**Permissions:**
- `read` only
- Tools: `compliance_check`, `content_analysis`
- Asset domains: all
- Budget: $10/day

**Key Methods:**
```python
class ComplianceAgent(BaseAgent):
    def check_compliance(self, asset_id: str) -> ComplianceReport:
        """Check asset compliance"""
        job_id = self.submit_job(
            job_type="check_compliance",
            input_data={"asset_id": asset_id},
            required_budget=0.50
        )
        return self.job_executor.get_job_result(job_id)
    
    def block_asset(self, asset_id: str, violation: str) -> str:
        """Block asset for compliance violation"""
        job_id = self.submit_job(
            job_type="block",
            input_data={"asset_id": asset_id, "violation": violation},
            required_budget=0.05
        )
        return job_id
```

**Acceptance Criteria:**
- [ ] Compliance can check and flag violations
- [ ] Compliance cannot execute killing
- [ ] Violations are logged
- [ ] Assets can be blocked pending review

---

### D9: Agent Initialization & Registry

**Objective:** Central initialization and lifecycle management for all agents.

**New File:** `src/agent_registry.py` (~300 lines)

**Functionality:**
```python
class AgentRegistry:
    def __init__(self, registry: Registry, governor: Governor, job_executor: JobExecutor):
        self.agents = {}
    
    def initialize_agent(self, agent_type: str) -> BaseAgent:
        """Create and initialize agent"""
        # Create agent with default permissions
        agent = self._create_agent(agent_type)
        
        # Load permissions from registry
        permissions = registry.get_agent_permissions(agent.agent_id)
        agent.permissions = permissions
        
        # Lock permissions (immutable)
        agent.permissions.lock()
        
        # Register in ledger
        ledger.log_action(
            actor="system",
            action_type="agent_initialized",
            resource_id=agent.agent_id,
            result="success"
        )
        
        return agent
    
    def disable_agent(self, agent_id: str) -> bool:
        """Disable agent without cascade failures"""
        agent = self.agents[agent_id]
        agent.status = "disabled"
        ledger.log_action(
            actor="system",
            action_type="agent_disabled",
            resource_id=agent_id,
            result="success"
        )
        return True
    
    def get_agent(self, agent_id: str) -> BaseAgent:
        """Retrieve agent"""
        return self.agents.get(agent_id)
```

**Acceptance Criteria:**
- [ ] All 7 agents initialized with correct permissions
- [ ] Permissions are immutable
- [ ] Agents can be disabled independently
- [ ] All agent actions logged

---

## IMPLEMENTATION SEQUENCE

**Week 1–2: Framework**
- D1: Agent framework and permission model
- D9: Agent registry

**Week 2–4: Core Agents**
- D2: Scout agent
- D3: Builder agent
- D4: Writer agent

**Week 4–6: Support Agents**
- D5: QA agent
- D6: Growth agent
- D7: Finance agent
- D8: Compliance agent

**Week 6–8: Integration & Testing**
- Integration with job executor and Governor
- Permission enforcement testing
- Multi-agent interaction testing
- Documentation

---

## SUCCESS GATES

**Gate 1: Framework Complete**
```
✓ Agent base class working
✓ Permission enforcement active
✓ All 7 agents instantiate
✓ Cannot escalate permissions
```

**Gate 2: Permissions Enforced**
```
✓ Scout cannot write/deploy
✓ Builder cannot kill/pay
✓ Writer cannot deploy
✓ QA cannot execute recommendations
✓ Growth cannot kill
✓ Finance cannot execute
✓ Compliance cannot kill
```

**Gate 3: Job Submission**
```
✓ All agents submit jobs through executor
✓ Jobs go through Governor
✓ Budget enforced per agent
✓ All actions logged
```

**Gate 4: Integration**
```
✓ Agents can call each other via job queue
✓ No direct calls (all through Governor)
✓ No circular dependencies
✓ Failures isolated
```

---

## INTENTIONALLY NOT INCLUDED

- Asset deployment (handled by Builder + Layer 4)
- Revenue calculations (Finance + Layer 5)
- UI interaction (Layer 5)
- Multi-server coordination (Layer 6)

---

## DELIVERABLES

1. `src/agent_framework.py` (700+ lines, base classes)
2. `src/scout_agent.py` (400+ lines)
3. `src/builder_agent.py` (500+ lines)
4. `src/writer_agent.py` (400+ lines)
5. `src/qa_agent.py` (450+ lines)
6. `src/growth_agent.py` (450+ lines)
7. `src/finance_agent.py` (400+ lines)
8. `src/compliance_agent.py` (400+ lines)
9. `src/agent_registry.py` (300+ lines)
10. Tests for all agents (800+ lines)
11. Execution report with gate validation

---

## AUTHORITY

This phase is mandatory before asset deployment (Layer 4) can proceed. Agents are the autonomous workforce.

**Governing Document:** EMPIRE_AI_CANONICAL_SPECIFICATION.md Section 2 Layer 3: Agent Economy & Permission Model
