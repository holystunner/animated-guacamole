# PHASE 1: CORE OS COMPLETION

**Objective:** Complete the operating system kernel (Governor, Runtime, Registry) and integrate all three into a functional, enforced decision pipeline.

**Current State:** Governor exists as standalone policy validator. **Not integrated into job execution.**

**Goal:** Make the system incapable of executing any action without policy clearance and logging.

**Duration:** 4–6 weeks  
**Complexity:** Very High (architectural integration)

---

## NON-NEGOTIABLE CONSTRAINTS

1. **All job execution goes through Governor**
2. **No policy bypass or override without logged approval**
3. **Budget limits are hard limits (enforced)**
4. **All decisions logged to universal ledger**
5. **Freeze/kill switch works instantly**
6. **No single point of failure for Governor**

---

## PHASE 1 DELIVERABLES

### D1: Job Execution Pipeline

**Objective:** Build unified job queue + runtime that enforces Governor policies.

**New File:** `src/job_executor.py` (~600 lines)

**Architecture:**
```
Job Request
    ↓
Governor.evaluate_action()  ← ALL actions go here
    ↓
[Allow/Deny/Override Required]
    ↓ (if Deny)
→ Reject, log, return error
    ↓ (if Override Required)
→ Queue for approval, wait for owner
    ↓ (if Allow)
→ Runtime.execute_job()
    ↓
Execute with checkpoints
    ↓
Log result to Universal Ledger
    ↓
Complete
```

**Core Classes:**
```python
class JobRequest:
    job_id: str
    job_type: str  # scout, build, publish, measure, scale, kill
    resource_id: str  # asset_id or agent_id
    actor: str  # which agent requested
    input_data: Dict[str, Any]
    required_budget: float
    risk_level: RiskLevel
    timestamp: datetime

class JobExecutor:
    def submit_job(self, request: JobRequest) -> Dict[str, Any]:
        """Submit job for policy evaluation"""
        # Call Governor.evaluate_action()
        # Route based on result
    
    def execute_approved_job(self, job_id: str) -> Dict[str, Any]:
        """Execute a policy-approved job"""
        # Run with checkpoints
        # Log every step
        # Return result
    
    def get_job_status(self, job_id: str) -> Dict[str, Any]:
        """Query job status"""
        return {
            "job_id": job_id,
            "status": "running|completed|failed|pending_approval",
            "progress": 0.0,
            "started_at": datetime,
            "completed_at": Optional[datetime],
            "result": Optional[Dict],
            "error": Optional[str]
        }

class Runtime:
    def execute_steps(self, steps: List[JobStep]) -> Dict[str, Any]:
        """Execute job steps with checkpoint recovery"""
        # For each step:
        #   Check if already completed (idempotent)
        #   Execute step with error handling
        #   Log result to ledger
        #   Checkpoint state
        # Return final result
```

**Acceptance Criteria:**
- [ ] All job requests route through Governor
- [ ] Governor decision is logged before execution
- [ ] Failed policy checks prevent execution
- [ ] Budget limits are enforced
- [ ] Jobs can resume from checkpoints

---

### D2: Registry Completion

**Objective:** Single source of truth for all system state.

**Update File:** `src/registry.py` (new, ~500 lines)

**Schema Additions:**
```sql
-- Asset registry
CREATE TABLE assets (
    asset_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    asset_type TEXT NOT NULL,  -- content_cluster, tool, lead_gen
    status TEXT NOT NULL,  -- draft, active, scaling, paused, retired
    owner TEXT NOT NULL,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    revenue REAL DEFAULT 0,
    cost REAL DEFAULT 0,
    roi REAL,
    health_score REAL,
    metadata JSONB
);

-- Agent registry
CREATE TABLE agents (
    agent_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    agent_type TEXT NOT NULL,  -- scout, builder, writer, qa, growth, finance, compliance
    status TEXT NOT NULL,  -- active, paused, disabled
    budget_limit_monthly REAL,
    budget_used_this_month REAL,
    permissions JSONB,  -- {tools: [], asset_domains: [], actions: []}
    created_at TIMESTAMP
);

-- Job definitions
CREATE TABLE job_templates (
    job_id TEXT PRIMARY KEY,
    job_type TEXT NOT NULL,
    agent_type TEXT NOT NULL,
    input_schema JSONB,
    output_schema JSONB,
    estimated_cost REAL,
    estimated_duration SECONDS,
    risk_level TEXT
);

-- Current state snapshots
CREATE TABLE state_snapshots (
    snapshot_id TEXT PRIMARY KEY,
    timestamp TIMESTAMP,
    asset_states JSONB,
    agent_states JSONB,
    budget_states JSONB,
    previous_snapshot_id TEXT  -- linked list
);
```

**Core Methods:**
```python
class Registry:
    def register_asset(self, asset: AssetMetadata) -> str:
        """Register new asset"""
    
    def get_asset(self, asset_id: str) -> AssetMetadata:
        """Retrieve asset metadata"""
    
    def update_asset_status(self, asset_id: str, new_status: str) -> bool:
        """Update asset lifecycle state"""
    
    def register_agent(self, agent: AgentMetadata) -> str:
        """Register new agent"""
    
    def get_agent_permissions(self, agent_id: str) -> Dict:
        """Get agent permission envelope"""
    
    def get_budget_remaining(self, agent_id: str) -> float:
        """Query available budget for agent"""
    
    def deduct_budget(self, agent_id: str, amount: float) -> bool:
        """Enforce budget limit"""
        # Reject if would exceed limit
        # Log deduction to ledger
    
    def create_state_snapshot(self) -> str:
        """Create immutable state checkpoint"""
        # Serialize all asset, agent, budget states
        # Hash the snapshot
        # Return snapshot_id for restore
    
    def restore_state(self, snapshot_id: str) -> bool:
        """Restore system to prior state"""
        # Verify snapshot exists
        # Roll back all state
        # Log restoration to ledger
```

**Acceptance Criteria:**
- [ ] Asset registry complete with all metadata
- [ ] Agent registry tracks permissions and budgets
- [ ] Budget enforcement prevents overspending
- [ ] State snapshots are immutable
- [ ] Restore functionality works

---

### D3: Governor Integration

**Objective:** Wire Governor into job execution pipeline (instead of standalone).

**Update File:** `src/governor.py` (~150 lines of changes)

**Changes:**
1. Add `enforce_policy()` method that **blocks job submission** if policy fails
2. Integrate with job queue (all submissions check Governor first)
3. Add approval workflow callbacks (override requests escalate to approval queue)
4. Wire kill switch to instant job termination (graceful cleanup)

**New Methods:**
```python
class Governor:
    def enforce_policy(self, job_request: JobRequest) -> PolicyEnforcement:
        """Enforce policy on job submission"""
        # Evaluate all applicable policies
        # If DENY: raise JobBlockedException
        # If OVERRIDE_REQUIRED: queue for approval
        # If ALLOW: return approval token
        # ALL decisions logged to universal ledger
    
    def trigger_freeze(self, reason: str = None) -> bool:
        """Instant freeze (pause all jobs)"""
        # Set global flag
        # Gracefully checkpoint all running jobs
        # Log to ledger
    
    def trigger_kill(self, reason: str = None) -> bool:
        """Hard stop (terminate all jobs)"""
        # Terminate all running jobs
        # Log to ledger
        # Prevent new job submission
```

**Enforcement Pipeline:**
```python
def submit_job(job_request: JobRequest) -> JobId:
    # Step 1: Governor validation (mandatory)
    try:
        approval = governor.enforce_policy(job_request)
    except JobBlockedException as e:
        # Log rejection
        ledger.log_action(
            actor="system",
            action_type="job_rejected",
            resource_id=job_request.job_id,
            reason=e.reason,
            result="rejected"
        )
        raise
    
    # Step 2: Budget check
    if not registry.deduct_budget(job_request.actor, job_request.required_budget):
        ledger.log_action(..., reason="budget_exceeded", result="rejected")
        raise BudgetExceededException()
    
    # Step 3: Queue job
    job_id = job_queue.enqueue(job_request, approval_token=approval.token)
    
    # Step 4: Log submission
    ledger.log_action(
        actor=job_request.actor,
        action_type="job_submitted",
        resource_id=job_id,
        input_data=job_request.to_dict(),
        result="queued"
    )
    
    return job_id
```

**Acceptance Criteria:**
- [ ] All job submissions validated by Governor
- [ ] Budget enforced before execution
- [ ] Freeze/kill operations work instantly
- [ ] No job bypasses policy checks

---

### D4: Scheduler & Job Queue

**Objective:** Background scheduler that autonomously executes queued jobs.

**New File:** `src/scheduler.py` (~400 lines)

**Features:**
```python
class Scheduler:
    def __init__(self):
        self.running = False
        self.job_queue = JobQueue()
        self.runtime = Runtime()
        self.ledger = UniversalLedger()
    
    async def run(self):
        """Main scheduler loop (runs continuously)"""
        while self.running:
            # Get next queued job
            job = self.job_queue.get_next()
            if not job:
                await asyncio.sleep(5)
                continue
            
            # Mark as executing
            self.job_queue.set_status(job.job_id, "executing")
            
            try:
                # Execute job
                result = await self.runtime.execute_steps(job.steps)
                
                # Log success
                self.ledger.log_action(
                    actor=job.actor,
                    action_type=job.job_type,
                    result="success",
                    output_data=result
                )
                
                # Mark complete
                self.job_queue.set_status(job.job_id, "completed")
            
            except Exception as e:
                # Log failure
                self.ledger.log_action(..., result="failed", reason=str(e))
                self.job_queue.set_status(job.job_id, "failed", error=str(e))
    
    def pause(self):
        """Pause scheduler (freeze)"""
        self.running = False
        self.ledger.log_action(
            actor="system",
            action_type="scheduler_paused",
            result="success"
        )
    
    def resume(self):
        """Resume scheduler"""
        self.running = True
        self.ledger.log_action(
            actor="system",
            action_type="scheduler_resumed",
            result="success"
        )
```

**Acceptance Criteria:**
- [ ] Scheduler runs continuously
- [ ] Jobs execute in order
- [ ] Failed jobs are retried with exponential backoff
- [ ] Pause/resume works instantly
- [ ] All job execution logged

---

### D5: System Health & Observability

**Objective:** Dashboard of system health for debugging (internal, not for owner yet).

**New File:** `src/health_monitor.py` (~300 lines)

**Metrics:**
```python
class SystemHealth:
    def get_metrics(self) -> Dict[str, Any]:
        return {
            "timestamp": datetime.now(),
            "scheduler_running": bool,
            "queue_depth": int,
            "active_jobs": int,
            "failed_jobs_24h": int,
            "avg_job_duration": float,
            "governor_blocks_24h": int,
            "ledger_entries": int,
            "registry_assets": int,
            "registry_agents": int,
            "total_budget_spent": float,
            "system_status": "healthy|degraded|critical"
        }
```

**Acceptance Criteria:**
- [ ] Metrics collected every minute
- [ ] Metrics persisted to database
- [ ] CLI command to view health: `python3 src/health_monitor.py --status`

---

## IMPLEMENTATION SEQUENCE

**Week 1–2: Architecture & Registry**
- D2: Registry schema and implementation
- D1 (start): Job executor skeleton

**Week 2–3: Job Execution Pipeline**
- D1 (complete): Job executor with Governor integration
- D3: Governor integration
- D4: Scheduler and job queue

**Week 4–5: Testing & Integration**
- D5: Health monitoring
- Integration testing of entire pipeline
- Load testing (queue under load)

**Week 5–6: Hardening**
- Edge case handling
- Failure recovery testing
- Documentation

---

## SUCCESS GATES

**Gate 1: Registry Complete**
```
✓ Asset registry working
✓ Agent registry working
✓ Budget enforcement active
✓ State snapshots immutable
```

**Gate 2: Governor Integration**
```
✓ All job submissions check Governor
✓ Policy enforcement blocks bad jobs
✓ Freeze/kill works instantly
✓ No bypass paths
```

**Gate 3: Scheduler Operational**
```
✓ Scheduler runs continuously
✓ Jobs execute in queue order
✓ All execution logged
✓ Pause/resume works
```

**Gate 4: System Health**
```
✓ Metrics collected and queryable
✓ System status visible
✓ Can diagnose failures
```

---

## INTENTIONALLY NOT INCLUDED

- Agent framework (Layer 3)
- Asset deployment (Layer 4)
- UI/admin console (Layer 5)
- Multi-server setup (Layer 6)
- Autonomous scaling logic

---

## DELIVERABLES

1. `src/registry.py` (500+ lines, complete asset/agent/job registry)
2. `src/job_executor.py` (600+ lines, unified execution pipeline)
3. Updated `src/governor.py` (integrate with job execution)
4. `src/scheduler.py` (400+ lines, background job runner)
5. `src/health_monitor.py` (300+ lines, system observability)
6. Updated `data/governance.db` (action ledger schema)
7. Tests for all components (500+ lines)
8. Execution report with gate validation

---

## AUTHORITY

This phase is mandatory before Layer 3 (agents) or Layer 4 (assets) work can proceed. The operating system must be functional first.

**Governing Document:** EMPIRE_AI_CANONICAL_SPECIFICATION.md Section 2 Layer 1 & 2: Governor, Runtime, Registry, Ledger
