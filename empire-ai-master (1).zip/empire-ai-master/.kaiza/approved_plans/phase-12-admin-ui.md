────────────────────────────────
PHASE EXECUTION PLAN
────────────────────────────────

1. Phase ID
   Phase 12

2. Phase Name
   Admin UI & Control Plane

3. Execution Objective
   Consolidate all distributed interfaces into a single, cohesive, secure Commander's Console that provides the Human Operator with total situational awareness and final veto power.

4. Scope of Authority
   - Remote Monitoring (Observer).
   - High-level Intent Injection (Commander).

5. In-Scope Components
   - `cockpit` (Unified Frontend: React/Next.js/HTML)
   - `auth-wall` (Strict mTLS or OAuth)
   - `api-gateway-internal` (Secure Control API)
   - Admin UI ("God View", Intervention Console)

6. Out-of-Scope (Hard Block)
   - Public internet exposure of Admin UI.
   - Unauthenticated access.

7. Preconditions
   - Phase 11 Complete.

8. Execution Steps (Ordered, Atomic)
   - Step 1: Deploy `api-gateway-internal`.
   - Step 2: Implement `auth-wall` security.
   - Step 3: Deploy `cockpit` frontend.
   - Step 4: Implement Reporting Loop (Aggregators -> Backend -> WebSocket -> UI).
   - Step 5: Implement Command Loop (UI Action -> Governor -> Execution).
   - Step 6: Implement Insight Synthesis ("Morning Reports").
   - Step 7: Implement Visual Mapping (Graph of components).
   - Step 8: Configure Logic: Read-Only default, Session Timeout.

9. Data & State Created
   - Admin Session Logs.
   - Action Logs (Human clicks).

10. Decision Logic Implemented
    - Read-Only Default: Admin is observer unless "Unlock" engaged.
    - Session Timeout: Aggressive auto-logout.

11. Observability & Audit Hooks
    - Access logs for the Admin UI itself.
    - Recording of every clickable action taken by human.

12. Failure Conditions
    - UI Down.

13. Rollback Strategy
    - UI Down: CLI fallback must remain available via SSH.

14. Validation Tests (Binary)
    - Test 1: PASS / FAIL (Unified dashboard operational)
    - Test 2: PASS / FAIL (All previous phase metrics visible in one place)
    - Test 3: PASS / FAIL (Successful strategy pivot command issued via UI)

15. Phase Exit Gate
    - All Validation Tests PASS.
