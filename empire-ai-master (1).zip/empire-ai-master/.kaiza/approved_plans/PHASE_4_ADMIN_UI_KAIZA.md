# PHASE 4: ADMIN UI — OWNER CONTROL DASHBOARD (KAIZA-EXECUTABLE)

**Status:** APPROVED FOR EXECUTION AFTER PHASE 1-3  
**Objective:** Build complete owner interface. Owner controls 100% of system via UI. ZERO CLI dependency.  
**Duration:** 8-10 weeks  
**Authority:** EMPIRE_AI_CANONICAL_SPECIFICATION.md v1.0 (Section 2, Layer 5, Design Decision #2)  

---

## BINDING CONSTRAINTS

1. **Full-stack UI** (not read-only)
2. **All 8 required screens** (see below)
3. **Owner can perform ANY operation** via UI
4. **Zero CLI operations required**
5. **Categorized tab navigation**
6. **Real-time data updates**
7. **Responsive design** (mobile-friendly)
8. **No stubs, no placeholder data**

---

## SCOPE: 8 REQUIRED SCREENS

### Screen 1: Portfolio Overview
**Tabs:**
- Revenue (30/90/365 day trends) — Line charts
- Costs (breakdown by asset/category) — Pie chart
- Profit (margin trend) — Area chart
- Asset status counts (active/scaling/paused/retired) — Count badges
- Capital allocation status — Bar chart
- System health (uptime, services running) — Status grid

**Interactive Elements:**
- Date range selector (30/90/365 days)
- Export report button (PDF/CSV)
- Refresh button

### Screen 2: Empire Tab
**Sections:**
- System status (Governor running, policies enforced)
- Kill switch button (LARGE, RED, always visible)
- Freeze system button
- Policy configuration (view/edit policies)
- Governance audit trail (searchable)

**Interactive Elements:**
- Policy add/edit dialog
- Kill switch activation modal
- Freeze system confirmation dialog

### Screen 3: Assets Tab
**Sections:**
- Asset catalog (table with all assets)
- Asset detail view (modal)
- Lifecycle state transition buttons (draft→active, active→scaling, etc.)
- Performance graphs (ROI, traffic, revenue)
- Audit trail per asset

**Columns in Asset Table:**
- Name
- Type
- Status (state)
- Revenue (30-day)
- Cost (30-day)
- ROI
- Uptime
- Actions (view, edit, scale, pause, kill)

**Interactive Elements:**
- Scale asset dialog (input scaling factor)
- Pause asset confirmation
- Kill asset confirmation
- Edit asset config dialog

### Screen 4: Agents Tab
**Sections:**
- Agent status table (all agents)
- Agent detail view (modal)
- Permission management
- Budget status (daily/monthly spend)
- Recent tool calls (audit)

**Columns in Agent Table:**
- Agent name
- Type
- Status (active/paused)
- Daily budget used
- Tools called (today)
- Last action (time)
- Actions (view, enable/disable, override)

**Interactive Elements:**
- Agent enable/disable toggle
- Permission editor dialog
- Budget adjustment dialog
- Override decision dialog

### Screen 5: Jobs & Runs Tab
**Sections:**
- Job queue (running jobs)
- Job history (completed jobs)
- Pending approvals (approval queue)

**Job Detail View:**
- Job ID, type, actor, resource
- Status (pending/approved/executing/completed)
- Input/output data (JSON viewer)
- Start/end times
- Full audit trail (policy, execution, result)

**Approval Queue:**
- Request ID, type, actor, risk score
- Policy reason (why approval needed)
- Approve/reject buttons
- Approval reason text input

**Interactive Elements:**
- Job status filters
- Date range selector
- Approve/reject buttons

### Screen 6: Capital Tab
**Sections:**
- P&L breakdown by asset
- P&L breakdown by category
- Budget allocation by agent
- Budget allocation by asset
- Forecast vs. actual
- Spending rate and headroom

**Interactive Elements:**
- Budget reallocation dialog (shift $ between assets/agents)
- Forecast adjustment
- Spending policy editor

### Screen 7: Compliance Tab
**Sections:**
- Disclosure health (% complete by asset)
- Flagged pages (violations)
- Policy violations by type/severity
- Corrective action status
- Audit trail (compliance changes)

**Interactive Elements:**
- View violation details
- Mark as resolved button
- Bulk resolve button
- Add manual disclosure dialog

### Screen 8: Audit Tab
**Sections:**
- Searchable event ledger
- Filter by: agent, asset, action, date, outcome
- Event detail view (full context)
- Export audit trail
- Verify ledger integrity

**Interactive Elements:**
- Search box (full-text search)
- Filter dropdowns
- Sort controls (date, type, actor)
- Export button (CSV/JSON)
- Verify integrity button

---

## DELIVERABLE 1: BACKEND API (FastAPI)

### File: `src/admin_ui_api.py` (2000 lines)

```python
from fastapi import FastAPI, WebSocket, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

class AdminUIServer:
    """Complete owner control dashboard"""
    
    def __init__(self, port: int = 3000, repo_path: str = "/"):
        self.port = port
        self.repo_path = Path(repo_path)
        self.app = FastAPI(title="Empire AI Admin UI", version="4.0.0")
        self.setup_middleware()
        self.setup_routes()
    
    def setup_middleware(self):
        """Setup CORS, auth, etc."""
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["localhost", "127.0.0.1"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"]
        )
    
    def setup_routes(self):
        """Setup all API routes"""
        
        # ============ AUTH ============
        @self.app.post("/api/auth/login")
        async def login(body: Dict[str, str], request: Request):
            """Admin login"""
            # Verify credentials against authorized list
            # Return session token
            pass
        
        # ============ PORTFOLIO OVERVIEW ============
        @self.app.get("/api/portfolio/overview")
        async def portfolio_overview(user=Depends(verify_auth)):
            """Portfolio overview: revenue, cost, profit, asset counts"""
            # Get all assets from registry
            # Calculate metrics
            # Return summary
            pass
        
        @self.app.get("/api/portfolio/revenue/{period}")
        async def revenue_chart(period: str, user=Depends(verify_auth)):
            """Revenue chart data (30/90/365 days)"""
            # Query ledger for revenue entries
            # Group by date
            # Return time series
            pass
        
        # ============ EMPIRE CONTROL ============
        @self.app.get("/api/empire/status")
        async def empire_status(user=Depends(verify_auth)):
            """System status: Governor, services, uptime"""
            pass
        
        @self.app.post("/api/empire/freeze")
        async def freeze_system(body: Dict[str, str], user=Depends(verify_auth)):
            """Freeze all jobs (emergency stop)"""
            # Call Governor.freeze()
            # Log action
            # Return success
            pass
        
        @self.app.post("/api/empire/kill_switch")
        async def activate_kill_switch(body: Dict[str, str], user=Depends(verify_auth)):
            """Activate kill switch (hard stop)"""
            # Call Governor.kill_switch()
            # Log action
            # Return success
            pass
        
        @self.app.get("/api/empire/governance/policies")
        async def list_policies(user=Depends(verify_auth)):
            """List all governance policies"""
            pass
        
        @self.app.post("/api/empire/governance/policy")
        async def create_policy(body: Dict, user=Depends(verify_auth)):
            """Create new governance policy"""
            pass
        
        @self.app.put("/api/empire/governance/policy/{policy_id}")
        async def update_policy(policy_id: str, body: Dict, user=Depends(verify_auth)):
            """Update governance policy"""
            pass
        
        # ============ ASSETS ============
        @self.app.get("/api/assets")
        async def list_assets(state: str = None, user=Depends(verify_auth)):
            """List all assets, optionally filtered by state"""
            # Query registry
            # Filter by state if provided
            # Return asset list
            pass
        
        @self.app.get("/api/assets/{asset_id}")
        async def get_asset(asset_id: str, user=Depends(verify_auth)):
            """Get asset detail"""
            # Query registry
            # Get health metrics
            # Get financial metrics
            # Get audit trail
            # Return full asset data
            pass
        
        @self.app.post("/api/assets/{asset_id}/scale")
        async def scale_asset(asset_id: str, body: Dict[str, float], user=Depends(verify_auth)):
            """Scale asset"""
            # Call AssetRuntimeManager.scale_asset()
            # Log action
            # Return result
            pass
        
        @self.app.post("/api/assets/{asset_id}/pause")
        async def pause_asset(asset_id: str, body: Dict, user=Depends(verify_auth)):
            """Pause asset"""
            # Call AssetRuntimeManager.pause_asset()
            # Log action
            # Return result
            pass
        
        @self.app.post("/api/assets/{asset_id}/retire")
        async def retire_asset(asset_id: str, body: Dict, user=Depends(verify_auth)):
            """Retire asset permanently"""
            # Call AssetRuntimeManager.retire_asset()
            # Log action
            # Return result
            pass
        
        @self.app.get("/api/assets/{asset_id}/health")
        async def asset_health(asset_id: str, user=Depends(verify_auth)):
            """Get asset health metrics"""
            # Query health table
            # Return current metrics + trend
            pass
        
        # ============ AGENTS ============
        @self.app.get("/api/agents")
        async def list_agents(user=Depends(verify_auth)):
            """List all agents"""
            pass
        
        @self.app.get("/api/agents/{agent_id}")
        async def get_agent(agent_id: str, user=Depends(verify_auth)):
            """Get agent detail"""
            pass
        
        @self.app.post("/api/agents/{agent_id}/enable")
        async def enable_agent(agent_id: str, user=Depends(verify_auth)):
            """Enable agent"""
            pass
        
        @self.app.post("/api/agents/{agent_id}/disable")
        async def disable_agent(agent_id: str, user=Depends(verify_auth)):
            """Disable agent"""
            pass
        
        @self.app.put("/api/agents/{agent_id}/permissions")
        async def update_agent_permissions(agent_id: str, body: Dict, user=Depends(verify_auth)):
            """Update agent permissions"""
            pass
        
        @self.app.put("/api/agents/{agent_id}/budget")
        async def update_agent_budget(agent_id: str, body: Dict, user=Depends(verify_auth)):
            """Update agent budget limit"""
            pass
        
        # ============ JOBS & APPROVALS ============
        @self.app.get("/api/jobs/running")
        async def running_jobs(user=Depends(verify_auth)):
            """Get running jobs"""
            pass
        
        @self.app.get("/api/jobs/history")
        async def job_history(limit: int = 100, user=Depends(verify_auth)):
            """Get job history"""
            pass
        
        @self.app.get("/api/approvals/pending")
        async def pending_approvals(user=Depends(verify_auth)):
            """Get pending approval requests"""
            pass
        
        @self.app.post("/api/approvals/{request_id}/approve")
        async def approve_request(request_id: str, body: Dict, user=Depends(verify_auth)):
            """Approve pending request"""
            pass
        
        @self.app.post("/api/approvals/{request_id}/reject")
        async def reject_request(request_id: str, body: Dict, user=Depends(verify_auth)):
            """Reject pending request"""
            pass
        
        # ============ CAPITAL ============
        @self.app.get("/api/capital/pnl")
        async def pnl_breakdown(period: str = "month", user=Depends(verify_auth)):
            """Get P&L breakdown by asset/category"""
            pass
        
        @self.app.get("/api/capital/allocation")
        async def capital_allocation(user=Depends(verify_auth)):
            """Get capital allocation by agent/asset"""
            pass
        
        @self.app.post("/api/capital/reallocate")
        async def reallocate_capital(body: Dict, user=Depends(verify_auth)):
            """Shift capital between assets/agents"""
            pass
        
        # ============ COMPLIANCE ============
        @self.app.get("/api/compliance/disclosures")
        async def disclosure_health(user=Depends(verify_auth)):
            """Get disclosure compliance status"""
            pass
        
        @self.app.get("/api/compliance/violations")
        async def compliance_violations(user=Depends(verify_auth)):
            """Get flagged compliance violations"""
            pass
        
        # ============ AUDIT ============
        @self.app.get("/api/audit/log")
        async def audit_log(
            actor: str = None,
            action_type: str = None,
            date_from: str = None,
            date_to: str = None,
            limit: int = 100,
            user=Depends(verify_auth)
        ):
            """Search audit ledger"""
            pass
        
        @self.app.get("/api/audit/export")
        async def export_audit(format: str = "csv", user=Depends(verify_auth)):
            """Export audit trail"""
            pass
        
        @self.app.get("/api/audit/verify")
        async def verify_ledger(user=Depends(verify_auth)):
            """Verify ledger integrity"""
            pass
    
    def run(self):
        """Start server"""
        uvicorn.run(self.app, host="0.0.0.0", port=self.port)
```

---

## DELIVERABLE 2: FRONTEND UI (React/TypeScript)

### File Structure
```
static/
  admin-ui/
    src/
      components/
        PortfolioOverview.tsx
        EmpireControl.tsx
        AssetManager.tsx
        AgentManager.tsx
        JobQueue.tsx
        CapitalDashboard.tsx
        ComplianceConsole.tsx
        AuditBrowser.tsx
      pages/
        Dashboard.tsx
        Login.tsx
      hooks/
        useAuth.ts
        useApi.ts
        useWebSocket.ts
      types/
        index.ts (type definitions)
      App.tsx
      index.tsx
    package.json
    tsconfig.json
```

### Key Components

**PortfolioOverview.tsx:**
- Revenue chart (30/90/365 days)
- Cost breakdown (pie chart)
- Profit trend
- Asset status badges
- Real-time refresh

**EmpireControl.tsx:**
- System status grid
- Kill switch button (prominent)
- Freeze system button
- Policy management (add/edit/delete)
- Governance audit view

**AssetManager.tsx:**
- Asset table with pagination
- Detail modal (click asset)
- Scale/pause/retire buttons
- Health metrics graph
- Audit trail for asset

**AgentManager.tsx:**
- Agent status table
- Permission editor
- Budget adjuster
- Tool call history
- Enable/disable toggle

**JobQueue.tsx:**
- Running jobs table
- Job detail modal
- Approval queue (pending)
- Approve/reject buttons
- Job history search

---

## SUCCESS CRITERIA (BINARY)

### For Backend API:

- [ ] **All 8 endpoint groups:** Portfolio, Empire, Assets, Agents, Jobs, Capital, Compliance, Audit
  - Verification: `pytest tests/test_admin_ui_api.py -v` (24+ tests, all pass)

- [ ] **Authentication:** Only authenticated users can access
  - Verification: Unauthenticated request returns 401

- [ ] **Authorization:** Role-based access (some endpoints admin-only)
  - Verification: Non-admin user rejected from admin endpoints

- [ ] **Real data:** No placeholder hardcoded values
  - Verification: Manual test: create asset, verify in `/api/assets`

### For Frontend UI:

- [ ] **All 8 screens:** Implemented and functional
  - Verification: User can navigate to each screen via tabs

- [ ] **Full interactivity:** Owner can perform all operations
  - Verification: User can: scale asset, pause asset, approve job, adjust budget, edit policy, etc.

- [ ] **Real-time updates:** Data refreshes without page reload
  - Verification: Update asset → see change on Portfolio screen (no refresh needed)

- [ ] **Zero CLI required:** All system operations via UI
  - Verification: New user can operate system without touching CLI

### Integration Tests:

- [ ] **End-to-end workflow:** Login → View portfolio → Approve job → Scale asset → View results
  - Verification: `pytest tests/test_admin_ui_e2e.py -v` passes

- [ ] **Concurrent users:** Multiple users don't interfere
  - Verification: 2 users simultaneously perform different actions, no conflicts

- [ ] **Error handling:** Failed operations show user-friendly errors
  - Verification: Try invalid scale factor → get helpful error message

---

## EXECUTION CHECKLIST

**Done via KAIZA write_file:**
- [ ] Create `src/admin_ui_api.py` with all endpoints
- [ ] Create React/TypeScript frontend
- [ ] Create all 8 required screens
- [ ] Create authentication layer
- [ ] Create integration tests
- [ ] Deploy frontend to static server
- [ ] Verify zero CLI operations required
- [ ] Commit with audit log

---

## NEXT STEPS

After Phase 4 completion, system has operational UI. Ready for **Phase 5+**.

---

**END OF PHASE 4 RECOVERY PLAN**
