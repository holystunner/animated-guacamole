────────────────────────────────
PHASE EXECUTION PLAN
────────────────────────────────

1. Phase ID
   Phase 5

2. Phase Name
   Custom Pricing, Billing & Revenue Collection

3. Execution Objective
   Implement a self-contained ledger and payment processing interface to capture value, managing subscriptions/one-time payments without reliance on heavy external SaaS UI (headless Stripe/Crypto only).

4. Scope of Authority
   - Pricing Strategy (CFO role).
   - Accounts Receivable (Tracking invoices/payments).
   - Dynamic Pricing and Invoice Generation.

5. In-Scope Components
   - `billing-engine` (Subscription state machine)
   - `payment-gateway-adaptor` (Stripe/BTC wrapper)
   - `ledger` (Double-entry SQLite table)
   - Admin UI (Revenue Dashboard, Transaction Log)

6. Out-of-Scope (Hard Block)
   - Access granted without proven payment/trial.
   - Customer data encrypted at rest.

7. Preconditions
   - Phase 4 Complete (Public product available).

8. Execution Steps (Ordered, Atomic)
   - Step 1: Initialize `ledger` (Double-entry accounting schema) in SQLite.
   - Step 2: Implement `payment-gateway-adaptor` for headless processing.
   - Step 3: Implement `billing-engine` logic (Checkout Loop, Subscription lifecycles).
   - Step 4: Implement Invoice Generation (PDF receipts).
   - Step 5: Implement Webhook Handling for payment reconciliation.
   - Step 6: Configure Dunning Logic (Retry 3x -> Downgrade).
   - Step 7: Configure Pricing Logic (Support for A/B testing).
   - Step 8: Deploy Admin UI: Revenue Dashboard and Transaction Log.

9. Data & State Created
   - Financial Ledger (Append-only).
   - Customer Accounts/Subscriptions.
   - Invoices.

10. Decision Logic Implemented
    - Dunning Logic: Retry payment 3x over 1 week, then downgrade/remove access.
    - Pricing Logic: Support dynamic/A-B testing.

11. Observability & Audit Hooks
    - Immutable Ledger: Financial records are append-only and hashed.
    - Reconciliation: Daily job checking Bank vs Ledger balance.

12. Failure Conditions
    - Webhook Failure.
    - Double Charge.

13. Rollback Strategy
    - Double Charge: Automated refund logic.
    - Ledger Integrity: Immutable, no rollback of history, only corrective entries.
    - Webhook Failure: Poll API every 15m.

14. Validation Tests (Binary)
    - Test 1: PASS / FAIL (End-to-end payment flow working in Test Mode)
    - Test 2: PASS / FAIL (Double-entry ledger correctly balancing)
    - Test 3: PASS / FAIL (Access automatically revoked upon cancellation)

15. Phase Exit Gate
    - All Validation Tests PASS.
