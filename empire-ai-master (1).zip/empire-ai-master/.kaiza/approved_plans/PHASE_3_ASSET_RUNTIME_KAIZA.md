# PHASE 3: ASSET RUNTIME FACTORY (KAIZA-EXECUTABLE)

**Status:** APPROVED FOR EXECUTION AFTER PHASE 2  
**Objective:** System can reliably generate, test, and launch real revenue-generating assets at scale. Deployed assets exist and generate revenue.  
**Duration:** 7-9 weeks  
**Authority:** EMPIRE_AI_CANONICAL_SPECIFICATION.md v1.0 (Section 2, Layer 4)  

---

## BINDING CONSTRAINTS

1. **Real deployed assets** (not mocks or stubs)
2. **Asset lifecycle states** enforced (draft → active → scaling → paused → retired)
3. **Asset metadata tracked** (ROI, cost, revenue, health)
4. **Assets run independently** on deployed infrastructure
5. **Health monitoring** continuous and automated
6. **Clean asset disposal** (deletion doesn't cascade)
7. **Autonomous deployment** via job queue
8. **Zero stubs, no mocks, no placeholder URLs**

---

## DELIVERABLE 1: ASSET RUNTIME ENGINE

### New File: `src/asset_runtime.py` (1200 lines)

```python
class AssetLifecycleState(Enum):
    DRAFT = "draft"          # Created, not deployed
    ACTIVE = "active"        # Running, generating revenue
    SCALING = "scaling"      # Actively optimizing
    PAUSED = "paused"        # Temporarily stopped
    RETIRED = "retired"      # Permanently deactivated

@dataclass
class AssetMetadata:
    asset_id: str
    asset_type: str  # content_cluster, tool_site, lead_gen, data_product, micro_saas, marketplace
    owner: str  # Agent that created it
    state: AssetLifecycleState
    created_at: datetime
    deployed_at: Optional[datetime]
    paused_at: Optional[datetime]
    retired_at: Optional[datetime]
    
    # Financial
    total_revenue: float = 0.0
    total_cost: float = 0.0
    monthly_revenue: float = 0.0
    monthly_cost: float = 0.0
    roi: float = 0.0
    
    # Health
    error_rate: float = 0.0
    uptime_percent: float = 100.0
    last_health_check: Optional[datetime] = None
    
    # Content
    content_id: Optional[str] = None
    deployment_url: Optional[str] = None
    domain: Optional[str] = None
    
    # Versioning
    current_version: str = "1.0.0"
    versions: List[str] = None

class AssetRuntimeManager:
    """Manages asset lifecycle and deployment"""
    
    def __init__(self, repo_path: str):
        self.repo_path = Path(repo_path)
        self.registry = Registry(repo_path)
        self.ledger = UniversalLedger(repo_path)
        self.job_executor = JobExecutor(repo_path)
        self.infra_manager = InfrastructureManager(repo_path)  # New, see Deliverable 3
        self._init_asset_db()
    
    def _init_asset_db(self):
        """Initialize asset tracking database"""
        # SQL Schema:
        # - assets table (asset_id, asset_type, owner, state, created_at, etc.)
        # - asset_versions table (asset_id, version, content_hash, deployed_at, etc.)
        # - asset_health table (asset_id, timestamp, uptime, errors, metrics)
        # - asset_revenue table (asset_id, date, revenue, cost, source)
    
    def create_asset(self, asset_type: str, owner: str, config: Dict[str, Any]) -> str:
        """Create new asset in DRAFT state"""
        asset_id = str(uuid.uuid4())
        
        metadata = AssetMetadata(
            asset_id=asset_id,
            asset_type=asset_type,
            owner=owner,
            state=AssetLifecycleState.DRAFT,
            created_at=datetime.utcnow()
        )
        
        # Register in registry
        self.registry.register_asset(asset_id, asset_type, asdict(metadata))
        
        # Log to ledger
        self.ledger.log_action(
            actor=owner,
            action_type="asset_created",
            resource_id=asset_id,
            input_data=config,
            output_data={"asset_id": asset_id},
            result="success",
            reason=f"Created {asset_type} asset"
        )
        
        return asset_id
    
    def deploy_asset(self, asset_id: str, approved_by: str = None) -> Dict[str, Any]:
        """Deploy asset from DRAFT to ACTIVE"""
        metadata = self.registry.get_asset(asset_id)
        if not metadata:
            return {"success": False, "error": f"Asset {asset_id} not found"}
        
        if metadata["state"] != AssetLifecycleState.DRAFT.value:
            return {"success": False, "error": f"Asset must be in DRAFT state, is {metadata['state']}"}
        
        try:
            # 1. Allocate infrastructure
            deployment = self.infra_manager.allocate_asset(asset_id, metadata["asset_type"])
            if not deployment["success"]:
                return {"success": False, "error": f"Infrastructure allocation failed: {deployment.get('error')}"}
            
            # 2. Deploy code/content
            deploy_result = self.infra_manager.deploy_code(
                asset_id,
                deployment["server_id"],
                metadata.get("code_ref")
            )
            if not deploy_result["success"]:
                self.infra_manager.deallocate_asset(asset_id)
                return {"success": False, "error": f"Code deployment failed: {deploy_result.get('error')}"}
            
            # 3. Update metadata
            metadata["state"] = AssetLifecycleState.ACTIVE.value
            metadata["deployed_at"] = datetime.utcnow().isoformat()
            metadata["deployment_url"] = deploy_result["url"]
            metadata["domain"] = deployment["domain"]
            self.registry.update_asset_state(asset_id, AssetLifecycleState.ACTIVE.value)
            
            # 4. Start health monitoring
            self._start_health_monitoring(asset_id)
            
            # 5. Log to ledger
            self.ledger.log_action(
                actor=approved_by or "system",
                action_type="asset_deployed",
                resource_id=asset_id,
                input_data={"asset_type": metadata["asset_type"]},
                output_data={"url": deploy_result["url"], "domain": deployment["domain"]},
                result="success",
                reason="Asset deployed and active"
            )
            
            return {
                "success": True,
                "asset_id": asset_id,
                "url": deploy_result["url"],
                "domain": deployment["domain"]
            }
        
        except Exception as e:
            self.ledger.log_action(
                actor="system",
                action_type="asset_deployment_failed",
                resource_id=asset_id,
                input_data={},
                output_data={"error": str(e)},
                result="fail",
                reason=str(e)
            )
            return {"success": False, "error": str(e)}
    
    def scale_asset(self, asset_id: str, scaling_factor: float = 1.5) -> Dict[str, Any]:
        """Scale asset to handle more traffic/revenue"""
        metadata = self.registry.get_asset(asset_id)
        if not metadata:
            return {"success": False, "error": f"Asset {asset_id} not found"}
        
        if metadata["state"] not in [AssetLifecycleState.ACTIVE.value, AssetLifecycleState.SCALING.value]:
            return {"success": False, "error": f"Can only scale ACTIVE or SCALING assets"}
        
        try:
            # Allocate additional resources
            scaling_result = self.infra_manager.scale_asset(asset_id, scaling_factor)
            if not scaling_result["success"]:
                return {"success": False, "error": f"Scaling failed: {scaling_result.get('error')}"}
            
            # Update state to SCALING
            metadata["state"] = AssetLifecycleState.SCALING.value
            self.registry.update_asset_state(asset_id, AssetLifecycleState.SCALING.value)
            
            # Log to ledger
            self.ledger.log_action(
                actor="system",
                action_type="asset_scaled",
                resource_id=asset_id,
                input_data={"scaling_factor": scaling_factor},
                output_data=scaling_result,
                result="success",
                reason=f"Scaled by {scaling_factor}x"
            )
            
            return {"success": True, "asset_id": asset_id, "new_resources": scaling_result}
        
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def pause_asset(self, asset_id: str, paused_by: str = None) -> Dict[str, Any]:
        """Pause asset (temporary deactivation)"""
        metadata = self.registry.get_asset(asset_id)
        if not metadata:
            return {"success": False, "error": f"Asset {asset_id} not found"}
        
        try:
            # Pause services
            pause_result = self.infra_manager.pause_asset(asset_id)
            if not pause_result["success"]:
                return {"success": False, "error": f"Pause failed: {pause_result.get('error')}"}
            
            # Update state
            metadata["state"] = AssetLifecycleState.PAUSED.value
            metadata["paused_at"] = datetime.utcnow().isoformat()
            self.registry.update_asset_state(asset_id, AssetLifecycleState.PAUSED.value)
            
            # Log to ledger
            self.ledger.log_action(
                actor=paused_by or "system",
                action_type="asset_paused",
                resource_id=asset_id,
                input_data={},
                output_data={},
                result="success",
                reason="Asset paused (temporary)"
            )
            
            return {"success": True, "asset_id": asset_id}
        
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def retire_asset(self, asset_id: str, retired_by: str = None) -> Dict[str, Any]:
        """Retire asset permanently (cleanup and deactivate)"""
        metadata = self.registry.get_asset(asset_id)
        if not metadata:
            return {"success": False, "error": f"Asset {asset_id} not found"}
        
        try:
            # Stop health monitoring
            self._stop_health_monitoring(asset_id)
            
            # Deallocate infrastructure
            dealloc_result = self.infra_manager.deallocate_asset(asset_id)
            if not dealloc_result["success"]:
                return {"success": False, "error": f"Deallocation failed: {dealloc_result.get('error')}"}
            
            # Update state
            metadata["state"] = AssetLifecycleState.RETIRED.value
            metadata["retired_at"] = datetime.utcnow().isoformat()
            self.registry.update_asset_state(asset_id, AssetLifecycleState.RETIRED.value)
            
            # Log to ledger
            self.ledger.log_action(
                actor=retired_by or "system",
                action_type="asset_retired",
                resource_id=asset_id,
                input_data={"final_roi": metadata.get("roi")},
                output_data={},
                result="success",
                reason="Asset permanently retired"
            )
            
            return {"success": True, "asset_id": asset_id}
        
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def get_asset_health(self, asset_id: str) -> Dict[str, Any]:
        """Get asset health metrics"""
        # Query health monitoring data
        # Return: uptime, error_rate, response_time, last_check
        pass
    
    def _start_health_monitoring(self, asset_id: str):
        """Start continuous health monitoring for asset"""
        # Spawn health monitor task
        # Check every 5 minutes
        # Log to health table
        pass
    
    def _stop_health_monitoring(self, asset_id: str):
        """Stop health monitoring for asset"""
        # Cancel health monitor task
        pass
```

---

## DELIVERABLE 2: ASSET TYPES

### 2.1 Content Cluster

**File: `src/assets/content_cluster.py`**

```python
class ContentCluster:
    """Multiple blog posts + product roundups + affiliate links"""
    
    def build(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Build content cluster"""
        # config = {
        #     "topic": "keyword research",
        #     "posts": 5,
        #     "roundup_products": 10,
        #     "internal_links": True,
        #     "affiliate_network": "amazon"
        # }
        
        # Generate 5 blog posts
        posts = self._generate_posts(config["topic"], config["posts"])
        
        # Generate product roundup
        roundup = self._generate_roundup(config["affiliate_network"], config["roundup_products"])
        
        # Generate internal links
        if config.get("internal_links"):
            links = self._generate_internal_links(posts)
        
        return {
            "posts": posts,
            "roundup": roundup,
            "links": links,
            "deployment_package": self._create_package(posts, roundup, links)
        }
```

### 2.2 Tool/Utility Site

**File: `src/assets/tool_site.py`**

```python
class ToolSite:
    """Single-page utility (calculator, converter, etc.)"""
    
    def build(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Build utility tool"""
        # config = {
        #     "tool_type": "calculator",  # calculator, converter, analyzer, etc.
        #     "name": "Mortgage Calculator",
        #     "features": [...],
        #     "revenue_model": "adsense"
        # }
        
        code = self._generate_tool_code(config)
        landing_page = self._generate_landing_page(config)
        
        return {
            "code": code,
            "landing_page": landing_page,
            "deployment_package": self._create_package(code, landing_page)
        }
```

### 2.3 Lead Generation Page

**File: `src/assets/lead_gen_page.py`**

```python
class LeadGenPage:
    """Email capture + nurture funnel"""
    
    def build(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Build lead gen page"""
        # config = {
        #     "topic": "email marketing",
        #     "form_fields": ["name", "email", "phone"],
        #     "email_provider": "mailchimp",
        #     "landing_page_variants": 3
        # }
        
        landing_pages = self._generate_landing_page_variants(config)
        form = self._generate_form(config["form_fields"])
        email_integration = self._setup_email_integration(config["email_provider"])
        
        return {
            "landing_pages": landing_pages,
            "form": form,
            "integration": email_integration,
            "deployment_package": self._create_package(landing_pages, form)
        }
```

---

## DELIVERABLE 3: INFRASTRUCTURE MANAGER

### New File: `src/infrastructure_manager.py` (800 lines)

```python
class InfrastructureManager:
    """Manages asset deployment and infrastructure allocation"""
    
    def __init__(self, repo_path: str):
        self.repo_path = Path(repo_path)
        self.ledger = UniversalLedger(repo_path)
        self._init_infra_db()
    
    def allocate_asset(self, asset_id: str, asset_type: str) -> Dict[str, Any]:
        """Allocate compute, storage, domain for asset"""
        try:
            # 1. Allocate server
            server = self._allocate_server(asset_type)
            if not server:
                return {"success": False, "error": "No available servers"}
            
            # 2. Allocate domain
            domain = self._allocate_domain(asset_id)
            if not domain:
                self._deallocate_server(server["id"])
                return {"success": False, "error": "Domain allocation failed"}
            
            # 3. Create DNS records
            dns_result = self._setup_dns(domain, server["ip"])
            if not dns_result["success"]:
                return {"success": False, "error": "DNS setup failed"}
            
            # 4. Log allocation
            self.ledger.log_action(
                actor="infrastructure",
                action_type="asset_allocated",
                resource_id=asset_id,
                input_data={"asset_type": asset_type},
                output_data={"server_id": server["id"], "domain": domain},
                result="success"
            )
            
            return {
                "success": True,
                "server_id": server["id"],
                "domain": domain,
                "ip": server["ip"]
            }
        
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def deploy_code(self, asset_id: str, server_id: str, code_ref: str) -> Dict[str, Any]:
        """Deploy code to server"""
        try:
            # 1. Fetch code from git repo
            code = self._fetch_code(code_ref)
            
            # 2. Deploy to server
            deploy_result = self._deploy_to_server(server_id, code)
            if not deploy_result["success"]:
                return {"success": False, "error": "Deployment failed"}
            
            # 3. Verify deployment
            verification = self._verify_deployment(asset_id, deploy_result["url"])
            if not verification["success"]:
                return {"success": False, "error": "Verification failed"}
            
            # 4. Log deployment
            self.ledger.log_action(
                actor="infrastructure",
                action_type="code_deployed",
                resource_id=asset_id,
                input_data={"code_ref": code_ref, "server_id": server_id},
                output_data={"url": deploy_result["url"]},
                result="success"
            )
            
            return {
                "success": True,
                "url": deploy_result["url"],
                "status": "deployed"
            }
        
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def scale_asset(self, asset_id: str, scaling_factor: float) -> Dict[str, Any]:
        """Add resources to handle higher load"""
        # Allocate additional servers if needed
        # Increase cache, CDN, etc.
        # Update load balancer
        pass
    
    def pause_asset(self, asset_id: str) -> Dict[str, Any]:
        """Pause asset services"""
        # Stop web server, background jobs
        # Keep storage intact
        pass
    
    def deallocate_asset(self, asset_id: str) -> Dict[str, Any]:
        """Free up all resources for asset"""
        # Delete code
        # Release domain
        # Deallocate server
        # Clear storage
        # Log deallocation
        pass
```

---

## SUCCESS CRITERIA (BINARY)

### For Asset Runtime:

- [ ] **Create asset:** Asset created in DRAFT state
  - Verification: `AssetRuntimeManager.create_asset()` returns asset_id
  
- [ ] **Deploy asset:** Asset transitions DRAFT → ACTIVE
  - Verification: `AssetRuntimeManager.deploy_asset()` succeeds, asset accessible
  
- [ ] **Asset accessible:** Asset URL responds (HTTP 200)
  - Verification: `curl https://asset-url` returns valid HTML
  
- [ ] **Health monitoring:** Asset health tracked continuously
  - Verification: `AssetRuntimeManager.get_asset_health()` returns metrics

### For Asset Types:

- [ ] **Content Cluster:** Deployable blog site
  - Verification: Deployed cluster generates index, posts, roundup pages
  
- [ ] **Tool Site:** Functional calculator/tool
  - Verification: Deployed tool accepts input, returns calculation
  
- [ ] **Lead Gen Page:** Form captures emails
  - Verification: Form submission creates lead in email provider

### Integration Tests:

- [ ] **Full asset lifecycle:** Draft → Active → Scaling → Paused → Retired
  - Verification: `pytest tests/test_asset_lifecycle.py -v` passes
  
- [ ] **Multiple assets coexist:** 5 assets running simultaneously
  - Verification: Deploy 5 assets, all accessible, all monitored
  
- [ ] **Asset retirement:** Retired asset deleted, no resources leaked
  - Verification: `AssetRuntimeManager.retire_asset()` cleans up all infra

---

## EXECUTION CHECKLIST

**Done via KAIZA write_file:**
- [ ] Create `src/asset_runtime.py`
- [ ] Create asset type implementations
- [ ] Create `src/infrastructure_manager.py`
- [ ] Create integration tests
- [ ] Deploy first real asset
- [ ] Verify asset generates revenue
- [ ] Commit with audit log

---

## NEXT STEPS

After Phase 3 completion, system has real deployed assets. Ready for **Phase 4: Autonomous Scaling & Iteration**.

---

**END OF PHASE 3 RECOVERY PLAN**
