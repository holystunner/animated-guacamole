# PHASE 2: AGENT ECONOMY (KAIZA-EXECUTABLE)

**Status:** APPROVED FOR EXECUTION AFTER PHASE 1  
**Objective:** Implement seven specialized agents with explicit permission boundaries. No agent can escalate permissions.  
**Duration:** 8-12 weeks  
**Authority:** EMPIRE_AI_CANONICAL_SPECIFICATION.md v1.0 (Section 2, Layer 3)  

---

## BINDING CONSTRAINTS

1. **Seven agent types defined** (Scout, Builder, Writer, QA/Verifier, Growth, Finance, Compliance)
2. **Permission model enforced** (each agent has explicit envelope)
3. **No permission escalation** (agents cannot modify own permissions)
4. **All tool calls logged** (attributed to agent, action logged)
5. **No agent can sabotage other agents** (sandbox isolation)
6. **Budget ceilings per agent** (enforced by Governor)
7. **No stubs**, no mocks, no placeholder implementations
8. **Written via KAIZA write_file** (auditability)

---

## DELIVERABLE 1: AGENT FRAMEWORK

### New File: `src/agent_framework.py` (1000 lines)

#### Core Agent Interface

```python
from abc import ABC, abstractmethod
from enum import Enum
from dataclasses import dataclass
from typing import Dict, Any, List, Optional

class AgentType(Enum):
    SCOUT = "scout"
    BUILDER = "builder"
    WRITER = "writer"
    QA_VERIFIER = "qa_verifier"
    GROWTH = "growth"
    FINANCE = "finance"
    COMPLIANCE = "compliance"

class Permission(Enum):
    READ = "read"
    WRITE = "write"
    DEPLOY = "deploy"
    PAY = "pay"
    KILL = "kill"

@dataclass
class AgentPermissionEnvelope:
    agent_id: str
    agent_type: AgentType
    allowed_tools: List[str]  # e.g., ["fetch_web", "git_commit", "deploy"]
    allowed_permissions: List[Permission]  # What this agent can do
    allowed_asset_domains: List[str]  # Which asset types (content, tools, leads, data)
    daily_budget_limit: float  # Max $ spend per day
    monthly_budget_limit: float  # Max $ spend per month
    cpu_limit_percent: float  # Max CPU % usage
    can_approve_jobs: bool = False  # If True, can approve other agents' jobs
    can_modify_governance: bool = False  # Should be False for all agents

class BaseAgent(ABC):
    """Base class for all agents"""
    
    def __init__(self, agent_id: str, repo_path: str):
        self.agent_id = agent_id
        self.repo_path = Path(repo_path)
        self.registry = Registry(repo_path)
        self.ledger = UniversalLedger(repo_path)
        self.governor = Governor(repo_path)
        self.job_executor = JobExecutor(repo_path)
        self.permissions = self._load_permissions()
    
    def _load_permissions(self) -> AgentPermissionEnvelope:
        """Load agent permissions from registry"""
        # Query registry for agent_id
        # Return permission envelope
        # If not found, raise error (don't create default)
    
    @abstractmethod
    def execute(self, job_id: str) -> Dict[str, Any]:
        """Execute assigned job"""
        pass
    
    def call_tool(self, tool_name: str, tool_args: Dict[str, Any]) -> Dict[str, Any]:
        """Call a tool with permission check"""
        # 1. Verify tool_name in self.permissions.allowed_tools
        if tool_name not in self.permissions.allowed_tools:
            error = f"Agent {self.agent_id} not permitted to call {tool_name}"
            self.ledger.log_action(
                actor=self.agent_id,
                action_type="tool_call_denied",
                resource_id=tool_name,
                input_data=tool_args,
                output_data={},
                result="denied",
                reason=f"Permission denied: {tool_name}"
            )
            raise PermissionError(error)
        
        # 2. Check budget
        daily_spent = self._get_daily_spend()
        if daily_spent + estimated_cost > self.permissions.daily_budget_limit:
            self.ledger.log_action(
                actor=self.agent_id,
                action_type="tool_call_denied",
                resource_id=tool_name,
                input_data=tool_args,
                output_data={},
                result="denied",
                reason="Daily budget limit exceeded"
            )
            raise PermissionError("Daily budget limit exceeded")
        
        # 3. Log tool call
        tool_call_id = str(uuid.uuid4())
        self.ledger.log_action(
            actor=self.agent_id,
            action_type="tool_call",
            resource_id=tool_name,
            input_data=tool_args,
            output_data={},
            result="pending"
        )
        
        # 4. Execute tool
        try:
            result = self._execute_tool(tool_name, tool_args)
            
            # 5. Log result
            self.ledger.log_action(
                actor=self.agent_id,
                action_type="tool_call",
                resource_id=tool_name,
                input_data=tool_args,
                output_data=result,
                result="success"
            )
            
            return result
        
        except Exception as e:
            # 6. Log failure
            self.ledger.log_action(
                actor=self.agent_id,
                action_type="tool_call",
                resource_id=tool_name,
                input_data=tool_args,
                output_data={"error": str(e)},
                result="fail",
                reason=str(e)
            )
            raise
    
    def submit_job(self, job_type: str, resource_id: str, input_data: Dict) -> Dict[str, Any]:
        """Submit a job (goes through Governor)"""
        job_request = JobRequest(
            job_id=str(uuid.uuid4()),
            job_type=job_type,
            actor=self.agent_id,
            resource_id=resource_id,
            input_data=input_data
        )
        
        return self.job_executor.submit_job(job_request)
    
    def _get_daily_spend(self) -> float:
        """Get today's cumulative spending"""
        # Query ledger for all tool calls by this agent TODAY
        # Sum up costs
        # Return total
        pass
    
    def _execute_tool(self, tool_name: str, tool_args: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a tool (implementation in subclass)"""
        # Map tool_name to actual tool implementation
        # Call with tool_args
        # Return result
        pass
```

---

## DELIVERABLE 2: SEVEN AGENT IMPLEMENTATIONS

### 2.1 Scout Agent

**File: `src/agents/scout_agent.py`**

```python
class ScoutAgent(BaseAgent):
    """Discovers opportunities: keywords, niches, products, gaps"""
    
    def __init__(self, agent_id: str, repo_path: str):
        super().__init__(agent_id, repo_path)
        self.agent_type = AgentType.SCOUT
        
        # Verify permissions
        if Permission.READ not in self.permissions.allowed_permissions:
            raise PermissionError(f"Scout {agent_id} lacks read permission")
    
    def execute(self, job_id: str) -> Dict[str, Any]:
        """Scout for opportunities"""
        job_status = self.job_executor.get_job_status(job_id)
        if not job_status["success"]:
            return {"success": False, "error": "Job not found"}
        
        input_data = job_status.get("input_data", {})
        keywords = input_data.get("keywords", [])
        domains = input_data.get("domains", [])
        
        opportunities = []
        for keyword in keywords:
            # Call tool: web_fetch
            result = self.call_tool("fetch_web", {
                "query": keyword,
                "top_results": 20
            })
            
            # Analyze results
            opportunities.extend(self._analyze_results(keyword, result))
        
        return {
            "success": True,
            "opportunities": opportunities,
            "count": len(opportunities)
        }
    
    def _analyze_results(self, keyword: str, results: Dict) -> List[Dict]:
        """Analyze search results for opportunities"""
        # Parse results
        # Extract opportunities (low-hanging fruit)
        # Return list of opportunity dicts
        pass
```

### 2.2 Builder Agent

**File: `src/agents/builder_agent.py`**

```python
class BuilderAgent(BaseAgent):
    """Generates code, integrates templates, deploys code"""
    
    def __init__(self, agent_id: str, repo_path: str):
        super().__init__(agent_id, repo_path)
        self.agent_type = AgentType.BUILDER
        
        # Verify permissions
        required = [Permission.WRITE, Permission.DEPLOY]
        for perm in required:
            if perm not in self.permissions.allowed_permissions:
                raise PermissionError(f"Builder {agent_id} lacks {perm.value} permission")
    
    def execute(self, job_id: str) -> Dict[str, Any]:
        """Build and deploy asset"""
        job_status = self.job_executor.get_job_status(job_id)
        if not job_status["success"]:
            return {"success": False, "error": "Job not found"}
        
        input_data = job_status.get("input_data", {})
        asset_type = input_data.get("asset_type")
        asset_config = input_data.get("config")
        
        # Generate code
        code_result = self.call_tool("generate_code", {
            "asset_type": asset_type,
            "config": asset_config
        })
        
        # Commit to repo
        commit_result = self.call_tool("git_commit", {
            "files": code_result["files"],
            "message": f"Generated {asset_type}: {asset_config.get('name')}"
        })
        
        # Deploy
        deploy_result = self.call_tool("deploy_asset", {
            "asset_id": asset_config.get("asset_id"),
            "code_ref": commit_result["commit_hash"]
        })
        
        return {
            "success": True,
            "asset_id": asset_config.get("asset_id"),
            "commit_hash": commit_result["commit_hash"],
            "deployed_url": deploy_result.get("url")
        }
```

### 2.3 Writer Agent

**File: `src/agents/writer_agent.py`**

```python
class WriterAgent(BaseAgent):
    """Generates/rewrites content, metadata, variants"""
    
    def __init__(self, agent_id: str, repo_path: str):
        super().__init__(agent_id, repo_path)
        self.agent_type = AgentType.WRITER
        
        if Permission.WRITE not in self.permissions.allowed_permissions:
            raise PermissionError(f"Writer {agent_id} lacks write permission")
    
    def execute(self, job_id: str) -> Dict[str, Any]:
        """Write and publish content"""
        job_status = self.job_executor.get_job_status(job_id)
        input_data = job_status.get("input_data", {})
        
        topic = input_data.get("topic")
        style = input_data.get("style", "professional")
        
        # Generate content
        content_result = self.call_tool("generate_content", {
            "topic": topic,
            "style": style,
            "length": input_data.get("length", 2000)
        })
        
        # Generate metadata
        metadata_result = self.call_tool("generate_metadata", {
            "content": content_result["text"],
            "topic": topic
        })
        
        # Create asset (without publishing yet)
        asset_config = {
            "asset_id": str(uuid.uuid4()),
            "content": content_result["text"],
            "metadata": metadata_result,
            "status": "draft"
        }
        
        return {
            "success": True,
            "asset_id": asset_config["asset_id"],
            "content_length": len(content_result["text"]),
            "status": "draft"  # Ready for QA/Verifier review
        }
```

### 2.4 QA/Verifier Agent

**File: `src/agents/qa_verifier_agent.py`**

```python
class QAVerifierAgent(BaseAgent):
    """Validates claims, checks compliance, verifies structure"""
    
    def __init__(self, agent_id: str, repo_path: str):
        super().__init__(agent_id, repo_path)
        self.agent_type = AgentType.QA_VERIFIER
        
        if Permission.READ not in self.permissions.allowed_permissions:
            raise PermissionError(f"QA {agent_id} lacks read permission")
    
    def execute(self, job_id: str) -> Dict[str, Any]:
        """Verify asset quality and compliance"""
        job_status = self.job_executor.get_job_status(job_id)
        input_data = job_status.get("input_data", {})
        
        asset_id = input_data.get("asset_id")
        asset = self.registry.get_asset(asset_id)
        
        violations = []
        
        # Check 1: Content quality
        quality_result = self.call_tool("check_content_quality", {
            "content": asset.get("content"),
            "min_score": 7.0
        })
        if not quality_result.get("passes"):
            violations.append({
                "type": "quality",
                "score": quality_result.get("score"),
                "details": quality_result.get("issues")
            })
        
        # Check 2: Compliance
        compliance_result = self.call_tool("check_compliance", {
            "asset_id": asset_id,
            "asset_type": asset.get("asset_type"),
            "content": asset.get("content")
        })
        if compliance_result.get("violations"):
            violations.extend(compliance_result["violations"])
        
        # Check 3: Structure
        structure_result = self.call_tool("check_structure", {
            "asset_id": asset_id
        })
        if not structure_result.get("valid"):
            violations.append({
                "type": "structure",
                "details": structure_result.get("errors")
            })
        
        # Return verdict
        if violations:
            return {
                "success": True,
                "verdict": "rejected",
                "violations": violations,
                "status": "blocked"
            }
        else:
            return {
                "success": True,
                "verdict": "approved",
                "violations": [],
                "status": "ready_for_publish"
            }
```

### 2.5 Growth Agent

**File: `src/agents/growth_agent.py`**

```python
class GrowthAgent(BaseAgent):
    """Optimizes assets: links, CTR, internal SEO, experiments"""
    
    def __init__(self, agent_id: str, repo_path: str):
        super().__init__(agent_id, repo_path)
        self.agent_type = AgentType.GROWTH
        
        required = [Permission.WRITE, Permission.DEPLOY]
        for perm in required:
            if perm not in self.permissions.allowed_permissions:
                raise PermissionError(f"Growth {agent_id} lacks {perm.value}")
    
    def execute(self, job_id: str) -> Dict[str, Any]:
        """Optimize asset performance"""
        job_status = self.job_executor.get_job_status(job_id)
        input_data = job_status.get("input_data", {})
        
        asset_id = input_data.get("asset_id")
        asset = self.registry.get_asset(asset_id)
        
        optimizations = []
        
        # Optimization 1: Internal linking
        linking_result = self.call_tool("optimize_internal_links", {
            "asset_id": asset_id,
            "content": asset.get("content")
        })
        if linking_result.get("links_added"):
            optimizations.append({
                "type": "linking",
                "links_added": linking_result["links_added"]
            })
        
        # Optimization 2: SEO improvements
        seo_result = self.call_tool("optimize_seo", {
            "asset_id": asset_id,
            "metadata": asset.get("metadata")
        })
        if seo_result.get("improvements"):
            optimizations.append({
                "type": "seo",
                "improvements": seo_result["improvements"]
            })
        
        # Optimization 3: A/B test
        if input_data.get("run_experiments", False):
            experiment_result = self.call_tool("run_experiment", {
                "asset_id": asset_id,
                "variants": input_data.get("variants", 2)
            })
            optimizations.append({
                "type": "experiment",
                "variants_tested": experiment_result.get("variant_count")
            })
        
        return {
            "success": True,
            "optimizations_applied": len(optimizations),
            "details": optimizations
        }
```

### 2.6 Finance Agent

**File: `src/agents/finance_agent.py`**

```python
class FinanceAgent(BaseAgent):
    """Forecasts ROI, recommends budget shifts, kills candidates"""
    
    def __init__(self, agent_id: str, repo_path: str):
        super().__init__(agent_id, repo_path)
        self.agent_type = AgentType.FINANCE
        
        if Permission.READ not in self.permissions.allowed_permissions:
            raise PermissionError(f"Finance {agent_id} lacks read permission")
    
    def execute(self, job_id: str) -> Dict[str, Any]:
        """Analyze portfolio and recommend actions"""
        # Get all assets
        assets = self.registry.get_all_assets()
        
        roi_analysis = []
        recommendations = []
        
        for asset in assets:
            # Calculate ROI
            revenue = asset.get("monthly_revenue", 0)
            cost = asset.get("monthly_cost", 0)
            
            if cost > 0:
                roi = (revenue - cost) / cost
            else:
                roi = float('inf')
            
            roi_analysis.append({
                "asset_id": asset["asset_id"],
                "roi": roi,
                "revenue": revenue,
                "cost": cost
            })
            
            # Make recommendations
            if roi < 0:
                recommendations.append({
                    "action": "kill",
                    "asset_id": asset["asset_id"],
                    "reason": f"Negative ROI: {roi:.2f}",
                    "confidence": 0.95
                })
            elif roi > 3.0:
                recommendations.append({
                    "action": "scale",
                    "asset_id": asset["asset_id"],
                    "reason": f"High ROI: {roi:.2f}",
                    "confidence": 0.90
                })
        
        return {
            "success": True,
            "roi_analysis": roi_analysis,
            "recommendations": recommendations
        }
```

### 2.7 Compliance Agent

**File: `src/agents/compliance_agent.py`**

```python
class ComplianceAgent(BaseAgent):
    """Enforces affiliate rules, disclosures, forbidden content"""
    
    def __init__(self, agent_id: str, repo_path: str):
        super().__init__(agent_id, repo_path)
        self.agent_type = AgentType.COMPLIANCE
        
        if Permission.READ not in self.permissions.allowed_permissions:
            raise PermissionError(f"Compliance {agent_id} lacks read permission")
    
    def execute(self, job_id: str) -> Dict[str, Any]:
        """Check all assets for compliance violations"""
        assets = self.registry.get_all_assets(state="active")
        
        violations = []
        
        for asset in assets:
            # Check 1: Affiliate disclosures
            affiliate_check = self.call_tool("check_affiliate_disclosures", {
                "asset_id": asset["asset_id"],
                "content": asset.get("content")
            })
            if affiliate_check.get("violations"):
                violations.extend([{
                    "asset_id": asset["asset_id"],
                    "type": "affiliate_disclosure",
                    **v
                } for v in affiliate_check["violations"]])
            
            # Check 2: Forbidden content
            content_check = self.call_tool("check_forbidden_content", {
                "asset_id": asset["asset_id"],
                "content": asset.get("content")
            })
            if content_check.get("violations"):
                violations.extend([{
                    "asset_id": asset["asset_id"],
                    "type": "forbidden_content",
                    **v
                } for v in content_check["violations"]])
            
            # Check 3: Required disclosures
            disclosure_check = self.call_tool("check_required_disclosures", {
                "asset_id": asset["asset_id"],
                "asset_type": asset.get("asset_type")
            })
            if disclosure_check.get("violations"):
                violations.extend([{
                    "asset_id": asset["asset_id"],
                    "type": "missing_disclosure",
                    **v
                } for v in disclosure_check["violations"]])
        
        return {
            "success": True,
            "violations_found": len(violations),
            "violations": violations
        }
```

---

## DELIVERABLE 3: PERMISSION ENFORCEMENT

### New File: `src/permission_enforcer.py` (400 lines)

```python
class PermissionEnforcer:
    """Enforces agent permission boundaries"""
    
    def __init__(self, repo_path: str):
        self.repo_path = Path(repo_path)
        self.registry = Registry(repo_path)
        self.ledger = UniversalLedger(repo_path)
    
    def verify_agent_can_call_tool(self, agent_id: str, tool_name: str) -> Tuple[bool, str]:
        """Verify agent has permission to call tool"""
        agent = self.registry.get_agent(agent_id)
        if not agent:
            return False, f"Agent {agent_id} not found"
        
        if tool_name not in agent["permissions"]["allowed_tools"]:
            return False, f"Agent {agent_id} not permitted to call {tool_name}"
        
        return True, "OK"
    
    def verify_agent_within_budget(self, agent_id: str) -> Tuple[bool, str]:
        """Verify agent hasn't exceeded budget limit"""
        agent = self.registry.get_agent(agent_id)
        daily_spent = self._get_daily_spend(agent_id)
        daily_limit = agent["permissions"]["daily_budget_limit"]
        
        if daily_spent >= daily_limit:
            return False, f"Daily budget limit reached: ${daily_limit}"
        
        return True, "OK"
    
    def prevent_permission_escalation(self, agent_id: str, requested_permissions: List[str]) -> Tuple[bool, str]:
        """Prevent agent from escalating own permissions"""
        agent = self.registry.get_agent(agent_id)
        current = set(agent["permissions"]["allowed_permissions"])
        requested = set(requested_permissions)
        
        if requested > current:
            # Trying to add new permissions
            self.ledger.log_action(
                actor=agent_id,
                action_type="permission_escalation_attempt",
                resource_id=agent_id,
                input_data={"requested": list(requested)},
                output_data={},
                result="denied",
                reason="Agents cannot escalate own permissions"
            )
            return False, "Permission escalation not allowed"
        
        return True, "OK"
    
    def _get_daily_spend(self, agent_id: str) -> float:
        """Get agent's daily spending"""
        today = datetime.utcnow().date()
        actions = self.ledger.get_by_actor(agent_id)
        
        daily_total = 0.0
        for action in actions:
            action_date = datetime.fromisoformat(action["timestamp"]).date()
            if action_date == today and action.get("cost"):
                daily_total += action["cost"]
        
        return daily_total
```

---

## SUCCESS CRITERIA (BINARY)

### For Agent Framework:

- [ ] **Seven agents implemented:** All 7 classes created
  - Verification: `ls src/agents/*_agent.py | wc -l` = 7
  
- [ ] **All agents inherit from BaseAgent:** Type checking passes
  - Verification: `grep -l "class.*Agent(BaseAgent)" src/agents/*.py | wc -l` = 7
  
- [ ] **Permission model enforced:** Agents cannot call unauthorized tools
  - Verification: Manual test: try to call unauthorized tool, get PermissionError
  
- [ ] **No permission escalation:** Agents cannot modify own permissions
  - Verification: `PermissionEnforcer.prevent_permission_escalation()` blocks all attempts

### For Tool Call Logging:

- [ ] **All tool calls logged:** Every call goes to ledger
  - Verification: Manual test: agent calls 10 tools, 10 entries in ledger
  
- [ ] **Permissions checked:** Unauthorized calls logged as denied
  - Verification: Manual test: unauthorized call logged with "denied" result

### Integration Tests:

- [ ] **Scout finds opportunities:** Returns list of opportunities
  - Verification: `pytest tests/test_scout_agent.py::test_scout_execution -v` passes
  
- [ ] **Builder deploys asset:** Asset appears in registry
  - Verification: `pytest tests/test_builder_agent.py::test_build_and_deploy -v` passes
  
- [ ] **QA blocks violations:** Rejected assets marked as blocked
  - Verification: `pytest tests/test_qa_agent.py::test_block_violations -v` passes
  
- [ ] **Finance recommends kills:** Negative ROI assets recommended for kill
  - Verification: `pytest tests/test_finance_agent.py::test_recommend_kill -v` passes

---

## EXECUTION CHECKLIST

**Done via KAIZA write_file:**
- [ ] Create `src/agent_framework.py` with base class
- [ ] Create `src/agents/` directory
- [ ] Create all 7 agent implementations
- [ ] Create `src/permission_enforcer.py`
- [ ] Update `src/registry.py` to store agent permissions
- [ ] Create integration tests
- [ ] Run all tests (must pass 100%)
- [ ] Verify all tool calls logged
- [ ] Commit with audit log

---

## NEXT STEPS

After Phase 2 completion, system is ready for **Phase 3: Asset Runtime Factory** (deploy real revenue-generating assets).

---

**END OF PHASE 2 RECOVERY PLAN**
