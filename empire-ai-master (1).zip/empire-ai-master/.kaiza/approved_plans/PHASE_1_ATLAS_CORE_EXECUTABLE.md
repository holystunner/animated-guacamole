## PLAN_HASH
065763d99e60e6c7835dcfecf8b57e991c220b7d34f7481c0d972d33791750b4

1. PLAN_METADATA
- ID: PHASE_1_ATLAS_CORE
- NAME: ATLAS Core OS Implementation
- VERSION: 1.0.0
- STATUS: EXECUTABLE_PENDING
- CONTEXT: Empire AI Phase 1
- PARENT: /docs/governance/CANONICAL_ROADMAP.md
- TARGET_PATH: /docs/plans/PHASE_1_ATLAS_CORE_EXECUTABLE.md
- AUTHOR: ANTIGRAVITY (KAIZA MCP)

2. SCOPE_LOCK
- LOCKED_TO: PHASE 1 (ATLAS CORE)
- PREVIOUS_PHASE: PHASE 0 (REALITY LOCK)
- EXPLICITLY_EXCLUDED:
  - LAYER 2 (ASSET FACTORIES)
  - LAYER 3 (CAPITAL & SCALE)
  - REVENUE_GENERATION
  - EXTERNAL_NETWORK_TRAFFIC (Except Localhost)

3. PHASE_OBJECTIVE
- PRIMARY: Create the minimum autonomous executive (ATLAS CORE) that will later control money.
- SECONDARY: Enforce "Zero Revenue By Design" until Phase 2.
- TERTIARY: Establish the "Brain" (Governor + Registry) and "Heart" (Runtime) of the Empire.

4. IN-SCOPE SYSTEMS
- GOVERNOR: Authority logic, Rule enforcement, Budget limits (0.00), Kill Switch.
- REGISTRY: State management for Agents, Assets, and System Configuration.
- RUNTIME: Deterministic execution loop, Job runner, Step runner, Retry logic.
- AUDIT_ENGINE: Immutable decision tracing, Action tracing, Dollar tracing (simulated).
- ADMIN_VISIBILITY: Read-only CLI/Dashboard to observe state and invoke Kill Switch.

5. OUT-OF-SCOPE (EXPLICIT)
- AGENT_LABOR: No agents performing "real work" (content gen, etc.).
- ASSETS: No creation of websites, accounts, or digital property.
- SEO: No keywords, no rankings, no search engine interaction.
- MONETIZATION: No affiliate links, no ads, no payment gateways.
- EXTERNAL_APIS: No usage of OpenAI, Google, etc. (Stub/Local only).
- REVENUE: Any revenue generation is a FAILURE condition.

6. REQUIRED SUBSYSTEMS
- SYSTEM: EmpireGovernor (Authority)
- SYSTEM: EmpireRegistry (State)
- SYSTEM: EmpireRuntime (Execution)
- SYSTEM: EmpireAudit (Observation)
- SYSTEM: EmpireCLI (Control)

7. DATA MODELS & STATE
- TYPE: AgentManifest { id, permissions, status, budget_cap }
- TYPE: AssetManifest { id, type, status, metrics }
- TYPE: ActionRequest { id, agent_id, intent, payload, timestamp }
- TYPE: AuditLogEntry { id, action_id, decision, outcome, hash }
- STATE: GlobalState { is_frozen, active_agents, budget_consumed }

8. EVENT & DECISION FLOWS
- FLOW_1: Runtime.tick() -> Registry.get_active_agents() -> Schedule Jobs.
- FLOW_2: Agent.request_action() -> Governor.check_rules() -> ALLOW/DENY.
- FLOW_3: Governor.ALLOW -> Runtime.execute() -> Audit.log_success().
- FLOW_4: Governor.DENY -> Audit.log_rejection() -> Runtime.notify_agent().
- FLOW_5: Admin.kill() -> Governor.set_frozen(TRUE) -> Runtime.halt().

9. GOVERNOR RULES (PHASE 1 ONLY)
- RULE_1: AUTHORITY_BOUNDARY -> Only registered 'SYSTEM' agents can execute.
- RULE_2: ISOLATION -> Deny all outbound network requests (allowlist: empty).
- RULE_3: BUDGET_ZERO -> Fail any action requiring > $0.00 cost.
- RULE_4: AUDIT_MANDATE -> Reject any action that fails to write to Audit Log.
- RULE_5: KILL_OVERRIDE -> If GlobalState.is_frozen == TRUE, Reject ALL.

10. FAILURE MODES & HARD STOPS
- MODE_1: AUDIT_FAILURE -> Crash immediately if Audit Log is unwritable.
- MODE_2: UNAUTHORIZED_AGENT -> Hard stop if unknown Agent ID acts.
- MODE_3: BUDGET_LEAK -> Hard stop if non-zero cost detected.
- MODE_4: NON_DETERMINISM -> Fail if action output cannot be serialized.

11. AUDIT & OBSERVABILITY REQUIREMENTS
- REQ_1: LOG_FORMAT -> JSON lines, append-only.
- REQ_2: ID_LINKING -> Traceability from ActionID -> DecisionID -> OutcomeID.
- REQ_3: HASH_CHAIN -> Each log entry must include hash of previous entry (Merkle-link).
- REQ_4: VISIBILITY -> CLI command `empire status` must show Frozen status.

12. EXECUTION STEPS (ORDERED, ATOMIC)
1. INITIALIZE_WORKSPACE
   - ACTION: Verify git clean state.
   - ACTION: Create directory structure: `src/core/{governor,registry,runtime,audit}`.
   - CHECK: Directories exist.

2. IMPLEMENT_AUDIT_CORE
   - ACTION: Create `src/core/audit/types.ts` (Interfaces).
   - ACTION: Create `src/core/audit/engine.ts` (Append-only Logic).
   - VERIFY: Run unit test writing 1000 logs and verifying integrity.

3. IMPLEMENT_REGISTRY_CORE
   - ACTION: Create `src/core/registry/types.ts` (Manifests).
   - ACTION: Create `src/core/registry/store.ts` (In-memory/File Store).
   - VERIFY: Register mock agent, retrieve it, verify data match.

4. IMPLEMENT_GOVERNOR_CORE
   - ACTION: Create `src/core/governor/rules.ts` (Rule definition).
   - ACTION: Create `src/core/governor/engine.ts` (Validation Logic).
   - VERIFY: Test Rule 3 (Budget Zero) enforces rejection.

5. IMPLEMENT_RUNTIME_CORE
   - ACTION: Create `src/core/runtime/loop.ts` (Tick Cycle).
   - ACTION: Integrate Governor check into Tick.
   - VERIFY: Run loop with mock agent, verify Audit Log traces decision.

6. IMPLEMENT_CLI_CONTROL
   - ACTION: Create `src/cli/empire.ts`.
   - ACTION: Implement flags: `--status`, `--kill`, `--audit`.
   - VERIFY: `empire --kill` successfully sets `is_frozen=TRUE`.

7. FINAL_INTEGRATION_TEST
   - ACTION: Run `tests/phase1_integration.test.ts`.
   - LOGIC: Attempt prohibited action, verify block. Kill system, verify halt.
   - CHECK: Audit log exists and is valid valid JSON-L.

13. ACCEPTANCE CRITERIA (PASS / FAIL ONLY)
- [ ] CRITICAL: System freezes immediately on Kill Switch? (PASS/FAIL)
- [ ] CRITICAL: Unauthorized network request blocked? (PASS/FAIL)
- [ ] CRITICAL: Audit log contains every decision made? (PASS/FAIL)
- [ ] CRITICAL: Budget stays at precisely $0.00? (PASS/FAIL)
- [ ] CRITICAL: No "ghost" agents (unregistered) allowed? (PASS/FAIL)

14. POST-PHASE INVARIANTS
- INVARIANT: The Codebase is compilable.
- INVARIANT: `npm test` passes.
- INVARIANT: `/data/audit.log` is present and valid.
- INVARIANT: No Stubs remain in `src/core`.
