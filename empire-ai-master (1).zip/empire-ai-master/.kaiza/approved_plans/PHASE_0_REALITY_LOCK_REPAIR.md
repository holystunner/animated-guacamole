# PHASE 0: REALITY LOCK REPAIR

**Objective:** Eliminate all stubs, mocks, TODOs, fake progress, and dead code. Make the repository incapable of hiding failures.

**Scope:** Repository-wide code cleanup and single unified action audit trail.

**Duration:** 2–3 weeks  
**Complexity:** High (refactoring, not feature work)

---

## NON-NEGOTIABLE CONSTRAINTS

1. **No stubs or mocks in production code paths**
2. **No TODO/FIXME/STUB comments left**
3. **All dead code removed**
4. **No duplicate implementations**
5. **Universal action ledger, not billing-only**
6. **All code must be deterministic and testable**

---

## PHASE 0 DELIVERABLES

### D1: Code Cleanup & Deduplication

**Objective:** Remove duplicate files, dead code, and stubs.

**Scope:**
- Merge `auto_tuner.py` + `auto-tuner.py` → keep one, delete other
- Merge `updater_agent.py` + `updater-agent.py` → keep one, delete other
- Merge `experiment_d.py` + `experiment-loop.py` + `experiment_loop.py` → keep one
- Merge `learning_registry.py` + `learning-registry.py` → keep one
- Delete all phase-X versions except latest (keep phase14, delete 07/08/10/11)
- Remove `innovation-lab.py` (feature-only)
- Remove all stub import handlers (content-factory.py lines 17–28)

**Acceptance Criteria:**
- [ ] No duplicate files in `/src/`
- [ ] Exactly one of each component
- [ ] Zero import fallbacks to mock classes
- [ ] All deletions logged to audit trail

---

### D2: Universal Action Ledger

**Objective:** Build comprehensive audit trail capturing every action (not just billing).

**New File:** `src/universal_ledger.py` (~400 lines)

**Schema:**
```sql
CREATE TABLE action_ledger (
    id INTEGER PRIMARY KEY,
    timestamp TIMESTAMP NOT NULL,
    action_id TEXT UNIQUE NOT NULL,
    actor TEXT NOT NULL,  -- agent, user, system
    action_type TEXT NOT NULL,  -- job, approval, policy, asset, deploy
    resource_id TEXT,  -- asset_id, agent_id, job_id
    input_data JSONB NOT NULL,
    output_data JSONB NOT NULL,
    result TEXT NOT NULL,  -- success, fail, pending
    reason TEXT,
    policy_evaluated BOOLEAN,
    previous_hash TEXT NOT NULL,
    action_hash TEXT UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_actor ON action_ledger(actor);
CREATE INDEX idx_action_type ON action_ledger(action_type);
CREATE INDEX idx_timestamp ON action_ledger(timestamp);
CREATE INDEX idx_resource_id ON action_ledger(resource_id);
```

**Core Methods:**
```python
class UniversalLedger:
    def log_action(self, actor: str, action_type: str, resource_id: str, 
                   input_data: Dict, output_data: Dict, result: str, reason: str = None) -> str:
        """Log an action with hash chain verification"""
        # Calculate hash(previous_hash + action_data)
        # Store with immutable chain verification
        # Return action_id
    
    def verify_integrity(self) -> bool:
        """Verify all hashes form unbroken chain"""
        # Check each action's hash against its data
        # Verify previous_hash points to prior action
        # Return True if chain is intact
    
    def get_by_actor(self, actor: str, limit: int = 100) -> List[Action]:
        """Query actions by actor"""
    
    def get_by_resource(self, resource_id: str, limit: int = 100) -> List[Action]:
        """Query actions by resource"""
    
    def replay(self, action_id: str) -> Dict:
        """Retrieve complete action for replay"""
```

**Acceptance Criteria:**
- [ ] All actions logged with timestamp, actor, reason
- [ ] Immutable hash chain prevents tampering
- [ ] Integrity verification passes
- [ ] All queries are indexed and < 100ms
- [ ] Cannot delete or modify entries

---

### D3: Remove All TODO/STUB Markers

**Objective:** Eliminate incomplete code or replace with real implementation.

**Files Affected:**
- `self-refactor-engine.py` — Either complete or delete
- `updater-agent.py` — Either complete or delete

**Rule:** For each file:
- If marked TODO/FIXME/STUB: **complete it or delete it**
- If completion requires external dependency: document the dependency and implement a stub loader that **fails fast** with clear error
- Never leave partially implemented code in repository

**Acceptance Criteria:**
- [ ] `grep -r "TODO\|FIXME\|STUB" src/` returns no matches
- [ ] All deleted files logged to audit trail

---

### D4: Deterministic Test Suite

**Objective:** Ensure all code is testable and produces consistent outputs.

**New Test File:** `tests/test_reality_lock.py` (~300 lines)

**Tests:**
```python
def test_duplicate_detection():
    """Verify no duplicate implementations"""
    # Scan src/ for naming collisions
    # Assert exactly one of each

def test_no_stubs():
    """Verify no stub imports or mock classes"""
    # Parse all Python files
    # Assert no try/except blocks with fallback mock classes
    # Assert no placeholder returns

def test_ledger_immutability():
    """Verify ledger cannot be modified"""
    # Insert entry
    # Attempt to modify entry → should fail
    # Assert immutability

def test_ledger_integrity():
    """Verify hash chain integrity"""
    # Insert 10 entries
    # Verify chain integrity
    # Tamper with one entry
    # Assert integrity check fails

def test_determinism():
    """Verify deterministic execution"""
    # Run component twice with same input
    # Assert identical output both times
```

**Acceptance Criteria:**
- [ ] All tests pass
- [ ] No flaky tests
- [ ] 100% coverage of ledger and critical paths

---

### D5: Configuration Validation

**Objective:** Lock all config values to deterministic, non-environment-dependent defaults.

**Scope:**
- All hardcoded `repo_path = "/media/ubuntux/DEVELOPMENT/empire-ai"` must be parameterized
- All config files must be version-controlled in `/data/`
- No environment variables affecting behavior

**Files:**
- Create `data/system_config.json` with all system defaults
- Update all components to load from central config
- Add config validation on startup

**Acceptance Criteria:**
- [ ] System boots with no environment variable dependencies
- [ ] All config is in version control
- [ ] Config changes are logged to action ledger

---

## IMPLEMENTATION SEQUENCE

1. **Week 1:**
   - D1: Code cleanup & deduplication
   - D3: Remove all TODO/STUB markers
   - D5: Configuration validation

2. **Week 2:**
   - D2: Universal action ledger implementation
   - Schema design review
   - Hash chain implementation and testing

3. **Week 3:**
   - D4: Test suite
   - Integration testing
   - Audit trail verification
   - Documentation

---

## SUCCESS GATES

**Gate 1: Code Cleanup Complete**
```
✓ No duplicate files
✓ No dead code
✓ No stubs in production paths
✓ All imports resolve
```

**Gate 2: Ledger Functional**
```
✓ Universal ledger records all actions
✓ Hash chain is immutable
✓ Integrity verification passes
✓ Replay works correctly
```

**Gate 3: Tests Pass**
```
✓ Reality lock tests pass (100% pass rate)
✓ No flaky tests
✓ Coverage > 80% of critical paths
```

**Gate 4: Audit Trail Complete**
```
✓ All changes logged
✓ Every deletion documented
✓ Ledger contains complete history
```

---

## INTENTIONALLY NOT INCLUDED

- Feature additions
- Performance optimization
- UI/frontend work
- New agent types
- Asset deployment

---

## DELIVERABLES

1. Cleaned `/src/` directory (no duplicates, no stubs)
2. `src/universal_ledger.py` (400+ lines)
3. `tests/test_reality_lock.py` (300+ lines)
4. `data/system_config.json` (centralized config)
5. Updated `data/governance.db` with action ledger schema
6. Execution report documenting all deletions and changes

---

## AUTHORITY

This phase is mandatory. The repository cannot claim Reality Lock compliance until Phase 0 passes all gates.

**Governing Document:** EMPIRE_AI_CANONICAL_SPECIFICATION.md Section 2, Appendix B Item 6: "Reality Lock policy: zero stubs, mocks, TODOs, or placeholder returns"
