# PHASE 3: ASSET RUNTIME IMPLEMENTATION

**Objective:** Build the runtime infrastructure where generated businesses actually run, generate revenue, and can be autonomously scaled or killed.

**Current State:** Content generation loops exist. **Zero deployed assets. No asset runtime.**

**Goal:** First real revenue-generating asset deployed and monitored.

**Duration:** 6–8 weeks  
**Complexity:** Very High (infrastructure + deployment + monitoring)

---

## NON-NEGOTIABLE CONSTRAINTS

1. **Assets are real, not mocked** (actual domains, actual hosting, actual revenue)
2. **Lifecycle states enforced** (draft → active → scaling → paused → retired)
3. **Asset health monitored** (uptime, revenue, errors, performance)
4. **Clean asset disposal** (no orphaned infrastructure)
5. **Assets can be spun up/down autonomously** (no manual DNS/hosting management)
6. **Cost accounting per asset** (know exactly what each costs)

---

## PHASE 3 DELIVERABLES

### D1: Asset Infrastructure Setup

**Objective:** Provision hosting, domain registration, and deployment pipeline.

**Components:**

1. **Web Hosting** (e.g., AWS, Vercel, or self-hosted)
   - Choose provider (recommendation: AWS for flexibility)
   - Set up API credentials
   - Provision VPC and networking

2. **Domain Management** (Namecheap/GoDaddy API)
   - API keys for domain registration
   - DNS automation

3. **Database for Assets**
   - Postgres or AWS RDS
   - Schema for asset storage
   - Asset data versioning

4. **Analytics Integration**
   - Google Analytics API
   - Plausible or similar
   - Real-time event capture

**New File:** `src/asset_infrastructure.py` (~400 lines)

```python
class AssetInfrastructure:
    def __init__(self, provider: str = "aws"):
        self.provider = provider
        self.aws = boto3.client("ec2")  # if AWS
        self.domains = DomainsAPI()
        self.database = AssetDatabase()
    
    def provision_asset_environment(self, asset_id: str) -> Dict[str, str]:
        """Provision hosting for new asset"""
        # Create container/VM
        # Configure networking
        # Return access details
    
    def deploy_asset_code(self, asset_id: str, code: str) -> bool:
        """Deploy asset code to provisioned environment"""
        # Push code to environment
        # Start services
        # Return success
    
    def register_domain(self, asset_id: str, domain_name: str) -> bool:
        """Register domain and point to asset"""
        # Register domain
        # Configure DNS
        # Wait for propagation
    
    def teardown_asset(self, asset_id: str) -> bool:
        """Cleanly remove all asset infrastructure"""
        # Stop services
        # Release resources
        # Archive data
```

**Acceptance Criteria:**
- [ ] Can provision hosting for asset
- [ ] Can deploy code to hosting
- [ ] Can register and configure domains
- [ ] Can teardown asset cleanly
- [ ] Cost per asset tracked

---

### D2: Asset Model & Lifecycle

**Objective:** Define asset data model with lifecycle enforcement.

**Update File:** `src/asset_model.py` (~500 lines)

**Asset Definition:**
```python
class AssetStatus(Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    SCALING = "scaling"
    PAUSED = "paused"
    RETIRED = "retired"

class Asset:
    asset_id: str
    name: str
    asset_type: str  # content_cluster, tool, lead_gen, micro_saas
    status: AssetStatus
    
    # Operational
    owner_agent: str  # who created it
    created_at: datetime
    updated_at: datetime
    
    # Content
    code: str  # source code
    configuration: Dict[str, Any]  # settings
    
    # Revenue & Cost
    revenue_30d: float
    revenue_90d: float
    revenue_lifetime: float
    cost_30d: float
    cost_90d: float
    cost_lifetime: float
    
    # Health
    uptime_percent: float  # 99.5%
    error_rate: float  # 0.1%
    avg_response_time: float  # ms
    
    # Metadata
    domain: str
    public_url: str
    hosting_provider: str
    deployment_region: str
    
    # History
    previous_status: AssetStatus
    status_changes: List[StatusChange]
    version_history: List[AssetVersion]

class AssetLifecycle:
    """Enforces asset lifecycle transitions"""
    
    def transition(self, asset: Asset, new_status: AssetStatus) -> bool:
        """Transition asset to new status"""
        
        # Validate transition
        if not self._is_valid_transition(asset.status, new_status):
            raise InvalidTransitionError(f"{asset.status} → {new_status}")
        
        # Pre-transition checks
        if new_status == AssetStatus.ACTIVE:
            # Must have QA approval
            if not asset.qa_approved:
                raise AssetNotApprovedException()
            # Must have revenue tracking
            if not asset.analytics_configured:
                raise AnalyticsNotConfiguredException()
        
        if new_status == AssetStatus.PAUSED:
            # Graceful shutdown
            self.infrastructure.pause_asset(asset.asset_id)
        
        if new_status == AssetStatus.RETIRED:
            # Clean teardown
            self.infrastructure.teardown_asset(asset.asset_id)
            # Archive data
            self.archive_asset(asset)
        
        # Update status
        asset.previous_status = asset.status
        asset.status = new_status
        asset.updated_at = datetime.now()
        
        # Log transition
        ledger.log_action(
            actor="system",
            action_type="asset_status_change",
            resource_id=asset.asset_id,
            input_data={"from": asset.previous_status.value, "to": new_status.value},
            result="success"
        )
        
        return True
    
    def _is_valid_transition(self, current: AssetStatus, next: AssetStatus) -> bool:
        """Define valid state transitions"""
        valid_transitions = {
            AssetStatus.DRAFT: [AssetStatus.ACTIVE, AssetStatus.RETIRED],
            AssetStatus.ACTIVE: [AssetStatus.SCALING, AssetStatus.PAUSED, AssetStatus.RETIRED],
            AssetStatus.SCALING: [AssetStatus.ACTIVE, AssetStatus.PAUSED, AssetStatus.RETIRED],
            AssetStatus.PAUSED: [AssetStatus.ACTIVE, AssetStatus.RETIRED],
            AssetStatus.RETIRED: []  # Final state
        }
        return next in valid_transitions.get(current, [])
```

**Acceptance Criteria:**
- [ ] Asset model complete
- [ ] Lifecycle transitions enforced
- [ ] Invalid transitions rejected
- [ ] Status changes logged

---

### D3: Asset Monitoring & Health

**Objective:** Continuous monitoring of asset uptime, revenue, errors.

**New File:** `src/asset_monitor.py` (~500 lines)

**Monitoring:**
```python
class AssetMonitor:
    def __init__(self, infrastructure: AssetInfrastructure, analytics: AnalyticsClient):
        self.infrastructure = infrastructure
        self.analytics = analytics
    
    async def run(self):
        """Continuous monitoring loop"""
        while True:
            assets = registry.get_all_active_assets()
            
            for asset in assets:
                try:
                    # Check uptime
                    uptime = self._check_uptime(asset)
                    
                    # Get revenue metrics
                    revenue = self._get_revenue(asset)
                    
                    # Get error metrics
                    errors = self._get_errors(asset)
                    
                    # Calculate health score
                    health = self._calculate_health(asset, uptime, revenue, errors)
                    
                    # Update registry
                    registry.update_asset_metrics(asset.asset_id, {
                        "uptime": uptime,
                        "revenue_24h": revenue,
                        "error_rate": errors,
                        "health_score": health
                    })
                    
                    # Check for alerts
                    if health < 0.5:  # Unhealthy
                        self._alert_on_asset_health(asset, health)
                
                except Exception as e:
                    logger.error(f"Monitor error for {asset.asset_id}: {e}")
            
            await asyncio.sleep(60)  # Check every minute
    
    def _check_uptime(self, asset: Asset) -> float:
        """Check asset uptime (0.0 to 1.0)"""
        try:
            response = requests.get(asset.public_url, timeout=5)
            return 1.0 if response.status_code == 200 else 0.0
        except:
            return 0.0
    
    def _get_revenue(self, asset: Asset) -> float:
        """Get revenue from analytics in past 24h"""
        return self.analytics.get_revenue(asset.asset_id, days=1)
    
    def _get_errors(self, asset: Asset) -> float:
        """Get error rate from logs (0.0 to 1.0)"""
        return self.analytics.get_error_rate(asset.asset_id)
    
    def _calculate_health(self, asset: Asset, uptime: float, revenue: float, errors: float) -> float:
        """Calculate overall health score"""
        # Weighted factors
        health = (uptime * 0.5) + ((1 - errors) * 0.3) + (min(revenue / 10, 1.0) * 0.2)
        return health
    
    def _alert_on_asset_health(self, asset: Asset, health: float):
        """Log alert when asset health degrades"""
        ledger.log_action(
            actor="system",
            action_type="asset_health_alert",
            resource_id=asset.asset_id,
            input_data={"health_score": health},
            reason="health_below_threshold",
            result="alert_created"
        )
```

**Acceptance Criteria:**
- [ ] Assets monitored every minute
- [ ] Uptime tracked
- [ ] Revenue tracked
- [ ] Errors detected
- [ ] Health score calculated
- [ ] Alerts generated for degradation

---

### D4: Asset Factory Integration

**Objective:** Wire agents into asset creation and deployment pipeline.

**Update File:** `src/asset_factory.py` (~600 lines)

**Workflow:**
```
Scout discovers opportunity
    ↓
Scout proposes asset → Approval queue
    ↓
Owner approves
    ↓
Builder generates asset (code, config, templates)
    ↓
Writer creates content
    ↓
QA verifies asset (quality, compliance)
    ↓
Compliance checks disclosures
    ↓
Growth seeds initial traffic
    ↓
Asset goes live
    ↓
Monitor measures performance
```

**Code:**
```python
class AssetFactory:
    def __init__(self, infrastructure: AssetInfrastructure, agent_registry: AgentRegistry):
        self.infrastructure = infrastructure
        self.agents = agent_registry
        self.asset_model = AssetModel()
    
    async def create_asset_from_proposal(self, proposal_id: str) -> Asset:
        """Create asset from Scout proposal"""
        
        proposal = registry.get_proposal(proposal_id)
        
        # 1. Builder generates asset
        builder = self.agents.get_agent("builder-1")
        build_result = await builder.generate_asset(
            template=proposal.asset_type,
            parameters=proposal.parameters
        )
        
        # 2. Writer creates content
        writer = self.agents.get_agent("writer-1")
        content_result = await writer.generate_content(
            asset_id=build_result.asset_id,
            content_type="primary"
        )
        
        # 3. QA verifies
        qa = self.agents.get_agent("qa-1")
        qa_result = await qa.verify_asset(build_result.asset_id)
        
        if not qa_result.approved:
            # QA failed, log rejection
            ledger.log_action(
                actor="qa-1",
                action_type="asset_rejected",
                resource_id=build_result.asset_id,
                reason=qa_result.reason,
                result="failed"
            )
            raise AssetRejectedError(qa_result.reason)
        
        # 4. Compliance checks
        compliance = self.agents.get_agent("compliance-1")
        compliance_result = await compliance.check_compliance(build_result.asset_id)
        
        if compliance_result.violations:
            ledger.log_action(
                actor="compliance-1",
                action_type="asset_blocked",
                resource_id=build_result.asset_id,
                reason=f"compliance_violations: {compliance_result.violations}",
                result="blocked"
            )
            raise ComplianceViolationError(compliance_result.violations)
        
        # 5. Provision infrastructure
        infrastructure_result = self.infrastructure.provision_asset_environment(
            build_result.asset_id
        )
        
        # 6. Deploy code
        self.infrastructure.deploy_asset_code(
            build_result.asset_id,
            build_result.code
        )
        
        # 7. Register domain
        domain = proposal.parameters.get("domain") or f"{build_result.asset_id}.ai"
        self.infrastructure.register_domain(build_result.asset_id, domain)
        
        # 8. Activate asset
        asset = Asset(asset_id=build_result.asset_id, **build_result.to_dict())
        lifecycle = AssetLifecycle()
        lifecycle.transition(asset, AssetStatus.ACTIVE)
        
        # 9. Growth seeds initial traffic
        growth = self.agents.get_agent("growth-1")
        await growth.seed_traffic(asset.asset_id)
        
        # Log creation
        ledger.log_action(
            actor="system",
            action_type="asset_created",
            resource_id=asset.asset_id,
            input_data=proposal.to_dict(),
            output_data=asset.to_dict(),
            result="success"
        )
        
        return asset
```

**Acceptance Criteria:**
- [ ] Scout proposal → approval workflow
- [ ] Builder can generate asset
- [ ] Writer creates content
- [ ] QA must approve before going live
- [ ] Compliance must clear before publishing
- [ ] Infrastructure provisioned
- [ ] Code deployed
- [ ] Domain registered
- [ ] Asset goes live
- [ ] All steps logged

---

### D5: First Asset Deployment

**Objective:** Deploy at least one real, revenue-generating asset end-to-end.

**Scope:**
- Deploy a content cluster (blog + affiliate links)
- Register real domain
- Set up Google Analytics
- Monitor for 7 days
- Measure revenue

**Asset Specification:**
```
Asset: "Python Learning Hub" (content_cluster)
Domain: pythonlearninghub.ai
Type: Educational content + affiliate links
Topics: Python tutorials, frameworks, tools
Revenue Model: Affiliate commissions (courses, books)
Target: $10/day by day 7
```

**Acceptance Criteria:**
- [ ] Domain registered and live
- [ ] Content deployed and accessible
- [ ] Analytics collecting data
- [ ] Revenue tracking working
- [ ] Asset status = "active"
- [ ] Monitored for 7 days
- [ ] Documented in execution report

---

### D6: Asset Scaling & Performance

**Objective:** Growth agent autonomously scales profitable assets.

**Update File:** `src/asset_scaling.py` (~400 lines)

**Scaling Rules:**
```python
class AssetScaler:
    async def evaluate_for_scaling(self, asset: Asset) -> Dict[str, Any]:
        """Determine if asset should be scaled"""
        
        revenue_per_day = asset.revenue_30d / 30
        cost_per_day = asset.cost_30d / 30
        roi = (revenue_per_day - cost_per_day) / cost_per_day if cost_per_day > 0 else 0
        
        decision = {
            "asset_id": asset.asset_id,
            "roi": roi,
            "action": "hold"  # hold, scale, kill
        }
        
        # Scale if ROI > 1.0 (profitable) and growing
        if roi > 1.0 and asset.revenue_trending_up:
            decision["action"] = "scale"
            decision["reason"] = f"ROI {roi:.1%} with uptrend"
        
        # Kill if ROI < 0.2 (unprofitable) for 7+ days
        elif roi < 0.2 and asset.unprofitable_days > 7:
            decision["action"] = "kill"
            decision["reason"] = f"ROI {roi:.1%} for {asset.unprofitable_days} days"
        
        return decision
    
    async def scale_asset(self, asset: Asset) -> bool:
        """Scale profitable asset"""
        
        scaling_actions = [
            ("add_keywords", {"count": 10}),
            ("expand_content", {"sections": 3}),
            ("optimize_seo", {}),
            ("increase_traffic", {"budget": 20})
        ]
        
        growth = agent_registry.get_agent("growth-1")
        
        for action_type, params in scaling_actions:
            job_id = await growth.scale_asset(
                asset_id=asset.asset_id,
                expansion_type=action_type
            )
            
            # Wait for completion
            result = job_executor.get_job_result(job_id)
            if not result["success"]:
                logger.error(f"Scaling failed: {action_type}")
                return False
        
        # Transition to SCALING state
        lifecycle = AssetLifecycle()
        lifecycle.transition(asset, AssetStatus.SCALING)
        
        return True
    
    async def kill_unprofitable(self, asset: Asset) -> bool:
        """Cleanly kill unprofitable asset"""
        
        lifecycle = AssetLifecycle()
        lifecycle.transition(asset, AssetStatus.RETIRED)
        
        # Infrastructure teardown happens in lifecycle
        
        ledger.log_action(
            actor="system",
            action_type="asset_killed",
            resource_id=asset.asset_id,
            reason="unprofitable",
            result="retired"
        )
        
        return True
```

**Acceptance Criteria:**
- [ ] Assets evaluated for scaling daily
- [ ] Profitable assets scaled automatically
- [ ] Unprofitable assets killed after threshold
- [ ] All scaling decisions logged

---

## IMPLEMENTATION SEQUENCE

**Week 1–2: Infrastructure Setup**
- D1: Hosting/domain/analytics setup
- D2: Asset model and lifecycle

**Week 2–3: Monitoring & Factory**
- D3: Asset monitoring
- D4: Asset factory integration

**Week 3–4: First Deployment**
- D5: Deploy first real asset
- Measure and validate

**Week 4–6: Scaling**
- D6: Asset scaling logic
- Monitor scaling performance

**Week 6–8: Hardening**
- Error recovery
- Cost optimization
- Documentation

---

## SUCCESS GATES

**Gate 1: Infrastructure Ready**
```
✓ Hosting provisioned
✓ Domains can be registered
✓ Analytics integrated
✓ Database working
```

**Gate 2: Asset Model Complete**
```
✓ Asset lifecycle enforced
✓ State transitions validated
✓ Status tracking works
```

**Gate 3: First Asset Live**
```
✓ Asset deployed
✓ Domain live
✓ Content accessible
✓ Analytics collecting
✓ Revenue tracking (even if $0)
```

**Gate 4: Scaling Active**
```
✓ Assets evaluated for scaling
✓ Profitable assets scaled
✓ Unprofitable assets killed
```

---

## INTENTIONALLY NOT INCLUDED

- Multiple asset types (start with content clusters)
- Complex monetization (affiliate only)
- Multi-region deployment
- Asset cloning/duplication

---

## DELIVERABLES

1. `src/asset_infrastructure.py` (400+ lines)
2. `src/asset_model.py` (500+ lines)
3. `src/asset_monitor.py` (500+ lines)
4. `src/asset_factory.py` (600+ lines)
5. `src/asset_scaling.py` (400+ lines)
6. First deployed asset (pythonlearninghub.ai or similar)
7. Asset monitoring dashboard (backend)
8. Execution report with first asset metrics

---

## AUTHORITY

This phase is mandatory. Without real deployed assets, there is no Empire AI.

**Governing Document:** EMPIRE_AI_CANONICAL_SPECIFICATION.md Section 2 Layer 4: Asset Runtime
