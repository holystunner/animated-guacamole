---
status: APPROVED
plan_id: phase-0-reality-lock-2025-01-12
title: Phase 0 - Reality Lock Repair
created_by: AMP
created_date: 2025-01-12
---

# PHASE 0: REALITY LOCK REPAIR (KAIZA-EXECUTABLE)

**Objective:** Eliminate all stubs, mocks, TODOs, fake progress, and dead code. Make repository incapable of hiding failures.

**Authority:** EMPIRE_AI_CANONICAL_SPECIFICATION.md v1.0 (Reality Lock policy)

**Duration:** 3 weeks

**Success Criteria:**
- ✅ Zero files with TODO/FIXME/STUB/mock comments
- ✅ Zero stub import fallbacks
- ✅ Universal ledger created and operational
- ✅ Pre-commit hook installed and enforced
- ✅ All tests pass 100%
- ✅ No code written outside KAIZA audit trail

---

## REQUIREMENTS

1. **Code Cleanup:** Remove duplicate files, delete old phases, purge stub code
2. **Universal Ledger:** Comprehensive action audit trail (not billing-only)
3. **Build Gates:** Pre-commit hooks prevent violations
4. **File Updates:** Integrate ledger into existing components

---

## IMPLEMENTATION SPECIFICATIONS

### File 1: `src/universal_ledger.py`

**Purpose:** Comprehensive append-only audit trail for ALL system actions (not just billing)

**Behavior:**
- Accept action submissions (actor, action_type, resource_id, input_data, output_data, result)
- Calculate SHA256 hash chain (action_hash = SHA256(previous_hash + action_json))
- Store in SQLite with full indexing (actor, action_type, timestamp, resource_id)
- Provide query methods: by_actor(), by_type(), by_resource(), by_date_range()
- Verify chain integrity (all hashes unbroken from genesis)
- Export to CSV/JSON for external audit

**Dependencies:**
- sqlite3 (stdlib)
- hashlib (stdlib)
- json (stdlib)
- datetime (stdlib)
- typing (stdlib)
- pathlib (stdlib)

**Exports:**
- Class: `UniversalLedger`
- Methods: `log_action()`, `verify_integrity()`, `get_by_actor()`, `get_by_resource()`, `get_by_type()`, `get_by_date_range()`, `export_csv()`, `export_json()`

**Error Handling:**
- Raise ValueError if action_type not in valid enum
- Raise IOError if database write fails (propagate, don't hide)
- Raise IntegrityError if hash chain broken
- All errors logged before raising (no silent failures)

**Testing Requirements:**
- Create 1000 test entries
- Verify hash chain integrity (must pass)
- Test all query methods return correct results
- Test CSV/JSON exports are valid

---

### File 2: `scripts/enforce_reality_lock.py`

**Purpose:** Pre-commit hook validator. Prevents commits with stubs, mocks, TODOs, fake code.

**Behavior:**
- Scan all Python files in staged changes
- Check for forbidden patterns: TODO, FIXME, XXX, HACK, stub, mock, placeholder, fake, pass (bare)
- Check for dangerous returns: `return []`, `return {}`, `return None` (without impl)
- Check for silent exception handlers: `except: pass`
- Report all violations with file:line_number
- Exit code 0 if clean, 1 if violations found

**Dependencies:**
- re (stdlib)
- pathlib (stdlib)
- subprocess (stdlib)

**Exports:**
- Function: `enforce_reality_lock(file_path: str) -> Tuple[bool, List[str]]`
- Function: `main()`

**Error Handling:**
- Raise IOError if file not readable
- Print violations to stderr (not silent)
- Exit with code 1 on first violation (fail-fast)

**Testing Requirements:**
- Create test file with violations → must reject
- Create clean test file → must accept
- Test all forbidden patterns detected

---

### File 3: `.git/hooks/pre-commit`

**Purpose:** Git pre-commit hook. Runs enforce_reality_lock on all staged files.

**Behavior:**
- Get list of staged Python files: `git diff --cached --name-only --diff-filter=ACM *.py`
- Run `python3 scripts/enforce_reality_lock.py` on each file
- Block commit if any violations found
- Print helpful error message with file paths and line numbers

**Dependencies:**
- Python 3.8+
- scripts/enforce_reality_lock.py (must exist)

**Exports:**
- Executable script (no imports, bash script)

**Error Handling:**
- Exit code 1 blocks commit
- Print violation details to user

**Testing Requirements:**
- Manual test: try `git commit` with TODO in staged file → must fail
- Manual test: try `git commit` with clean code → must succeed

---

### File 4: `src/governor.py` (UPDATED)

**Purpose:** Update existing Governor to log all policy evaluations to universal ledger

**Behavior Changes:**
- In `__init__()`: Initialize UniversalLedger instance
- After `evaluate_action()` completes: Call `ledger.log_action()` with policy result
- Ensure all policy evaluation data (input, output, result) logged with hash chain

**New Code Addition:**
```python
# At top of Governor.__init__():
from universal_ledger import UniversalLedger

# In __init__():
self.ledger = UniversalLedger(str(self.repo_path / "data" / "universal_ledger.db"))

# At end of evaluate_action(), after all policy evaluation:
self.ledger.log_action(
    actor=user or "system",
    action_type="policy_evaluation",
    resource_id=action_type,
    input_data=action_data,
    output_data=result,
    result="pending",
    policy_result=result.get("overall_result"),
    reason=result.get("reason_code")
)
```

**Dependencies:**
- universal_ledger (new file)

**Error Handling:**
- If ledger write fails, log error but continue (non-blocking)
- Ledger failure must not prevent policy evaluation

**Testing Requirements:**
- Submit 10 policy evaluations
- Verify 10 entries in universal_ledger
- Verify hash chain integrity

---

### File 5: `docs/ledger_config.py`

**Purpose:** Centralized ledger database paths and configuration

**Behavior:**
- Define all ledger database paths as constants
- Document which ledger is for what
- Provide helper functions for database initialization

**Exports:**
```python
UNIVERSAL_LEDGER_DB = "data/universal_ledger.db"  # ALL actions
BILLING_LEDGER_DB = "data/billing_ledger.db"      # Financial only
GOVERNANCE_DB = "data/governance.db"               # Policies
```

**Dependencies:**
- pathlib (stdlib)

**Error Handling:**
- No error handling needed (config file)

**Testing Requirements:**
- Import and verify all constants defined
- Verify paths are strings

---

## CLEANUP TASKS (Not new files, but deletions/mergers)

**Delete Files (old duplicates):**
- src/auto-tuner.py (keep auto_tuner.py)
- src/updater-agent.py (keep updater_agent.py)
- src/learning-registry.py (keep learning_registry.py)
- src/experiment_d.py, src/experiment-loop.py (keep experiment_loop.py)
- src/optimization-loop.py (keep optimization_loop.py)
- src/update-loop.py (keep update_loop.py)
- src/strategy-core.py, src/strategy-loop.py (keep strategy_core.py)
- src/canary-tester.py (keep canary_tester.py)
- src/safety-monitor.py (keep safety_monitor.py)
- src/innovation_lab.py (feature-only, no active use)
- src/self_refactor_engine.py (incomplete)
- src/self-refactor-engine.py (incomplete)
- src/phase07_admin_ui.py, src/phase08_admin_ui.py, src/phase10_admin_ui.py, src/phase11_admin_ui.py (keep phase12_admin_ui_server.py and phase14_admin_ui_server.py)

**Update Files (remove stub code):**
- src/content_factory.py: Remove stub import handlers (lines 24-44)
- src/product_factory.py: Remove MockSpec, MockRepo, MockCommit classes
- src/distribution_engine.py: Remove mock content object

---

## SUCCESS CRITERIA (Binary Verification)

**Checkpoint 1: Code Cleanup**
- [ ] Run: `ls src/ | grep -E '(auto_tuner|auto-tuner|experiment|learning_registry)' | wc -l` → Result: 0
- [ ] Run: `ls src/phase0[7-9]*.py src/phase1[01]*.py 2>/dev/null | wc -l` → Result: 0
- [ ] Run: `grep -r "Create stub classes for testing" src/ | wc -l` → Result: 0

**Checkpoint 2: Universal Ledger**
- [ ] File exists: `ls -l data/universal_ledger.db` → Shows file
- [ ] Schema valid: `sqlite3 data/universal_ledger.db ".schema action_ledger" | wc -l` → 8+ columns
- [ ] Test ledger integrity: `python3 -c "from src.universal_ledger import UniversalLedger; l=UniversalLedger(); print(l.verify_integrity())"` → Result: True

**Checkpoint 3: Pre-commit Hook**
- [ ] Hook installed: `ls -la .git/hooks/pre-commit` → Shows x permission
- [ ] Hook blocks violations: Add `# TODO: test`, run `git commit` → Result: Rejected
- [ ] Hook allows clean code: Remove TODO, run `git commit` → Result: Success

**Checkpoint 4: Governor Integration**
- [ ] Ledger called: `grep -n "self.ledger.log_action" src/governor.py | wc -l` → Result: 1+
- [ ] 10 test evals logged: Run 10 policy evals, query ledger → Result: 10 entries found

**Checkpoint 5: Tests Pass**
- [ ] All tests: `python3 -m pytest tests/ -v` → Result: 100% pass
- [ ] No TODOs in code: `grep -r "TODO\|FIXME" src/ tests/ | wc -l` → Result: 0
- [ ] No mock data: `grep -r "mock\|stub\|fake" src/ | grep -v "\.pyc" | wc -l` → Result: 0

---

## RELATED PLANS

**Blocks:**
- PHASE_1_CORE_OS_KAIZA (must complete Phase 0 first)

**Depends On:**
- EMPIRE_AI_CANONICAL_SPECIFICATION.md (defines Reality Lock)

---

## APPROVED BY

**Name:** AMP (Autonomous Meta-Planner)  
**Authority:** Governance audit and recovery planning authority  
**Date:** 2025-01-12  
**KAIZA Signature:** Created via KAIZA-MCP governance  

---

**STATUS: READY FOR EXECUTION BY WINDSURF**

This plan is 100% executable via KAIZA write_file. No ambiguity. No improvisation.
