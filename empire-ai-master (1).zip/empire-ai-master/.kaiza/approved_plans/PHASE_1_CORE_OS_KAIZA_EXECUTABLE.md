---
status: APPROVED
plan_id: phase-1-core-os-2025-01-12
title: Phase 1 - Core OS Completion
created_by: AMP
created_date: 2025-01-12
---

# PHASE 1: CORE OS COMPLETION (KAIZA-EXECUTABLE)

**Objective:** Complete the operating system kernel. Governor enforces policies on ALL job execution. Ledger is comprehensive. System cannot run without policy clearance.

**Authority:** EMPIRE_AI_CANONICAL_SPECIFICATION.md v1.0 (Section 2, Layers 1-2)

**Duration:** 5-6 weeks

**Success Criteria:**
- ✅ All jobs routed through Governor.evaluate_action()
- ✅ No job can execute without policy clearance
- ✅ Budget limits are hard limits (enforced, not suggested)
- ✅ All job steps logged to universal ledger
- ✅ Approval queue works (hold high-risk decisions)
- ✅ Kill switch works instantly (pauses all jobs)
- ✅ All tests pass 100%

**Depends On:** PHASE_0_REALITY_LOCK_KAIZA_EXECUTABLE (must be complete)

---

## REQUIREMENTS

1. **Job Execution Pipeline:** All jobs routed through Governor for policy validation
2. **Governor Enforcement:** No bypass possible
3. **Registry:** Single source of truth for system state and configuration
4. **Budget Enforcement:** Hard limits on spending per agent, asset, period
5. **Approval Queue:** Owner approval workflow for high-risk decisions
6. **Kill Switch:** Emergency stop that pauses all running jobs
7. **Ledger Integration:** All job lifecycle events logged

---

## IMPLEMENTATION SPECIFICATIONS

### File 1: `src/job_executor.py`

**Purpose:** Central job execution engine. Routes all jobs through Governor for policy validation before execution.

**Behavior:**
- Accept JobRequest (job_id, job_type, actor, resource_id, input_data, required_budget)
- Call Governor.evaluate_action() immediately (mandatory, no bypass)
- Handle three outcomes:
  - ALLOW: Execute immediately via execute_approved_job()
  - DENY: Log rejection, return error, stop
  - OVERRIDE_REQUIRED: Queue for owner approval, wait
- Execute jobs with step-level checkpoints (can resume from failure point)
- Log every step to universal ledger
- Track job status (pending, awaiting_approval, approved, executing, succeeded, failed, cancelled)

**Key Methods:**
- `submit_job(request: JobRequest) -> Dict` - Entry point, routes through Governor
- `execute_approved_job(job_id: str) -> Dict` - Run after approval
- `approve_job(job_id: str, approved_by: str) -> Dict` - Owner approves pending job
- `reject_job(job_id: str, rejected_by: str) -> Dict` - Owner rejects pending job
- `get_job_status(job_id: str) -> Dict` - Query job state
- `get_pending_approvals() -> List[Dict]` - All jobs awaiting approval

**Dependencies:**
- governor (must call for every job)
- universal_ledger (log all events)
- registry (get asset/agent info)
- uuid (generate job IDs)
- datetime (timestamps)
- sqlite3 (job tracking database)
- json (data serialization)

**Exports:**
- Class: `JobExecutor`
- Class: `JobRequest`
- Class: `JobExecution`
- Enum: `JobStatus`
- Enum: `JobType`

**Error Handling:**
- If Governor unavailable: raise RuntimeError (fail-fast, don't proceed)
- If budget check fails: return error (policy denial, not exception)
- If ledger write fails: log error but return status (non-blocking)
- If execution fails: catch exception, log failure, mark job as failed

**Database Schema:**
```sql
CREATE TABLE jobs (
    job_id TEXT PRIMARY KEY,
    job_type TEXT NOT NULL,
    actor TEXT NOT NULL,
    resource_id TEXT NOT NULL,
    input_data TEXT NOT NULL,
    required_budget REAL,
    status TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    policy_result TEXT,
    policy_reason TEXT,
    approval_request_id TEXT,
    approved_by TEXT,
    approved_at TIMESTAMP,
    result TEXT,
    error TEXT
);

CREATE INDEX idx_job_status ON jobs(status);
CREATE INDEX idx_job_actor ON jobs(actor);
CREATE INDEX idx_job_resource ON jobs(resource_id);
```

**Testing Requirements:**
- Test 50 jobs: submit through approve to completion
- Test 20 denied jobs (verify rejection logged)
- Test 10 override-required jobs (verify approval queue)
- Verify no job executes without Governor clearance
- Verify all job steps logged to ledger
- Run: `python3 -m pytest tests/test_job_executor.py -v` (100% pass)

---

### File 2: `src/registry.py`

**Purpose:** Single source of truth for all system state (assets, agents, configuration, health).

**Behavior:**
- Store and retrieve asset catalog with lifecycle states (draft → active → scaling → paused → retired)
- Store and retrieve agent definitions with permissions
- Store and retrieve versioned configuration (immutable snapshots)
- Store references to secrets (not secrets themselves)
- Store current system health state
- Store portfolio financial state (revenue, cost, profit by asset)

**Key Methods:**
- `register_asset(asset_id, asset_type, metadata) -> str` - Create asset record
- `get_asset(asset_id) -> Dict` - Retrieve asset
- `get_all_assets(state: str) -> List[Dict]` - Get assets, optionally filtered by state
- `update_asset_state(asset_id, new_state) -> bool` - Transition asset state
- `register_agent(agent_id, agent_type, permissions) -> str` - Create agent record
- `get_agent(agent_id) -> Dict` - Retrieve agent with permissions
- `set_config(key, value, version) -> bool` - Set config (versioned)
- `get_config(key) -> Any` - Get current config value
- `get_config_history(key) -> List[Dict]` - Get all versions
- `restore_config(key, version) -> bool` - Restore to prior version
- `get_portfolio_state() -> Dict` - Get current portfolio metrics

**Dependencies:**
- sqlite3 (persistent storage)
- universal_ledger (log all state changes)
- json (data serialization)
- datetime (timestamps)
- pathlib (database path)

**Exports:**
- Class: `Registry`

**Database Schema:**
```sql
CREATE TABLE assets (
    asset_id TEXT PRIMARY KEY,
    asset_type TEXT NOT NULL,
    owner TEXT,
    state TEXT NOT NULL,
    created_at TIMESTAMP,
    deployed_at TIMESTAMP,
    paused_at TIMESTAMP,
    retired_at TIMESTAMP,
    total_revenue REAL DEFAULT 0,
    total_cost REAL DEFAULT 0,
    monthly_revenue REAL DEFAULT 0,
    monthly_cost REAL DEFAULT 0,
    roi REAL DEFAULT 0,
    metadata TEXT NOT NULL
);

CREATE TABLE agents (
    agent_id TEXT PRIMARY KEY,
    agent_type TEXT NOT NULL,
    permissions TEXT NOT NULL,
    budget_daily REAL,
    budget_monthly REAL,
    enabled BOOLEAN DEFAULT TRUE
);

CREATE TABLE configuration (
    config_key TEXT,
    version INTEGER,
    value TEXT NOT NULL,
    set_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (config_key, version)
);

CREATE INDEX idx_asset_state ON assets(state);
CREATE INDEX idx_config_key ON configuration(config_key);
```

**Error Handling:**
- Raise ValueError if asset state transition invalid (e.g., retired → active)
- Raise IntegrityError if duplicate asset_id
- Raise IOError if database write fails (propagate)
- All state changes logged before commit (audit trail first)

**Testing Requirements:**
- Create asset, verify in registry
- Transition asset state: draft → active → scaling → paused → retired (all valid)
- Try invalid transition (e.g., retired → active) → must fail
- Create agent with permissions, retrieve, verify
- Set config v1, set v2, restore v1 → v1 restored
- Get portfolio state, verify aggregations
- Run: `python3 -m pytest tests/test_registry.py -v` (100% pass)

---

### File 3: `src/kill_switch.py` (NEW)

**Purpose:** Emergency stop mechanism. Pauses all running jobs instantly.

**Behavior:**
- Maintain kill switch state (global_active, triggered_by, reason, triggered_at)
- When activated: pause all running jobs (mark status = paused)
- When deactivated: resume paused jobs
- Log all activations/deactivations to ledger
- Prevent override (only governor or owner can activate)

**Key Methods:**
- `activate(triggered_by: str, reason: str) -> bool` - Activate kill switch
- `deactivate(released_by: str) -> bool` - Deactivate kill switch
- `is_active() -> bool` - Check current state
- `get_state() -> Dict` - Get full kill switch state

**Dependencies:**
- sqlite3 (state persistence)
- universal_ledger (log all actions)
- datetime (timestamps)

**Database Schema:**
```sql
CREATE TABLE kill_switch_state (
    id INTEGER PRIMARY KEY,
    global_active BOOLEAN DEFAULT FALSE,
    triggered_at TIMESTAMP,
    triggered_by TEXT,
    reason TEXT,
    released_at TIMESTAMP,
    released_by TEXT
);
```

**Error Handling:**
- If already active: return False with message (idempotent)
- If ledger write fails: raise error (must be logged)

**Testing Requirements:**
- Activate kill switch, verify all running jobs paused
- Deactivate kill switch, verify jobs resume
- Try to approve job while kill switch active → must fail
- Verify all activations logged to ledger
- Run: `python3 -m pytest tests/test_kill_switch.py -v` (100% pass)

---

### File 4: `src/governor.py` (UPDATED - FROM PHASE 0)

**Purpose:** Existing Governor, updated to be tightly integrated with JobExecutor

**Required Changes:**
- Already logs to universal_ledger (from Phase 0)
- Add method: `freeze()` - Pauses all running jobs (calls kill_switch.activate())
- Add method: `unfreeze()` - Resumes all jobs (calls kill_switch.deactivate())
- Ensure evaluate_action() is called for EVERY job submission

**Testing Requirements:**
- Run existing governor tests (should still pass)
- Test that no job can bypass Governor evaluation
- Test budget enforcement (spending over limit → denied)
- Run: `python3 -m pytest tests/test_governor.py -v` (100% pass)

---

## SUCCESS CRITERIA (Binary Verification)

**Checkpoint 1: Job Executor Operational**
- [ ] Submit 50 jobs via `submit_job()` → All routed through Governor
- [ ] 50 policy evaluations logged to ledger → Verify 50 entries with "policy_evaluation" action
- [ ] Query: `python3 -c "from src.job_executor import JobExecutor; je = JobExecutor('.'); print(je.get_pending_approvals())"` → Returns list

**Checkpoint 2: Governor Enforcement**
- [ ] Submit job that violates policy → Governor denies → job doesn't execute
- [ ] Try to directly execute job without submit → fails (no bypass possible)
- [ ] 100% of jobs have policy evaluation logged → No jobs without policy entry

**Checkpoint 3: Budget Enforcement**
- [ ] Agent at daily limit tries new job → Denied with "budget exceeded" reason
- [ ] Agent under limit tries job → Allowed
- [ ] Test monthly limit enforcement → Works

**Checkpoint 4: Approval Queue**
- [ ] Submit override-required job → Queued for approval
- [ ] Query pending approvals → Shows job
- [ ] Approve job → Executes
- [ ] Reject job → Marked cancelled, not executed

**Checkpoint 5: Kill Switch**
- [ ] Activate kill switch → All running jobs paused
- [ ] Submit new job while active → Rejected (kill switch active)
- [ ] Deactivate kill switch → Jobs resume
- [ ] All activations logged to ledger

**Checkpoint 6: Tests Pass**
- [ ] Run: `python3 -m pytest tests/test_job_executor.py tests/test_registry.py tests/test_kill_switch.py -v` → 100% pass
- [ ] Run: `python3 -m pytest tests/test_job_flow.py::test_full_job_flow -v` → Passes (end-to-end)
- [ ] No TODOs, mocks, stubs: `grep -r "TODO\|mock\|stub" src/job_executor.py src/registry.py src/kill_switch.py | wc -l` → 0

**Checkpoint 7: Ledger Integrity**
- [ ] Query: `python3 -c "from src.universal_ledger import UniversalLedger; l = UniversalLedger(); print(l.verify_integrity())"` → True
- [ ] 1000+ entries in ledger → All with valid hash chain

---

## RELATED PLANS

**Blocks:**
- PHASE_2_AGENT_ECONOMY_KAIZA_EXECUTABLE (must complete Phase 1 first)

**Depends On:**
- PHASE_0_REALITY_LOCK_KAIZA_EXECUTABLE (must be complete before starting)
- EMPIRE_AI_CANONICAL_SPECIFICATION.md (defines Layer 1 & 2 requirements)

---

## APPROVED BY

**Name:** AMP (Autonomous Meta-Planner)  
**Authority:** Governance audit and recovery planning authority  
**Date:** 2025-01-12  
**KAIZA Signature:** Created via KAIZA-MCP governance  

---

**STATUS: READY FOR EXECUTION BY WINDSURF**

This plan is 100% executable. All file specifications are exact. No improvisation needed.

**Note:** JobExecutor.execute_job() methods (_execute_scout, _execute_build, etc.) are stubs in this phase (will be implemented in Phase 2-3). They must raise NotImplementedError with clear message: "Agent execution implemented in Phase 2"
