# PHASE 0: REALITY LOCK REPAIR (KAIZA-EXECUTABLE)

**Status:** APPROVED FOR EXECUTION VIA KAIZA-MCP  
**Objective:** Eliminate all stubs, mocks, TODOs, fake progress, and dead code. Make the repository incapable of hiding failures.  
**Duration:** 3 weeks  
**Authority:** EMPIRE_AI_CANONICAL_SPECIFICATION.md v1.0 (Reality Lock policy)  

---

## BINDING CONSTRAINTS

1. **Zero stubs or mocks** in production code paths
2. **Zero TODO/FIXME/STUB** comments in final code
3. **All dead code removed**
4. **No duplicate implementations**
5. **Universal action ledger** (not billing-only)
6. **All code deterministic and testable**
7. **Written via KAIZA write_file only** (auditability)
8. **Binary success criteria** (no fuzzy completion)

---

## DELIVERABLE 1: CODE CLEANUP & DEDUPLICATION

### Objective
Remove duplicate files, dead code, and stubs. Establish single source of truth for each component.

### Scope of Work

#### 1.1 Merge Duplicate Files (Keep Latest, Delete Other)

| Component | Keep | Delete | Rationale |
|-----------|------|--------|-----------|
| Auto-Tuning | `auto_tuner.py` | `auto-tuner.py` | Consolidate naming convention |
| Updater Agent | `updater_agent.py` | `updater-agent.py` | Consolidate naming convention |
| Experiment Loop | `experiment_loop.py` | `experiment_d.py`, `experiment-loop.py` | Consolidate 3 variants |
| Learning Registry | `learning_registry.py` | `learning-registry.py` | Consolidate naming convention |
| Optimizers | `optimizer.py` | `optimization_loop.py`, `optimization-loop.py` | Consolidate 3 variants |
| Rollout Manager | `rollout_manager.py` | `rollout-manager.py` | Consolidate naming convention |
| Update Loop | `update_loop.py` | `update-loop.py` | Consolidate naming convention |
| Strategy Core | `strategy_core.py` | `strategy-core.py`, `strategy-loop.py` | Consolidate 3 variants |
| Canary Tester | `canary_tester.py` | `canary-tester.py` | Consolidate naming convention |
| Safety Monitor | `safety_monitor.py` | `safety-monitor.py` | Consolidate naming convention |
| Deploy Manager | `deploy_manager.py` (new) | `deploy-d.py` | Create unified deploy interface |
| Experimentation | `experiment_manager.py` (new) | `experiment-d.py` | Create unified experiment interface |
| Kernel Services | `kernel_services.py` (new) | `kernel-d.py` | Create unified kernel interface |
| Deployment Dist | `distribution_engine.py` | `distribution-engine.py` | Consolidate naming convention |
| Discovery Loop | Keep as-is | None | No duplicate found |
| Git Manager | Keep as-is | None | No duplicate found |

#### 1.2 Delete Old Phase Versions (Keep Phase 14 Only)

Delete all but latest:
- DELETE: `src/phase07_admin_ui.py`
- DELETE: `src/phase08_admin_ui.py`
- DELETE: `src/phase10_admin_ui.py`
- DELETE: `src/phase11_admin_ui.py`
- KEEP: `src/phase12_admin_ui_server.py` (latest backend)
- KEEP: `src/phase14_admin_ui_server.py` (newest)
- Compare 12 vs 14, keep merged version as `src/admin_ui_server.py`

#### 1.3 Remove Stub Import Fallbacks

**File: `src/content_factory.py` (lines 24-44)**
- VIOLATION: Imports fail silently, returns empty stubs
- FIX: Remove entire try-except block that creates mock classes
- ACTION: Let import errors fail loudly (fail-fast principle)
- Result: Code is either valid or raises exception (no silent failures)

**File: `src/product_factory.py` (lines 26-47)**
- VIOLATION: Mock classes (MockSpec, MockRepo, MockCommit)
- FIX: Remove all mock class definitions
- ACTION: Require real implementations or explicit skip
- Result: Zero stubs in production code

**File: `src/distribution_engine.py` (lines 25-38)**
- VIOLATION: Mock content object with placeholder fields
- FIX: Remove all mock class definitions
- ACTION: Use typed data classes (dataclass) with required fields
- Result: Type-safe, no silent failures

**File: `src/growth_loop.py` (lines 25+)**
- ACTION: Scan for stub imports, remove all fallbacks
- Result: All imports explicit and enforced

**File: `src/discovery_loop.py` (lines 1-50)**
- ACTION: Scan for stub imports, remove all fallbacks
- Result: All imports explicit and enforced

#### 1.4 Remove Dead Code

**Remove entirely:**
- `src/innovation_lab.py` (feature-only, no active use)
- `src/self_refactor_engine.py` (incomplete, TODOs)
- `src/self-refactor-engine.py` (duplicate)

**Audit and clean:**
- `src/validator_bot.py` (contains "mock landing pages" — real landing pages needed)
- `src/escalation_engine.py` (lines 359, 363, 367 have placeholder returns)
- `src/governance_loop.py` (lines 371, 377 have placeholder returns)

---

## DELIVERABLE 2: UNIVERSAL ACTION LEDGER

### Objective
Build comprehensive audit trail capturing every action (not just billing). Single source of truth for auditability.

### New File: `src/universal_ledger.py` (500 lines)

#### Schema Definition
```sql
CREATE TABLE action_ledger (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TIMESTAMP NOT NULL,
    action_id TEXT UNIQUE NOT NULL,
    actor TEXT NOT NULL,  -- agent_name, user_id, or "system"
    action_type TEXT NOT NULL,  -- job, approval, policy, asset, deploy, tool_call
    resource_id TEXT,  -- asset_id, agent_id, job_id, or tool_name
    input_data JSONB NOT NULL,  -- complete input to action
    output_data JSONB NOT NULL,  -- complete output/result
    result TEXT NOT NULL CHECK (result IN ('success', 'fail', 'pending', 'denied', 'approved', 'override')),
    reason TEXT,  -- Why action succeeded/failed
    policy_evaluated BOOLEAN DEFAULT FALSE,
    policy_result TEXT CHECK (policy_result IN ('allow', 'deny', 'override_required')),
    previous_hash TEXT NOT NULL,  -- Hash of prior action
    action_hash TEXT UNIQUE NOT NULL,  -- SHA256(previous_hash + action_data)
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_actor ON action_ledger(actor);
CREATE INDEX idx_action_type ON action_ledger(action_type);
CREATE INDEX idx_timestamp ON action_ledger(timestamp);
CREATE INDEX idx_resource_id ON action_ledger(resource_id);
CREATE INDEX idx_action_hash ON action_ledger(action_hash);
```

#### Core Class: UniversalLedger

**Required Methods:**
```python
class UniversalLedger:
    def __init__(self, db_path: str = "data/universal_ledger.db"):
        """Initialize ledger with schema"""
    
    def log_action(self, actor: str, action_type: str, resource_id: str, 
                   input_data: Dict, output_data: Dict, result: str, 
                   policy_result: str = None, reason: str = None) -> str:
        """Log action to ledger, return action_id"""
        # Verify action_type is valid
        # Get previous_hash from last entry
        # Calculate action_hash = SHA256(previous_hash + json(action_data))
        # Insert into action_ledger
        # Return action_id
    
    def verify_integrity(self) -> bool:
        """Verify ledger chain is unbroken"""
        # For each row (ordered by id):
        #   Recalculate action_hash
        #   Verify matches stored value
        #   Verify previous_hash matches prior row's hash (or 'genesis')
        # Return True if all match, False if any mismatch
    
    def get_by_actor(self, actor: str, limit: int = 100) -> List[Dict]:
        """Query actions by actor"""
        # SELECT * FROM action_ledger WHERE actor = ? ORDER BY timestamp DESC LIMIT ?
    
    def get_by_resource(self, resource_id: str, limit: int = 100) -> List[Dict]:
        """Query actions by resource (asset, agent, job, tool)"""
        # SELECT * FROM action_ledger WHERE resource_id = ? ORDER BY timestamp DESC LIMIT ?
    
    def get_by_type(self, action_type: str, limit: int = 100) -> List[Dict]:
        """Query actions by type"""
        # SELECT * FROM action_ledger WHERE action_type = ? ORDER BY timestamp DESC LIMIT ?
    
    def get_by_date_range(self, start: datetime, end: datetime, limit: int = 100) -> List[Dict]:
        """Query actions by time window"""
        # SELECT * FROM action_ledger WHERE timestamp BETWEEN start AND end ORDER BY timestamp DESC LIMIT ?
    
    def replay(self, action_id: str) -> Dict:
        """Retrieve complete action for replay"""
        # SELECT * FROM action_ledger WHERE action_id = ?
        # Return full action record
    
    def get_chain_from(self, action_id: str) -> List[Dict]:
        """Get all actions from this action forward"""
        # SELECT * FROM action_ledger WHERE id >= (SELECT id FROM action_ledger WHERE action_id = ?) ORDER BY id ASC
    
    def get_genesis_to(self, action_id: str) -> List[Dict]:
        """Get all actions from genesis to this action"""
        # SELECT * FROM action_ledger WHERE id <= (SELECT id FROM action_ledger WHERE action_id = ?) ORDER BY id ASC
    
    def export_csv(self, output_path: str, start: datetime = None, end: datetime = None):
        """Export ledger to CSV for external audit"""
    
    def export_json(self, output_path: str, start: datetime = None, end: datetime = None):
        """Export ledger to JSON for external audit"""
```

#### Integration Points (Where UniversalLedger is called)

1. **From Governor** (`src/governor.py`):
   - After each `evaluate_action()`, call `ledger.log_action(action_id, "policy_evaluation", ...)`

2. **From Job Executor** (new in Phase 1):
   - Before job execution: `ledger.log_action(actor, "job_submitted", job_id, ...)`
   - After job completion: `ledger.log_action(actor, "job_completed", job_id, ...)`

3. **From Approval Workflow** (`src/phase12_approval_workflows.py`):
   - When request created: `ledger.log_action(actor, "approval_requested", request_id, ...)`
   - When approved: `ledger.log_action(approver, "approval_granted", request_id, ...)`
   - When rejected: `ledger.log_action(approver, "approval_rejected", request_id, ...)`

4. **From Asset Manager** (new in Phase 4):
   - When asset created: `ledger.log_action("system", "asset_created", asset_id, ...)`
   - When asset scaled: `ledger.log_action("system", "asset_scaled", asset_id, ...)`
   - When asset paused: `ledger.log_action("system", "asset_paused", asset_id, ...)`
   - When asset killed: `ledger.log_action("system", "asset_killed", asset_id, ...)`

5. **From Tool Executor** (new in Phase 1):
   - When tool called: `ledger.log_action(agent, "tool_call", tool_name, ...)`

---

## DELIVERABLE 3: UNIFIED BUILD & LINT GATES

### Objective
Make it impossible to commit code with stubs, mocks, or unresolved TODOs.

### New File: `scripts/enforce_reality_lock.py`

**Purpose:** Pre-commit hook validator. Runs on every git commit.

**Forbidden Patterns (Fail Build):**
- `TODO`, `FIXME`, `XXX`, `HACK`, `stub`, `mock`, `placeholder`, `fake`
- `return []` without implementation
- `return {}` without implementation
- `return None` without implementation
- `pass` (bare pass statements)
- Import fallbacks with mock classes
- `# This is a placeholder` comments

**Enforcement:**
```python
def enforce_reality_lock(file_path: str) -> Tuple[bool, List[str]]:
    """Check file for Reality Lock violations"""
    violations = []
    forbidden = [
        r'TODO', r'FIXME', r'XXX', r'HACK',
        r'stub', r'mock', r'placeholder', r'fake',
        r'pass\s*$',  # bare pass
        r'return\s*\[\]',  # empty list return
        r'return\s*\{\}',  # empty dict return
        r'except.*:\s*pass',  # silent exception handling
    ]
    
    with open(file_path) as f:
        for line_no, line in enumerate(f, 1):
            for pattern in forbidden:
                if re.search(pattern, line, re.IGNORECASE):
                    violations.append(f"{file_path}:{line_no} — {line.strip()}")
    
    return len(violations) == 0, violations
```

**Integration:**
- Create `.git/hooks/pre-commit` that calls this script
- Block commit if violations found
- Exit code 1 = build failure

---

## DELIVERABLE 4: UPDATE EXISTING FILES (via KAIZA write_file)

### 4.1 Update `src/governor.py`

**Change:** Add ledger integration

```python
# At top of Governor.__init__():
from universal_ledger import UniversalLedger

self.ledger = UniversalLedger(str(self.repo_path / "data" / "universal_ledger.db"))

# In Governor.evaluate_action(), after all evaluations:
self.ledger.log_action(
    actor=user,
    action_type="policy_evaluation",
    resource_id=action_type,
    input_data=action_data,
    output_data=result,
    result=result["overall_result"],
    policy_result=result.get("policy_results", [None])[0].get("result"),
    reason=result.get("reason_code")
)
```

### 4.2 Update Billing Ledger (`src/ledger.py`)

**Rename to:** `src/billing_ledger.py` (to distinguish from universal ledger)

**Add docstring:**
```python
"""
Billing-specific ledger for financial transactions.
For all-action audit trail, use universal_ledger.py instead.
"""
```

### 4.3 Create Configuration

**New file:** `src/ledger_config.py`

```python
"""Ledger configuration and database paths"""

UNIVERSAL_LEDGER_DB = "data/universal_ledger.db"
BILLING_LEDGER_DB = "data/billing_ledger.db"
GOVERNANCE_DB = "data/governance.db"

# All actions MUST go through universal_ledger
# Financial transactions ALSO go through billing_ledger
```

---

## SUCCESS CRITERIA (BINARY)

### For Code Cleanup:

- [ ] **Merge complete:** Exactly one file for each component (no duplicates)
  - Verification: `ls src/ | grep -E '(auto_tuner|auto-tuner|experiment|learning_registry)' | wc -l` = 0
  
- [ ] **Old phases deleted:** No phase07-11 admin UI files exist
  - Verification: `ls src/phase0[7-9]*.py src/phase1[01]*.py 2>/dev/null | wc -l` = 0
  
- [ ] **Stub imports removed:** No try-except with mock class creation
  - Verification: `grep -r "Create stub classes for testing" src/` returns 0 results
  
- [ ] **Dead code removed:** No innovation-lab, self-refactor-engine files
  - Verification: `ls src/innovation_lab.py src/self*.py 2>/dev/null | wc -l` = 0

### For Universal Ledger:

- [ ] **Schema created:** `universal_ledger.db` exists with 8 required columns
  - Verification: `sqlite3 data/universal_ledger.db ".schema action_ledger"` shows all columns
  
- [ ] **Hash chain works:** All 1000 test entries have valid hashes
  - Verification: `UniversalLedger.verify_integrity()` returns True
  
- [ ] **Integration ready:** Governor logs to universal_ledger
  - Verification: `grep -n "self.ledger.log_action" src/governor.py` shows calls
  
- [ ] **Query methods work:** All 7 query methods return valid results
  - Verification: `python3 -m pytest tests/test_universal_ledger.py -v` passes all

### For Build Gates:

- [ ] **Pre-commit hook installed:** `.git/hooks/pre-commit` is executable
  - Verification: `ls -la .git/hooks/pre-commit` shows `x` permission
  
- [ ] **Hook blocks violations:** Attempting to commit code with TODO fails
  - Verification: Manual test: add `# TODO: fix this`, run `git commit` → fails
  
- [ ] **Hook passes clean code:** Attempting to commit clean code succeeds
  - Verification: Manual test: remove TODO, run `git commit` → succeeds

---

## EXECUTION CHECKLIST

**Done via KAIZA write_file:**
- [ ] Merge duplicate files (keep one, delete others, record in audit log)
- [ ] Delete old phase files (record deletions)
- [ ] Remove stub imports and mock classes (record removals)
- [ ] Delete dead code files (record deletions)
- [ ] Create `universal_ledger.py` with complete schema and methods
- [ ] Create `ledger_config.py` with database paths
- [ ] Update `governor.py` to call ledger
- [ ] Create `enforce_reality_lock.py` script
- [ ] Install git pre-commit hook
- [ ] Run `UniversalLedger.verify_integrity()` test (must pass)
- [ ] Commit all changes with audit log

---

## EXPECTED REPOSITORY STATE AFTER PHASE 0

```
src/
  ✅ 85-90 Python files (down from 119)
  ✅ 0 files with TODO/FIXME/STUB comments
  ✅ 0 duplicate implementations
  ✅ 1 universal_ledger.py
  ✅ 1 governor.py (with ledger integration)
  ✅ 1 billing_ledger.py (formerly ledger.py, renamed for clarity)

data/
  ✅ universal_ledger.db (append-only ledger)
  ✅ governance.db (policies)
  ✅ billing_ledger.db (financial)

.git/hooks/
  ✅ pre-commit (enforces reality lock on all commits)

✅ Build passes lint gate
✅ Zero hidden failures
✅ All code deterministic
✅ Auditability enabled
```

---

## NEXT STEPS

After Phase 0 completion, system is ready for **Phase 1: Core OS Completion** (enforce Governor on job execution).

---

**END OF PHASE 0 RECOVERY PLAN**
