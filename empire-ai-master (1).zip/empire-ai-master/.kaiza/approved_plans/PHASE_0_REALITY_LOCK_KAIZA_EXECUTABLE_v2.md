---
status: APPROVED
plan_id: phase-0-reality-lock-2025-01-12-v2
title: Phase 0 - Reality Lock Repair (Dependency-Ordered)
created_by: AMP
created_date: 2025-01-12
---

# PHASE 0: REALITY LOCK REPAIR (KAIZA-EXECUTABLE - DEPENDENCY ORDERED)

**Objective:** Eliminate all stubs, mocks, TODOs, fake progress, and dead code.

**Key Principle:** Files created in dependency order. Each file is COMPLETE on first write. No nulls, no stubs, no placeholders.

**Duration:** 3 weeks

**Success Criteria:**
- ✅ Zero files with TODO/FIXME/STUB/mock
- ✅ Universal ledger operational
- ✅ Pre-commit hook enforced
- ✅ All tests pass 100%
- ✅ All cleanup tasks completed

---

## IMPLEMENTATION ORDER (Strict Sequence)

### STEP 1: Create Universal Ledger (No Dependencies)

**File:** `src/universal_ledger.py` (500 lines)

**Purpose:** Append-only audit trail. Core primitive for entire system.

**Complete Implementation:**
- SQLite schema with action_ledger table
- Hash chain implementation (SHA256)
- All query methods: log_action(), verify_integrity(), get_by_actor(), get_by_type(), get_by_resource(), get_by_date_range(), export_csv(), export_json()
- Full error handling
- No stubs, no NotImplementedError, no placeholders

**Dependencies:** None (only stdlib)

**Exports:**
```python
class UniversalLedger:
    def __init__(self, db_path: str = "data/universal_ledger.db")
    def log_action(self, actor: str, action_type: str, resource_id: str, 
                   input_data: Dict, output_data: Dict, result: str, 
                   policy_result: str = None, reason: str = None) -> str
    def verify_integrity(self) -> bool
    def get_by_actor(self, actor: str, limit: int = 100) -> List[Dict]
    def get_by_type(self, action_type: str, limit: int = 100) -> List[Dict]
    def get_by_resource(self, resource_id: str, limit: int = 100) -> List[Dict]
    def get_by_date_range(self, start: datetime, end: datetime, limit: int = 100) -> List[Dict]
    def export_csv(self, output_path: str, start: datetime = None, end: datetime = None)
    def export_json(self, output_path: str, start: datetime = None, end: datetime = None)
```

**Success Criteria:**
- Create 1000 test entries
- Verify hash chain (all 1000 hashes valid)
- Query by actor returns correct entries
- Export to CSV/JSON succeeds
- Test: `python3 -m pytest tests/test_universal_ledger.py -v` → 100% pass

---

### STEP 2: Create Build Gate Script (Depends on: Nothing)

**File:** `scripts/enforce_reality_lock.py` (200 lines)

**Purpose:** Pre-commit validator. Detects violations BEFORE commit.

**Complete Implementation:**
- Scan Python files for forbidden patterns
- Report with file:line_number
- Exit code 0 (clean) or 1 (violations)
- Patterns checked:
  - TODO, FIXME, XXX, HACK, stub, mock, placeholder, fake
  - `return []`, `return {}`, `return None` (bare)
  - `except: pass` (silent handlers)

**Dependencies:** None (only stdlib: re, pathlib)

**Exports:**
```python
def enforce_reality_lock(file_path: str) -> Tuple[bool, List[str]]
def main()
```

**Success Criteria:**
- Detect violations in test file → Returns False
- Accept clean code → Returns True
- Test: `python3 -m pytest tests/test_enforce_reality_lock.py -v` → 100% pass

---

### STEP 3: Install Pre-commit Hook (Depends on: enforce_reality_lock.py)

**File:** `.git/hooks/pre-commit` (50 lines, bash script)

**Purpose:** Block commits with violations.

**Complete Implementation:**
```bash
#!/bin/bash
# Get staged Python files
staged_files=$(git diff --cached --name-only --diff-filter=ACM | grep '\.py$')

# Run enforce_reality_lock on each
for file in $staged_files; do
    python3 scripts/enforce_reality_lock.py "$file"
    if [ $? -ne 0 ]; then
        echo "❌ COMMIT BLOCKED: Real Lock violations in $file"
        exit 1
    fi
done

echo "✅ Pre-commit check passed"
exit 0
```

**Dependencies:** enforce_reality_lock.py (must exist)

**Success Criteria:**
- Test: Try commit with TODO → Fails
- Test: Try commit with clean code → Succeeds

---

### STEP 4: Update Governor (Depends on: universal_ledger.py)

**File:** `src/governor.py` (Modified - ADD ledger integration)

**Changes:**
1. At import: `from universal_ledger import UniversalLedger`
2. In `__init__()`: `self.ledger = UniversalLedger(str(self.repo_path / "data" / "universal_ledger.db"))`
3. At end of `evaluate_action()`: Log all policy evaluations to ledger
4. Add method: `freeze()` (will be used in Phase 1, stub OK here with raise NotImplementedError)
5. Add method: `unfreeze()` (will be used in Phase 1, stub OK here with raise NotImplementedError)

**Key:** Only ADD to existing code. Don't remove or change existing logic.

**Error Handling:**
- If ledger write fails → log warning but continue (policy evaluation doesn't block)

**Dependencies:** universal_ledger.py (must exist)

**Success Criteria:**
- Run 10 policy evaluations
- Verify 10 entries in universal_ledger
- Test: `python3 -m pytest tests/test_governor.py -v` → 100% pass (existing tests should still pass)

---

### STEP 5: Delete Dead Code (Depends on: Nothing, but do after Step 4)

**Purpose:** Clean repository. No forward-facing changes.

**Files to Delete (exactly):**
```
src/auto-tuner.py
src/updater-agent.py
src/learning-registry.py
src/experiment_d.py
src/experiment-loop.py
src/optimization-loop.py
src/update-loop.py
src/strategy-loop.py
src/strategy-core.py (keep this, delete strategy-core.py if different)
src/canary-tester.py
src/safety-monitor.py
src/innovation_lab.py
src/self_refactor_engine.py
src/self-refactor-engine.py
src/phase07_admin_ui.py
src/phase08_admin_ui.py
src/phase10_admin_ui.py
src/phase11_admin_ui.py
```

**Files to Clean (remove stub code, keep files):**
```
src/content_factory.py - Remove stub import handlers (lines with MockClass)
src/product_factory.py - Remove MockSpec, MockRepo, MockCommit classes
src/distribution_engine.py - Remove mock object
src/escalation_engine.py - Remove placeholder returns
src/governance_loop.py - Remove placeholder returns
```

**Success Criteria:**
- Verify deleted files are gone: `ls src/auto-tuner.py 2>&1` → No such file
- Verify cleaned files have no stubs: `grep -i "mock\|stub" src/content_factory.py | wc -l` → 0

---

### STEP 6: Create Config File (Depends on: Nothing)

**File:** `src/ledger_config.py` (30 lines)

**Purpose:** Centralized database paths.

**Complete Implementation:**
```python
from pathlib import Path

# All ledger database paths
UNIVERSAL_LEDGER_DB = "data/universal_ledger.db"  # ALL actions
BILLING_LEDGER_DB = "data/billing_ledger.db"      # Financial only
GOVERNANCE_DB = "data/governance.db"               # Policies

def get_universal_ledger_path(repo_path: str = ".") -> str:
    return str(Path(repo_path) / UNIVERSAL_LEDGER_DB)

def get_billing_ledger_path(repo_path: str = ".") -> str:
    return str(Path(repo_path) / BILLING_LEDGER_DB)

def get_governance_db_path(repo_path: str = ".") -> str:
    return str(Path(repo_path) / GOVERNANCE_DB)
```

**Dependencies:** None

**Success Criteria:**
- Import successfully: `python3 -c "from src.ledger_config import *; print(UNIVERSAL_LEDGER_DB)"` → Prints path
- Test: `python3 -m pytest tests/test_ledger_config.py -v` → 100% pass

---

## SUCCESS VERIFICATION (Binary Checkpoints)

### Checkpoint 1: Universal Ledger Created
```bash
# Verify file exists
ls -l src/universal_ledger.py

# Verify schema
sqlite3 data/universal_ledger.db ".schema action_ledger"

# Verify functionality
python3 << 'EOF'
from src.universal_ledger import UniversalLedger
ledger = UniversalLedger()
ledger.log_action("test_actor", "test_action", "test_resource", {}, {}, "success")
result = ledger.verify_integrity()
print("Ledger OK" if result else "Ledger FAILED")
EOF
```

Expected: ✅ File exists, schema valid, verify_integrity() returns True

### Checkpoint 2: Build Gate Working
```bash
# Test with violations
echo "# TODO: fix this" > test_bad.py
python3 scripts/enforce_reality_lock.py test_bad.py
# Should exit with code 1

# Test with clean code
echo "print('hello')" > test_good.py
python3 scripts/enforce_reality_lock.py test_good.py
# Should exit with code 0

rm test_bad.py test_good.py
```

Expected: ✅ Bad code rejected, clean code accepted

### Checkpoint 3: Pre-commit Hook Installed
```bash
# Verify hook exists and is executable
ls -la .git/hooks/pre-commit
# Should show -rwxr-xr-x

# Verify hook content
head -1 .git/hooks/pre-commit
# Should show #!/bin/bash
```

Expected: ✅ Hook exists, executable, correct content

### Checkpoint 4: Governor Updated
```bash
# Verify import
grep -n "from universal_ledger import" src/governor.py

# Verify initialization
grep -n "self.ledger = UniversalLedger" src/governor.py

# Verify ledger calls
grep -n "self.ledger.log_action" src/governor.py
```

Expected: ✅ All three patterns found

### Checkpoint 5: Dead Code Deleted
```bash
# Count remaining duplicates
ls src/auto-tuner.py 2>/dev/null && echo "FAIL: auto-tuner.py still exists" || echo "OK: auto-tuner.py deleted"
ls src/auto_tuner.py 2>/dev/null && echo "OK: auto_tuner.py exists" || echo "FAIL: auto_tuner.py missing"

# Verify no TODOs in src/
grep -r "TODO\|FIXME" src/ | wc -l
# Should be 0
```

Expected: ✅ Duplicates gone, no TODOs remain

### Checkpoint 6: All Tests Pass
```bash
# Run all Phase 0 tests
python3 -m pytest tests/test_universal_ledger.py \
                   tests/test_enforce_reality_lock.py \
                   tests/test_ledger_config.py \
                   tests/test_governor.py \
                   -v

# Should show: passed 100%
```

Expected: ✅ 100% pass rate

---

## WHAT NOT TO DO (Prevent Mistakes)

❌ **Don't create stubs:**
- No `def log_action(): pass`
- No `raise NotImplementedError("todo")`
- No returning empty lists/dicts

❌ **Don't leave TODOs:**
- Every TODO must be addressed or deleted
- Every FIXME must be addressed or deleted

❌ **Don't use mocks in production code:**
- No `MockDatabase` classes
- No test data in production files

❌ **Don't forward-reference:**
- Don't call function that doesn't exist yet
- Don't import from file not yet created

---

## APPROVED BY

**Name:** AMP  
**Authority:** Governance and recovery planning  
**Date:** 2025-01-12  

---

**STATUS: READY FOR EXECUTION BY WINDSURF**

**Strict Order:** Follow STEP 1 → STEP 2 → STEP 3 → STEP 4 → STEP 5 → STEP 6

Each step produces complete, working code. No stubs. No nulls. Fully executable.
