────────────────────────────────
PHASE EXECUTION PLAN
────────────────────────────────

1. Phase ID
   Phase 2

2. Phase Name
   Automated Market Sensing & Opportunity Scoring

3. Execution Objective
   Establish continuous, real-time sensing of the selected market niche to identify specific entry points, keyword gaps, and competitor weaknesses dynamic opportunity scoring.

4. Scope of Authority
   - Competitive Intelligence (Tracking features/pricing).
   - Demand Forecasting (Spike prediction).
   - Opportunity Alerting.

5. In-Scope Components
   - `watchtower-d` (Scheduled monitoring of competitor sites/feeds)
   - `opportunity-db` (Time-series database)
   - `score-keeper` (Logic engine applying weights)
   - Admin UI Surfaces (Live Market Feed, Competitor Graph)

6. Out-of-Scope (Hard Block)
   - Violation of `robots.txt` where legally binding.
   - Non-deterministic scoring algorithms.

7. Preconditions
   - Phase 1 Complete (Target niches confirmed).

8. Execution Steps (Ordered, Atomic)
   - Step 1: Deploy `watchtower-d` for scheduled monitoring.
   - Step 2: Initialize `opportunity-db` for time-series data storage.
   - Step 3: Implement `score-keeper` logic engine.
   - Step 4: Implement Sentiment Analysis (NLP) and Gap Analysis modules.
   - Step 5: Configure Sensing Loop: Watchtower -> DB -> ScoreKeeper -> Alert.
   - Step 6: Implement Entry Trigger Logic (Score > 85/100 AND Saturation < High).
   - Step 7: Implement Pivot Trigger Logic (Volume decline > 20% -> Pause).
   - Step 8: Deploy Admin UI: Live Market Feed and Competitor Graph.

9. Data & State Created
   - Keyword Volumes & Sentiment (Time-series database).
   - Opportunity Scores.
   - Competitor Feature Matrices.
   - Raw HTML Snapshots (Archived).

10. Decision Logic Implemented
    - Entry Trigger: Score > 85 AND Competitor Saturation != High.
    - Pivot Trigger: Niche Volume < 80% (Decline > 20%).

11. Observability & Audit Hooks
    - Traceable logic tree for Opportunity Scores.
    - Archive raw HTML of competitor pages.

12. Failure Conditions
    - Data Drift.
    - Source Feed Failure.

13. Rollback Strategy
    - Data Drift: Re-calibrate baselines weekly.
    - Source Failure: Fallback to secondary APIs/Mirrors.
    - Resource Cap: Prune HTML snapshots > 30 days.

14. Validation Tests (Binary)
    - Test 1: PASS / FAIL (Live data feeds ingested correctly)
    - Test 2: PASS / FAIL (Scoring algorithm backtested)
    - Test 3: PASS / FAIL ("Opportunity Alert" generated for test event)

15. Phase Exit Gate
    - All Validation Tests PASS.
