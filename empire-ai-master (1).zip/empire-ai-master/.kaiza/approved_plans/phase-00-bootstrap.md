────────────────────────────────
PHASE EXECUTION PLAN
────────────────────────────────

1. Phase ID
   Phase 0

2. Phase Name
   System Bootstrap & Authority Foundation

3. Execution Objective
   Initialize the Empire AI kernel on a single bare-metal node, establishing the immutable authority root, secure logging, and agentic execution sandbox required for all subsequent evolution.

4. Scope of Authority
   - Establishment of Root Authority and Identity.
   - Enforcement of Architectural Governance ("One Roadmap").
   - Exclusive Resource Allocation of the initial hardware.
   - Creation of the immutable audit log foundation.

5. In-Scope Components
   - `kernel-d` (Primary daemon, wrapper of OS)
   - `audit-log` (SQLite/Flatfile, append-only)
   - `agent-sandbox` (Docker/Podman wrapper)
   - `bootstrap-cli` (Manual recovery tooling)
   - Hetzner CX33 hardware (Resource control)

6. Out-of-Scope (Hard Block)
   - Multi-node scaling (Hard constraint to `localhost`).
   - External internet (Strictly limited to setup).
   - Deletion of `audit-log` (Immutable).

7. Preconditions
   - Single bare-metal node processed/acquired.
   - SSH keys only (Hardened provision).

8. Execution Steps (Ordered, Atomic)
   - Step 1: Provision and harden server with SSH keys only.
   - Step 2: Initialize `audit-log` storage (SQLite/Flatfile) with append-only permissions.
   - Step 3: Implement `kernel-d` daemon interacting with OS process lifecycle.
   - Step 4: Configure `kernel-d` startup sequence: Check integrity -> Mount `audit-log` -> Signal READY.
   - Step 5: Implement `agent-sandbox` wrapper (Docker/Podman) for isolated execution.
   - Step 6: Deploy `bootstrap-cli` for initial setup and recovery.
   - Step 7: Enforce Data Flow: Command Loop (Input -> Audit Write -> Execution -> Output -> Audit Update).
   - Step 8: Apply Resource Policies: Max 4GB RAM Kernel+DB, 4GB Agents.
   - Step 9: Configure Rule 1: Terminate processes >80% CPU >5m.
   - Step 10: Configure Rule 2: Hourly backup of critical state.

9. Data & State Created
   - `audit-log` (Immutable ledger of commands).
   - Process ID/Location/Resource Footprint (Self-Identity).
   - Local backups (Hourly).

10. Decision Logic Implemented
    - Rule 0: No command executes without successful audit log write.
    - Rule 1: Terminate process if CPU > 80% for 5 mins (unless whitelisted).
    - Rule 2: Backup critical state every hour.

11. Observability & Audit Hooks
    - Shell command hashing and storage.
    - Record PID, Start Time, Exit Code for every spawned process.
    - Console Output (stdout/stderr).
    - Health Endpoint (HTTP 200/503).

12. Failure Conditions
    - `kernel-d` crash.
    - Disk usage > 90%.

13. Rollback Strategy
    - Kernel Panic: Systemd auto-restart of `kernel-d`.
    - Disk Full: Log rotation triggers; emergency stop non-critical agents.
    - Manual Recovery: Use `bootstrap-cli`.

14. Validation Tests (Binary)
    - Test 1: PASS / FAIL (Server hardened, SSH only)
    - Test 2: PASS / FAIL (`kernel-d` running as system service)
    - Test 3: PASS / FAIL (Audit log captures dummy events)
    - Test 4: PASS / FAIL ("Hello World" agent task executes in sandbox)

15. Phase Exit Gate
    - All Validation Tests PASS.
