# Contributing to Empire AI

**Thank you for your interest in contributing to Empire AI!**  
This document provides comprehensive guidelines for contributing to the project.

## Table of Contents

1. [Getting Started](#getting-started)
2. [Development Setup](#development-setup)
3. [Contribution Types](#contribution-types)
4. [Development Workflow](#development-workflow)
5. [Code Standards](#code-standards)
6. [Testing Requirements](#testing-requirements)
7. [Documentation](#documentation)
8. [Security](#security)
9. [Review Process](#review-process)
10. [Community Guidelines](#community-guidelines)

---

## Getting Started

### Prerequisites

Before contributing to Empire AI, ensure you have:

- **Git**: For version control
- **Python 3.8+**: For backend development
- **Node.js 18+**: For frontend development
- **Code Editor**: VS Code recommended with our extensions
- **Docker**: For containerized development (optional)

### First Steps

1. **Fork the repository** on GitHub
2. **Clone your fork** locally:
   ```bash
   git clone https://github.com/YOUR_USERNAME/empire-ai.git
   cd empire-ai
   ```
3. **Add upstream remote**:
   ```bash
   git remote add upstream https://github.com/empire-ai/empire-ai.git
   ```
4. **Set up your development environment** (see below)

---

## Development Setup

### Backend Setup

1. **Create virtual environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   pip install -r requirements-dev.txt  # Development dependencies
   ```

3. **Set up environment variables**:
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

4. **Run database migrations** (if applicable):
   ```bash
   python scripts/migrate.py
   ```

### Frontend Setup

1. **Install Node.js dependencies**:
   ```bash
   npm install
   ```

2. **Set up environment variables**:
   ```bash
   cp .env.example .env.local
   # Edit .env.local with your configuration
   ```

3. **Start development server**:
   ```bash
   npm run dev
   ```

### Development Tools

Install our recommended VS Code extensions:
```bash
code --install-extension ms-python.python
code --install-extension bradlc.vscode-tailwindcss
code --install-extension esbenp.prettier-vscode
code --install-extension ms-vscode.vscode-eslint
```

---

## Contribution Types

We welcome contributions in many forms:

### Code Contributions
- **Bug fixes**: Resolve issues in existing functionality
- **New features**: Add new capabilities to Empire AI
- **Performance improvements**: Optimize existing code
- **Refactoring**: Improve code structure and maintainability

### Documentation Contributions
- **Documentation updates**: Improve existing documentation
- **Tutorials**: Create step-by-step guides
- **Examples**: Add usage examples and code samples
- **Translations**: Help translate documentation

### Community Contributions
- **Issue triage**: Help categorize and prioritize issues
- **User support**: Help other users in discussions
- **Testing**: Test pre-release versions
- **Feedback**: Provide constructive feedback

---

## Development Workflow

### 1. Create an Issue

Before starting work:
1. **Search existing issues** to avoid duplicates
2. **Create a new issue** describing your proposed change
3. **Wait for maintainer approval** before starting work
4. **Label the issue** with appropriate tags

### 2. Create a Branch

```bash
# Sync with upstream
git fetch upstream
git checkout main
git merge upstream/main

# Create feature branch
git checkout -b feature/your-feature-name
# Or for bug fixes:
git checkout -b fix/issue-number-description
```

### 3. Make Changes

Follow our [Code Standards](#code-standards) and [Testing Requirements](#testing-requirements).

### 4. Test Your Changes

```bash
# Run backend tests
pytest

# Run frontend tests
npm test

# Run linting
npm run lint
pylint src/

# Run type checking
npm run typecheck
python -m mypy src/
```

### 5. Commit Changes

Use our commit message format:
```
type(scope): description

[optional body]

[optional footer]
```

**Types:**
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation
- `style`: Formatting
- `refactor`: Code refactoring
- `test`: Testing
- `chore`: Maintenance

**Examples:**
```
feat(agent): add market analysis capability

Implement market trend analysis for the Scout agent to improve
opportunity identification accuracy.

Closes #123
```

### 6. Create Pull Request

1. **Push your branch**:
   ```bash
   git push origin feature/your-feature-name
   ```

2. **Create Pull Request** on GitHub
3. **Fill out the PR template** completely
4. **Link relevant issues**
5. **Request reviews** from appropriate maintainers

### 7. Address Feedback

- **Respond to review comments** promptly
- **Make requested changes**
- **Push additional commits** to your branch
- **Keep PR updated** with latest main branch

---

## Code Standards

### Python Standards

#### Style Guide
- **PEP 8**: Follow Python style guidelines
- **Black**: Use Black for code formatting
- **Line length**: 88 characters
- **Imports**: Group imports (standard library, third-party, local)

#### Code Quality
- **Type hints**: Use type hints for all functions
- **Docstrings**: Use Google-style docstrings
- **Error handling**: Handle exceptions appropriately
- **Logging**: Use structured logging

#### Example
```python
from typing import List, Optional
import logging

logger = logging.getLogger(__name__)

def analyze_market(data: List[dict], threshold: float = 0.5) -> Optional[dict]:
    """Analyze market data and identify opportunities.
    
    Args:
        data: List of market data points
        threshold: Minimum confidence threshold
        
    Returns:
        Analysis results or None if insufficient data
        
    Raises:
        ValueError: If data format is invalid
    """
    if not data:
        logger.warning("No market data provided")
        return None
    
    try:
        # Analysis logic here
        result = {"score": 0.8, "opportunities": []}
        logger.info(f"Market analysis completed: {result}")
        return result
    except Exception as e:
        logger.error(f"Market analysis failed: {e}")
        raise
```

### JavaScript/TypeScript Standards

#### Style Guide
- **Prettier**: Use Prettier for code formatting
- **ESLint**: Follow ESLint rules
- **TypeScript**: Use TypeScript for type safety
- **Naming**: Use camelCase for variables, PascalCase for classes

#### Code Quality
- **Components**: Use functional components with hooks
- **Props**: Define prop interfaces
- **Error handling**: Use error boundaries
- **State management**: Use appropriate state management

#### Example
```typescript
interface AgentStatus {
  id: string;
  status: 'active' | 'inactive' | 'error';
  lastActivity: Date;
}

const AgentMonitor: React.FC<{ agents: AgentStatus[] }> = ({ agents }) => {
  const [selectedAgent, setSelectedAgent] = useState<string | null>(null);

  const handleAgentClick = useCallback((agentId: string) => {
    setSelectedAgent(agentId);
  }, []);

  return (
    <div className="agent-monitor">
      {agents.map((agent) => (
        <AgentCard
          key={agent.id}
          agent={agent}
          onClick={handleAgentClick}
          isSelected={selectedAgent === agent.id}
        />
      ))}
    </div>
  );
};
```

### General Standards

#### Naming Conventions
- **Files**: kebab-case for files (`agent-monitor.py`)
- **Directories**: kebab-case for directories (`agent-system/`)
- **Constants**: UPPER_SNAKE_CASE (`MAX_RETRIES`)
- **Functions**: snake_case for Python, camelCase for JavaScript

#### Comments and Documentation
- **Code comments**: Explain why, not what
- **TODO comments**: Use `TODO:` with issue number
- **README**: Update README for significant changes
- **API docs**: Document all public APIs

---

## Testing Requirements

### Test Coverage

- **Backend**: Minimum 90% code coverage
- **Frontend**: Minimum 80% code coverage
- **Critical paths**: 95% coverage required
- **Integration tests**: Cover all major workflows

### Test Types

#### Unit Tests
- Test individual functions and methods
- Mock external dependencies
- Test edge cases and error conditions
- Use descriptive test names

#### Integration Tests
- Test component interactions
- Test API endpoints
- Test database operations
- Use test databases/fixtures

#### End-to-End Tests
- Test complete user workflows
- Test UI interactions
- Test system integration
- Use Playwright for browser testing

### Test Structure

#### Python Tests (pytest)
```python
import pytest
from unittest.mock import Mock, patch

class TestMarketAnalyzer:
    def test_analyze_market_success(self, market_data):
        """Test successful market analysis."""
        analyzer = MarketAnalyzer()
        result = analyzer.analyze(market_data)
        
        assert result is not None
        assert "score" in result
        assert result["score"] > 0

    def test_analyze_market_empty_data(self):
        """Test analysis with empty data."""
        analyzer = MarketAnalyzer()
        result = analyzer.analyze([])
        
        assert result is None

    @patch('requests.get')
    def test_external_api_call(self, mock_get):
        """Test external API integration."""
        mock_get.return_value.json.return_value = {"data": "test"}
        
        analyzer = MarketAnalyzer()
        result = analyzer.fetch_external_data()
        
        assert result == {"data": "test"}
```

#### JavaScript Tests (Jest)
```typescript
import { render, screen, fireEvent } from '@testing-library/react';
import { AgentMonitor } from './AgentMonitor';

describe('AgentMonitor', () => {
  const mockAgents = [
    { id: '1', status: 'active', lastActivity: new Date() },
    { id: '2', status: 'inactive', lastActivity: new Date() },
  ];

  test('renders agent cards', () => {
    render(<AgentMonitor agents={mockAgents} />);
    
    expect(screen.getByText('Agent 1')).toBeInTheDocument();
    expect(screen.getByText('Agent 2')).toBeInTheDocument();
  });

  test('handles agent selection', () => {
    render(<AgentMonitor agents={mockAgents} />);
    
    fireEvent.click(screen.getByText('Agent 1'));
    
    expect(screen.getByText('Agent 1')).toHaveClass('selected');
  });
});
```

### Running Tests

```bash
# Backend tests
pytest                          # Run all tests
pytest tests/unit/              # Run unit tests only
pytest tests/integration/       # Run integration tests only
pytest --cov=src               # Run with coverage

# Frontend tests
npm test                        # Run all tests
npm run test:unit              # Run unit tests only
npm run test:e2e               # Run e2e tests
npm run test:coverage          # Run with coverage
```

---

## Documentation

### Documentation Types

#### Code Documentation
- **Docstrings**: All public functions and classes
- **Comments**: Complex logic and business rules
- **Type hints**: Python type annotations
- **JSDoc**: JavaScript documentation

#### User Documentation
- **API docs**: REST API and WebSocket documentation
- **User guides**: Step-by-step instructions
- **Tutorials**: Learning materials
- **Examples**: Code examples and use cases

#### Developer Documentation
- **Architecture**: System design and architecture
- **Setup**: Development environment setup
- **Contributing**: This guide
- **Release notes**: Version changelogs

### Documentation Standards

#### Markdown Format
- Use GitHub-flavored markdown
- Include table of contents for long documents
- Use proper heading hierarchy
- Include code examples with syntax highlighting

#### API Documentation
- Document all endpoints
- Include request/response examples
- Document error responses
- Include authentication requirements

#### Examples
```python
def create_asset(name: str, config: dict) -> Asset:
    """Create a new digital asset.
    
    Args:
        name: Human-readable name for the asset
        config: Asset configuration dictionary
        
    Returns:
        Created asset object
        
    Raises:
        ValueError: If configuration is invalid
        AssetExistsError: If asset with name already exists
        
    Example:
        >>> config = {"type": "website", "budget": 1000}
        >>> asset = create_asset("My Website", config)
        >>> print(asset.name)
        My Website
    """
```

---

## Security

### Security Principles

- **Never commit secrets**: No API keys, passwords, or tokens
- **Validate inputs**: Validate all user inputs and data
- **Use secure defaults**: Secure by default configuration
- **Follow least privilege**: Minimal permissions required
- **Report vulnerabilities**: Responsible disclosure

### Security Guidelines

#### Code Security
- **SQL injection**: Use parameterized queries
- **XSS prevention**: Sanitize user input
- **Authentication**: Secure authentication practices
- **Authorization**: Proper access controls

#### Dependency Security
- **Vulnerability scanning**: Regular dependency scans
- **Updates**: Keep dependencies updated
- **Review**: Review new dependencies for security
- **Patches**: Apply security patches promptly

#### Data Security
- **Encryption**: Encrypt sensitive data
- **Redaction**: Redact sensitive information from logs
- **Retention**: Follow data retention policies
- **Privacy**: Protect user privacy

### Security Testing

```bash
# Security scans
npm audit                    # Node.js security audit
pip install safety && safety check  # Python security check

# Run security tests
pytest tests/security/       # Security-specific tests
npm run test:security       # Frontend security tests
```

---

## Review Process

### Review Types

#### Code Review
- **Technical review**: Code quality and correctness
- **Security review**: Security implications
- **Performance review**: Performance impact
- **Documentation review**: Documentation completeness

#### Architecture Review
- **Design review**: Architecture and design decisions
- **Scalability review**: System scalability
- **Integration review**: System integration impact
- **Standards review**: Compliance with standards

### Review Guidelines

#### For Reviewers
- **Be constructive**: Provide helpful, specific feedback
- **Be thorough**: Check all aspects of the change
- **Be timely**: Review within 3 business days
- **Be respectful**: Maintain professional communication

#### For Authors
- **Be responsive**: Address feedback promptly
- **Be open**: Consider all feedback constructively
- **Be thorough**: Address all review comments
- **Be patient**: Allow adequate time for review

### Review Checklist

#### Code Quality
- [ ] Code follows project standards
- [ ] Tests are comprehensive and passing
- [ ] Documentation is updated
- [ ] No hardcoded secrets or credentials

#### Security
- [ ] Input validation is implemented
- [ ] Authentication/authorization is appropriate
- [ ] No security vulnerabilities introduced
- [ ] Security best practices followed

#### Performance
- [ ] No performance regressions
- [ ] Database queries are optimized
- [ ] Memory usage is appropriate
- [ ] Scalability considerations addressed

---

## Community Guidelines

### Code of Conduct

We are committed to providing a welcoming and inclusive environment. Please:

- **Be respectful**: Treat all community members with respect
- **Be inclusive**: Welcome contributions from all backgrounds
- **Be constructive**: Provide helpful and constructive feedback
- **Be patient**: Understand that contributors have different experience levels

### Communication

#### GitHub Issues
- **Search first**: Check for existing issues
- **Be specific**: Provide clear, detailed descriptions
- **Use templates**: Use provided issue templates
- **Tag appropriately**: Use relevant labels

#### Discussions
- **Stay on topic**: Keep discussions relevant
- **Be helpful**: Help others when you can
- **Share knowledge**: Contribute your expertise
- **Learn from others**: Be open to learning

#### Pull Requests
- **Be clear**: Describe your changes clearly
- **Be responsive**: Respond to review comments
- **Be patient**: Allow time for thorough review
- **Be grateful**: Thank reviewers for their time

### Getting Help

#### Resources
- **Documentation**: Comprehensive project documentation
- **Issues**: GitHub issues for bugs and features
- **Discussions**: GitHub discussions for questions
- **Community**: Community forums and chat

#### Support Channels
- **GitHub Issues**: For bugs and feature requests
- **GitHub Discussions**: For questions and general discussion
- **Security**: security@empire-ai.com for security issues
- **Maintainers**: Tag maintainers for specific questions

---

## Recognition

### Contributor Recognition

We value all contributions and recognize contributors through:

- **Contributors list**: Acknowledged in README and documentation
- **Release notes**: Mentioned in release notes for significant contributions
- **Community highlights**: Featured in community communications
- **Swag**: Empire AI merchandise for significant contributors

### Types of Contributions

We recognize all types of contributions:

- **Code**: Bug fixes, features, performance improvements
- **Documentation**: Docs, tutorials, examples, translations
- **Community**: Support, triage, feedback, testing
- **Design**: UI/UX improvements, graphics, branding
- **Infrastructure**: DevOps, CI/CD, monitoring improvements

---

## Getting Started Checklist

- [ ] Read this contributing guide
- [ ] Set up development environment
- [ ] Fork and clone the repository
- [ ] Set up upstream remote
- [ ] Install dependencies
- [ ] Run tests to verify setup
- [ ] Explore the codebase
- [ ] Find an issue to work on
- [ ] Create a branch for your work
- [ ] Make your changes
- [ ] Write tests for your changes
- [ ] Update documentation
- [ ] Run all tests and checks
- [ ] Commit your changes
- [ ] Create a pull request
- [ ] Respond to review feedback
- [ ] Celebrate your contribution! 🎉

---

## Questions?

If you have questions about contributing:

- **Check the documentation**: Most questions are answered in our docs
- **Search issues**: See if your question has been asked before
- **Create a discussion**: Ask questions in GitHub Discussions
- **Contact maintainers**: Tag maintainers in issues or discussions

---

**Thank you for contributing to Empire AI!** Your contributions help make Empire AI better for everyone.

**Last Updated**: January 21, 2026  
**Version**: 1.0  
**Maintainers**: Empire AI Team
