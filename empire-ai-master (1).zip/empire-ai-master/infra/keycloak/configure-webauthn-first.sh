#!/bin/bash

# ATLAS Protection System - Keycloak WebAuthn-First Configuration
# Configures empire-humans realm for WebAuthn-first authentication per plan §4.1-4.2

set -euo pipefail

# Configuration
KEYCLOAK_URL="${KEYCLOAK_URL:-http://localhost:8080}"
ADMIN_USER="${KEYCLOAK_ADMIN:-admin}"
ADMIN_PASSWORD="${KEYCLOAK_ADMIN_PASSWORD:-admin}"
REALM="empire-humans"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}"
    exit 1
}

# Get admin token
get_admin_token() {
    log "Getting admin token from Keycloak..."
    TOKEN=$(curl -s -X POST "${KEYCLOAK_URL}/realms/master/protocol/openid-connect/token" \
        -H "Content-Type: application/x-www-form-urlencoded" \
        -d "username=${ADMIN_USER}" \
        -d "password=${ADMIN_PASSWORD}" \
        -d "grant_type=password" \
        -d "client_id=admin-cli" | jq -r '.access_token')
    
    if [[ "$TOKEN" == "null" || -z "$TOKEN" ]]; then
        error "Failed to get admin token"
    fi
    
    log "Admin token obtained successfully"
}

# Update realm to use WebAuthn-first flow
configure_webauthn_first() {
    log "Configuring WebAuthn-first authentication flow..."
    
    # Import the WebAuthn-first flow
    curl -s -X POST "${KEYCLOAK_URL}/admin/realms/${REALM}/authentication/flows" \
        -H "Authorization: Bearer ${TOKEN}" \
        -H "Content-Type: application/json" \
        -d @/opt/keycloak/conf/flows/webauthn-first-flow.json
    
    # Set browser flow to use WebAuthn-first
    curl -s -X PUT "${KEYCLOAK_URL}/admin/realms/${REALM}" \
        -H "Authorization: Bearer ${TOKEN}" \
        -H "Content-Type: application/json" \
        -d '{
            "browserFlow": "webauthn-first-browser"
        }'
    
    # Update realm settings to enforce WebAuthn
    curl -s -X PUT "${KEYCLOAK_URL}/admin/realms/${REALM}" \
        -H "Authorization: Bearer ${TOKEN}" \
        -H "Content-Type: application/json" \
        -d '{
            "attributes": {
                "webAuthnPolicyPasswordless": "true",
                "webAuthnPolicyRequireResidentKey": "false",
                "webAuthnPolicyUserVerificationRequirement": "required",
                "webAuthnPolicySignatureAlgorithms": "ES256,RS256,EdDSA",
                "webAuthnPolicyAttestationConveyancePreference": "required",
                "webAuthnPolicyAuthenticatorAttachment": "platform",
                "webAuthnPolicyAvoidSameAuthenticatorReuse": "false",
                "webAuthnPolicyAcceptableAaguids": ""
            }
        }'
    
    log "WebAuthn-first flow configured"
}

# Verify configuration
verify_configuration() {
    log "Verifying WebAuthn-first configuration..."
    
    # Check browser flow
    FLOW=$(curl -s -X GET "${KEYCLOAK_URL}/admin/realms/${REALM}" \
        -H "Authorization: Bearer ${TOKEN}" | jq -r '.browserFlow')
    
    if [[ "$FLOW" == "webauthn-first-browser" ]]; then
        log "✓ Browser flow correctly set to WebAuthn-first"
    else
        error "Browser flow not set correctly: $FLOW"
    fi
    
    # Check required actions
    WEBAUTHN_ACTION=$(curl -s -X GET "${KEYCLOAK_URL}/admin/realms/${REALM}/authentication/required-actions" \
        -H "Authorization: Bearer ${TOKEN}" | jq -r '.[] | select(.alias=="webauthn-register-passwordless") | .enabled')
    
    if [[ "$WEBAUTHN_ACTION" == "true" ]]; then
        log "✓ WebAuthn registration action is enabled and required"
    else
        error "WebAuthn registration action not properly configured"
    fi
    
    # Check token lifespans
    ACCESS_LIFESPAN=$(curl -s -X GET "${KEYCLOAK_URL}/admin/realms/${REALM}" \
        -H "Authorization: Bearer ${TOKEN}" | jq -r '.accessTokenLifespan')
    
    if [[ "$ACCESS_LIFESPAN" == "900" ]]; then
        log "✓ Access token lifespan correctly set to 900 seconds (15 minutes)"
    else
        warn "Access token lifespan is $ACCESS_LIFESPAN, expected 900"
    fi
    
    REFRESH_LIFESPAN=$(curl -s -X GET "${KEYCLOAK_URL}/admin/realms/${REALM}" \
        -H "Authorization: Bearer ${TOKEN}" | jq -r '.refreshTokenLifespan')
    
    if [[ "$REFRESH_LIFESPAN" == "604800" ]]; then
        log "✓ Refresh token lifespan correctly set to 604800 seconds (7 days)"
    else
        warn "Refresh token lifespan is $REFRESH_LIFESPAN, expected 604800"
    fi
    
    # Check brute force protection
    BRUTE_FORCE=$(curl -s -X GET "${KEYCLOAK_URL}/admin/realms/${REALM}" \
        -H "Authorization: Bearer ${TOKEN}" | jq -r '.bruteForceProtected')
    
    if [[ "$BRUTE_FORCE" == "true" ]]; then
        log "✓ Brute force protection is enabled"
    else
        error "Brute force protection is not enabled"
    fi
    
    # Check security headers
    HEADERS=$(curl -s -X GET "${KEYCLOAK_URL}/admin/realms/${REALM}" \
        -H "Authorization: Bearer ${TOKEN}" | jq -r '.browserSecurityHeaders.xFrameOptions')
    
    if [[ "$HEADERS" == "DENY" ]]; then
        log "✓ X-Frame-Options header set to DENY"
    else
        error "X-Frame-Options header not properly configured"
    fi
    
    log "Configuration verification complete"
}

# Main execution
main() {
    log "Starting Keycloak WebAuthn-first configuration..."
    
    # Wait for Keycloak to be ready
    log "Waiting for Keycloak to be ready..."
    until curl -s "${KEYCLOAK_URL}/health/ready" > /dev/null; do
        sleep 5
    done
    log "Keycloak is ready"
    
    get_admin_token
    configure_webauthn_first
    verify_configuration
    
    log "WebAuthn-first configuration completed successfully!"
    log "Realm ${REALM} now enforces WebAuthn as primary authentication method"
}

# Run if executed directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
