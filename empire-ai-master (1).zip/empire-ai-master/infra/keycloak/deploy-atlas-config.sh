#!/bin/bash

# ATLAS Protection System - Keycloak Deployment Script
# Deploys Phase 1: Identity & Keycloak Foundation configuration

set -euo pipefail

# Configuration
KEYCLOAK_URL="${KEYCLOAK_URL:-http://localhost:8080}"
ADMIN_USER="${KEYCLOAK_ADMIN:-admin}"
ADMIN_PASSWORD="${KEYCLOAK_ADMIN_PASSWORD:-admin}"
REALM_FILE="minimal-atlas-realm.json"
CLIENT_FILE="empire-admin-ui-client-atlas-v1.json"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Logging
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}"
    exit 1
}

# Check if Keycloak is ready
check_keycloak() {
    log "Checking Keycloak availability..."
    
    local max_attempts=30
    local attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        if curl -f -s "${KEYCLOAK_URL}/health/ready" > /dev/null; then
            log "Keycloak is ready"
            return 0
        fi
        
        warn "Attempt $attempt/$max_attempts: Keycloak not ready, waiting..."
        sleep 10
        ((attempt++))
    done
    
    error "Keycloak not ready after $max_attempts attempts"
}

# Get admin token
get_admin_token() {
    log "Obtaining admin token..."
    
    local token=$(curl -s -X POST "${KEYCLOAK_URL}/realms/master/protocol/openid-connect/token" \
        -H "Content-Type: application/x-www-form-urlencoded" \
        -d "grant_type=password" \
        -d "username=${ADMIN_USER}" \
        -d "password=${ADMIN_PASSWORD}" \
        -d "client_id=admin-cli" | jq -r '.access_token')
    
    if [[ "$token" == "null" || -z "$token" ]]; then
        error "Failed to obtain admin token"
    fi
    
    echo "$token"
}

# Import realm
import_realm() {
    local token=$1
    log "Importing atlas realm..."
    
    local response=$(curl -s -w "\n%{http_code}" -X POST "${KEYCLOAK_URL}/admin/realms" \
        -H "Authorization: Bearer $token" \
        -H "Content-Type: application/json" \
        -d @"${REALM_FILE}")
    
    local status=$(echo "$response" | tail -n1)
    # The body might be many lines, so sed '$d' is fine, but let's be careful.
    local body=$(echo "$response" | head -n -1)
    
    if [[ "$status" -ne 201 && "$status" -ne 200 ]]; then
        if echo "$body" | grep -q "Conflict"; then
            warn "Realm already exists, updating..."
            curl -s -f -X DELETE "${KEYCLOAK_URL}/admin/realms/atlas" \
                -H "Authorization: Bearer $token"
            
            # Import again
            curl -s -f -X POST "${KEYCLOAK_URL}/admin/realms" \
                -H "Authorization: Bearer $token" \
                -H "Content-Type: application/json" \
                -d @"${REALM_FILE}"
        else
            error "Failed to import realm (Status: $status). Response body: $body"
        fi
    fi
    
    log "Realm imported successfully"
}

# Update client configuration
update_client() {
    local token=$1
    log "Updating empire-admin-ui client configuration..."
    
    # Get client ID
    local client_id=$(curl -s -X GET "${KEYCLOAK_URL}/admin/realms/atlas/clients?clientId=empire-admin-ui" \
        -H "Authorization: Bearer $token" | jq -r '.[0].id')
    
    if [[ "$client_id" == "null" || -z "$client_id" ]]; then
        error "Client empire-admin-ui not found"
    fi
    
    # Update client
    curl -s -X PUT "${KEYCLOAK_URL}/admin/realms/atlas/clients/${client_id}" \
        -H "Authorization: Bearer $token" \
        -H "Content-Type: application/json" \
        -d @"${CLIENT_FILE}" > /dev/null
    
    log "Client configuration updated"
}

# Verify configuration
verify_config() {
    local token=$1
    log "Verifying ATLAS configuration..."
    
    # Check realm settings
    local realm_config=$(curl -s -X GET "${KEYCLOAK_URL}/admin/realms/atlas" \
        -H "Authorization: Bearer $token")
    
    # Verify token lifespan
    local access_token_lifespan=$(echo "$realm_config" | jq -r '.accessTokenLifespan')
    if [[ "$access_token_lifespan" != "900" ]]; then
        error "Access token lifespan should be 900 seconds (15 minutes), got $access_token_lifespan"
    fi
    
    # Verify refresh token max reuse
    local refresh_token_reuse=$(echo "$realm_config" | jq -r '.refreshTokenMaxReuse')
    if [[ "$refresh_token_reuse" != "1" ]]; then
        error "Refresh token max reuse should be 1, got $refresh_token_reuse"
    fi
    
    # Verify WebAuthn required action is enabled and default
    local webauthn_action=$(echo "$realm_config" | jq -r '.requiredActions[] | select(.alias=="webauthn-register-passwordless") | {enabled, defaultAction}')
    if [[ "$(echo "$webauthn_action" | jq -r '.enabled')" != "true" ]]; then
        error "WebAuthn passwordless registration should be enabled"
    fi
    if [[ "$(echo "$webauthn_action" | jq -r '.defaultAction')" != "true" ]]; then
        error "WebAuthn passwordless registration should be default action"
    fi
    
    # Verify brute force protection
    local brute_force=$(echo "$realm_config" | jq -r '.bruteForceProtected')
    if [[ "$brute_force" != "true" ]]; then
        error "Brute force protection should be enabled"
    fi
    
    # Verify security headers
    local x_frame_options=$(echo "$realm_config" | jq -r '.browserSecurityHeaders.xFrameOptions')
    if [[ "$x_frame_options" != "DENY" ]]; then
        error "X-Frame-Options should be DENY"
    fi
    
    # Check client flow binding
    local client_flow=$(curl -s -X GET "${KEYCLOAK_URL}/admin/realms/atlas/clients?clientId=empire-admin-ui" \
        -H "Authorization: Bearer $token" | jq -r '.[0].authenticationFlowBindingOverrides.browser')
    if [[ "$client_flow" != "webauthn-first-browser" ]]; then
        error "Client should use webauthn-first-browser flow"
    fi
    
    log "ATLAS configuration verified successfully"
}

# Main execution
main() {
    log "Starting ATLAS Keycloak deployment..."
    
    # Check prerequisites
    command -v curl >/dev/null || error "curl is required"
    command -v jq >/dev/null || error "jq is required"
    
    # Check files exist
    [[ -f "$REALM_FILE" ]] || error "Realm file $REALM_FILE not found"
    [[ -f "$CLIENT_FILE" ]] || error "Client file $CLIENT_FILE not found"
    
    # Execute deployment
    check_keycloak
    local token=$(get_admin_token)
    import_realm "$token"
    update_client "$token"
    verify_config "$token"
    
    log "ATLAS Keycloak deployment completed successfully!"
    log ""
    log "Next steps:"
    log "1. Create initial operators with required attributes"
    log "2. Enroll WebAuthn devices for each operator"
    log "3. Configure TOTP backup for each operator"
    log "4. Test WebAuthn-first authentication flow"
}

# Run if executed directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
