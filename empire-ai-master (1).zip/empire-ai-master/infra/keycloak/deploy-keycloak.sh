#!/bin/bash

# Deployment script for Keycloak realm configuration
# ATLAS PROTECTION SYSTEM - Phase 1: Identity & Keycloak Foundation

set -euo pipefail

# Configuration
KEYCLOAK_URL="${KEYCLOAK_URL:-http://localhost:8080}"
KEYCLOAK_ADMIN="${KEYCLOAK_ADMIN:-admin}"
KEYCLOAK_PASSWORD="${KEYCLOAK_PASSWORD:-admin}"
REALM_FILE="empire-humans-realm.json"
ADMIN_UI_CLIENT_FILE="empire-admin-ui-client.json"
API_CLIENT_FILE="empire-api-client.json"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Logging function
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}"
    exit 1
}

# Check if jq is installed
check_dependencies() {
    if ! command -v jq &> /dev/null; then
        error "jq is required but not installed. Please install jq."
    fi
    
    if ! command -v curl &> /dev/null; then
        error "curl is required but not installed. Please install curl."
    fi
}

# Wait for Keycloak to be ready
wait_for_keycloak() {
    log "Waiting for Keycloak to be ready..."
    
    local max_attempts=30
    local attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        if curl -s "$KEYCLOAK_URL/health/ready" > /dev/null 2>&1; then
            log "Keycloak is ready!"
            return 0
        fi
        
        warn "Attempt $attempt/$max_attempts: Keycloak not ready, waiting..."
        sleep 10
        ((attempt++))
    done
    
    error "Keycloak did not become ready within expected time"
}

# Get admin token
get_admin_token() {
    log "Getting admin token from Keycloak..."
    
    local response
    response=$(curl -s -X POST "$KEYCLOAK_URL/realms/master/protocol/openid-connect/token" \
        -H "Content-Type: application/x-www-form-urlencoded" \
        -d "username=$KEYCLOAK_ADMIN" \
        -d "password=$KEYCLOAK_PASSWORD" \
        -d "grant_type=password" \
        -d "client_id=admin-cli")
    
    if echo "$response" | jq -e '.error' > /dev/null; then
        error "Failed to get admin token: $(echo "$response" | jq -r '.error_description')"
    fi
    
    echo "$response" | jq -r '.access_token'
}

# Create or update realm
create_realm() {
    local token="$1"
    log "Creating realm empire-humans..."
    
    local response
    response=$(curl -s -w "%{http_code}" -X POST "$KEYCLOAK_URL/admin/realms" \
        -H "Authorization: Bearer $token" \
        -H "Content-Type: application/json" \
        -d @"$REALM_FILE")
    
    local http_code="${response: -3}"
    local body="${response%???}"
    
    if [ "$http_code" = "409" ]; then
        warn "Realm already exists, updating..."
        response=$(curl -s -w "%{http_code}" -X PUT "$KEYCLOAK_URL/admin/realms/empire-humans" \
            -H "Authorization: Bearer $token" \
            -H "Content-Type: application/json" \
            -d @"$REALM_FILE")
        
        http_code="${response: -3}"
        body="${response%???}"
    fi
    
    if [ "$http_code" -ge 400 ]; then
        error "Failed to create/update realm: $body"
    fi
    
    log "Realm empire-humans created/updated successfully"
}

# Create clients
create_clients() {
    local token="$1"
    log "Creating clients..."
    
    # Create empire-admin-ui client
    log "Creating empire-admin-ui client..."
    local response
    response=$(curl -s -w "%{http_code}" -X POST "$KEYCLOAK_URL/admin/realms/empire-humans/clients" \
        -H "Authorization: Bearer $token" \
        -H "Content-Type: application/json" \
        -d @"$ADMIN_UI_CLIENT_FILE")
    
    local http_code="${response: -3}"
    
    if [ "$http_code" = "409" ]; then
        warn "Client empire-admin-ui already exists, updating..."
        # Get client ID
        local client_id
        client_id=$(curl -s "$KEYCLOAK_URL/admin/realms/empire-humans/clients?clientId=empire-admin-ui" \
            -H "Authorization: Bearer $token" | jq -r '.[0].id')
        
        response=$(curl -s -w "%{http_code}" -X PUT "$KEYCLOAK_URL/admin/realms/empire-humans/clients/$client_id" \
            -H "Authorization: Bearer $token" \
            -H "Content-Type: application/json" \
            -d @"$ADMIN_UI_CLIENT_FILE")
        
        http_code="${response: -3}"
    fi
    
    if [ "$http_code" -ge 400 ]; then
        error "Failed to create/update empire-admin-ui client"
    fi
    
    log "Client empire-admin-ui created/updated successfully"
    
    # Create empire-api client
    log "Creating empire-api client..."
    response=$(curl -s -w "%{http_code}" -X POST "$KEYCLOAK_URL/admin/realms/empire-humans/clients" \
        -H "Authorization: Bearer $token" \
        -H "Content-Type: application/json" \
        -d @"$API_CLIENT_FILE")
    
    http_code="${response: -3}"
    
    if [ "$http_code" = "409" ]; then
        warn "Client empire-api already exists, updating..."
        # Get client ID
        local client_id
        client_id=$(curl -s "$KEYCLOAK_URL/admin/realms/empire-humans/clients?clientId=empire-api" \
            -H "Authorization: Bearer $token" | jq -r '.[0].id')
        
        response=$(curl -s -w "%{http_code}" -X PUT "$KEYCLOAK_URL/admin/realms/empire-humans/clients/$client_id" \
            -H "Authorization: Bearer $token" \
            -H "Content-Type: application/json" \
            -d @"$API_CLIENT_FILE")
        
        http_code="${response: -3}"
    fi
    
    if [ "$http_code" -ge 400 ]; then
        error "Failed to create/update empire-api client"
    fi
    
    log "Client empire-api created/updated successfully"
}

# Create initial roles
create_roles() {
    local token="$1"
    log "Creating roles..."
    
    local roles=("admin" "operator" "auditor" "viewer")
    
    for role in "${roles[@]}"; do
        log "Creating role: $role"
        local response
        response=$(curl -s -w "%{http_code}" -X POST "$KEYCLOAK_URL/admin/realms/empire-humans/roles" \
            -H "Authorization: Bearer $token" \
            -H "Content-Type: application/json" \
            -d "{\"name\":\"$role\",\"description\":\"$role role for empire-humans realm\"}")
        
        local http_code="${response: -3}"
        
        if [ "$http_code" = "409" ]; then
            warn "Role $role already exists"
        elif [ "$http_code" -ge 400 ]; then
            error "Failed to create role $role"
        else
            log "Role $role created successfully"
        fi
    done
}

# Create capability roles
create_capability_roles() {
    local token="$1"
    log "Creating capability roles..."
    
    # Define capabilities as per plan §7.2
    local capabilities=(
        "action:execute"
        "action:kill"
        "action:approve"
        "policy:read"
        "policy:propose"
        "policy:test"
        "policy:deploy"
        "audit:read"
        "audit:export"
        "audit:search"
        "operator:list"
        "operator:create"
        "operator:suspend"
        "operator:restore"
        "operator:manage"
        "governance:list-decisions"
        "governance:test-policy"
        "governance:set-epoch"
        "system:healthcheck"
        "system:metrics"
        "system:reset"
        "system:emergency"
    )
    
    for capability in "${capabilities[@]}"; do
        log "Creating capability role: $capability"
        local response
        response=$(curl -s -w "%{http_code}" -X POST "$KEYCLOAK_URL/admin/realms/empire-humans/roles" \
            -H "Authorization: Bearer $token" \
            -H "Content-Type: application/json" \
            -d "{\"name\":\"$capability\",\"description\":\"Capability: $capability\",\"clientRole\":false}")
        
        local http_code="${response: -3}"
        
        if [ "$http_code" = "409" ]; then
            warn "Capability role $capability already exists"
        elif [ "$http_code" -ge 400 ]; then
            error "Failed to create capability role $capability"
        else
            log "Capability role $capability created successfully"
        fi
    done
}

# Verify deployment
verify_deployment() {
    local token="$1"
    log "Verifying deployment..."
    
    # Check realm exists
    local realm_info
    realm_info=$(curl -s "$KEYCLOAK_URL/admin/realms/empire-humans" \
        -H "Authorization: Bearer $token")
    
    if echo "$realm_info" | jq -e '.enabled' > /dev/null; then
        log "✓ Realm empire-humans is enabled"
    else
        error "Realm empire-humans not found or not enabled"
    fi
    
    # Check token settings
    local access_token_lifespan
    access_token_lifespan=$(echo "$realm_info" | jq -r '.accessCodeLifespan')
    if [ "$access_token_lifespan" = "900" ]; then
        log "✓ Access token lifespan set to 900 seconds (15 minutes)"
    else
        warn "Access token lifespan is $access_token_lifespan, expected 900"
    fi
    
    local refresh_token_lifespan
    refresh_token_lifespan=$(echo "$realm_info" | jq -r '.refreshTokenMaxReuse')
    if [ "$refresh_token_lifespan" = "1" ]; then
        log "✓ Refresh token max reuse set to 1 (single-use)"
    else
        warn "Refresh token max reuse is $refresh_token_lifespan, expected 1"
    fi
    
    # Check clients exist
    local admin_ui_client
    admin_ui_client=$(curl -s "$KEYCLOAK_URL/admin/realms/empire-humans/clients?clientId=empire-admin-ui" \
        -H "Authorization: Bearer $token")
    
    if echo "$admin_ui_client" | jq -e '.[0]' > /dev/null; then
        log "✓ Client empire-admin-ui exists"
    else
        error "Client empire-admin-ui not found"
    fi
    
    local api_client
    api_client=$(curl -s "$KEYCLOAK_URL/admin/realms/empire-humans/clients?clientId=empire-api" \
        -H "Authorization: Bearer $token")
    
    if echo "$api_client" | jq -e '.[0]' > /dev/null; then
        log "✓ Client empire-api exists"
    else
        error "Client empire-api not found"
    fi
    
    # Check WebAuthn is required
    local required_actions
    required_actions=$(curl -s "$KEYCLOAK_URL/admin/realms/empire-humans/authentication/flows/browser/executions" \
        -H "Authorization: Bearer $token")
    
    if echo "$required_actions" | jq -e '.[] | select(.requirement=="REQUIRED" and (.alias=="webauthn-register-passwordless"))' > /dev/null; then
        log "✓ WebAuthn passwordless is required"
    else
        warn "WebAuthn passwordless may not be properly configured as required"
    fi
    
    log "Deployment verification completed"
}

# Main execution
main() {
    log "Starting Keycloak deployment for ATLAS PROTECTION SYSTEM..."
    
    check_dependencies
    wait_for_keycloak
    
    local token
    token=$(get_admin_token)
    
    if [ -z "$token" ] || [ "$token" = "null" ]; then
        error "Failed to obtain admin token"
    fi
    
    create_realm "$token"
    create_clients "$token"
    create_roles "$token"
    create_capability_roles "$token"
    verify_deployment "$token"
    
    log "Keycloak deployment completed successfully!"
    log ""
    log "Next steps:"
    log "1. Create initial operator accounts with WebAuthn devices"
    log "2. Assign appropriate roles and capabilities"
    log "3. Configure mTLS for admin UI clients"
    log "4. Test authentication flows"
}

# Run main function
main "$@"
