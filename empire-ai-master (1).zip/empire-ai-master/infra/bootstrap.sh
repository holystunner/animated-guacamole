#!/bin/bash

set -eo pipefail

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Empire AI Governor Bootstrap Starting"

LOG_FILE="/app/logs/governor.log"
mkdir -p "$(dirname "$LOG_FILE")"

exec 1> >(tee -a "$LOG_FILE")
exec 2>&1

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Environment Variables Check"
if [ -z "$DATABASE_URL" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: DATABASE_URL not set"
    exit 1
fi

if [ -z "$REDIS_URL" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: REDIS_URL not set"
    exit 1
fi

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Database Connection Test"
python3 -c "
import psycopg2
import os
try:
    conn = psycopg2.connect(os.environ['DATABASE_URL'])
    cursor = conn.cursor()
    cursor.execute('SELECT 1')
    result = cursor.fetchone()
    print(f'[$(date '+%Y-%m-%d %H:%M:%S')] Database connection successful: {result[0]}')
    conn.close()
except Exception as e:
    print(f'[$(date '+%Y-%m-%d %H:%M:%S')] Database connection failed: {e}')
    exit(1)
"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Redis Connection Test"
python3 -c "
import redis
import os
try:
    r = redis.from_url(os.environ['REDIS_URL'])
    r.ping()
    print('[$(date '+%Y-%m-%d %H:%M:%S')] Redis connection successful')
except Exception as e:
    print(f'[$(date '+%Y-%m-%d %H:%M:%S')] Redis connection failed: {e}')
    exit(1)
"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Starting Governor Core"
cd /app/src
export PYTHONPATH="/app/src:${PYTHONPATH:-}"

# Start the governor with error handling
if ! exec uvicorn governor.main:app --host 0.0.0.0 --port 8080 --log-level "${LOG_LEVEL:-info}"; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: Failed to start Governor Core" >&2
    exit 1
fi
