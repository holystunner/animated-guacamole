# /bootstrap-repo (Empire-AI)
Initialize or harden Empire-AI for production-grade development.

## Prerequisites
- Repository root has AGENTS.md
- CI/scripts are installed
- Observability pack is available

## Inputs
- Target repo: empire-ai
- Primary stack: Node.js frontend + Python backend
- Services: API (Flask/FastAPI), Web (React)

## Steps
1) Verify governance installed
   - AGENTS.md exists and is readable
   - observability/ pack is in place
   - runbooks/ are available
   - scripts/ci/ are executable

2) Read repo configuration
   - Review: AGENTS.md
   - Understand: tech stack, directory layout
   - Identify: entry points, test runners, linters

3) Run local-equivalent gates
   - `npm test` (frontend)
   - `pytest` (backend)
   - `npm run lint` (frontend)
   - `python3 scripts/ci/forbidden_markers_scan.py --root .`
   - `npm audit --audit-level=high`

4) Verify observability
   - Check logging_schema.md is present
   - Verify redaction_policy.md is in place
   - Confirm obs.js reference implementation available

5) Verify incident response
   - Check triage.md exists
   - Check rca_template.md exists
   - Review runbooks/

6) Output
   - Governance system verified for empire-ai
   - All gates pass locally
   - Ready to use for all tasks

## Success Criteria
- AGENTS.md is authoritative for this repo
- All verification gates pass locally
- Observability conventions are clear
- Team can use guides immediately
