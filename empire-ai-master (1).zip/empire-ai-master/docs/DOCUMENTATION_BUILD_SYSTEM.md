# Documentation Build System

**Purpose**: Defines the separation between documentation source files and build artifacts, ensuring a clean repository surface and reproducible builds.

**Version**: 1.0  
**Date**: January 22, 2026  
**Review Cycle**: Quarterly  

---

## File Classification

### Tracked in Git (Source of Truth)

**Documentation Source Files**:
- `/docs/*.md` - All Markdown source files
- `/docs/adr/` - Architecture Decision Records
- `/docs/diagrams/source/` - Diagram source files (Mermaid, PlantUML, Draw.io)
- `/docs/v1/` - Version 1.0 documentation source
- `/docs/v2/` - Version 2.0 documentation source
- `mkdocs.yml` - MkDocs configuration
- `.readthedocs.yaml` - Read the Docs configuration
- `docs/requirements.txt` - Python documentation dependencies

**Configuration Files**:
- `mkdocs.yml` - Static site generator configuration
- `docs/requirements.txt` - Documentation build dependencies
- `.readthedocs.yaml` - Read the Docs build configuration

### Generated and Ignored (Build Artifacts)

**Static Site Outputs**:
- `site/` - MkDocs build output
- `build/` - Generic build directory
- `dist/` - Distribution build output
- `public/` - Public build output
- `docs/_build/` - Sphinx build output
- `docs/.doctrees/` - Sphinx doctrees
- `docs/_static/` - Sphinx static files
- `docs/_templates/` - Sphinx templates

**Tooling Cache and Metadata**:
- `.mkdocs_cache/` - MkDocs cache
- `.readthedocs/` - Read the Docs cache
- `.cache/` - Generic build cache
- `.parcel-cache/` - Parcel bundler cache
- `docs/node_modules/` - Node.js dependencies
- `docs/.package-lock.json` - Package lock file
- `docs/.yarn-integrity` - Yarn integrity file

**Generated Documentation Formats**:
- `docs/*.pdf` - Generated PDF documentation
- `docs/*.epub` - Generated EPUB documentation
- `docs/*.mobi` - Generated MOBI documentation
- `docs/**/*.html` - Generated HTML files
- `docs/xml/` - Generated XML documentation
- `docs/doxygen/` - Doxygen generated documentation
- `docs/sphinx/` - Sphinx generated documentation

**Diagram Build Artifacts**:
- `docs/diagrams/rendered/*.svg` - Rendered SVG diagrams
- `docs/diagrams/rendered/*.png` - Rendered PNG diagrams
- `docs/diagrams/rendered/*.pdf` - Rendered PDF diagrams
- `docs/diagrams/cache/` - Diagram generation cache
- `docs/diagrams/temp/` - Temporary diagram files
- `docs/diagrams/.plantuml/` - PlantUML cache
- `docs/diagrams/.mermaid/` - Mermaid cache

**Build Logs and Temporary Files**:
- `docs/.build.log` - Build process logs
- `docs/.build-cache/` - Build cache directory
- `docs/.temp/` - Temporary build files
- `docs/tmp/` - Temporary directory
- `docs/*.tmp` - Temporary files

---

## Build Process

### Local Development

**Prerequisites**:
```bash
# Python dependencies
pip install -r docs/requirements.txt

# Node.js dependencies (if using Node.js tools)
cd docs && npm install
```

**Build Commands**:
```bash
# Build documentation locally
mkdocs build

# Serve documentation locally
mkdocs serve

# Clean build artifacts
mkdocs build --clean

# Generate diagrams
bash docs/diagrams/tools/generate-diagrams.sh
```

### Continuous Integration

**CI Build Process**:
1. Install documentation dependencies
2. Validate documentation sources
3. Generate diagrams from source
4. Build static documentation
5. Validate build output
6. Deploy to documentation hosting

**CI Validation**:
```bash
# Validate Markdown links
mkdocs build --strict

# Validate diagram sources
bash docs/diagrams/tools/validate-diagrams.sh

# Check for broken internal links
python scripts/check-docs-links.py
```

---

## Repository Hygiene Strategy

### Rationale for Ignoring Build Artifacts

**Reduce Merge Conflicts**: Generated files create unnecessary merge conflicts in pull requests.

**Prevent Source Pollution**: Build artifacts clutter the repository and obscure source files.

**Enforce Source Discipline**: Ensures all changes go through the proper build process.

**Maintain Reproducibility**: Generated files can be reliably reproduced from source.

**Align with Enterprise Standards**: Follows industry best practices for documentation management.

### Clean Repository Surface

**Root Directory**: Contains only high-signal, long-lived artifacts:
- `README.md` - Project overview and quick start
- `LICENSE` - Legal terms
- `CONTRIBUTING.md` - Contribution guidelines
- `SECURITY.md` - Security policy
- `mkdocs.yml` - Documentation configuration

**Documentation Directory**: Organized structure with clear separation:
- `/docs/` - All documentation source files
- `/docs/v1/` - Versioned documentation source
- `/docs/v2/` - Versioned documentation source
- `/docs/adr/` - Architecture decision records
- `/docs/diagrams/source/` - Diagram source files

---

## Build Automation

### Makefile Integration

```makefile
# Documentation build targets
.PHONY: docs-build docs-clean docs-serve docs-validate

docs-build:
	mkdocs build
	bash docs/diagrams/tools/generate-diagrams.sh

docs-clean:
	rm -rf site/ docs/_build/ docs/.doctrees/
	rm -rf docs/diagrams/rendered/ docs/diagrams/cache/

docs-serve:
	mkdocs serve

docs-validate:
	mkdocs build --strict
	bash docs/diagrams/tools/validate-diagrams.sh
	python scripts/check-docs-links.py
```

### Pre-commit Hooks

**Hook Configuration** (`.pre-commit-config.yaml`):
```yaml
repos:
  - repo: local
    hooks:
      - id: docs-validate
        name: Validate documentation
        entry: make docs-validate
        language: system
        files: '^docs/.*\.md$|^mkdocs\.yml$'
      
      - id: no-generated-docs
        name: Prevent generated docs commits
        entry: python scripts/check-generated-docs.py
        language: system
        exclude: '^docs/.*\.md$|^docs/diagrams/source/.*$'
```

---

## Quality Assurance

### Build Validation

**Source Validation**:
- Markdown syntax validation
- Link checking (internal and external)
- Diagram source validation
- Configuration file validation

**Build Output Validation**:
- Generated HTML structure validation
- Navigation completeness
- Asset accessibility
- Cross-browser compatibility

### Automated Checks

**CI Pipeline Checks**:
```bash
# Fail on broken links
mkdocs build --strict

# Validate diagram generation
bash docs/diagrams/tools/validate-diagrams.sh

# Check for committed build artifacts
python scripts/check-generated-docs.py

# Validate documentation structure
python scripts/validate-docs-structure.py
```

---

## Troubleshooting

### Common Issues

**Build Artifacts Committed**:
```bash
# Remove committed build artifacts
git rm -r site/ docs/_build/ docs/diagrams/rendered/
git commit -m "Remove committed build artifacts"
```

**Missing Dependencies**:
```bash
# Install documentation dependencies
pip install -r docs/requirements.txt
cd docs && npm install
```

**Diagram Generation Failures**:
```bash
# Check diagram tool dependencies
bash docs/diagrams/tools/check-dependencies.sh

# Regenerate all diagrams
bash docs/diagrams/tools/generate-diagrams.sh --force
```

**Build Cache Issues**:
```bash
# Clean all build caches
make docs-clean
rm -rf .mkdocs_cache/ .cache/
```

### Recovery Procedures

**Complete Workspace Reset**:
```bash
# Remove all generated files
make docs-clean
rm -rf .mkdocs_cache/ .cache/ docs/node_modules/

# Rebuild from source
make docs-build
```

**Repository State Verification**:
```bash
# Check for untracked build artifacts
git status --ignored

# Validate clean repository state
python scripts/validate-repo-cleanliness.py
```

---

## Governance

### Change Management

**Documentation Source Changes**:
- All changes go through pull request review
- Automated validation runs on every commit
- Documentation builds must pass before merge

**Build System Changes**:
- Changes to build process require update to this document
- CI configuration changes require testing in feature branch
- New ignore rules must be documented here

### Compliance

**Enterprise Standards Compliance**:
- Source/build separation enforced
- No build artifacts in version control
- Reproducible builds from source
- Clean repository surface maintained

**Audit Requirements**:
- All documentation changes tracked in source
- Build process documented and reproducible
- Quality gates enforced through automation
- Regular validation of repository hygiene

---

**Document Control**: Version 1.0, January 22, 2026  
**Next Review**: April 22, 2026  
**Approval**: Documentation Platform Engineering  
**Implementation**: Release Management Team
