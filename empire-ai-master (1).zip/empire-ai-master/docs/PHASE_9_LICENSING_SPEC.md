# Phase 9: Licensing Architecture Specification

**Authority:** KAIZA Execution Framework  
**Status:** COMPLETE  
**Version:** 1.0  
**Date:** 2026-01-15

---

## 1. Overview

This document specifies the licensing infrastructure for Atlas Empire productization. It implements Section 6.4 of the Phase 9 executable plan, defining the cryptographic key schema, validation logic, and feature-gating mechanisms.

**Key Principle:** Licensing is DORMANT by default. No revenue or billing is activated.

---

## 2. License Key Structure

### 2.1 JWT-Like Format

License keys use a JWT-like structure: `header.payload.signature`

**Header (Base64URL-encoded JSON):**
```json
{
  "alg": "HS256",
  "typ": "LICENSE",
  "kid": "lic_master_v1"
}
```

**Payload (Base64URL-encoded JSON):**
```json
{
  "key_id": "lic_abc123def456",
  "instance_id": "inst_xyz789",
  "issued_at": "2026-01-15T00:00:00Z",
  "expires_at": "2027-01-15T00:00:00Z",
  "tier": "professional",
  "features": [
    "managed_instance",
    "asset_factory_basic",
    "asset_factory_advanced",
    "audit_export",
    "analytics_dashboard"
  ],
  "limits": {
    "max_concurrent_agents": 100,
    "max_assets": 10000,
    "max_registries": 5,
    "max_audit_retention_days": 365
  },
  "metadata": {
    "customer_name": "ACME Corp",
    "contact_email": "admin@acme.com",
    "region": "us-east-1"
  }
}
```

**Signature:**
```
HMAC-SHA256(
  header.payload,
  ATLAS_MASTER_SECRET
)
```

### 2.2 Key Components

| Field | Type | Required | Purpose |
|-------|------|----------|---------|
| `key_id` | string | YES | Unique identifier for key rotation |
| `instance_id` | string | YES | Links license to specific instance |
| `issued_at` | ISO 8601 | YES | Key issuance timestamp |
| `expires_at` | ISO 8601 | YES | Key expiration timestamp |
| `tier` | enum | YES | License tier (free/professional/enterprise) |
| `features` | string[] | YES | Enabled features for this tier |
| `max_concurrent_agents` | int | YES | Agent concurrency limit |
| `max_assets` | int | YES | Asset count limit |
| `max_registries` | int | YES | Registry count limit |
| `max_audit_retention_days` | int | NO | Audit data retention (days) |
| `metadata` | object | NO | Customer metadata (non-enforced) |
| `signature` | string | YES | HMAC-SHA256 signature |

---

## 3. License Tiers

### 3.1 Tier Definitions

**Free Tier:**
- Target: Internal testing, demonstration
- Features: `managed_instance`, `asset_factory_basic`
- Agent Limit: 5
- Asset Limit: 100
- Registry Limit: 1
- Audit Retention: 7 days
- Cost: $0

**Professional Tier:**
- Target: Small teams, production deployments
- Features: All free + `audit_export`, `analytics_dashboard`, `asset_factory_advanced`
- Agent Limit: 100
- Asset Limit: 10,000
- Registry Limit: 5
- Audit Retention: 365 days
- Cost: $500/month

**Enterprise Tier:**
- Target: Large organizations, custom requirements
- Features: All professional + `custom_factories`, `dedicated_support`
- Agent Limit: 1,000
- Asset Limit: 100,000
- Registry Limit: 50
- Audit Retention: Unlimited
- Cost: Custom pricing

### 3.2 Feature Definitions

| Feature | Tier | Description |
|---------|------|-------------|
| `managed_instance` | All | Run as isolated managed instance |
| `asset_factory_basic` | Free+ | Access to basic asset factories |
| `asset_factory_advanced` | Professional+ | Access to advanced factories |
| `audit_export` | Professional+ | Export audit logs as JSON/CSV |
| `analytics_dashboard` | Professional+ | View instance health dashboards |
| `custom_factories` | Enterprise | Create custom asset factories |
| `dedicated_support` | Enterprise | Dedicated support channel |
| `sso_integration` | Enterprise | Single sign-on integration |
| `compliance_reports` | Enterprise | SOC2/ISO compliance reporting |

---

## 4. License Validation

### 4.1 Validation Flow

```
1. Load License Key (env var or file)
   ↓
2. Parse JWT structure (header.payload.signature)
   ↓
3. Verify signature (HMAC-SHA256 with master_secret)
   ↓
4. Extract and validate claims
   - instance_id matches
   - not expired
   - required fields present
   ↓
5. Cache result (5-minute TTL)
   ↓
6. Return LicenseInfo or raise LicenseError
```

### 4.2 Validation Code

```python
class LicenseManager:
    def validate_license(self, force_refresh: bool = False) -> LicenseInfo:
        # 1. Check cache
        if not force_refresh and self._cached_license:
            if time.time() < self._cache_expiry:
                return self._cached_license
        
        # 2. Load and parse key
        if not self._license_key:
            raise LicenseError("No license key configured")
        
        parts = self._license_key.split('.')
        if len(parts) != 3:
            raise LicenseError("Invalid license key format")
        
        # 3. Verify signature
        header = json.loads(base64url_decode(parts[0]))
        payload = json.loads(base64url_decode(parts[1]))
        signature = parts[2]
        
        if not self._verify_signature(self._license_key, signature):
            raise LicenseError("Invalid license signature")
        
        # 4. Validate claims
        if payload['instance_id'] != self.instance_id:
            raise LicenseError("Instance ID mismatch")
        
        expires_at = datetime.fromisoformat(payload['expires_at'])
        if datetime.utcnow() > expires_at:
            raise LicenseError(f"License expired on {expires_at}")
        
        # 5. Create LicenseInfo
        license_info = LicenseInfo(
            key_id=payload['key_id'],
            instance_id=payload['instance_id'],
            issued_at=datetime.fromisoformat(payload['issued_at']),
            expires_at=expires_at,
            tier=payload['tier'],
            features=payload['features'],
            max_concurrent_agents=payload['limits']['max_concurrent_agents'],
            max_assets=payload['limits']['max_assets'],
            max_registries=payload['limits']['max_registries'],
            signature=signature
        )
        
        # 6. Cache
        self._cached_license = license_info
        self._cache_expiry = time.time() + 300
        
        return license_info
```

### 4.3 Signature Verification

```python
def _verify_signature(self, license_key: str, signature: str) -> bool:
    """Verify HMAC-SHA256 signature."""
    message = license_key.rsplit('.', 1)[0]  # header.payload
    
    h = HMAC(self.master_secret.encode(), hashes.SHA256())
    h.update(message.encode())
    
    expected_signature = h.finalize().hex()
    
    # Constant-time comparison to prevent timing attacks
    return hmac.compare_digest(signature, expected_signature)
```

---

## 5. Permission Checking

### 5.1 Operation Gating

Operations are gated by license features:

```python
OPERATION_TO_FEATURES = {
    'export_audit': {'audit_export'},
    'view_analytics': {'analytics_dashboard'},
    'create_custom_factory': {'custom_factories'},
    'use_advanced_factory': {'asset_factory_advanced'},
}

def check_operation_permitted(operation: str, license_info: LicenseInfo) -> bool:
    if operation not in OPERATION_TO_FEATURES:
        return True  # Ungated operations allowed
    
    required_features = OPERATION_TO_FEATURES[operation]
    license_features = set(license_info.features)
    
    return required_features.issubset(license_features)
```

### 5.2 Resource Limit Checking

```python
def check_resource_limit(operation: str, current_usage: int, 
                        license_info: LicenseInfo) -> bool:
    if operation == 'create_agent':
        return current_usage < license_info.max_concurrent_agents
    elif operation == 'create_asset':
        return current_usage < license_info.max_assets
    elif operation == 'create_registry':
        return current_usage < license_info.max_registries
    
    return True
```

---

## 6. License Generation (Master Only)

### 6.1 Master Key Management

```python
class MasterLicenseIssuer:
    """Issues licenses - master instance only."""
    
    def __init__(self):
        self.master_secret = os.getenv('ATLAS_MASTER_SECRET')
        if not self.master_secret:
            raise ValueError("Master secret not configured")
    
    def issue_license(self, instance_id: str, tier: str, 
                     customer_info: Dict) -> str:
        """Issue a new license key."""
        
        # Validate tier
        if tier not in ['free', 'professional', 'enterprise']:
            raise ValueError(f"Invalid tier: {tier}")
        
        # Get tier configuration
        tier_config = self._get_tier_config(tier)
        
        # Create payload
        now = datetime.utcnow()
        expires = now + timedelta(days=365)
        
        payload = {
            'key_id': f"lic_{secrets.token_hex(12)}",
            'instance_id': instance_id,
            'issued_at': now.isoformat() + 'Z',
            'expires_at': expires.isoformat() + 'Z',
            'tier': tier,
            'features': tier_config['features'],
            'limits': {
                'max_concurrent_agents': tier_config['max_agents'],
                'max_assets': tier_config['max_assets'],
                'max_registries': tier_config['max_registries'],
                'max_audit_retention_days': tier_config['retention_days']
            },
            'metadata': customer_info
        }
        
        # Create header
        header = {
            'alg': 'HS256',
            'typ': 'LICENSE',
            'kid': 'lic_master_v1'
        }
        
        # Encode and sign
        header_b64 = base64url_encode(json.dumps(header))
        payload_b64 = base64url_encode(json.dumps(payload))
        message = f"{header_b64}.{payload_b64}"
        
        signature = self._sign(message)
        
        # Return complete key
        return f"{message}.{signature}"
```

### 6.2 Key Rotation

Keys are rotated annually:

```python
def rotate_license(instance_id: str, old_key: str) -> str:
    """Rotate an expiring license."""
    
    # Validate old key
    old_info = validate_license(old_key)
    
    # Issue new key with same tier and features
    new_key = issue_license(
        instance_id=old_info.instance_id,
        tier=old_info.tier,
        customer_info=old_info.metadata
    )
    
    # Log rotation
    audit_log.log_event(
        event_type='license_rotated',
        old_key_id=old_info.key_id,
        new_key_id=extract_key_id(new_key),
        instance_id=instance_id
    )
    
    return new_key
```

---

## 7. License Distribution

### 7.1 Environment Variable

```bash
# Set on instance startup
export ATLAS_LICENSE_KEY="eyJhbGc..."
```

### 7.2 Secure Vault

```bash
# Or load from secure vault (e.g., HashiCorp Vault)
vault kv get secret/atlas/licenses/inst_xyz789
```

### 7.3 Configuration File

```yaml
# config/licenses.yaml (git-ignored)
licenses:
  inst_xyz789:
    key: "eyJhbGc..."
    tier: "professional"
    customer: "ACME Corp"
```

---

## 8. Failure Modes

### 8.1 Missing License

**Symptom:** `LicenseError: No license key configured`

**Causes:**
- `ATLAS_LICENSE_KEY` not set
- License file missing or unreadable
- Vault unreachable

**Recovery:**
- Set environment variable or provide config file
- Instance enters read-only degraded mode until license available

### 8.2 Expired License

**Symptom:** `LicenseError: License expired on 2026-01-15T00:00:00Z`

**Causes:**
- License expiration date has passed
- No key rotation performed

**Recovery:**
- Issue new license via master
- Rotate license (automatic if renewal configured)

### 8.3 Invalid Signature

**Symptom:** `LicenseError: Invalid license signature`

**Causes:**
- Key corrupted or modified
- Wrong master secret configured
- Tampering attempt

**Recovery:**
- Reissue key from master
- Verify master secret is correct
- Audit for tampering

### 8.4 Instance ID Mismatch

**Symptom:** `LicenseError: License key instance mismatch: expected inst_a, got inst_b`

**Causes:**
- License issued for wrong instance
- Key deployed to wrong instance
- Configuration error

**Recovery:**
- Verify license is for correct instance
- Reissue with correct instance ID
- Check deployment configuration

---

## 9. Testing

### 9.1 Unit Tests

```bash
pytest tests/licensing/test_license_manager.py -v
pytest tests/licensing/test_license_validation.py -v
```

### 9.2 Key Generation Tests

```python
def test_license_generation():
    issuer = MasterLicenseIssuer()
    key = issuer.issue_license(
        instance_id='inst_test',
        tier='professional',
        customer_info={'name': 'Test Corp'}
    )
    
    # Parse and validate
    manager = LicenseManager('inst_test', master_secret=issuer.master_secret)
    info = manager.validate_license()
    
    assert info.tier == 'professional'
    assert 'audit_export' in info.features
```

### 9.3 Feature Gating Tests

```python
def test_feature_gating():
    license_info = LicenseInfo(
        tier='free',
        features=['managed_instance', 'asset_factory_basic']
    )
    
    # Free tier cannot export audit
    assert not check_operation_permitted('export_audit', license_info)
    
    # Free tier can use basic factories
    assert check_operation_permitted('use_basic_factory', license_info)
```

### 9.4 Expiration Tests

```python
def test_license_expiration():
    expired_key = create_expired_license_key()
    manager = LicenseManager('inst_test')
    
    with pytest.raises(LicenseError, match="expired"):
        manager.validate_license()
```

---

## 10. Verification Checklist

- [ ] License key format is JWT-like (header.payload.signature)
- [ ] Signature verification prevents tampering
- [ ] Instance ID in license matches instance
- [ ] Expiration dates are enforced
- [ ] Features are properly gated
- [ ] Resource limits are checked before operations
- [ ] License validation has 5-minute cache with force-refresh
- [ ] All validation failures raise clear LicenseError
- [ ] Master secret is never logged or leaked
- [ ] Licenses are per-instance, not shared

---

**PHASE 9 LICENSING COMPLETE**
