# Phase 9: Instance Isolation Design Document

**Authority:** KAIZA Execution Framework  
**Status:** COMPLETE  
**Version:** 1.0  
**Date:** 2026-01-15

---

## 1. Overview

This document specifies the instance isolation strategy for Atlas Empire productization. It implements Section 8 of the Phase 9 executable plan, ensuring complete logical isolation between master and customer instances while maintaining immutable architecture boundaries.

---

## 2. Isolation Architecture

### 2.1 Complete Isolation Model

```
Master Atlas Instance (Core)
├── Governor (Master Logic - Private)
├── Canonical Registry (Read-only copies for customers)
├── Authority Ledger (Master-only)
└── Master Control Plane

Customer Instance N (Isolated)
├── Isolated Governor Copy (Immutable, executable)
├── Customer Registry (Independent tables)
├── Customer Ledger (Independent database)
├── Customer Assets (Independent storage)
└── Customer Control Plane (Limited API surface)

Isolation Boundary
├── No shared database connections
├── No shared ledgers
├── No shared registries
├── No shared asset factories (except frozen versions)
├── No cross-instance delegation
└── No master override capability
```

### 2.2 Isolation Dimensions

| Dimension | Master | Customer Instance | Enforcement Mechanism |
|-----------|--------|-------------------|----------------------|
| Ledger | Private | Isolated copy | Separate PostgreSQL database, no joins |
| Registry | Canonical | Customer-owned | Independent schema, RBAC at database level |
| Asset Factory | Master controls | Frozen copy per version | Version binding in instance config, no modifications |
| Governor | Master-only logic | Immutable copy | Code integrity checks on startup |
| Evolution API | Master-only | Disabled per instance | `EVOLUTION_MODE=DORMANT` feature gate |
| Authority Ledger | Canonical | Read-only snapshot | Downloaded at instance startup, cached locally |
| Asset Storage | Master templates | Customer instances | Per-instance storage buckets with isolation validation |
| Credentials | Master-only | Instance-specific | Unique secrets per instance, no cross-access |

---

## 3. Database Isolation

### 3.1 Schema Separation

**Master Database:**
```sql
-- Master ledgers (private)
CREATE SCHEMA master_ledger;
CREATE SCHEMA master_registry;

-- Public reference (read-only for customers)
CREATE SCHEMA authority_snapshot;
```

**Customer Instance Database:**
```sql
-- Customer isolation via schema
CREATE SCHEMA inst_{instance_id}_ledger;
CREATE SCHEMA inst_{instance_id}_registry;
CREATE SCHEMA inst_{instance_id}_audit;
```

### 3.2 Access Control

```sql
-- Master user (full access)
GRANT ALL ON master_ledger.* TO master_user;
GRANT ALL ON master_registry.* TO master_user;

-- Customer user (limited to their schema)
GRANT SELECT, INSERT, UPDATE ON inst_{instance_id}_ledger.* TO cust_user_{instance_id};
GRANT SELECT, INSERT, UPDATE ON inst_{instance_id}_registry.* TO cust_user_{instance_id};

-- No cross-schema access
REVOKE ALL ON master_ledger.* FROM cust_user_{instance_id};
REVOKE ALL ON other_inst_*.* FROM cust_user_{instance_id};
```

### 3.3 Query Validator

Every query must be validated before execution:

```python
def validate_and_execute_query(instance_id: str, query: str, params: List) -> Any:
    """
    1. Parse SQL (using sqlparse)
    2. Extract table names
    3. Verify all tables match inst_{instance_id}_ prefix
    4. Check for forbidden keywords (DROP, ALTER, etc.)
    5. Execute if valid
    6. Log (audit trail)
    7. Return results
    """
    enforcer = IsolationEnforcer(instance_id)
    enforcer.validate_sql_query(query)
    # Execute safely...
```

---

## 4. API Isolation

### 4.1 Endpoint Scoping

All API endpoints must be scoped to the instance:

**Valid Endpoint Patterns:**
```
/api/v1/instances/{instance_id}/ledger
/api/v1/instances/{instance_id}/registry
/api/v1/instances/{instance_id}/assets
/api/v1/instances/{instance_id}/audit
```

**Invalid Patterns (Rejected):**
```
/api/v1/ledger                      # No instance scope
/api/v1/instances/{other_id}/data  # Different instance
/api/v1/master/...                  # Master endpoints
```

### 4.2 Request Validation

Every API request is validated:

```python
@app.before_request
def validate_isolation():
    instance_id = extract_instance_id(request)
    enforcer = IsolationEnforcer(instance_id)
    
    # Validate path, headers, body
    enforcer.validate_api_request(
        path=request.path,
        method=request.method,
        headers=dict(request.headers),
        body=request.get_data(as_text=True)
    )
```

### 4.3 Response Isolation

Responses are validated before returning:

```python
def send_response(data: Dict, instance_id: str) -> Response:
    # Ensure response doesn't contain cross-instance data
    validate_response_scoping(data, instance_id)
    return jsonify(data)
```

---

## 5. Governor Isolation

### 5.1 Code Integrity

Governor code is verified on every startup:

```python
def verify_governor_integrity(instance_id: str) -> bool:
    """
    1. Load Governor code
    2. Compute SHA256 checksum
    3. Compare with canonical checksum
    4. If mismatch: FAIL and enter read-only mode
    5. Log verification result
    """
    canonical_hash = CANONICAL_GOVERNOR_HASH
    actual_code = load_governor_code()
    actual_hash = sha256(actual_code).hexdigest()
    
    if actual_hash != canonical_hash:
        logger.critical("Governor integrity check failed")
        enter_read_only_mode()
        return False
    
    return True
```

### 5.2 Data Isolation

Governor logic is isolated by execution context:

```python
class GovernorContext:
    def __init__(self, instance_id: str, is_master: bool = False):
        self.instance_id = instance_id
        self.is_master = is_master
        self.ledger = get_instance_ledger(instance_id)
        self.registry = get_instance_registry(instance_id)
        
        # Master can see all data; customer sees only their own
        if not is_master:
            self.ledger = self.ledger.scoped_to_instance(instance_id)
            self.registry = self.registry.scoped_to_instance(instance_id)
```

---

## 6. Asset Factory Isolation

### 6.1 Frozen Factory Versions

Asset factories are versioned and frozen per instance:

```yaml
instance_config.yaml:
  asset_factories:
    basic_factory:
      version: "1.0.0"
      hash: "sha256:abc123..."
      locked: true
      modifications_allowed: false
```

### 6.2 Factory Execution

Factories execute in isolated sandbox:

```python
def execute_factory(instance_id: str, factory_name: str, params: Dict) -> Asset:
    # 1. Load factory (frozen version for this instance)
    factory = load_frozen_factory(instance_id, factory_name)
    
    # 2. Validate parameters (no cross-instance refs)
    validate_factory_params(instance_id, params)
    
    # 3. Execute in sandbox
    result = factory.execute(params, context={
        'instance_id': instance_id,
        'allowed_resources': get_instance_resources(instance_id)
    })
    
    # 4. Validate output (no sensitive data leaked)
    validate_output(instance_id, result)
    
    return result
```

---

## 7. Evolution Protection

### 7.1 Disabled Evolution

Self-evolution is disabled for customer instances:

```python
# Feature gate
EVOLUTION_MODE = os.getenv('EVOLUTION_MODE', 'DORMANT')

if EVOLUTION_MODE == 'DORMANT':
    # Customer instances cannot trigger evolution
    @forbid_operation('trigger_self_evolution')
    def evolve_system(self):
        raise ForbiddenOperationError("Evolution disabled in customer instances")
```

### 7.2 Phase 0-8 Immutability

Core phases cannot be modified:

```python
IMMUTABLE_MODULES = {
    'src/governor/governor_logic.py',
    'src/core/authority.py',
    'src/core/ledger.py',
    # ... all Phase 0-8 critical modules
}

def check_code_modification(filepath: str):
    if filepath in IMMUTABLE_MODULES:
        raise ImmutabilityViolation(f"{filepath} is immutable")
```

---

## 8. Authority Rules Isolation

### 8.1 Read-Only Authority Rules

Authority rules are downloaded at startup and cached:

```python
class AuthorityRules:
    def __init__(self, instance_id: str, is_master: bool = False):
        self.instance_id = instance_id
        self.is_master = is_master
        self._rules = self._download_rules() if is_master else self._cache_rules()
    
    def _download_rules(self) -> Dict:
        # Master: fetch from source
        return master_authority_service.get_rules()
    
    def _cache_rules(self) -> Dict:
        # Customer: use cached snapshot
        return load_from_cache('authority_rules_snapshot.json')
    
    def get_rule(self, rule_name: str) -> Any:
        return self._rules.get(rule_name)
    
    def modify_rule(self, rule_name: str, value: Any):
        # Cannot modify - rules are read-only for customers
        if not self.is_master:
            raise PermissionDenied("Rules are immutable in customer instances")
```

---

## 9. Audit Trail Isolation

### 9.1 Instance-Specific Audit Logs

Each instance has its own audit database:

```python
audit_db_path = f"data/audit/inst_{instance_id}.db"
audit_logger = AuditLogger(instance_id, db_path=audit_db_path)
```

### 9.2 Audit Immutability

Audit logs are append-only and cryptographically signed:

```python
class AuditEvent:
    timestamp: str
    event_type: str
    operation: str
    instance_id: str
    actor: str
    result: str
    signature: str  # HMAC-SHA256(content, signing_key)
```

---

## 10. License-Driven Isolation

### 10.1 Instance Configuration

License key controls instance initialization:

```json
{
  "key_id": "lic_abc123",
  "instance_id": "inst_customer1",
  "tier": "professional",
  "features": ["managed_instance", "audit_export"],
  "max_agents": 100,
  "max_assets": 10000,
  "expires_at": "2027-01-15T00:00:00Z"
}
```

### 10.2 Feature Gating

Features are gated by license tier:

```python
def can_export_audit(instance_id: str) -> bool:
    license = LicenseManager(instance_id).validate_license()
    return 'audit_export' in license.features
```

---

## 11. Failure Modes & Containment

### 11.1 Cross-Instance Query Attempt

**Detection:**
- SQL parser detects reference to other instance's schema
- Query validator blocks execution

**Containment:**
- Query is rejected (IsolationViolation exception)
- Security event logged with full query hash
- Instance metrics updated

**Recovery:**
- Admin investigates audit log
- No data leaked (query never executed)

### 11.2 Database Credential Leak

**Detection:**
- Customer obtains database credentials for other instance
- Connection attempt logged by database

**Containment:**
- Database RBAC prevents access
- Connection rejected by database
- Security alert fired

**Recovery:**
- Rotate credentials
- Audit all connections in timeframe
- No data leaked

### 11.3 Governor Code Tampering

**Detection:**
- Integrity check on startup fails
- Code hash doesn't match canonical

**Containment:**
- Instance enters read-only mode
- All write operations denied
- Incident logged

**Recovery:**
- Restore from backup
- Audit logs analyzed
- Rollback if damage confirmed

---

## 12. Testing Strategy

### 12.1 Unit Tests

```bash
pytest tests/isolation/test_isolation_enforcer.py -v
pytest tests/isolation/test_permission_checker.py -v
```

### 12.2 Integration Tests

```bash
pytest tests/integration/productization_tests.py::TestInstanceIsolation -v
```

### 12.3 Security Tests

```bash
pytest tests/isolation/test_forbidden_gates.py -v
```

### 12.4 Coverage Targets

- Isolation enforcer: ≥90%
- Permission checker: ≥90%
- Forbidden gates: ≥95%

---

## 13. Verification Checklist

- [ ] No shared database connections between instances
- [ ] All table names prefixed with `inst_{instance_id}_`
- [ ] Governor code integrity verified on startup
- [ ] Cross-instance queries blocked
- [ ] Authority rules are read-only
- [ ] Evolution disabled for customer instances
- [ ] Asset factories are frozen per version
- [ ] Audit logs are per-instance and immutable
- [ ] License validates instance scoping
- [ ] All forbidden operations blocked

---

**PHASE 9 ISOLATION COMPLETE**
