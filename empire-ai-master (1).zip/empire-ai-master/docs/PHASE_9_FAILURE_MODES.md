# Phase 9: Failure Modes & Containment Playbook

**Authority:** KAIZA Execution Framework  
**Status:** COMPLETE  
**Version:** 1.0  
**Date:** 2026-01-15

---

## 1. Overview

This document specifies failure modes and containment strategies for Phase 9 productization features. It implements Section 14 of the Phase 9 executable plan, ensuring all failure scenarios are handled safely without compromising isolation or governance.

---

## 2. Failure Mode Categories

### 2.1 Isolation Failures
- Cross-instance data access
- Shared resource leaks
- Database credential compromise
- Governor code tampering

### 2.2 License Failures
- Missing or expired key
- Invalid signature
- Instance ID mismatch
- Key forgery attempt

### 2.3 Permission Failures
- Forbidden operation attempt
- Resource limit exceeded
- Feature not licensed
- Authority rule violation

### 2.4 System Failures
- Database unavailable
- Master unreachable
- Configuration error
- Storage failure

---

## 3. Isolation Failures

### 3.1 Cross-Instance Query Attempt

**Symptom:**
```
IsolationViolation: Cross-instance access detected in query
Query contained pattern: inst_customer2_ledger
```

**Root Causes:**
- SQL injection attempt
- Malicious query construction
- Misconfigured table prefixing
- Application bug in query generation

**Detection Mechanism:**
```python
# Regex pattern matching
patterns = [
    r'inst_[a-zA-Z0-9_-]+_.*',  # Direct instance ref
    r'UNION.*FROM.*inst_',      # Union across instances
]

# IsolationEnforcer checks all queries
def validate_sql_query(query: str):
    for pattern in patterns:
        if pattern in query:
            raise IsolationViolation(...)
```

**Containment Actions:**
1. **Query Rejection**: Query is blocked immediately
2. **Audit Log**: Full query hash (not content) recorded
3. **Security Event**: Logged as isolation_violation
4. **Instance State**: Instance marked as suspicious
5. **Alert**: Admin notified if configured
6. **No Rollback**: Database transaction never started

**Recovery Steps:**
1. Inspect audit logs for query pattern
2. Determine if accidental or malicious
3. If accidental: Fix application query builder
4. If malicious: Investigate actor permissions
5. No data recovery needed (query never executed)

**Prevention:**
- Use ORM with instance-scoped query builders
- Parameterized queries (prevents SQL injection)
- Table prefix validation before query generation
- Query logging and review

---

### 3.2 Cross-Instance API Request

**Symptom:**
```
IsolationViolation: API path not scoped to instance
Path: /api/v1/ledger
Expected: /api/v1/instances/{instance_id}/ledger
```

**Root Causes:**
- Hardcoded API paths missing instance ID
- Request routing misconfiguration
- Client-side application bug
- Proxy misconfiguration

**Detection Mechanism:**
```python
@app.before_request
def validate_isolation():
    instance_id = extract_instance_id(request)
    enforcer = IsolationEnforcer(instance_id)
    enforcer.validate_api_request(
        path=request.path,
        method=request.method,
        headers=dict(request.headers)
    )
```

**Containment Actions:**
1. **Request Rejection**: 403 Forbidden returned
2. **Error Response**: Clear isolation error message
3. **Audit Log**: Request path and headers logged
4. **Security Event**: isolation_violation recorded
5. **Rate Limiting**: Request source rate-limited
6. **No Execution**: Request handler never called

**Recovery Steps:**
1. Review client application code
2. Fix hardcoded URLs to include instance ID
3. Verify proxy/load balancer passes instance context
4. Test with instance-scoped URLs
5. Clear rate limit on source IP if accidental

**Prevention:**
- Use instance-aware API client library
- Validate paths in middleware (before routing)
- Unit tests for path generation
- Integration tests for full request path

---

### 3.3 Database Credential Compromise

**Symptom:**
```
Error: Access denied for user 'customer_user'@'db.example.com'
  Trying to access: master_ledger (not authorized)
Connection from: 192.168.1.50
```

**Root Causes:**
- Credentials leaked in logs
- Credentials in git repository
- Credentials on compromised machine
- Phishing/social engineering

**Detection Mechanism:**
```python
# Database logs show unauthorized access attempt
# PostgreSQL audit logging
SELECT * FROM pg_audit.event_log
WHERE user_name = 'cust_user_inst123'
  AND statement LIKE '%master_ledger%'
  AND statement_result = 'denied';
```

**Containment Actions:**
1. **Access Denied**: Database RBAC prevents access (defense in depth)
2. **Connection Logged**: Full connection details recorded
3. **Audit Alert**: Database triggers security alert
4. **No Data Leak**: Query rejected at database level
5. **Credential Revocation**: Account password rotated
6. **Session Termination**: All sessions for user terminated

**Recovery Steps:**
1. Rotate compromised credentials
2. Audit database access logs for breach window
3. Search for other instances of credentials in logs
4. Review who had access to credentials
5. Implement secret management system (Vault)
6. Force password rotation across all instances

**Prevention:**
- No credentials in logs (redact in middleware)
- Rotate credentials every 90 days
- Use secrets management system
- Audit database access regularly
- Disable direct database access (API only)

---

### 3.4 Governor Code Tampering

**Symptom:**
```
CRITICAL: Governor integrity check failed
  Expected hash: abc123def456...
  Actual hash:   xyz789uvw012...
  Entering read-only mode
```

**Root Causes:**
- Attacker modifies Governor Python file
- Binary corruption on disk
- Version control rollback
- Deployment error

**Detection Mechanism:**
```python
def verify_governor_integrity():
    # Computed at startup
    canonical_hash = CANONICAL_GOVERNOR_HASH
    actual_code = load_governor_code()
    actual_hash = sha256(actual_code).hexdigest()
    
    if actual_hash != canonical_hash:
        logger.critical("Governor integrity check failed")
        return False
    return True

# Periodic re-verification
@scheduler.scheduled_job('interval', hours=1)
def periodic_integrity_check():
    if not verify_governor_integrity():
        alert_admin("Governor integrity violation detected")
```

**Containment Actions:**
1. **Startup Failure**: Instance fails to start if hash mismatch
2. **Read-Only Mode**: If already running, enter read-only mode
3. **Audit Log**: Integrity violation recorded with timestamp
4. **Security Alert**: Admin notified immediately
5. **No Execution**: Untrusted code never executes
6. **Forensics**: Original code preserved for analysis

**Recovery Steps:**
1. Restore Governor code from backup/version control
2. Re-verify hash after restore
3. Restart instance
4. Investigate how code was modified
5. Audit instance logs during tampering window
6. Check for other modifications

**Prevention:**
- Immutable Governor code (read-only filesystem)
- Regular integrity checks
- Code signing on deployment
- Access control on source files
- Audit changes to core files

---

### 3.5 Shared Resource Leak

**Symptom:**
```
IsolationViolation: Resource 'shared_asset_store' is not instance-scoped
  Expected prefix: inst_customer1_
  Actual prefix: shared_
```

**Root Causes:**
- Developer creates shared asset store
- Resource naming convention not followed
- Infrastructure misconfiguration
- Legacy multi-tenant code not removed

**Detection Mechanism:**
```python
def validate_resource_access(resource_id: str, instance_id: str):
    enforcer = IsolationEnforcer(instance_id)
    result = enforcer.validate_resource_access(
        resource_type='asset_store',
        resource_id=resource_id,
        operation='read'
    )
    
    if not result.is_valid:
        raise IsolationViolation(result.violation_type)
```

**Containment Actions:**
1. **Access Denied**: Resource access blocked
2. **Audit Log**: Shared resource reference logged
3. **Security Event**: Recorded as isolation_breach
4. **Alert**: Admin notified of isolation violation
5. **No Access**: Resource never opened/accessed

**Recovery Steps:**
1. Identify all shared resources
2. For each shared resource: Create instance-scoped copies
3. Migrate data from shared to instance-specific storage
4. Update resource references to new names
5. Delete shared resource
6. Verify all operations use instance-scoped resources

**Prevention:**
- Resource naming convention enforcement
- Code review for resource creation
- Automated tests checking resource prefixes
- Documentation of isolation boundaries
- No "shared" or "global" resource names

---

## 4. License Failures

### 4.1 Missing License Key

**Symptom:**
```
LicenseError: No license key configured
Environment variable ATLAS_LICENSE_KEY not set
```

**Root Causes:**
- Environment variable not set
- Configuration file missing
- Vault unreachable
- Deployment misconfiguration

**Detection Mechanism:**
```python
def __init__(self, instance_id: str):
    self._license_key = os.getenv('ATLAS_LICENSE_KEY')
    if not self._license_key:
        self.logger.critical("No license key configured")
        # Instance can still start in degraded mode
```

**Containment Actions:**
1. **Graceful Degradation**: Instance enters read-only mode
2. **Clear Error**: Admin sees "License missing" in logs
3. **Feature Gating**: All licensed features disabled
4. **No Revenue Loss**: Licensing is dormant (no billing affected)
5. **Logging**: Missing license logged every 5 minutes

**Recovery Steps:**
1. Generate license key from master instance
2. Set ATLAS_LICENSE_KEY environment variable
3. Restart instance
4. Verify license is valid and not expired

**Prevention:**
- Use secrets management (Vault, K8s secrets)
- Deployment validation before startup
- Monitoring for license expiration warnings
- Automated license renewal 30 days before expiry

---

### 4.2 Expired License Key

**Symptom:**
```
LicenseError: License expired on 2026-01-15T00:00:00Z
Current time is 2026-02-01T00:00:00Z
```

**Root Causes:**
- License expiration not renewed
- No automation for renewal
- Renewal request lost/ignored
- Time sync issue on system

**Detection Mechanism:**
```python
def validate_license(self):
    expires_at = datetime.fromisoformat(payload['expires_at'])
    if datetime.utcnow() > expires_at:
        raise LicenseError(f"License expired on {expires_at}")
```

**Containment Actions:**
1. **Graceful Degradation**: Instance enters read-only mode
2. **Clear Error**: "License expired" message
3. **Feature Gating**: All licensed features disabled
4. **Logging**: Expiration logged every startup
5. **Warning**: Admin sees expiration warning in UI

**Recovery Steps:**
1. Renew license from master instance
2. Rotate license key before startup
3. Update ATLAS_LICENSE_KEY with new key
4. Restart instance
5. Verify license is valid

**Prevention:**
- Automated license rotation (30 days before expiry)
- Expiration warnings in UI (60, 30, 7 days before)
- Calendar reminders for operations team
- License validation in pre-startup checks

---

### 4.3 Invalid License Signature

**Symptom:**
```
LicenseError: Invalid license signature
Expected: abc123def456...
Actual:   xyz789uvw012...
```

**Root Causes:**
- License key corrupted
- Wrong master secret configured
- License modified by attacker
- Key encoding error

**Detection Mechanism:**
```python
def _verify_signature(self, license_key: str, signature: str) -> bool:
    message = license_key.rsplit('.', 1)[0]
    h = HMAC(self.master_secret.encode(), hashes.SHA256())
    h.update(message.encode())
    expected_signature = h.finalize().hex()
    return hmac.compare_digest(signature, expected_signature)
```

**Containment Actions:**
1. **Startup Failure**: Instance cannot start
2. **No Degradation**: Fail-secure (no read-only mode)
3. **Audit Log**: Signature verification failure recorded
4. **Security Alert**: Tampering attempt logged
5. **Forensics**: Invalid key saved for analysis

**Recovery Steps:**
1. Verify master secret is correct
2. Request new license from master
3. Update ATLAS_LICENSE_KEY with new key
4. Verify signature validates
5. Restart instance
6. Investigate why signature failed

**Prevention:**
- Secure license storage (Vault, encrypted)
- Regular license validation in pre-startup checks
- Master secret in environment variables (not hardcoded)
- License key audit trail

---

### 4.4 Instance ID Mismatch

**Symptom:**
```
LicenseError: License key instance mismatch
License issued for: inst_customer2
Instance running as: inst_customer1
```

**Root Causes:**
- License deployed to wrong instance
- Instance ID configuration error
- License assignment mistake
- Copy-paste error in deployment

**Detection Mechanism:**
```python
if payload['instance_id'] != self.instance_id:
    raise LicenseError(
        f"License key instance mismatch: "
        f"expected {self.instance_id}, "
        f"got {payload['instance_id']}"
    )
```

**Containment Actions:**
1. **Startup Failure**: Instance cannot start
2. **Clear Error**: Specific instance ID mismatch message
3. **No Degradation**: Fail-secure
4. **Logging**: Mismatch logged with both IDs
5. **Prevention**: Configuration validation before deployment

**Recovery Steps:**
1. Verify instance ID is correct (echo $ATLAS_INSTANCE_ID)
2. Issue license for correct instance ID
3. Update ATLAS_LICENSE_KEY with correct license
4. Verify instance_id in license matches
5. Restart instance

**Prevention:**
- Pre-deployment validation (check all config matches)
- License validation in deployment automation
- Instance ID in instance metadata/config
- Configuration templates to prevent mistakes

---

## 5. Permission Failures

### 5.1 Forbidden Operation Attempt

**Symptom:**
```
ForbiddenOperationError: Operation 'modify_governor_logic' blocked
Reason: Cannot modify Governor logic in customer instances
```

**Root Causes:**
- Attacker attempts privilege escalation
- Application bug calls forbidden operation
- Misconfigured feature flags
- Developer testing code in production

**Detection Mechanism:**
```python
class ForbiddenGates:
    def check_operation(self, operation: str):
        if operation in self.FORBIDDEN_OPERATIONS:
            raise ForbiddenOperationError(operation, reason, description)
```

**Containment Actions:**
1. **Operation Blocked**: Exception raised, execution stops
2. **Audit Log**: Attempted operation recorded
3. **Security Event**: forbidden_operation logged
4. **Alert**: If repeated attempts, escalation triggered
5. **Metrics**: Block count incremented

**Recovery Steps:**
1. Inspect application code for accidental forbidden operation calls
2. Fix code to not call forbidden operations
3. If attack: Investigate actor permissions
4. Review audit logs for pattern of attempts
5. No data affected (operation never executed)

**Prevention:**
- Code review for forbidden operation calls
- Static analysis (linters) to catch patterns
- Automated tests for forbidden operations
- Documentation of allowed operations

---

### 5.2 Feature Not Licensed

**Symptom:**
```
PermissionDenied: Operation 'export_audit' requires features: {'audit_export'}
Current tier: free
```

**Root Causes:**
- User attempts feature not in license tier
- License tier not upgraded
- Feature deprecated in tier
- User misunderstands capabilities

**Detection Mechanism:**
```python
if operation in self.LICENSED_OPERATIONS:
    required_features = self.LICENSED_OPERATIONS[operation]
    if not required_features.intersection(license_features):
        raise PermissionDenied(...)
```

**Containment Actions:**
1. **Operation Denied**: Clear error returned
2. **Logging**: Feature check logged (not security event)
3. **UI Feedback**: User sees "upgrade required" message
4. **No Degradation**: System continues normally
5. **Suggestion**: License upgrade path shown to user

**Recovery Steps:**
1. Upgrade instance to higher tier license
2. Reissue license with new tier
3. Restart instance
4. Feature becomes available

**Prevention:**
- UI shows which features available at each tier
- Clear upgrade prompts when feature unavailable
- License tier information in settings
- Feature documentation per tier

---

### 5.3 Resource Limit Exceeded

**Symptom:**
```
LimitExceeded: Resource limit exceeded for 'create_agent'
Current usage: 100 / 100
```

**Root Causes:**
- User has many agents running
- Agents not properly cleaned up
- Shared agents not counted correctly
- Limit too low for use case

**Detection Mechanism:**
```python
def check_resource_limit(operation: str, current_usage: int, 
                        license_info: LicenseInfo):
    if operation == 'create_agent':
        if current_usage >= license_info.max_concurrent_agents:
            raise LimitExceeded(...)
```

**Containment Actions:**
1. **Operation Denied**: New resource creation blocked
2. **Logging**: Limit exceeded logged
3. **UI Feedback**: User sees "limit reached" message
4. **No Data Loss**: Existing resources unaffected
5. **Suggestion**: Delete unused resources or upgrade

**Recovery Steps:**
1. Delete unused agents/assets/registries
2. Or upgrade to higher tier license
3. After cleanup/upgrade, retry operation

**Prevention:**
- Resource cleanup policies
- Warnings when approaching limit (80%, 90%)
- UI shows current usage vs. limit
- Recommendation to upgrade when usage high

---

## 6. System Failures

### 6.1 Database Unavailable

**Symptom:**
```
DatabaseConnectionError: Cannot connect to database
Host: db.example.com:5432
Timeout: 10 seconds
```

**Root Causes:**
- Database server down
- Network connectivity loss
- Database maintenance
- Credential rotation in progress

**Detection Mechanism:**
```python
def get_connection():
    try:
        conn = psycopg2.connect(...)
        return conn
    except psycopg2.OperationalError as e:
        logger.error("Database connection failed", error=str(e))
        raise
```

**Containment Actions:**
1. **Graceful Degradation**: Enter read-only mode
2. **Error Message**: Admin sees "Database unavailable"
3. **Logging**: Connection failure logged with retry attempts
4. **Alerting**: Admin notified if unavailable > 5 min
5. **Buffering**: Write operations queued (up to 500 events)

**Recovery Steps:**
1. Restore database connectivity
2. Database reconnects automatically
3. Queued writes are flushed to database
4. Instance resumes normal mode

**Prevention:**
- Database replication for high availability
- Connection pooling with retry logic
- Heartbeat/health checks
- Automated failover to replica
- Monitoring and alerting

---

### 6.2 Master Instance Unreachable

**Symptom:**
```
MasterConnectionError: Cannot reach master instance
URL: https://master.example.com/api/v1
Timeout: 30 seconds
```

**Root Causes:**
- Master instance down
- Network connectivity loss
- Master under maintenance
- Firewall rule change

**Detection Mechanism:**
```python
def verify_license_with_master():
    try:
        response = requests.get('https://master/api/v1/verify-license')
        return response.json()
    except requests.ConnectionError:
        logger.warn("Master unreachable, using cached verification")
        # Continue with cached data
```

**Containment Actions:**
1. **Graceful Degradation**: Use cached authority/license info
2. **Cache TTL**: Cached data valid for 5 minutes
3. **Logging**: Master connection failure logged
4. **Alerting**: Admin notified if down > 30 min
5. **Read-Write**: Operations continue (not blocked)

**Recovery Steps:**
1. Restore master connectivity
2. Cached data expires after 5 min, fresh data fetched
3. Instance resumes normal operation

**Prevention:**
- Master instance redundancy
- DNS failover to backup master
- Cached authority data with fallback
- Monitoring of master availability

---

## 7. Testing Failure Modes

### 7.1 Unit Tests

```bash
pytest tests/isolation/test_failure_modes.py -v
pytest tests/licensing/test_license_failures.py -v
pytest tests/permissions/test_permission_failures.py -v
```

### 7.2 Integration Tests

```bash
# Simulate cross-instance access
pytest tests/integration/test_isolation_breach.py -v

# Simulate license failures
pytest tests/integration/test_license_validation_failures.py -v

# Simulate permission denials
pytest tests/integration/test_forbidden_operations.py -v
```

### 7.3 Chaos Engineering

```python
@pytest.fixture
def chaos_db():
    """Simulate database failures."""
    with patch('db.connection') as mock_conn:
        mock_conn.execute.side_effect = DatabaseError("Connection lost")
        yield mock_conn

def test_database_failure_degradation(chaos_db):
    """Verify graceful degradation on database failure."""
    instance = Instance('inst_test')
    
    # Read operation should still work (cached)
    result = instance.read_ledger()
    assert result  # Uses cache
    
    # Write operation should be buffered
    instance.write_asset(data)
    assert len(instance._write_buffer) == 1
```

---

## 8. Verification Checklist

- [ ] All isolation failures are detected and blocked
- [ ] All license failures degrade gracefully
- [ ] All permission failures are logged
- [ ] No data leaks on any failure
- [ ] All failures include clear error messages
- [ ] Admin is alerted on security failures
- [ ] Recovery steps are documented
- [ ] Prevention strategies are implemented
- [ ] Tests cover all failure modes
- [ ] Failure modes do not compromise core invariants

---

**PHASE 9 FAILURE MODES COMPLETE**
