
# Phase 3 Asset Factory Implementation

## Overview

Phase 3 implements an autonomous asset factory that processes opportunities
and generates revenue-capable digital assets.

## Architecture

### Asset Types

1. **Content Site**: SEO-optimized content sites with affiliate links
2. **Affiliate Landing Page**: Single-page landing pages for offers
3. **Micro Tool**: Client-side utility tools

### Pipeline Steps

1. **Opportunity Intake**: Receive opportunities from Scout agent
2. **Feasibility Scoring**: Score opportunities based on market signals
3. **Specification Generation**: Generate detailed specifications
4. **Code Generation**: Build assets using Builder and Writer agents
5. **Security Scan**: Validate security requirements
6. **Compliance Check**: Verify compliance with monetization rules
7. **Deployment**: Deploy to staging with health checks
8. **Measurement Bootstrap**: Initialize tracking and metrics

## Monetization Rules

- Exactly one monetization path per asset
- Content sites: affiliate_links
- Landing pages: affiliate_links or lead_capture
- Micro tools: embedded_recommendations

## Kill Rules

Assets are killed if they:
- Remain in staging > 90 days
- Have 3+ build failures
- Fail compliance verification
- Have zero signal in production for 30 days

## Audit Trail

All operations are logged to the universal ledger for complete auditability.
        