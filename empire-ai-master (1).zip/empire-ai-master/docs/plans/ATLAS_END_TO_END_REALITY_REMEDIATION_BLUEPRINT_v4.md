# ATLAS PRODUCTION EXECUTION BLUEPRINT — END-TO-END REALITY REMEDIATION v4

**PLAN HASH**: 25d8c56a164875d01672ba94d7ba3bebaee4510b70a4765f8f07dec47bbaed3d
**STATUS**: APPROVED
**SUPERVISOR**: KAIZA MCP
**PLAN IDENTIFIER**: ATLAS-E2E-REALITY-REMED-v4
**DATE**: 2026-01-19

---

## 0. GLOBAL GOVERNANCE REQUIREMENTS (LAW)

### 0.1 Zero-Mock Reality Law

Execution MUST eliminate and permanently forbid all hardcoded metrics, placeholder functions, and static health states. All system telemetry MUST originate from real hardware (e.g., via `psutil`), live OS state, or hydrated database records. Detection of mock behavior renders the execution INVALID.

### 0.2 Authentication Integrity Law

Authentication MUST satisfy all OIDC/Keycloak requirements. Every request MUST verify live operator existence in the database. Property access MUST align with defined schemas. No bypass or "split-brain" auth logic is permitted.

### 0.3 Kill-System Reality Law

The emergency `kill.system` control MUST produce a real, observable system halt, emit auditable side-effects (e.g., process termination, state lock), and fail loudly if unauthorized. Illusionary "success" responses without backend effects are forbidden.

### 0.4 Hive UI Truth Law

Every Hive UI control MUST trigger a real backend side effect and reflect live backend state. E2E tests MUST be capable of detecting deterministic fake data or static values.

### 0.5 Failure Semantics (HARD LAW)

All failures MUST hard-stop execution, emit a stable error code naming the violated invariant, and produce a written failure report. Silent failures are forbidden.

### 0.6 Mandatory Commentary & Debug Law

Every modified file MUST have a corresponding `<file>.intent.md` documenting Purpose, Authorizing Plan/Phase, Invariants, Failure Modes, and Debug Signals.

---

## 1. REMEDIATION PHASES

### Phase R1: Metric Reality & Telemetry Restoration

**Objective**: Replace hardcoded resource metrics and health states with real system telemetry.
**Allowed File Operations**:

- **MODIFY**: [action_envelope.py](file:///home/lin/Documents/empire-ai/src/execution/action_envelope.py) (Integrate `psutil` into `_get_cpu_usage`, `_get_memory_usage`, `_get_disk_usage`)
- **MODIFY**: [db.py](file:///home/lin/Documents/empire-ai/src/db.py) (Replace static `health` block in `get_asset` with live monitoring integration)
**Explicitly Forbidden Actions**:
- Retaining any return values of `45.0`, `60.0`, or `30.0` as constants.
- Providing "simulated" entropy.
**Governance Laws**: Zero-Mock Reality Law (0.1), Hard Failure Law (0.5).
**Verification Gates**:
- `scripts/verify_metric_entropy.sh` MUST detect variance in metrics over 3 consecutive calls.
- `grep "45.0" src/execution/action_envelope.py` MUST return zero matches.

### Phase R2: Agent Economic Reality

**Objective**: Connect agent budget usage to real ledger state and audit trails.
**Allowed File Operations**:

- **MODIFY**: [agent_permissions.py](file:///home/lin/Documents/empire-ai/src/agent_permissions.py) (Implement `_get_budget_usage` using `audit_events` and `capital_ledger` data)
**Explicitly Forbidden Actions**:
- Returning hardcoded zero values or "Phase 2" placeholder comments.
**Governance Laws**: Zero-Mock Reality Law (0.1), Audit Readability Law (D-LAW-4).
**Verification Gates**:
- Verify that initializing an agent with a budget limit blocks actions once ledger usage exceeds that limit.

### Phase R3: Kill-System Causal Reality

**Objective**: Implement real side-effects for the emergency kill system.
**Allowed File Operations**:

- **MODIFY**: [main_api.py](file:///home/lin/Documents/empire-ai/src/main_api.py) (Implement `kill_system` to emit a persistent HALT signal, terminate agent processes, and lock the API state)
**Explicitly Forbidden Actions**:
- Returning `status: "HALTED"` without stopping system processes.
- Leaving "In production: actually halt..." comments in code.
**Governance Laws**: Kill-System Reality Law (0.3), Hive UI Truth Law (0.4).
**Verification Gates**:
- `scripts/verify_kill_switch.sh` MUST confirm process termination and 503 responses for subsequent API calls.

### Phase R4: E2E Reality Verification (Anti-Mock Testing)

**Objective**: Deploy tests capable of detecting fake/static backend responses.
**Allowed File Operations**:

- **CREATE**: [tests/e2e/reality_audit.spec.ts](file:///home/lin/Documents/empire-ai/tests/e2e/reality_audit.spec.ts) (Implement "Entropy Assertions" that fail if metrics remain static over 5 seconds)
- **MODIFY**: [tests/e2e/auth_reality.spec.ts](file:///home/lin/Documents/empire-ai/tests/e2e/auth_reality.spec.ts) (Enhance to verify side-effects of revocation)
**Governance Laws**: Hive UI Truth Law (0.4).
**Verification Gates**:
- `npx playwright test tests/e2e/reality_audit.spec.ts`

---

## 2. REQUIRED REPORTS

- `docs/reports/REALITY_REMEDIATION_SUMMARY.md`: Mapping of Audit v4 failures to implemented fixes.
- `docs/reports/INTENT_REGISTRY.json`: Index of all `.intent.md` files created.

## 3. STOP CONDITIONS

1. Detection of `mock`, `stub`, or `Math.random()` in functional remediation code.
2. Metrics failing the entropy test (static values across time).
3. "Success" response from `kill.system` without observable process exit.
4. Any `.intent.md` file missing required [INTENT] or [FAILURE_MODES] blocks.

---
