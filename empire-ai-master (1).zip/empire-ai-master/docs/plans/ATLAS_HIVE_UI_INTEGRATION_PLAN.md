# PLAN: ATLAS HIVE UI INTEGRATION & AUTH REBRANDING

**PLAN_HASH:** d425e08e9cf90d87b8f4a581758e59800454ddc71f24f18d38cd500dc2c38658
**AUTHORITY:** ATLAS_PROTECTION_SYSTEM
**STATUS:** DRAFT - REQUIRES OPERATOR APPROVAL

## 1. Objective

Replace the brutalist "Construct" UI with the organic "Hive Mind" aesthetic across both the main application and the authentication boundary. Ensure absolute adherence to the **Reality Lock** and **Identity Precedes Control** laws.

## 2. Global Enforcement Rules

- **Zero-Illusion Guarantee**: Every cell on the map must represent a real backend entity (asset, agent, or process). Simulated data generation (e.g., `Math.random`) is STRICTLY FORBIDDEN.
- **Reality Verification**: Actions taken in the UI (Pheromones/Transmit) must result in real side-effects in the backend and be recorded in the Universal Ledger.
- **Identity Gating**: No UI rendering shall occur without a verified session via the `AuthenticationProvider` (MS-9 compliance).
- **Thematic Consistency**: The Authentication Boundary (Login/Verification) must share the Hive theme (Amber/Hexagonal).

## 3. High-Fidelity Integration

### 3.1 Map & Clusters (Restoration)

- **Component**: `EmpireHiveUI.tsx` [RESTORED]
- **Data Source**: `useHiveState.cells`. No randomized yields.
- **Integrity**: `Total Nectar` wired to dynamic revenue metrics.

### 3.2 Authentication Rebranding

- **Component**: `AuthBoundary.tsx` [MODIFIED]
- **Aesthetic**: Radial amber gradients with spinning hexagonal primitives.
- **Logic**: Identity-first bootstrap remains immutable.

### 3.3 Safety Protocols

- **Guarded Kill Switch**: The brutalist lift-guard logic is re-themed for the Hive. "Colony Collapse" requires lifting the safety guard and a held interaction (Apoptosis).

## 4. Proposed Changes

### [MODIFY] [AuthBoundary.tsx](file:///home/lin/Documents/empire-ai/src/admin_ui_frontend/src/ui/auth/AuthBoundary.tsx)

- Rebrand UI elements to match Hive theme.

### [NEW] [EmpireHiveUI.tsx](file:///home/lin/Documents/empire-ai/src/admin_ui_frontend/src/components/EmpireHiveUI.tsx)

- Re-implement with real telemetry wiring and lift-guard logic.

### [MODIFY] [index.tsx](file:///home/lin/Documents/empire-ai/src/admin_ui_frontend/src/index.tsx)

- Set `EmpireHiveUI` as the root component.

## 5. Verification Gate

1. **Audit Check**: `scripts/verify` must pass with 0 findings.
2. **Identity Gate**: Confirm redirection to `/public/hive.html` if unauthenticated.
3. **Reality Proof**: Demonstrate that killing a process in the UI results in a real side-effect on the host.

---
**END_OF_PLAN**
