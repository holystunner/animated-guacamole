# ATLAS END-TO-END REALITY REMEDIATION BLUEPRINT (v6)

**STATUS**: APPROVED
**PLAN HASH**: 5afa55b69cf0297048e6a2b4aff04f70188c5533c776798bfc77b68852a1cad3
**SUPERVISOR**: KAIZA MCP
**DATE**: 2026-01-19
**AUTHORITY**: docs/audits/ATLAS_END_TO_END_SYSTEM_AUDITv6.md

---

## 0. GLOBAL GOVERNANCE REQUIREMENTS (LAW)

### 4.1 Authentication Integrity Law

Execution MUST ensure:

- No reference to undefined database methods.
- Operator existence validation is real, atomic, and auditable.
- No bypass or degraded auth behavior under failure.
- Authentication failure MUST hard-stop execution.
- Violation: ⛔ EXECUTION INVALID

### 4.2 Zero-Mock Reality Law

Execution MUST permanently forbid:

- Hardcoded metrics (e.g. uptime, latency, error rate).
- Simulated telemetry generators.
- Static UI placeholders presented as real state.
- Randomized fake data (Math.random, timers, seeded illusions).
- Detection of any mock or placeholder behavior: ⛔ EXECUTION INVALID

### 4.3 Hive UI Truth Law

Every Hive UI element MUST:

- Be backed by live backend state.
- Reflect real system conditions.
- Fail visibly if backend data is unavailable.
- Be verifiable via E2E testing.
- Visual-only or simulated success: ⛔ EXECUTION INVALID

### 4.4 Failure Semantics Law

All failures MUST:

- Hard-stop execution.
- Emit a stable error code.
- Identify violated invariant.
- Attribute phase + component.
- Produce written debug evidence.
- Silent failure (except: pass): ⛔ EXECUTION INVALID

### 4.5 Mandatory Commentary & Debug Law

For EVERY file created or modified:

- `<file>.intent.md` MUST exist.
- Each intent document MUST describe: Purpose, Authorizing plan + phase, Inputs/outputs, Invariants, Failure modes, Debug signals, and Explicit out-of-scope behavior.
- Missing or incomplete intent documentation: ⛔ EXECUTION INVALID

---

## 1. REMEDIATION PHASES

### Phase R1: Auth Integrity & Semantic Hard-Stop

- **Phase ID**: R1-AUTH-SEMANTICS
- **Objective**: Fix the authentication runtime crash and eliminate silent failure paths in system halt logic.
- **Allowed File Operations**:
  - **MODIFY**: src/db.py (Implement operator_exists method; ensure real DB check).
  - **MODIFY**: src/main_api.py (Replace except Exception: pass in_is_system_halted with explicit error propagation and MON_001 failure code).
- **Explicitly Forbidden Actions**: Using hardcoded true/false for operator existence; masking any exceptions during system status checks.
- **Governance Laws Enforced**: 4.1 (Auth Integrity), 4.4 (Failure Semantics).
- **Verification Gates**:
  - grep "def operator_exists" src/db.py returns implementation.
  - grep -r "except.*pass" src/main_api.py returns zero matches in critical paths.
- **Required Reports**: docs/reports/R1-INTEGRITY-COMPLIANCE.md
- **STOP Conditions**: Failure to implement atomic DB checks; persistent use of pass in error blocks.

### Phase R2: Metric Reality Restoration

- **Phase ID**: R2-METRIC-REALITY
- **Objective**: Remove hardcoded health metrics from the database layer fallbacks.
- **Allowed File Operations**:
  - **MODIFY**: src/db.py (Remove static blocks return 99.9, 0.1, 120).
- **Explicitly Forbidden Actions**: Replacing hardcoded values with other static constants or randomized mocks.
- **Governance Laws Enforced**: 4.2 (Zero-Mock Reality).
- **Verification Gates**:
  - Telemetry Entropy Test: Verify that returned metrics show variance consistent with real system activity.
- **Required Reports**: docs/reports/R2-TELEMETRY-VERIFICATION.md
- **STOP Conditions**: Static metrics detected in any health-check API response.

### Phase R3: Hive UI Truth Migration

- **Phase ID**: R3-UI-TRUTH
- **Objective**: Re-wire the Hive UI to consume live backend metrics and events instead of simulated generators.
- **Allowed File Operations**:
  - **MODIFY**: src/admin_ui_frontend/src/AtlasUI.tsx (Remove setInterval log generation; connect LogTerminal, TacticalMap, SystemsGrid, and IncidentsTable to real API endpoints).
- **Explicitly Forbidden Actions**: Using Math.random or static string constants for UI telemetry values.
- **Governance Laws Enforced**: 4.3 (Hive UI Truth), 4.2 (Zero-Mock Reality).
- **Verification Gates**:
  - Manual verification of UI state against raw API responses (/api/system/metrics).
- **Required Reports**: docs/reports/R3-UI-TRUTH-AUDIT.md
- **STOP Conditions**: Any UI component found rendering data not present in the backend state.

### Phase R4: End-to-End Reality Verification

- **Phase ID**: R4-E2E-VERIFICATION
- **Objective**: Implement and execute mechanical tests that detect simulation/mock behavior.
- **Allowed File Operations**:
  - **CREATE**: tests/e2e/reality_check.spec.ts (Playwright tests for data entropy and auth paths).
- **Explicitly Forbidden Actions**: Snapshot testing without entropy validation.
- **Governance Laws Enforced**: All.
- **Verification Gates**:
  - npx playwright test tests/e2e/reality_check.spec.ts
- **Required Reports**: docs/reports/ATLAS_E2E_REALITY_FINAL_REPORT.md
- **STOP Conditions**: Any test failure or detection of static "simulation" patterns.

---

## 2. END-TO-END VERIFICATION REQUIREMENTS

Practical mechanical enforcement via:

1. **Entropy Assertion**: Tests must sample a value (e.g., Throughput) at T1 and T2; if Value(T1) == Value(T2) across 5 samples without system idleness, test must FAIL.
2. **Auth Path Exhaustion**: Test must verify 403 response when operator_id is removed from DB.
3. **Log Sourcing**: Verify that LogTerminal entries exist in the audit_events table via direct DB query during test execution.

---

## 3. STOP CONDITIONS

1. Discovery of ANY hardcoded metric or placeholder not covered by this plan.
2. Failure to produce <file>.intent.md for any modification.
3. Inability to verify a UI component against a real backend endpoint.
