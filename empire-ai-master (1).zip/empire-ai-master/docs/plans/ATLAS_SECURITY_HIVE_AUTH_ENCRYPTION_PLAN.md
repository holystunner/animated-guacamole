# ATLAS SECURITY HIVE AUTH ENCRYPTION PLAN

**Plan ID:** ATLAS-SEC-HIVE-001
**Status:** APPROVED
**Hash-Lock:** ec10e0f008c6fdf61adb358f83671c58123410d70279bebbed958cd8619fde7e

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🎯 MISSION OBJECTIVE

Eliminate security theater by implementing production-grade, open-source authentication (WebAuthn/Keycloak), short-lived session security with mandatory revocation, and end-to-end encryption for the Atlas Empire Hive.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE 1: WEBAUTHN & IDENTITY REALITY LOCK

**Phase ID:** AE-SEC-P1
**Objective:** Replace stubbed WebAuthn verification with cryptographically sound attestation and signature verification.

**Explicit File Operations:**

- **MODIFY** [auth_endpoints.py](file:///home/lin/Documents/empire-ai/src/api/auth_endpoints.py)
  - Remove "skip full attestation verification" fallback.
  - Enforce `webauthn` library calls for all registration/authentication steps.
  - Implement hard reject on `ImportError` for cryptographic dependencies.
- **MODIFY** [device_binding.py](file:///home/lin/Documents/empire-ai/src/auth/device_binding.py)
  - Replace "simulated" `_verify_webauthn_signature` with production-grade `webauthn-py` implementation.
  - Enforce strict JWK format validation and sign count tracking for replay protection.

**Explicit Forbidden Actions:**
- Do NOT use simulated or "simplified" signature verification.
- Do NOT allow registration without verified attestation.

**Required Verification Gates:**
- **Command:** `pytest tests/auth/test_webauthn_reality.py`
- **Expected:** Success (0).
- **Mandatory Report Artifact:** `docs/reports/AE-SEC-P1-EXECUTION.md`

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE 2: SESSION SECURITY & REVOCATION ENFORCEMENT

**Phase ID:** AE-SEC-P2
**Objective:** Hard-lock session security with rotating refresh tokens and mandatory revocation checks across all API gateways.

**Explicit File Operations:**

- **MODIFY** [token_revocation.py](file:///home/lin/Documents/empire-ai/src/token_revocation.py)
  - Enforce periodic Redis synchronization for the revocation cache.
  - Implement "Fail-Closed" behavior: if Redis is unavailable and local cache is stale (>60s), reject all write-operation tokens.
- **MODIFY** [gateway_pep.py](file:///home/lin/Documents/empire-ai/src/gateway_pep.py)
  - Wire all incoming requests through `TokenRevocationList.is_revoked()`.
  - Enforce maximum session age of 12 hours for all Operator IDs.

**Explicit Forbidden Actions:**
- Do NOT allow "Fail-Open" on revocation list connectivity issues.
- Do NOT use persistent tokens; all access tokens must expire in <15 minutes.

**Required Verification Gates:**
- **Command:** `python3 scripts/verify_session_lock.py`
- **Expected:** Success (0) - verified token rejection after revocation.
- **Mandatory Report Artifact:** `docs/reports/AE-SEC-P2-EXECUTION.md`

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE 3: UI SECURITY INTEGRATION (HIVE LOGIN)

**Phase ID:** AE-SEC-P3
**Objective:** Integrate production-grade authentication into the Hive UI, replacing demo credentials with real WebAuthn/TOTP flow.

**Explicit File Operations:**

- **MODIFY** [hive-login.html](file:///home/lin/Documents/empire-ai/hive-login.html)
  - Remove any remaining hardcoded demo text or "admin/admin123" logic.
  - Integrate WebAuthn "Passkey" login flow consistent with Hive aesthetic.
- **MODIFY** [HiveState.ts](file:///home/lin/Documents/empire-ai/src/admin_ui_frontend/src/ui/state/useHiveState.ts)
  - Enforce authentication state check before any backend data fetch.
  - Redirect to `/login` immediately on 401/403 responses.

**Explicit Forbidden Actions:**
- Do NOT keep "Demo" or "Bypass" buttons in the UI.
- Do NOT store raw access codes or passwords in local storage.

**Required Verification Gates:**
- **Command:** `grep -r "admin123" .`
- **Expected:** Empty result.
- **Mandatory Report Artifact:** `docs/reports/AE-SEC-P3-EXECUTION.md`

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE 4: ENCRYPTION & SECRETS LOCKDOWN

**Phase ID:** AE-SEC-P4
**Objective:** Implement at-rest encryption for sensitive DB fields and secure secret injection at runtime.

**Explicit File Operations:**

- **MODIFY** [database.py](file:///home/lin/Documents/empire-ai/src/database.py)
  - Implement transparent field encryption for `operator_attributes` and `secret_keys` using `cryptography.fernet`.
- **CREATE** [prod_secrets_loader.py](file:///home/lin/Documents/empire-ai/src/auth/prod_secrets_loader.py)
  - Implement mandatory environment-only secret loading (no .env fallback in production).

**Explicit Forbidden Actions:**
- Do NOT commit encryption keys to the repository.
- Do NOT store secrets in plaintext logs.

**Required Verification Gates:**
- **Command:** `python3 scripts/verify_encryption_lock.py`
- **Expected:** Success (0) - verified cipher-text in DB for sensitive fields.
- **Mandatory Report Artifact:** `docs/reports/AE-SEC-P4-EXECUTION.md`

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🏆 ACCEPTANCE CRITERIA

1. **Reality Lock:** `scripts/verify` passes with zero "mock", "stub", or "pass" violations in auth modules.
2. **Fail-Secure:** System rejects all operations if the Identity Provider (Keycloak) or Revocation List (Redis) is unreachable.
3. **Hive Integrity:** UI only shows data after a successful WebAuthn/TOTP 2FA challenge.
4. **Encryption Cert:** All sensitive data in `atlas_protection` schema is encrypted at-rest.
