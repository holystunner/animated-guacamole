# ATLAS END-TO-END PRODUCTION REALITY FIX BLUEPRINT

**STATUS**: APPROVED
**PLAN HASH**: c62cf943a7924588f0ac1f2bd65766ea5d388878a81426e0b4685a5ac89ebdde
**SUPERVISOR**: KAIZA MCP
**DATE**: 2026-01-21
**EXECUTION_MODE**: BATCH
**BATCH_EXECUTION_ALLOWED**: true
**STOP_ON_FAILURE**: true

---

## 1. GLOBAL GOVERNANCE REQUIREMENTS (LAW)

### 4.1 Zero-Mock Reality Law

Execution MUST ensure:

- NO mock data, stub logic, or placeholder UI state.
- NO fake API responses or hardcoded demo values.
- NO `Math.random()` or simulated telemetry in metrics.
- Detection of any of the above: ⛔ **EXECUTION INVALID**

### 4.2 Authentication & Security Law

Execution MUST enforce:

- Real OIDC/Keycloak authentication.
- Backend authorization checks for ALL UI actions.
- UI buttons wired ONLY to real backend endpoints.
- Any UI action hitting fake data or bypassing auth: ⛔ **FAIL**

### 4.3 Failure Semantics Law

All failures MUST:

- Hard-stop execution immediately.
- Produce a stable error code and human-readable explanation.
- Attribute failure to specific phase and component.
- Silent failure is STRICTLY FORBIDDEN.

### 4.4 Mandatory Commentary & Debug Law

For EVERY file created or modified:

- `<file>.intent.md` MUST be written.
- Intent MUST explain: Purpose, Invariants, Failure modes, and Debug signals.
- Missing intent artifact: ⛔ **FAIL**

---

## 2. REMEDIATION PHASES

### Phase P0: Plan Commit & Provenance

- **Objective**: Lock the plan into git history.
- **Operations**:
  - `git add docs/plans/ATLAS_END_TO_END_PRODUCTION_REALITY_FIX_BLUEPRINT.md`
  - `git commit -m "PLAN: ATLAS_END_TO_END_PRODUCTION_REALITY_FIX | SHA256=<HASH> | APPROVED"`
- **Stop Condition**: Git commit failure.

### Phase 1: Remove Mock/Stub Data

- **Objective**: Eliminate hardcoded telemetry and approval stubs.
- **Allowed Operations**:
  - **MODIFY** [db.py](file:///home/lin/Documents/empire-ai/src/db.py): Add `approvals` table; remove heuristic formulas in `_get_basic_health_metrics` and `_extract_asset_health`.
  - **MODIFY** [main_api.py](file:///home/lin/Documents/empire-ai/src/main_api.py): Replace hardcoded `pending` list in `list_approvals` with DB query.
  - **MODIFY** [useCapabilities.tsx](file:///home/lin/Documents/empire-ai/src/admin_ui_frontend/src/ui/policy/useCapabilities.tsx): Fix syntax corruption on Line 144.
- **Verification**: `grep` for "Math.random" or hardcoded metric constants in `db.py`.

### Phase 2: Authentication Enforcement

- **Objective**: Rectify circular dependencies and enforce strict OIDC checks.
- **Allowed Operations**:
  - **MODIFY** [db.py](file:///home/lin/Documents/empire-ai/src/db.py): Refactor `operator_exists` to query a real identity/operator table instead of audit logs.
  - **MODIFY** [main_api.py](file:///home/lin/Documents/empire-ai/src/main_api.py): Ensure all `/api/` routes pass through `get_current_user` with no bypasses.
- **Verification**: Unauthorized API calls MUST return 401/403.

### Phase 3: Hive UI Real-Data Wiring

- **Objective**: Connect the "SystemsGrid" and Gauges to real API data.
- **Allowed Operations**:
  - **MODIFY** [AtlasUI.tsx](file:///home/lin/Documents/empire-ai/src/admin_ui_frontend/src/AtlasUI.tsx):
    - Replace static cluster array `[1,2,3...6]` with data from `/api/assets` or `/api/system/metrics`.
    - Replace hardcoded `Gauge` value formulas with real metric values.
- **Verification**: UI reflects changes made directly to the backend database (entropy check).

### Phase 4: End-to-End Browser Verification

- **Objective**: Mechanically prove system reality via Playwright and Puppeteer.
- **Required Tests**:
  - Real login flow (Keycloak interaction).
  - Real data rendering in Hive UI.
  - Button click side-effect verification (DB state change).
- **Stop Condition**: UI works without backend state change.

### Phase 5: Final Production Readiness

- **Objective**: Declaring final PASS/FAIL.
- **Required Report**: `docs/reports/ATLAS_E2E_REALITY_FINAL_REPORT.md`.

---

## 3. VERIFICATION LAW

- All tests MUST use Playwright AND Puppeteer.
- Verified side-effects must be checked by observing changes in `audit_events`.
- Any component found rendering non-backend data: ⛔ **VERIFICATION FAILURE**
