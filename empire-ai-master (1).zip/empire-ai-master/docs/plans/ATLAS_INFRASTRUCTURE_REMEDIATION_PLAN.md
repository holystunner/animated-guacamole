# ATLAS INFRASTRUCTURE REMEDIATION PLAN

**Plan ID:** ATLAS-INFRA-REMED-001
**Authority:** ATLAS_ENTERPRISE_PRODUCTION_READINESS_PLAN.md
**Status:** APPROVED
**Hash-Lock:** d609ea07484e070734b093ddb8e7b77ddfc0e622c5ca48e69bf0209858f9ae39

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🎯 MISSION OBJECTIVE

Restore the Atlas Empire infrastructure to a functional state by resolving PostgreSQL authentication failures, configuration model mismatches, and verification script invocation errors. This plan addresses only the infrastructure-level blockers identified in AE-REMED-P3 and AE-REMED-P4.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE IR-1: CONFIGURATION SYSTEM ALIGNMENT

**Phase ID:** IR-1
**Objective:** Align environment variables with the Pydantic Settings model and suppress validation errors for extra environment variables.

**Explicit File Operations:**

- **MODIFY** [config.py](file:///home/lin/Documents/empire-ai/src/config.py)
  - Add `extra = 'ignore'` to `class Config` in the `Settings` model to prevent validation failures on non-prefixed environment variables.
- **MODIFY** [.env](file:///home/lin/Documents/empire-ai/.env)
  - Align environment variable names with the `Settings` model (e.g., transition from `EMPIRE_LOG_LEVEL` to `LOG_LEVEL`).

**Explicit Forbidden Actions:**

- Any change to business logic or service behavior.
- Hardcoding sensitive credentials directly in source code.

**Required Verification Gates:**

- **Command:** `python3 -c "from src.config import get_settings; print('Status: PASS') if get_settings() else exit(1)"`
- **Expected PASS:** "Status: PASS" output without Pydantic validation errors.

**Mandatory Report Artifact:** `docs/reports/AE-REMED-IR1-EXECUTION.md`
**Hard STOP Conditions:** Continued Settings instantiation failure after modification.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE IR-2: POSTGRESQL CONNECTIVITY & AUTHENTICATION

**Phase ID:** IR-2
**Objective:** Configure valid PostgreSQL credentials and ensure consistency between application settings and verification scripts.

**Explicit File Operations:**

- **MODIFY** [.env](file:///home/lin/Documents/empire-ai/.env)
  - Explicitly define `DATABASE_URL` for `DatabaseManager`.
  - Define `POSTGRES_USER`, `POSTGRES_PASSWORD`, `POSTGRES_DB`, and `POSTGRES_PORT` for compatibility with `verify_production_readiness.sh`.

**Explicit Forbidden Actions:**

- Modification of `src/database.py` connection pooling or query logic.
- Switching database providers (must remain PostgreSQL).

**Required Verification Gates:**

- **Command:** `bash scripts/verify_production_readiness.sh`
- **Expected PASS:** "✔ PostgreSQL connection successful" and "✔ Redis connection successful".

**Mandatory Report Artifact:** `docs/reports/AE-REMED-IR2-EXECUTION.md`
**Hard STOP Conditions:** `password authentication failed for user "postgres"` persists after credential update.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE IR-3: VERIFICATION PIPELINE & TEST ENVIRONMENT

**Phase ID:** IR-3
**Objective:** Correct the invocation of verification scripts and fix module resolution for the test suite.

**Explicit File Operations:**

- **MODIFY** [.env](file:///home/lin/Documents/empire-ai/.env)
  - Correct any path resolution variables if necessary.

**Explicit Forbidden Actions:**

- Modifying `src/` business logic to satisfy import errors (must use PYTHONPATH).
- Changing UI behavior or data presentation.

**Required Verification Gates:**

- **Command:** `PYTHONPATH=. bash scripts/verify` (Corrected invocation from python3 to bash)
- **Expected PASS:** "VERIFY PASSED — SAFE TO SHIP".

**Mandatory Report Artifact:** `docs/reports/AE-REMED-IR3-EXECUTION.md`
**Hard STOP Conditions:** Any failure in `scripts/verify` that identifies remaining stubs or mock data in source code.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🔒 FINALIZATION

**Hash-Address:** d609ea07484e070734b093ddb8e7b77ddfc0e622c5ca48e69bf0209858f9ae39
**Status:** APPROVED
