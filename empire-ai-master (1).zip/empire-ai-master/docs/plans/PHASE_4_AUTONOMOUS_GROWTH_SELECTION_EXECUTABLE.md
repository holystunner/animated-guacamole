## PLAN_HASH

a2ead1bbeb2d6157dd80db6f712cd467aadfe7661c790270517105056c458d8c

1. PLAN_METADATA

- ID: PHASE_4_AUTONOMOUS_GROWTH
- NAME: Autonomous Growth & Selection
- VERSION: 1.0.0
- STATUS: EXECUTABLE_PENDING
- CONTEXT: Empire AI Phase 4
- PARENT: /docs/governance/CANONICAL_ROADMAP.md
- DEPENDS_ON:
  - /docs/plans/PHASE_3_AEA_ATLAS_OMEGA_EXECUTABLE.md
- TARGET_PATH: /docs/plans/PHASE_4_AUTONOMOUS_GROWTH_SELECTION_EXECUTABLE.md
- AUTHOR: ANTIGRAVITY (KAIZA MCP)

1. SCOPE_LOCK

- LOCKED_TO: PHASE 4 (AUTONOMOUS GROWTH & SELECTION)
- PREVIOUS_PHASE: PHASE 3 (AEA / ATLAS-Ω)
- EXPLICITLY_EXCLUDED:
  - NEW_BUSINESS_MODELS
  - NEW_ASSET_CATEGORIES
  - PAID_TRAFFIC_ACQUISITION
  - SOCIAL_MEDIA_PLATFORMS
  - EMAIL_MARKETING
  - MULTI_SERVER_SCALING
  - HUMAN_MANUAL_TUNING

1. PHASE_OBJECTIVE

- PRIMARY: Convert Phase 3's static success into evolutionary pressure (Growth).
- SECONDARY: Enforce "Survival of the Fittest" via programmatic selection.
- TERTIARY: Maximize revenue per compute unit through asset cloning and pruning.

1. REQUIRED_PRECONDITIONS

- PRECONDITION_1: Phase 3 accepted and complete.
- PRECONDITION_2: Revenue > $0.00 confirmed in Phase 3 ledger.
- PRECONDITION_3: At least 1 active asset exists in Registry.

1. IN-SCOPE ASSET ACTIONS

- ACTION_1: REWRITE_CONTENT (Title, Meta, H1, Body).
- ACTION_2: RESTRUCTURE_LINKS (Internal Semantic Mesh).
- ACTION_3: CLONE_ASSET (Fork successful template to new keyword).
- ACTION_4: RETIRE_ASSET (Delete failed assets).
- ACTION_5: REALLOCATE_BUDGET (Shift compute priority to winners).

1. OUT-OF-SCOPE ACTIONS

- NO_NEW_MODELS: Cannot invent dropshipping, SaaS, etc.
- NO_PAID_KICKSTART: Cannot buy ads to test assets.
- NO_SOCIAL: Cannot post to Twitter/Reddit/LinkedIn.
- NO_SPAM_EMAIL: Cannot send outbound emails.
- NO_HUMAN_LABOR: No "review queues" for humans. Assumed autonomous.

1. GROWTH ACTION TAXONOMY

- TYPE_A: META_OPTIMIZATION
  - Target: Title Tags, Meta Descriptions.
  - Trigger: High Impressions, Low CTR.
  - Method: A/B Test variants from LLM.
- TYPE_B: CONTENT_REFRESH
  - Target: Body Content.
  - Trigger: Decay in ranking or > 90 days old.
  - Method: Update facts, dates, and re-generate sections.
- TYPE_C: LINK_MESHING
  - Target: Interval Linking structure.
  - Trigger: New related asset deployed.
  - Method: Update graph to cluster related topics.
- TYPE_D: VARIANT_CLONING
  - Target: Successful Asset.
  - Trigger: Revenue Verification.
  - Method: Deploy 5 variants targeting adjacent long-tail keywords.

1. SELECTION & PRUNING RULES

- RULE_1: THE_GLADIATOR -> Winners receive more pages, links, and clones.
- RULE_2: THE_MERCY -> Losers are rewritten ONCE (Attempt Rescue).
- RULE_3: THE_EXECUTIONER -> If Rescue fails (No lift in 30d), Asset is DELETED.
- RULE_4: THE_WAGER -> No asset survives > 60 days without measurable revenue or traffic growth.
- RULE_5: THE_PRESSURE -> Selection pressure (thresholds) increases by 5% per month.

1. CLONING & SCALING RULES

- THRESHOLD_REWRITE: CTR < 1.0% (Context dependent) OR Traffic Decay > 20%.
- THRESHOLD_KILL: Revenue == $0.00 AND Traffic < 50 visits/mo (Age > 60d).
- THRESHOLD_CLONE: Revenue > $10.00/mo (Stable).
- WINDOW_TIME: Evaluation Window = Rolling 30 Days.
- PERIOD_COOLDOWN: 7 Days between major actions per asset.
- LIMIT_DEPTH: Maximum Clone Depth = 3 (Original -> Clone -> Clone -> Stop).

1. DECISION LOGIC (FORMAL CONDITIONS)

- IF Asset.Revenue_30d > $10.00 AND Asset.Last_Action_Days > 7:
  - THEN: EXECUTE(CLONE_ASSET, Count=5)
- IF Asset.Revenue_30d == 0 AND Asset.Traffic_30d < 50 AND Asset.Age_Days > 60:
  - IF Asset.Has_Been_Rewritten == FALSE:
    - THEN: EXECUTE(REWRITE_CONTENT)
  - ELSE:
    - THEN: EXECUTE(RETIRE_ASSET)
- IF Asset.Impressions > 1000 AND Asset.CTR < 1.0%:
  - THEN: EXECUTE(META_OPTIMIZE)

1. AGENT ROLES & PERMISSIONS (PHASE 4 ONLY)

- ROLE: GROWTH_AGENT
  - Goal: Analyze metrics, schedule Growth Actions.
  - Permissions: READ_METRICS, PLAN_ACTION.
- ROLE: EDITOR_AGENT
  - Goal: Execute localized content optimizations.
  - Permissions: WRITE_ASSET_CONTENT.
- ROLE: ARCHITECT_AGENT
  - Goal: Manage site structure and link graph.
  - Permissions: WRITE_LINK_STRUCTURE.
- ROLE: GOVERNOR (SYSTEM)
  - Goal: Enforce Kill/Clone Limits.
  - Permissions: ALL (Approves/Denies Plans).

1. DATA INPUTS & METRICS

- INPUT_1: Google Search Console (Impressions, Clicks, CTR, Position).
- INPUT_2: Revenue Ledger (Confirmed $).
- INPUT_3: Asset Registry (Age, History, Lineage).
- METRIC_1: Revenue per Page (RPP).
- METRIC_2: Revenue per Compute Unit (RPCU).

1. DEPLOYMENT & ROLLBACK MODEL

- STRATEGY: Atomic File Swaps.
- ROLLBACK: Previous version stored for 7 days.
- TRIGGER: If 404 rate > 5% post-update -> AUTO_ROLLBACK.

1. FAILURE MODES & CIRCUIT BREAKERS

- MODE_1: INFINITE_LOOP -> Metric glitch causes endless Clones.
  - BREAKER: Max 10 Clones per day globally.
- MODE_2: MASS_EXTINCTION -> Bad rule kills healthy assets.
  - BREAKER: Max 5% of portfolio deleted per day.
- MODE_3: ZERO_CONTENT -> Rewrites produce empty files.
  - BREAKER: Output validation (Min size check).

1. AUDIT & TRACEABILITY REQUIREMENTS

- REQ_1: Parent_ID tracking for all Clones (Lineage).
- REQ_2: Reason_Code logged for every Kill (e.g., "RULE_3_EXECUTIONER").
- REQ_3: Snapshot of asset state *before* modification.
- REQ_4: Ledger of all Agent "Growth Bets" vs Outcomes.

1. EXECUTION STEPS (ORDERED, ATOMIC)
1. EXTEND_METRICS_SCHEMA
   - ACTION: Update Registry to track `parent_id`, `generation`, `rewrite_count`.
1. IMPLEMENT_GROWTH_AGENT
   - ACTION: Create `src/core/agents/growth.ts` with Decision Logic.
1. IMPLEMENT_ACTION_EXECUTORS
   - ACTION: Create `src/core/actions/{clone,rewrite,retire}.ts`.
1. IMPLEMENT_CIRCUIT_BREAKERS
   - ACTION: Update Governor with `Global_Clone_Limit` and `Global_Kill_Limit`.
1. SIMULATE_EVOLUTION
   - ACTION: Run simulation with 100 mock assets, active specific rules.
   - CHECK: Winners multiply, Losers die.
1. DEPLOY_MONITOR
   - ACTION: Activate GSC/Revenue ingestion.

1. ACCEPTANCE CRITERIA (PASS / FAIL ONLY)

- [ ] At least ONE asset is rewritten by Agent? (PASS/FAIL)
- [ ] At least ONE asset is cloned based on Revenue? (PASS/FAIL)
- [ ] At least ONE asset is killed based on Rules? (PASS/FAIL)
- [ ] Revenue continues post-modification (No regressions)? (PASS/FAIL)
- [ ] All actions are logged in the audit ledger? (PASS/FAIL)
- [ ] Zero human actions are taken? (PASS/FAIL)

1. POST-PHASE INVARIANTS

- INVARIANT: The Portfolio Size is dynamic (grows/shrinks autonomous).
- INVARIANT: Audit Log contains full evolutionary history.
- INVARIANT: ROI is strictly increasing or stable.
