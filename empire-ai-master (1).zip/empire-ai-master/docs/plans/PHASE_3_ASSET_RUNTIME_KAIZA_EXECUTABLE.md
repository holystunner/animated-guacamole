---
status: APPROVED
plan_id: PHASE_3_ASSET_RUNTIME_KAIZA_EXECUTABLE
title: Phase 3 Asset Runtime (KAIZA Executable)
created_by: Antigravity (Planner)
created_date: 2026-01-12
source_inputs:
  - docs/plans/PHASE_3_ASSET_RUNTIME_KAIZA.md
  - docs/plans/PHASE_2_AGENT_ECONOMY_KAIZA_EXECUTABLE.md
authority:
  - /docs/governance/EMPIRE_AI_CANONICAL_SPECIFICATION.md (Layer 4)
  - KAIZA_COMPLETE_GUIDE.md
---

# PHASE 3: ASSET RUNTIME (KAIZA-EXECUTABLE)

## 1. Header Block
**Phase ID:** PHASE_3_ASSET_RUNTIME  
**Status:** APPROVED  
**Date:** 2026-01-12  
**Authority:** EMPIRE_AI_CANONICAL_SPECIFICATION.md v1.0, KAIZA_COMPLETE_GUIDE.md  
**Source Inputs:** docs/plans/PHASE_3_ASSET_RUNTIME_KAIZA.md, PHASE_2 (Dependency)

## 2. Objective
Implement the factory floor where Assets are created, deployed, and managed. Assets (Content Clusters, Tool Sites, Lead Gen Pages) are first-class entities with a lifecycle (Draft -> Active -> Paused -> Retired). The Runtime Engine manages deployment infrastructure and collects metrics (traffic, revenue) which are fed back to the Ledger.

## 3. Scope Lock
**Allowed Paths:**
- `src/asset_runtime.py`
- `src/infrastructure_manager.py`
- `src/assets/*.py`
- `src/metrics_collector.py`
- `tests/test_assets.py`
- `docs/plans/` (self-update)

**Forbidden Paths:**
- `src/web/*.py` (Phase 4)
- `src/agents/*.py` (Phase 2 - use integration, don't modify logic)

*Touching forbidden paths = HARD FAIL.*

## 4. Hard Bans / Reality Lock
- **NO** fake metrics (must read from implementation or return 0).
- **NO** "simulate deployment" (must actually call infra manager, even if infra manager is local-sim for now).
- **NO** generic `Asset` class without concrete implementations.
- **NO** ignoring deployment errors.

## 5. Write Tool Law
- ALL file writes MUST be performed using `kaiza_mcp.write_file`.
- Writing code directly in chat is **FORBIDDEN**.
- Partial writes are **FORBIDDEN**.

## 6. Deliverables
1.  **Asset Runtime Engine (`src/asset_runtime.py`)**: Manages the lifecycle loop (Deploy -> Check Health -> Collect Metrics).
2.  **Infrastructure Manager (`src/infrastructure_manager.py`)**: Abstraction for where assets live (S3, Vercel, VPS).
3.  **Asset Implementations**:
    - `src/assets/content_cluster.py` (SEO blog network)
    - `src/assets/tool_site.py` (Single utility wrapper)
    - `src/assets/lead_gen_page.py` (Landing page)
4.  **Metrics Collector (`src/metrics_collector.py`)**: Interface to GA/Stripe/Logs.
5.  **Integration Tests**: Verify lifecycle transitions and metric handling.

## 7. File-Level Write Set

| Path | Action | Purpose | Required Behaviors | Failure Modes | Tests |
|------|--------|---------|-------------------|---------------|-------|
| `src/asset_runtime.py` | CREATE | Lifecycle Engine | - `deploy_asset()`<br>- `pause_asset()`<br>- `collect_metrics()` loop | - Deployment fail<br>- State deadlock | `test_asset_runtime.py` |
| `src/infrastructure_manager.py` | CREATE | Infra Abstraction | - `provision_resources()`<br>- `get_deployment_status()` | - API fail<br>- Quota fail | `test_infra.py` |
| `src/assets/content_cluster.py` | CREATE | Asset Type | - `generate_static_site()`<br>- `sync_to_s3()` | - Build fail | `test_content_cluster.py` |
| `src/assets/tool_site.py` | CREATE | Asset Type | - `build_react_app()`<br>- `deploy_vercel()` | - Build fail | `test_tool_site.py` |
| `src/metrics_collector.py` | CREATE | Feedback Loop | - `fetch_traffic()`<br>- `fetch_revenue()`<br>- Write to Registry/Ledger | - API block | `test_metrics.py` |
| `tests/test_assets.py` | CREATE | Asset Verification | - Test full lifecycle: Create->Deploy->Metrics->Retire | - N/A | `pytest` |

## 8. Data Flows & Control Loops

1.  **Deployment**:
    `BuilderAgent` -> `AssetRuntime.deploy` -> `InfraManager.provision` -> `Registry (State: Active)` -> `Ledger (Log)`
2.  **Feedback Loop**:
    `Cron/Loop` -> `AssetRuntime.collect_metrics` -> `MetricsCollector` -> `Registry (Update ROI)` -> `Ledger (Log)`

## 9. Determinism & Audit Guarantees
- **Attribution**: Metric updates must be signed by `system` or `metrics_collector`.
- **State Changes**: Asset state changes (e.g. Active->Paused) must have a `reason` logged in Ledger.
- **Idempotency**: `deploy()` on an active asset should be a no-op or update.

## 10. Acceptance Criteria (BINARY)

- [ ] **Command**: `npm run test` passes 100%.
- [ ] **Invariant**: Paused assets generate 0 cost/revenue (model-wise).
- [ ] **Invariant**: Retired assets cannot be deployed.
- [ ] **Invariant**: Every asset in Registry has a valid `state`.

## 11. Stop Conditions
- If `InfrastructureManager` fails consistently, system MUST HALT (prevent run-away retries).
- If Metrics are stale > 24h, alert Owner.

## 12. Non-Scope
- **No Agent Logic**: Agents use this layer, but this layer doesn't control agents.
- **No UI**: Admin UI (Phase 4) visualizes this, but logic is here.
