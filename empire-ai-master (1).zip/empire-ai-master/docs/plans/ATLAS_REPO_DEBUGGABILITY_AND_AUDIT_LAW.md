# ATLAS REPO DEBUGGABILITY AND AUDIT LAW

**Status**: APPROVED
**Plan Hash**: dac44aaa8c4bd25c52f79e44757452686ea31455bc30cecc6c7757a9c17ff009
**Supervisor**: KAIZA MCP
**Scope**: REPO-GLOBAL (ALL MODULES)

---

## EXECUTION AUTHORITY CONSTITUTION

This document establishes new invariant laws for the Atlas Empire repository. These laws are structural requirements, not stylistic preferences. Failure to comply with these laws constitutes a blocking defect in any execution phase.

---

## Phase D-LAW-1 — Commentary Classification Law

**Objective**: Ensure every non-trivial logic block is self-documenting regarding intent, invariants, and failure modes.

### Enforcement Rules

- **REQUIRED Comment Classes**:
  - `[INTENT]`: Why this logic exists and what business/technical problem it solves.
  - `[INVARIANTS]`: Assumptions that must remain true for the code to function correctly.
  - `[FAILURE_MODES]`: How this code can break and what the expected system behavior is during failure.
  - `[DEPENDENCIES]`: External systems, files, or specific state this logic relies on.
- **Mandatory Locations**:
  - All public functions and class methods.
  - All non-obvious branching logic (complex if/else, match statements).
  - All external integration points (API calls, DB queries).
- **Forbidden Patterns**:
  - "How" comments that merely restate the code (e.g., `x = x + 1 # increment x`).
  - Stale or misleading comments.
  - Placeholder comments (e.g., `// TODO: add comments`).
- **Violation Criteria**: Any mandatory location missing one or more of the 4 REQUIRED classes.

### Operations

- **ALLOWED**: `MODIFY` across all files in `src/`, `infra/`, and `scripts/`.
- **FORBIDDEN**: Deletion of functional code logic without replacement.

### Verification

- **Command**: `grep -rE "\[INTENT\]|\[INVARIANTS\]|\[FAILURE_MODES\]|\[DEPENDENCIES\]" src/`
- **Expected Outcome**: 100% coverage of public interfaces and complex logic blocks.
- **Report**: `docs/reports/D-LAW-1-COMPLIANCE.md`

---

## Phase D-LAW-2 — Debug Visibility & Error Surface Law

**Objective**: Eliminate all silent failures and ambiguous states by enforcing explicit error propagation and strict return contracts.

### Enforcement Rules

- **Zero Silent Failure**: No `try...except: pass` or empty catch blocks.
- **Explicit Returns**: Functions must return concrete state or a structured `Result` object. No ambiguous `None` returns without a clear "why".
- **Propagation Law**: Every re-raised exception must be wrapped with contextual metadata (e.g., `raise WrappedError("context") from err`).
- **Surface Audit**: Error messages must be operator-safe (no PII) but actionable (include IDs and state).

### Operations

- **ALLOWED**: `MODIFY` across all files in `src/`.
- **FORBIDDEN**: Modifying business logic outcome; only error handling and visibility are in scope.

### Verification

- **Command**: `scripts/verify_error_surfaces.sh`
- **Expected Outcome**: Zero instances of silent swallows or ambiguous returns.
- **Report**: `docs/reports/D-LAW-2-COMPLIANCE.md`

---

## Phase D-LAW-3 — Logging & Traceability Law

**Objective**: Standardize structured logging and trace correlation across all modules to enable deterministic post-mortem analysis.

### Enforcement Rules

- **Structured Schema**: All logs MUST emit JSON with `trace_id`, `span_id`, `correlation_id`, and `component` fields.
- **Logic Boundaries**: Entry and Exit logging is mandatory for all high-value logic paths (transactions, external calls).
- **Correlation Law**: Every asynchronous operation or inter-process call MUST propagate the `trace_id`.
- **Forbidden Logging**: No PII, no un-redacted secrets, no raw "print" statements for debugging.

### Operations

- **ALLOWED**: `MODIFY` across all files in `src/`.
- **FORBIDDEN**: Changing logging backend configuration unless required for structured output.

### Verification

- **Command**: `scripts/verify_logging_schema.sh`
- **Expected Outcome**: All logs adhere to the JSON schema and include correlation IDs.
- **Report**: `docs/reports/D-LAW-3-COMPLIANCE.md`

---

## Phase D-LAW-4 — Audit Readability Law

**Objective**: Implement human-readable audit trails and causality chains to guarantee explainability of every system action.

### Enforcement Rules

- **Human-Readable Traces**: Every system state change must be accompanied by an `audit_msg` field explaining the change in plain language.
- **Deterministic Causality**: Every log entry must link back to a parent `event_id` or `request_id`.
- **Metadata Context**: All high-level actions must include `actor_id`, `action_type`, `target_resource`, and `final_status`.

### Operations

- **ALLOWED**: `MODIFY` across all files in `src/`.
- **FORBIDDEN**: Altering the functional state of the application.

### Verification

- **Command**: `scripts/verify_audit_trails.sh`
- **Expected Outcome**: Every state-mutating action is traceable to an actor and a causal event.
- **Report**: `docs/reports/D-LAW-4-COMPLIANCE.md`

---

## STOP CONDITIONS

Execution MUST stop immediately if:

1. Enforcement requires guessing developer intent for a component.
2. A remediation introduces a performance regression > 5% in critical paths.
3. The SHA256 hash of this plan is invalidated.
