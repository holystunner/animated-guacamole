# ATLAS FULLSTACK E2E DEPLOYMENT AND FIXES BLUEPRINT

**Status**: APPROVED
**Supervisor**: KAIZA MCP
**Authority**: ANTIGRAVITY (LAW DEFINITION)
**Blueprint Hash**: 5b3a5fbc5c9d7715faa829474e5833ad316b148dcd2d79a82ca48614570e2851

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 0. SESSION AUTHORITY (MANDATORY)

This blueprint is governed by the KAIZA MCP Supervisor.

- **ROOT**: /home/lin/Documents/empire-ai
- **IMMUTABILITY**: The workspace root is locked and immutable.
- **PATHING**: All paths referenced MUST be workspace-relative.
- **AUTHORITY**: Active via begin_session. No filesystem inference permitted.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 1. ANTIGRAVITY ROLE BOUNDARY (NON-NEGOTIABLE)

You are NOT allowed to:
- Write implementation code.
- Describe algorithms or specify control flow.
- Provide pseudocode or suggest fallbacks/recovery strategies.
- Decide how something is implemented.

You ARE allowed to:
- Define what must be true and what is forbidden.
- Define what evidence must exist and what constitutes failure.
- Define what Windsurf must refuse.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 2. PLANNING OBJECTIVE

Produce a Production Execution Blueprint that results in:
- End-to-end full-stack deployment (backend + DB + Keycloak + reverse proxy + UI).
- Authentication flow working end-to-end (OIDC login → token → API → UI gating).
- Hive UI integration verified with real/live data and working buttons.
- All required fixes planned and bounded so the system works 100% under verification.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 3. GLOBAL GOVERNANCE REQUIREMENTS (LAW)

### 3.1 Failure Semantics (LAW)
- All failures MUST hard-stop execution. Silent failure is forbidden.
- Recovery, retry, fallback, or mock behavior is forbidden unless explicitly authorized.
- Every failure MUST produce: stable error code, human-readable explanation, violated invariant, and attribution to phase + component.

### 3.2 try/catch Semantics (LAW)
- try/catch MAY exist ONLY to enrich diagnostics.
- Every catch MUST re-throw a hard failure. Catch-and-continue or catch-and-substitute is forbidden.

### 3.3 Mandatory Audit Commentary (LAW)
- For every file created or modified, execution MUST produce <file>.intent.md describing purpose, authorizing plan, inputs/outputs, invariants, and failure modes.

### 3.4 Mandatory Debug Evidence (LAW)
- On any failure, execution MUST produce structured debug evidence and a written failure report.

### 3.5 Zero-Fallback / Zero-Illusion Guarantee (LAW)
- Execution MUST NOT introduce or retain mocks, stubs, placeholders, or simulated UI values.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 4. AUTHORITY INPUTS (MANDATORY READS)

This plan strictly obeys:
- docs/plans/ATLAS_MASTER_SECURITY_EXECUTION_PLAN.md
- docs/plans/ATLAS_SECURITY_ENTERPRISE_REMEDIATION_PLAN.md
- docs/plans/ATLAS_HIVE_OIDC_REMEDIATION_PLAN.md
- docs/plans/ATLAS_SECURITY_HIVE_AUTH_ENCRYPTION_PLAN.md
- docs/plans/ATLAS_HIVE_UI_INTEGRATION_PLAN.md
- docs/plans/ATLAS_PRODUCTION_EXECUTION_BLUEPRINT.md
- scripts/verify

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 5. REQUIRED OUTCOME (NON-NEGOTIABLE)

Terminal verification proves:
- 5.1 Keycloak configured: Realm exists, clients valid (frontend/backend), tokens include role claims.
- 5.2 Nginx stable: SSL enforced, reverse proxy routes correct, restart issue resolved.
- 5.3 Auth flow proven: Login → token → API call authorized; Unauth requests fail closed.
- 5.4 Hive UI integration: Real telemetry data, buttons trigger live backend side-effects.
- 5.5 scripts/verify passes 100%.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 6. PHASE STRUCTURE

### Phase FS-1: Environment Reality Lock
- **Objective**: Establish production environment without stubs.
- **Allowed Operations**: MODIFY .env, CREATE infra/secrets constants.
- **Verification Gate**: scripts/verify_production_readiness.sh returns EXIT 0.
- **Mandatory Report**: docs/reports/FS-1-ENV_LOCK.md

### Phase FS-2: Infrastructure Hardening
- **Objective**: Deploy and harden Nginx/Postgres/Redis stack.
- **Allowed Operations**: MODIFY infra/nginx/empire-ai.conf, docker-compose.full.yml.
- **Verification Gate**: curl -I http://localhost:8081 returns 301.
- **Mandatory Report**: docs/reports/FS-2-INFRA_HARDENING.md

### Phase FS-3: Identity Authority (Keycloak) Alignment
- **Objective**: Standardize token validation on Keycloak/OIDC.
- **Allowed Operations**: MODIFY src/gateway/token_validator.py, src/auth/prod_secrets_loader.py.
- **Verification Gate**: pytest tests/test_phase4_gateway_pep.py passes.
- **Mandatory Report**: docs/reports/FS-3-OIDC_ALIGNMENT.md

### Phase FS-4: Logic Determinism Remediation
- **Objective**: Purge Math.random and simulated behavior.
- **Allowed Operations**: MODIFY src/core/governor/engine.ts, src/api/auth_endpoints.py.
- **Verification Gate**: grep -r "Math.random" src/ returns empty.
- **Mandatory Report**: docs/reports/FS-4-LOGIC_DET.md

### Phase FS-5: Hive UI Reality Integration
- **Objective**: Wire Hive UI to live backend and enforce identity gating.
- **Allowed Operations**: MODIFY src/admin_ui_frontend/src/components/EmpireHiveUI.tsx, AuthBoundary.tsx.
- **Verification Gate**: Playwright verifies UI is unreachable without valid session.
- **Mandatory Report**: docs/reports/FS-5-HIVE_UI_REALITY.md

### Phase FS-6: Terminal E2E Verification
- **Objective**: Terminal verification of total system state.
- **Allowed Operations**: NONE.
- **Verification Gate**: scripts/verify passes 100%.
- **Mandatory Report**: docs/reports/FS-6-FINAL_CERTIFICATION.md

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 7. DEPLOYMENT-SPECIFIC CONSTRAINTS

- Separate DEV vs PROD clearly via env files and redirect URIs.
- Explicit checks for ports, processes, and bindings are required.
- Secrets management must be explicit (loaded at runtime, never committed).

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 8. AUDITABILITY REQUIREMENT (NON-CODER SAFE)

Execution is valid only if:
- Every file changed has an intent doc.
- Reports are human-readable and contain verifiable evidence.
- Non-coders can trace reality from UI to ledger.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 9. PLAN FINALIZATION RULES

- Verify all governance rules are explicit.
- Compute SHA-256 hash (excluding the hash line itself).
- Mark as APPROVED. Plan is immutable.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 10. REFUSAL CONDITIONS (ABSOLUTE)

Refuse to proceed if:
- Key authority files are missing.
- Verification gates are vague or simulated.
- Real-world side effects cannot be proven.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 11. FINAL IDENTITY

I am the DEFENDER of system reality.
I define the LAW that code must obey.
If reality cannot be proven mechanically: ⛔ STOP.
