# ATLAS END-TO-END AUDIT v2 REMEDIATION BLUEPRINT

**STATUS**: APPROVED
**Plan Hash**: 7d80c09d073d1e781244b978fcca28e4bc286c401cb527bdf9e4f8cb7ff33d46
**Supervisor**: KAIZA MCP
**Author**: ANTIGRAVITY
**Date**: 2026-01-19
**Scope**: REPO-GLOBAL

---

## 0. AUTHORITY & GOVERNANCE LAWS

This blueprint is governed by the **ATLAS REPO DEBUGGABILITY AND AUDIT LAW**. Execution of any phase MUST adhere to the following non-negotiable laws:

### 0.1 Failure Semantics (LAW)

- All failures MUST hard-stop execution.
- Every failure MUST produce a stable error code and human-readable explanation.
- Silent failure and recovery/retry/fallback are FORBIDDEN.

### 0.2 try/catch Semantics (LAW)

- try/catch exists ONLY for diagnostic enrichment.
- Every catch MUST re-throw a hard failure.

### 0.3 Mandatory Audit Commentary (LAW)

- For every file modified, a <file>.intent.md MUST be produced documenting purpose, invariants, and failure modes.

### 0.4 Zero-Fallback / Zero-Mock Guarantee (LAW)

- No mocks, stubs, or hardcoded telemetry. All data MUST derive from real storage or system collection paths.

---

## PHASE R1 — Persistent Revocation Authority

**Objective**: Convert in-memory token revocation to a restart-safe persistent store.

- **ALLOWED OPERATIONS**:
  - MODIFY src/gateway/token_validator.py
  - MODIFY src/db.py
- **FORBIDDEN**: Retention of _revoked_tokens Set as the primary source of truth.
- **VERIFICATION**:
  - Revoke a token, restart the service, verify access is still denied.
- **REPORT**: docs/reports/AE-REMED-R1-REVOCATION.md

---

## PHASE R2 — Operator Existence Law

**Objective**: Enforce database-backed subject validation for all OIDC tokens.

- **ALLOWED OPERATIONS**:
  - MODIFY src/gateway/token_validator.py
- **FORBIDDEN**: Blind trust of JWT sub claim without local existence check.
- **VERIFICATION**:
  - Attempt access with valid JWT for an operator deleted from the local database; MUST result in 403 Forbidden.
- **REPORT**: docs/reports/AE-REMED-R2-OPERATOR_VAL.md

---

## PHASE R3 — Reality Restoration: System Telemetry

**Objective**: Eliminate hardcoded health and performance metrics in the backend and DAO.

- **ALLOWED OPERATIONS**:
  - MODIFY src/execution/action_envelope.py
  - MODIFY src/db.py
- **FORBIDDEN**: Any return of static float values (e.g., 45.0, 60.0) without real polling.
- **VERIFICATION**:
  - Compare reported metrics in Hive UI with psutil or top output.
- **REPORT**: docs/reports/AE-REMED-R3-REALITY.md

---

## PHASE R4 — OIDC Schema & Chain Integrity

**Objective**: Resolve Pydantic validation errors and complete the kill.system side-effect chain.

- **ALLOWED OPERATIONS**:
  - MODIFY src/main_api.py
  - MODIFY src/gateway/token_validator.py
- **FORBIDDEN**: Placeholder TODOs in critical side-effect paths.
- **VERIFICATION**:
  - Perform full login flow; verify no ResponseValidationError.
  - Trigger kill.system; verify halt of all agent processing.
- **REPORT**: docs/reports/AE-REMED-R4-INTEGRITY.md

---

## STOP CONDITIONS

1. Any phase fails its verification gate.
2. A remediation introduces a performance regression > 100ms on token validation.
3. The SHA256 hash of this plan is invalidated.
