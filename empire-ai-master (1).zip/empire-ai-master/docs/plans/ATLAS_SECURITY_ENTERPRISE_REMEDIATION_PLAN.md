# ATLAS EMPIRE: SECURITY ENTERPRISE REMEDIATION PLAN

## HASH: 3ac4dc8a606d81e53830aa705feb7d9cec6372f5dfb865e5da500889fc0dcd1b

## STATUS: APPROVED

## SUPERVISOR: KAIZA MCP

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🎯 MISSION OBJECTIVE

Transition the Atlas Empire system to enterprise-grade, attack-resilient production readiness by hardening network/secrets infrastructure, enforcing deterministic identity-aware rate limiting, and implementation of cryptographically bound audit provenance.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE SEC-1 — Infrastructure Hardening

**Phase ID:** AE-SEC-P1
**Objective:** Harden network exposure, secrets handling, and runtime boundaries to eliminate "Security Theater" infrastructure.

**Explicit Allowed File Operations:**

- **MODIFY** [nginx.conf](file:///home/lin/Documents/empire-ai/infra/nginx.conf)
  - Enforce SSL/TLS strictly on port 443/8443.
  - Implement permanent 301 redirect from HTTP (80/8081) to HTTPS.
  - Add security headers: Strict-Transport-Security, Content-Security-Policy, X-Frame-Options.

- **MODIFY** [docker-compose.yml](file:///home/lin/Documents/empire-ai/infra/docker-compose.yml)
  - Replace environment variables for POSTGRES_PASSWORD and REDIS_PASSWORD with file-based secrets (Docker Secrets pattern or mounted read-only volume).
  - Enforce no-new-privileges: true for all containers.

**Explicit Forbidden Actions:**

- Do NOT allow unencrypted (HTTP) traffic to REACH the application services.
- Do NOT use hardcoded credentials in any configuration file.

**Verification Gates:**

- **Command:** curl -k -I <http://localhost:8081>
- **Expected:** HTTP/1.1 301 Moved Permanently pointing to https://.
- **Command:** docker inspect empire-governor | grep NoNewPrivileges
- **Expected:** "NoNewPrivileges": true

**Mandatory Report Artifact:** docs/reports/AE-SEC-P1-EXECUTION.md

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE SEC-2 — Gateway Rate Limiting

**Phase ID:** AE-SEC-P2
**Objective:** Enforce deterministic, identity-aware request throttling that fails closed on infrastructure failure.

**Explicit Allowed File Operations:**

- **MODIFY** [rate_limiter.py](file:///home/lin/Documents/empire-ai/src/gateway/rate_limiter.py)
  - Change RateLimitResult to default to allowed=False on initialization.
  - Modify check_rate_limit to return allowed=False (Fail-Closed) if Redis is unavailable or if any error occurs.
  - Ensure the sub claim from the OIDC token is the SOLE identifier for user-based limiting.

- **MODIFY** [gateway_pep.py](file:///home/lin/Documents/empire-ai/src/gateway/gateway_pep.py)
  - Remove "Fail Open" logging; replace with "Enforcement Denial" logging.

**Explicit Forbidden Actions:**

- Do NOT allow "fail-open" behavior for rate limiting under any circumstances.
- Do NOT use IP-based limiting as a primary identifier for authenticated requests.

**Verification Gates:**

- **Command:** docker stop empire-redis && pytest tests/test_phase4_gateway_pep.py
- **Expected:** 100% of requests must be REJECTED with 403/429 while Redis is down.

**Mandatory Report Artifact:** docs/reports/AE-SEC-P2-EXECUTION.md

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE SEC-3 — JWT-Bound Audit Logging

**Phase ID:** AE-SEC-P3
**Objective:** Record all privileged and mutating actions with cryptographic attribution bound to the authorizing token.

**Explicit Allowed File Operations:**

- **MODIFY** [audit_logger.py](file:///home/lin/Documents/empire-ai/src/observability/audit_logger.py)
  - Extend AuditEvent to include auth_token_hash (SHA256 of the JWT signature).
  - Modify log_event to require auth_token_hash for any action involving operation or resource mutation.

- **MODIFY** [gateway_pep.py](file:///home/lin/Documents/empire-ai/src/gateway/gateway_pep.py)
  - Extract the JWT signature from the validated token.
  - Hash the signature and pass it to the audit_logger during decision enforcement.

**Explicit Forbidden Actions:**

- Do NOT log the JWT content or raw signature.
- Do NOT allow mutating actions to proceed if the audit log entry fails to bind to the auth_token_hash.

**Verification Gates:**

- **Command:** sqlite3 data/audit.db "SELECT auth_token_hash FROM audit_logs WHERE operation='action_execute' LIMIT 1;"
- **Expected:** A non-null, valid SHA256 hex string.

**Mandatory Report Artifact:** docs/reports/AE-SEC-P3-EXECUTION.md

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🚦 STOP CONDITIONS

- **HALT** if any phase fails its verification gate.
- **HALT** if SSL certificate injection into empire-nginx fails.
- **HALT** if auth_token_hash binding results in a performance degradation > 50ms.
- **HALT** if Redis fail-closed logic allows a single unauthorized request.
