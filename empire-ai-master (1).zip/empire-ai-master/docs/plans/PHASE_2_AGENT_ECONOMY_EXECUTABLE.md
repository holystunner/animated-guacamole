## PLAN_HASH

5f54af7029e58a24b5acb11fc2ee556245275432eb2d9bc997436151f381e13d

1. PLAN_METADATA

- ID: PHASE_2_AGENT_ECONOMY
- NAME: Agent Economy & Labor Replacement
- VERSION: 1.0.0
- STATUS: EXECUTABLE_PENDING
- CONTEXT: Empire AI Phase 2
- PARENT: /docs/governance/CANONICAL_ROADMAP.md
- DEPENDS_ON: /docs/plans/PHASE_1_ATLAS_CORE_EXECUTABLE.md
- TARGET_PATH: /docs/plans/PHASE_2_AGENT_ECONOMY_EXECUTABLE.md
- AUTHOR: ANTIGRAVITY (KAIZA MCP)

1. SCOPE_LOCK

- LOCKED_TO: PHASE 2 (AGENT ECONOMY)
- PREVIOUS_PHASE: PHASE 1 (ATLAS CORE)
- EXPLICITLY_EXCLUDED:
  - REVENUE_GENERATION
  - ASSET_DEPLOYMENT
  - CONTENT_PUBLISHING
  - EXTERNAL_PAID_APIS
  - AGENT_SELF_SPAWNING

1. PHASE_OBJECTIVE

- PRIMARY: Replace human labor with permissioned internal agents (Labor Replacement).
- SECONDARY: Establish the Agent Lifecycle (Spawn -> Execute -> Audit -> Halt).
- TERTIARY: Enforce "No Revenue" and "Zero Budget" constraints on new agents.

1. IN-SCOPE AGENT CLASSES

- MARKET_INTELLIGENCE: Read-only discovery of opportunities (Simulated/Mocked if Network Locked).
- ASSET_PLANNING: Generate blueprints for assets (No build/deploy).
- SEO_ANALYSIS: Analyze keywords/competitors (No interaction).
- MONETIZATION_ANALYSIS: Identify revenue paths (No links/implementation).
- OPERATIONS: System health checks and self-diagnosis.
- FINANCE: Budget simulation and cost modeling (Zero spend).
- COMPLIANCE: Policy verification and rule checking.

1. OUT-OF-SCOPE (EXPLICIT)

- DEPLOYMENT: No agent may push to production.
- REVENUE: No agent may generate income.
- SPENDING: No agent may incur costs.
- EXPANSION: No agent may increase its own permissions.
- EXTERNAL_INTERACTION: No posting to social media, no emails, no API calls to paid services.

1. AGENT AUTHORITY & PERMISSIONS MODEL

- MODEL: Role-Based Access Control (RBAC) enforced by Governor.
- PERMISSION_1: `CAN_READ_INTERNAL_STATE` (All Agents).
- PERMISSION_2: `CAN_PROPOSE_PLAN` (AssetPlanning, MarketIntelligence).
- PERMISSION_3: `CAN_AUDIT_LOG` (All Agents - MANDATORY).
- RESTRICTION_1: `CANNOT_SPEND_MONEY`.
- RESTRICTION_2: `CANNOT_MODIFY_GOVERNOR`.
- RESTRICTION_3: `CANNOT_ACCESS_NETWORK_OUTBOUND` (Unless strictly whitelisted free/safe).

1. AGENT LIFECYCLE (SPAWN → EXECUTE → HALT)

- STATE_1: `UNREGISTERED` -> `REGISTERED` (Via Manifest).
- STATE_2: `IDLE` -> `REQUESTING_ACTION` (Intent Declaration).
- STATE_3: `EXECUTING` (Runtime allows).
- STATE_4: `COMPLETED` (Success).
- STATE_5: `HALTED` (Governor Intervention or Failure).
- STATE_6: `KILLED` (Removed from Registry).

1. GOVERNOR ↔ AGENT INTERACTION RULES

- INTERACTION_1: Agent MUST declare intent before action.
- INTERACTION_2: Governor validates intent against Permissions + Global State + Budget.
- INTERACTION_3: Governor RETURNS `APPROVED` or `DENIED` with reason.
- INTERACTION_4: Agent MUST handle `DENIED` gracefully (Log & Retry/Abort).
- INTERACTION_5: Governor monitors Pulse; if Agent silent > Timeout -> HALT.

1. DATA MODELS & STATE OWNERSHIP

- UPDATE: `AgentManifest` adds `role`, `capabilities[]`.
- NEW: `AgentState` { current_task, active_plan_id, health_status }.
- NEW: `TaskManifest` { id, assigned_agent, status, output_hash }.
- OWNER: Registry owns all Agent State. Agents have READ-ONLY access to their own state, WRITE via Actions only.

1. EVENT & DECISION FLOWS

- FLOW_1: `Admin` -> `Spawn Agent(Type)` -> `Governor` checks Max Concurrent -> `Registry` creates.
- FLOW_2: `Agent` -> `Propose Plan` -> `Governor` checks Policy -> `Audit` logs Plan.
- FLOW_3: `Agent` -> `Execute Step` -> `Governor` validates permissions -> `Runtime` runs.
- FLOW_4: `Violation` (e.g., Spend > 0) -> `Governor` triggers `Hard Stop` -> Agent `HALTED`.

1. FAILURE MODES & HARD STOPS

- MODE_1: `BUDGET_VIOLATION` -> Immediate Agent Kill.
- MODE_2: `PERMISSION_ESCALATION` -> Immediate Agent Kill.
- MODE_3: `UNDECLARED_ACTION` -> Runtime Exception & Audit Flag.
- MODE_4: `RESOURCE_HOG` -> CPU/Mem limit exceeded -> Throttle/Halt.

1. AUDIT & OBSERVABILITY REQUIREMENTS

- REQ_1: All Agent Intents logged BEFORE execution.
- REQ_2: All Agent Outcomes logged AFTER execution.
- REQ_3: "Dry Run" flag available for all actions.
- REQ_4: Agent "Thought Process" (if any) loggable.

1. EXECUTION STEPS (ORDERED, ATOMIC)
1. REFINE_AGENT_TYPES
   - ACTION: Update `src/core/registry/types.ts` to support specific Agent Roles (Market, Asset, etc.).
   - VERIFY: Compiler checks new types.

1. IMPLEMENT_BASE_AGENT
   - ACTION: Create `src/core/agents/base_agent.ts`.
   - LOGIC: Abstract class with `lifecycle`, `intent_declaration`, `audit_logging`.
   - VERIFY: Unit test: Mock agent inherits and runs lifecycle.

1. IMPLEMENT_REQUIRED_AGENTS_I
   - ACTION: Create `src/core/agents/market_intelligence.ts`.
   - ACTION: Create `src/core/agents/asset_planning.ts`.
   - VERIFY: Files exist and compile.

1. IMPLEMENT_REQUIRED_AGENTS_II
   - ACTION: Create `src/core/agents/seo_analysis.ts`, `monetization_analysis.ts`.
   - ACTION: Create `src/core/agents/operations.ts`, `finance.ts`, `compliance.ts`.
   - VERIFY: Files exist and compile.

1. UPDATE_GOVERNOR_FOR_AGENTS
   - ACTION: Update `src/core/governor/rules.ts` to enforce Role-Based logic.
   - ACTION: Implement "Max Concurrent Agents" rule.
   - VERIFY: Test: Spawn Limit enforced.

1. IMPLEMENT_AGENT_SPAWNER
   - ACTION: Add CLI command `empire spawn <role>`.
   - LOGIC: Connects CLI -> Registry -> Governor -> Runtime.
   - VERIFY: `empire spawn market_intelligence` creates active agent in Registry.

1. VERIFY_AGENT_CONSTRAINTS
   - ACTION: Create test where `FinanceAgent` tries to log a "Spend" > 0.
   - EXPECT: Governor blocks, Audit logs violation, Agent halts.

1. ACCEPTANCE CRITERIA (PASS / FAIL ONLY)

- [ ] System can spawn each of the 7 required agent types? (PASS/FAIL)
- [ ] Agents strictly adhere to "Read-Only" or "Plan-Only" outputs? (PASS/FAIL)
- [ ] Any attempt to spend money results in immediate block? (PASS/FAIL)
- [ ] Governor enforces maximum concurrent agents constraint? (PASS/FAIL)
- [ ] Audit log reflects correct Agent ID and Role for every action? (PASS/FAIL)

1. POST-PHASE INVARIANTS

- INVARIANT: `src/core/agents/` contains all 7 implementations.
- INVARIANT: No revenue code exists.
- INVARIANT: Budget remains 0.00.
