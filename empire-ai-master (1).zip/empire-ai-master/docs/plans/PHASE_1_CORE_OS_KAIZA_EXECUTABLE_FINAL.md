# KAIZA_EXECUTABLE_PLAN
# PROJECT: ATLAS EMPIRE
# PHASE: 1
# PHASE_NAME: CORE OS (GOVERNOR + RUNTIME + REGISTRY)
# PLAN_VERSION: 1.0.0
# CANONICAL_SOURCE: /docs/governance/CANONICAL_ROADMAP.md
# PLAN_HASH: 0x7f2e1a3b9c4d6e8f

---

## 0. REQUIRED SKILL LOADING (HARD GATE)

**EXECUTION HALT IF ANY SKILL FAILS TO LOAD**

Windsurf must load and confirm successful loading of the following skills BEFORE any file modification:

- @repo-understanding
- @kaiza-mcp-ops
- @no-placeholders-production-code
- @audit-first-commentary
- @debuggable-by-default
- @observability-pack-implementer
- @secure-by-default
- @test-engineering-suite
- @incident-triage-and-rca
- @refactor-with-safety
- @release-readiness

**Explicit confirmation required:**
- All skills must report "LOADED" status
- No files may be written before skill confirmation
- If any skill load fails, entire execution halts; plan is invalid

---

## 1. PLAN AUTHORITY & GOVERNANCE

### Authority Statement

This plan is the **exclusive authority** for Phase 1 execution. All decisions, file operations, and implementation details flow from this document.

### Execution Framework

- Windsurf must use the Kaiza MCP write tool **exclusively** for all file operations
- No manual edits to generated files are permitted during execution
- No deviations from this plan are allowed without explicit section amendment
- All decisions must trace back to a section in this plan

### Invalidation Conditions

The plan becomes invalid if:
- Any required skill fails to load
- Phase 0 artifacts are not present or corrupted
- Windsurf lacks sufficient permissions to execute Kaiza MCP write operations
- Any dependency stated in Section 2 is unmet

---

## 2. DEPENDENCIES

### Phase 0 Completion Assertions

Phase 0 (Reality Lock) must be complete and verified. The following invariants must be enforced:

1. **Monorepo Structure:** Single, unified codebase at `/home/lin/Documents/empire-ai/`
   - All source code in `/src/`
   - All tests in `/tests/`
   - Configuration in `/config/`

2. **No Fake Work:** Reality Lock prevents:
   - Stub functions (functions that do nothing)
   - Mock implementations (fake business logic)
   - Placeholder comments (TODO, FIXME, XXX)
   - Unimplemented features

3. **Deterministic Execution:** All Phase 0 systems operate deterministically:
   - Same inputs → same outputs
   - No randomness in core logic
   - Replay capability from logs
   - No environment-dependent behavior

4. **Append-Only Event Ledger:** Exists at `/src/core/ledger.py` or equivalent
   - All actions logged immutably
   - Hash-linked for tamper-evidence
   - Replayable from first event
   - Searchable by timestamp, actor, action

5. **Authority Layer:** Exists and operational
   - Act: Execute decisions
   - Observe: Query state
   - Approve: Review pending actions
   - Kill: Emergency halt capability

### Required Directories & Files (Must Exist)

```
/src/
  core/
    ledger.py (append-only log engine)
    decision_engine.py (authority decisions)
    [phase 0 systems must be present]
  registry/
    [placeholder, will be expanded in Phase 1]
  governor/
    [placeholder, will be expanded in Phase 1]
  runtime/
    [placeholder, will be expanded in Phase 1]

/tests/
  [test files from Phase 0 must exist]

/config/
  [configuration must exist]

/.kaiza/
  governance.json (tracks execution state)
  approved_plans/ (archive of approved plans)
```

### HALT Conditions

**EXECUTION HALTS IF:**
- `/src/core/ledger.py` is missing or non-functional
- Event ledger cannot prove all actions were logged
- Any Phase 0 system shows evidence of fake work (stubs, mocks, placeholders)
- Monorepo structure is non-standard or fragmented

---

## 3. PHASE OBJECTIVE (DETERMINISTIC)

### What Phase 1 Exists to Build

Phase 1 builds the **minimum autonomous executive** that can later control money.

Specifically, Phase 1 delivers:

1. **Governor** — Policy enforcement engine
   - Rules engine (if-then decisions)
   - Budget enforcement (per-agent, per-asset, per-period)
   - Authority limits (hard caps on spending/actions)
   - Global kill switch (instant system halt)

2. **Runtime** — Deterministic job execution
   - Job queue (ordered, replayable execution)
   - Step runner (atomic units of work)
   - Retry logic (bounded, idempotent)
   - Failure handling (explicit, logged)

3. **Registry** — Single source of truth
   - Asset metadata (owner, status, ROI, cost, revenue)
   - Agent definitions (permissions, budgets, tools)
   - Configuration (all system settings)
   - State snapshots (current health, queue depth, metrics)

4. **Audit Surfaces** — Decision tracing
   - Decision log (why each choice was made)
   - Action log (what happened and when)
   - Attribution (who/what performed each action)
   - Searchable ledger (queryable by agent, asset, action, date)

### Non-Objectives

The following are **explicitly out of scope** for Phase 1:

- Asset factories (Phase 2+)
- Agent logic (detailed agent implementations → Phase 2)
- Revenue generation (Phase 3+)
- Multi-server scaling (Phase 8)
- Admin UI (Phase 7)
- Self-evolution (Phase 10+)
- Payment processing (Phase 3+)
- Monetization models (Phase 3+)

Phase 1 is infrastructure. It does not generate revenue.

---

## 4. SCOPE LOCK

### IN SCOPE (Allowed Creation/Modification)

**Core Systems:**
- `/src/governor/` — Governor engine and policy enforcement
- `/src/runtime/` — Job executor, step runner, retry logic
- `/src/registry/` — Asset, agent, config, state registries
- `/src/core/audit.py` — Audit engine and decision tracing
- `/src/core/decision_engine.py` — Extensible decision framework

**Supporting Systems:**
- `/src/core/event_bus.py` — Event distribution (if needed by Phase 1)
- `/src/core/kill_switch.py` — Emergency halt mechanism
- `/config/phase_1_defaults.json` — Default policies and budgets

**Tests:**
- `/tests/test_governor_*.py` — Governor functionality
- `/tests/test_runtime_*.py` — Runtime execution
- `/tests/test_registry_*.py` — Registry operations
- `/tests/test_audit_*.py` — Audit trail correctness

**Documentation:**
- `/docs/PHASE_1_IMPLEMENTATION.md` — Implementation guide
- `/docs/API.md` — Governor, Runtime, Registry APIs
- `/docs/AUDIT_SCHEMA.md` — Audit event schema

### OUT OF SCOPE (Forbidden Modification)

- `/src/admin_ui_*.py` — Admin UI code (Phase 7)
- `/src/[agent]_*.py` — Agent-specific logic (Phase 2)
- `/src/asset_*.py` — Asset runtime (Phase 4+)
- `/src/monetization/` — Revenue systems (Phase 3+)
- `/src/distribution/` — Distribution logic (Phase 3+)
- Any file in `/src/` not explicitly listed as IN SCOPE

### Files Allowed to Exist But Not Modify

- `/src/core/ledger.py` — May call, but do not modify implementation
- `/src/core/decision_engine.py` — May extend, but do not break existing API
- Any Phase 0 system

### Forbidden Modifications

- No changes to ledger append mechanism
- No changes to Phase 0 API contracts
- No removal of Reality Lock constraints
- No addition of stub/mock code
- No new TODOs or FIXMEs

---

## 5. SYSTEMS TO DESIGN

### System 1: Governor

#### Purpose
Enforce policies, budgets, and authority without human involvement. Act as the decision engine that routes requests through approval gates.

#### Inputs
- Request (action, actor, resource, budget)
- Policies (rules, limits, thresholds)
- Current state (budget used, spend rate, queue depth)
- Authority (owner override, agent permissions)

#### Outputs
- Decision (APPROVE, DENY, HOLD_FOR_APPROVAL)
- Reasoning (why decision was made)
- Side effects (log decision, allocate budget, queue job)

#### Authority Boundaries
- Governor cannot modify its own policies (owner only)
- Governor cannot escalate agent permissions
- Governor cannot spend money outside policy (Phase 3+)
- Governor cannot create assets (Phase 2+)
- Governor enforces hard caps; no exceptions except owner override

#### Invariants
1. Every decision is logged with reasoning
2. Budget cannot be overspent (hard limit)
3. No agent action proceeds without governor approval
4. Kill switch can freeze all jobs instantly
5. Owner can override any decision without explanation

#### Failure Modes
- Policy is malformed → reject request, log error
- Budget exceeded → deny request, escalate to approval queue
- Kill switch engaged → all future requests denied
- Ledger write fails → abort decision, retry on next cycle
- Unknown agent → deny request with "permission not found"

#### Key Concepts

**Budget Model:**
```
Budget = {
  agent_id: string,
  resource: string,         # "api_calls", "compute_hours", "assets_created"
  limit: integer,
  period: "day" | "month" | "year",
  current_used: integer,
  reset_at: timestamp
}
```

**Policy Model:**
```
Policy = {
  id: string,
  name: string,
  condition: string,         # "action == 'create_asset' AND budget_used > 80%"
  decision: "APPROVE" | "DENY" | "HOLD_FOR_APPROVAL",
  reasoning: string,
  enabled: boolean
}
```

---

### System 2: Runtime

#### Purpose
Execute jobs deterministically, with bounded retries and idempotent semantics.

#### Inputs
- Job definition (name, steps, parameters)
- Queue state (pending, running, completed)
- Retry policy (max attempts, backoff)

#### Outputs
- Job result (success / failure / partial)
- Execution log (every step, every retry)
- Metrics (duration, attempts, cost)

#### Authority Boundaries
- Runtime cannot modify job definitions
- Runtime cannot skip steps
- Runtime cannot ignore failures
- Runtime cannot exceed timeout (owner enforces via Governor)

#### Invariants
1. Every step is logged atomically
2. Idempotent operations can be safely retried
3. Non-idempotent operations fail instead of retry
4. Each retry is logged separately
5. Job can be replayed from log and get identical result
6. Timeout is enforced (hard halt after duration_seconds)

#### Failure Modes
- Step fails → log error, check retry count, retry or mark job failed
- Timeout exceeded → halt job, mark failed, log timeout event
- Non-idempotent operation → fail immediately, no retry
- System crash → resume from last logged step on restart
- Unknown job → return error "job_not_found"

#### Key Concepts

**Job Model:**
```
Job = {
  id: string,
  name: string,
  actor: string,              # agent_id or "owner"
  steps: [Step],
  parameters: dict,
  status: "pending" | "running" | "succeeded" | "failed",
  result: any,
  created_at: timestamp,
  started_at: timestamp,
  completed_at: timestamp,
  timeout_seconds: integer
}

Step = {
  id: string,
  name: string,
  action: string,             # "fetch_url", "deploy", "query_db", etc.
  parameters: dict,
  idempotent: boolean,
  max_retries: integer,
  current_attempt: integer,
  status: "pending" | "running" | "succeeded" | "failed",
  result: any,
  error: string,
  logs: [string]
}
```

**Retry Policy:**
```
RetryPolicy = {
  max_attempts: integer,
  backoff_type: "linear" | "exponential",
  backoff_seconds: integer,
  max_backoff_seconds: integer
}
```

---

### System 3: Registry

#### Purpose
Single source of truth for all configuration and state. All queries about "what exists" hit the registry.

#### Inputs
- Configuration updates (owner, agent, policy changes)
- State snapshots (current metrics, job queue, asset status)
- Queries (list assets, get agent, current budget used)

#### Outputs
- Configuration (consistent, versioned)
- State (current, read-only view)
- Query results (filtered, searchable)

#### Authority Boundaries
- Registry cannot modify policies (Governor + owner only)
- Registry cannot accept writes from agents (read-only for agents)
- Registry cannot make decisions (enforcement is Governor's job)
- Registry tracks versions but never deletes

#### Invariants
1. Registry is single source of truth (only one value per key)
2. All configuration changes are versioned
3. State is read-only except for explicit writes
4. Queries return consistent snapshots
5. No two agents see different values for the same key

#### Failure Modes
- Configuration key missing → return error "not_found", not default
- Concurrent write attempt → reject, log conflict, escalate
- State is stale → timestamp indicates staleness
- Query timeout → return partial results with warning
- Database failure → fail gracefully, keep in-memory cache active

#### Key Concepts

**Configuration Registry:**
```
ConfigRegistry = {
  agents: {
    [agent_id]: AgentDefinition
  },
  policies: {
    [policy_id]: Policy
  },
  assets: {
    [asset_id]: AssetMetadata
  },
  system_config: {
    kill_switch_engaged: boolean,
    max_concurrent_jobs: integer,
    ledger_path: string
  }
}

AgentDefinition = {
  id: string,
  name: string,
  enabled: boolean,
  permissions: [string],     # "create_asset", "fetch_url", "deploy"
  budget: Budget,
  description: string
}

AssetMetadata = {
  id: string,
  name: string,
  owner: string,             # agent_id or "owner"
  status: "draft" | "active" | "scaling" | "paused" | "retired",
  created_at: timestamp,
  created_by: string,
  metrics: {
    roi: float,
    cost: float,
    revenue: float
  }
}
```

**State Registry:**
```
StateRegistry = {
  job_queue: [Job],
  current_metrics: {
    budget_used_today: dict,  # {agent_id: amount}
    jobs_completed_today: integer,
    jobs_failed_today: integer,
    active_jobs: integer
  },
  asset_health: {
    [asset_id]: {
      status: string,
      last_checked: timestamp,
      error_rate: float
    }
  }
}
```

---

### System 4: Audit Engine

#### Purpose
Capture every decision and action. Enable root-cause analysis, compliance, and auditability.

#### Inputs
- Events from Governor (decision made, policy applied)
- Events from Runtime (job started, step completed, error occurred)
- Events from Registry (configuration changed)
- Events from all other systems

#### Outputs
- Audit trail (immutable, searchable log)
- Decision trace (why X happened)
- Action trace (who did Y, when, with what result)

#### Authority Boundaries
- Audit cannot be modified after write (immutable)
- Audit cannot hide failures or errors
- Audit can only be queried/deleted by owner
- Audit records cannot be suppressed

#### Invariants
1. Every decision is logged with full context
2. Every action is attributed (who did it)
3. Every failure is recorded
4. Audit trail is tamper-evident (hashed)
5. Owner can query audit trail without modifying production

#### Failure Modes
- Ledger write fails → retry indefinitely, block subsequent operations
- Query timeout → return partial results with "incomplete" warning
- Corrupted ledger → detection and alert (never silent)
- Audit overflow → archive old logs (configurable retention)

#### Key Concepts

**Audit Event Schema:**
```
AuditEvent = {
  id: string,                 # unique, sequential
  timestamp: timestamp,
  actor: string,              # agent_id, "owner", or system component
  action: string,             # "governor_decision", "job_started", "asset_created"
  resource: string,           # "asset_id:X", "agent_id:Y", "job_id:Z"
  details: dict,              # full context (inputs, outputs, reasoning)
  result: "success" | "failure" | "partial",
  error: string,              # if result != "success"
  hash: string                # SHA256(previous_hash + content)
}
```

---

## 6. DATA & STATE MODEL

### Canonical Schemas (Conceptual)

All Phase 1 data conforms to these canonical schemas. No schema variations are allowed.

#### Budget
```yaml
Budget:
  agent_id: string
  resource_type: enum[api_calls, compute_hours, assets_created, deployments]
  limit: integer
  period: enum[day, month, year]
  current_used: integer
  reset_timestamp: timestamp
  escalation_threshold: float (0.0-1.0)  # Trigger approval queue at X% used
```

#### Policy
```yaml
Policy:
  policy_id: string
  name: string
  rule: string                # Human-readable condition
  decision: enum[APPROVE, DENY, HOLD_FOR_APPROVAL]
  priority: integer           # Higher number = evaluated first
  enabled: boolean
  created_at: timestamp
  modified_at: timestamp
  version: integer
```

#### Job
```yaml
Job:
  job_id: string
  job_name: string
  actor: string               # Agent ID or "owner"
  status: enum[pending, running, succeeded, failed, halted]
  steps: [Step]
  parameters: dict
  timeout_seconds: integer
  created_at: timestamp
  started_at: timestamp
  completed_at: timestamp
  result: any
  error_message: string
```

#### Asset Metadata
```yaml
Asset:
  asset_id: string
  asset_name: string
  owner: string               # Agent ID or "owner"
  status: enum[draft, active, scaling, paused, retired]
  type: string                # Phase 3+; reserved for future
  created_at: timestamp
  created_by: string
  metrics:
    roi: float
    cost_accumulated: float
    revenue_accumulated: float
    health_status: enum[healthy, degraded, broken]
```

### Persistent vs. Ephemeral State

**PERSISTENT (Survives reboot):**
- Event ledger (immutable log)
- Registry configuration (agents, policies, assets)
- Job definitions (work to be done)
- Completed job records
- Audit trail

**EPHEMERAL (Lost on reboot):**
- Job queue state (pending/running jobs)
- In-flight metrics (current second's data)
- Cache (can be rebuilt from persistent state)

**RECOVERY GUARANTEE:**
- Any job in queue at reboot must be identifiable
- System can resume from last logged step
- No data loss in persistent layer

### Ownership & Mutation Rules

| Entity | Owner | Can Mutate | Via |
|--------|-------|-----------|-----|
| Policy | Owner | Owner only | Owner API / UI |
| Budget | Owner | Owner only | Governor, Owner override |
| Agent Definition | Owner | Owner + Agent (enable/disable only) | Owner API / UI |
| Asset | Agent\|Owner | Creator + Governor | Job execution |
| Job | Actor | Governor (status only) | Runtime executor |
| Audit Event | System | None (immutable) | Ledger write only |

### Versioning Expectations

1. **Configuration Versioning:** Every policy, budget, agent definition has a version number
   - Increment on every change
   - Retain history (owner can view prior versions)
   - Allow rollback to prior version (at owner's request)

2. **Job Versioning:** Job definitions can be templated; runs are distinct
   - Job template = reusable definition (version X)
   - Job run = one execution (linked to template version X)
   - Can rerun old job with new template version

3. **State Versioning:** Current state is always latest, but snapshots are timestamped
   - State snapshot = point-in-time view
   - Can query state at prior time (from audit log)
   - Cannot restore state (data is immutable)

---

## 7. EXECUTION CHECKLIST (ORDERED)

### Pre-Execution Verification

- [ ] All skills loaded successfully (Section 0)
- [ ] Phase 0 artifacts verified present and functional
- [ ] Monorepo structure confirmed (single `/src/`)
- [ ] Ledger system operational (`/src/core/ledger.py`)
- [ ] No Reality Lock violations detected
- [ ] Plan hash recorded in `/.kaiza/approved_plans/`

### Phase 1a: Governor System Implementation

**Step 1.1: Define Governor API**
- [ ] Create `/src/governor/__init__.py`
- [ ] Define `Governor` class with methods:
  - `approve_request(actor, action, resource, budget) -> Decision`
  - `check_budget(agent_id, resource_type) -> BudgetStatus`
  - `get_policies() -> [Policy]`
  - `set_policy(policy: Policy) -> Result`
  - `get_policy(policy_id) -> Policy`
  - `trigger_kill_switch() -> Result`
  - `check_kill_switch() -> boolean`
- [ ] Add full docstrings
- [ ] Add type hints
- [ ] Implement no stubs

**Step 1.2: Implement Governor Decision Logic**
- [ ] Load policies from registry
- [ ] Evaluate condition for each policy (in priority order)
- [ ] Return first matching decision
- [ ] If no policy matches, default decision = APPROVE (logging enabled)
- [ ] Log decision with full context (inputs, policy matched, reasoning)
- [ ] Enforce budget limits (hard cap)
- [ ] Check kill switch status

**Step 1.3: Implement Budget Enforcement**
- [ ] Track budget used per agent per period
- [ ] Reset budget at period boundary (automatic)
- [ ] Escalate to approval queue if usage > threshold
- [ ] Allow owner override (no limit)
- [ ] Log all budget checks and updates

**Step 1.4: Implement Kill Switch**
- [ ] Create kill switch registry entry (initially false)
- [ ] Check kill switch before approving any request
- [ ] All requests fail if kill switch engaged (return DENY with reason)
- [ ] Log kill switch toggle events
- [ ] Allow owner to toggle kill switch

**Step 1.5: Write Governor Tests**
- [ ] Test approve/deny logic (all policy types)
- [ ] Test budget enforcement (under limit, at limit, over limit)
- [ ] Test escalation to approval queue
- [ ] Test kill switch (engage, disengage, all requests fail)
- [ ] Test owner override (bypasses all policies)
- [ ] Test logging (every decision logged)
- [ ] Test concurrent requests (no race conditions)
- [ ] Achieve >90% statement coverage

### Phase 1b: Runtime System Implementation

**Step 2.1: Define Runtime API**
- [ ] Create `/src/runtime/__init__.py`
- [ ] Define `JobExecutor` class with methods:
  - `submit_job(job: Job) -> JobID`
  - `execute_job(job_id: JobID) -> Result`
  - `get_job_status(job_id: JobID) -> JobStatus`
  - `list_jobs(filter: dict) -> [Job]`
  - `retry_job(job_id: JobID) -> Result`
  - `halt_job(job_id: JobID) -> Result`
- [ ] Add full docstrings
- [ ] Add type hints
- [ ] Implement no stubs

**Step 2.2: Implement Job Queue**
- [ ] Create queue data structure (persisted in registry)
- [ ] Implement FIFO ordering
- [ ] Implement priority (owner can promote/demote)
- [ ] Track job state (pending, running, succeeded, failed)
- [ ] Implement job locking (only one executor per job)

**Step 2.3: Implement Step Runner**
- [ ] Define step execution interface
- [ ] Implement atomic step execution (all or nothing)
- [ ] Log step inputs, outputs, duration
- [ ] Detect step failure (exception → failure)
- [ ] Enforce timeout per step (or per job)
- [ ] Return step result

**Step 2.4: Implement Retry Logic**
- [ ] Check step idempotent flag
- [ ] If idempotent and failed, retry (up to max_retries)
- [ ] If not idempotent, fail immediately (no retry)
- [ ] Implement exponential backoff
- [ ] Log each retry attempt separately
- [ ] Fail job after max retries exceeded

**Step 2.5: Implement Job Replay**
- [ ] Load job from ledger
- [ ] Identify last completed step
- [ ] Resume from next step (not restart)
- [ ] Log resume event
- [ ] Verify no duplicate side effects

**Step 2.6: Write Runtime Tests**
- [ ] Test job submission (queue state)
- [ ] Test job execution (all steps succeed)
- [ ] Test partial success (some steps fail)
- [ ] Test retry logic (idempotent vs non-idempotent)
- [ ] Test timeout (job halted after duration)
- [ ] Test job replay (same result)
- [ ] Test concurrent jobs (no interference)
- [ ] Achieve >90% statement coverage

### Phase 1c: Registry System Implementation

**Step 3.1: Define Registry API**
- [ ] Create `/src/registry/__init__.py`
- [ ] Define `Registry` class with methods:
  - `set_agent(agent: AgentDefinition) -> Result`
  - `get_agent(agent_id: string) -> AgentDefinition`
  - `list_agents() -> [AgentDefinition]`
  - `set_policy(policy: Policy) -> Result`
  - `get_policy(policy_id: string) -> Policy`
  - `list_policies() -> [Policy]`
  - `set_asset(asset: AssetMetadata) -> Result`
  - `get_asset(asset_id: string) -> AssetMetadata`
  - `list_assets(filter: dict) -> [AssetMetadata]`
  - `set_config(key: string, value: any) -> Result`
  - `get_config(key: string) -> any`
  - `get_state() -> StateRegistry`
  - `set_state(state: StateRegistry) -> Result`
- [ ] Add full docstrings
- [ ] Add type hints
- [ ] Implement no stubs

**Step 3.2: Implement Configuration Persistence**
- [ ] Store agents, policies, assets in registry
- [ ] Version all changes (increment version on write)
- [ ] Implement read-only view for agents (except owner)
- [ ] Prevent agent self-modification (write protection)
- [ ] Track modification history (who, when, what changed)

**Step 3.3: Implement State Storage**
- [ ] Store current job queue
- [ ] Store current budget usage
- [ ] Store asset health status
- [ ] Timestamp all state updates
- [ ] Implement periodic state snapshots (for quick restore)

**Step 3.4: Implement Registry Queries**
- [ ] List agents by status (enabled/disabled)
- [ ] List policies by priority
- [ ] List assets by status or owner
- [ ] Filter by creation date, owner, health status
- [ ] Support regex search (optional)
- [ ] Return query results with freshness timestamp

**Step 3.5: Write Registry Tests**
- [ ] Test agent CRUD operations
- [ ] Test policy CRUD operations
- [ ] Test asset CRUD operations
- [ ] Test configuration storage
- [ ] Test concurrent reads (no blocking)
- [ ] Test concurrent writes (conflict detection)
- [ ] Test rollback to prior version
- [ ] Achieve >85% statement coverage

### Phase 1d: Audit Engine Implementation

**Step 4.1: Define Audit API**
- [ ] Create `/src/core/audit.py`
- [ ] Define `AuditEngine` class with methods:
  - `log_event(event: AuditEvent) -> EventID`
  - `query_events(filter: dict) -> [AuditEvent]`
  - `get_event(event_id: string) -> AuditEvent`
  - `search_events(actor: string, action: string, date_range: tuple) -> [AuditEvent]`
  - `export_audit_trail(start_date, end_date) -> bytes`
  - `verify_integrity() -> boolean`
- [ ] Add full docstrings
- [ ] Add type hints
- [ ] Implement no stubs

**Step 4.2: Integrate with Ledger**
- [ ] Use existing ledger from Phase 0
- [ ] Append audit events to ledger immutably
- [ ] Hash-link events (each event references previous hash)
- [ ] Verify chain integrity on startup
- [ ] Fail loudly if ledger is corrupted (no silent errors)

**Step 4.3: Implement Event Logging**
- [ ] Log every Governor decision (policy matched, decision, reasoning)
- [ ] Log every Runtime event (job start, step start/end, error, retry)
- [ ] Log every Registry mutation (what changed, by whom, timestamp)
- [ ] Log every configuration change (old value, new value, reason)
- [ ] Log kill switch toggles
- [ ] Ensure no decision happens without audit event

**Step 4.4: Implement Audit Queries**
- [ ] Query by actor (which agent did what)
- [ ] Query by action (all "deploy" events)
- [ ] Query by date range (events in window)
- [ ] Query by resource (all events for asset X)
- [ ] Combine filters (AND logic)
- [ ] Return results with timestamps (sorted chronologically)

**Step 4.5: Implement Audit Export**
- [ ] Export full audit trail as JSON
- [ ] Include all events in date range
- [ ] Export with hashes (for external verification)
- [ ] Support streaming (large exports)
- [ ] Include index/manifest

**Step 4.6: Write Audit Tests**
- [ ] Test event logging (all event types)
- [ ] Test hash-linking (chain integrity)
- [ ] Test audit queries (all filter combinations)
- [ ] Test tamper detection (corrupted ledger detected)
- [ ] Test export (complete, no missing events)
- [ ] Achieve >85% statement coverage

### Phase 1e: Integration & System Tests

**Step 5.1: Integration Tests**
- [ ] Governor + Registry: Policy enforcement uses registry
- [ ] Governor + Runtime: Request approval before job starts
- [ ] Runtime + Registry: Job execution uses registry for config
- [ ] Audit + All systems: All decisions logged
- [ ] All systems respond to kill switch

**Step 5.2: System Tests**
- [ ] Full workflow: Request → Governor → Registry → Runtime → Audit
- [ ] Concurrent requests: Multiple jobs, multiple agents
- [ ] Failure recovery: Crash and restart, resume from checkpoint
- [ ] High load: 100s of jobs in queue, system stable
- [ ] Long-running: Run for 10 minutes, no memory leak

**Step 5.3: Configuration Tests**
- [ ] Load default policies from config
- [ ] Load agent definitions from config
- [ ] Load budgets from config
- [ ] Override config at runtime (owner only)
- [ ] Persist config changes

### Phase 1f: Documentation & API Reference

**Step 6.1: Governor Documentation**
- [ ] Write `/docs/GOVERNOR.md`
- [ ] Document decision logic (how policies are evaluated)
- [ ] Document budget enforcement (how limits are checked)
- [ ] Document kill switch (how to trigger)
- [ ] Document API (all methods, parameters, return values)
- [ ] Include decision flow diagram

**Step 6.2: Runtime Documentation**
- [ ] Write `/docs/RUNTIME.md`
- [ ] Document job lifecycle (pending → running → succeeded/failed)
- [ ] Document step execution (inputs, outputs, failure handling)
- [ ] Document retry logic (when to retry, backoff strategy)
- [ ] Document timeout handling (how jobs are halted)
- [ ] Document job replay (how to resume from checkpoint)
- [ ] Include execution flow diagram

**Step 6.3: Registry Documentation**
- [ ] Write `/docs/REGISTRY.md`
- [ ] Document data model (agents, policies, assets, config)
- [ ] Document schema (all fields, types, constraints)
- [ ] Document CRUD operations (create, read, update, delete)
- [ ] Document queries (filtering, searching)
- [ ] Document versioning (how changes are tracked)
- [ ] Include schema diagram

**Step 6.4: Audit Documentation**
- [ ] Write `/docs/AUDIT.md`
- [ ] Document audit schema (all event types, fields)
- [ ] Document event logging (when events are created)
- [ ] Document queries (filtering, searching)
- [ ] Document export (how to extract audit trail)
- [ ] Document integrity verification (how to detect tampering)
- [ ] Include audit event diagram

**Step 6.5: Configuration Documentation**
- [ ] Write `/config/DEFAULTS.md`
- [ ] Document all configurable parameters
- [ ] Document default values
- [ ] Document constraints (min/max, valid values)
- [ ] Document how to override at runtime
- [ ] Include example configurations

### Phase 1g: Pre-Completion Validation

**Step 7.1: Reality Lock Compliance**
- [ ] No stub functions (all have real implementations)
- [ ] No mock code (all systems use real components)
- [ ] No TODO/FIXME comments (search for forbidden markers)
- [ ] No placeholder logic (if-then branches are complete)
- [ ] All error paths implemented (no "should not reach here")

**Step 7.2: Testing Compliance**
- [ ] Governor: >90% statement coverage
- [ ] Runtime: >90% statement coverage
- [ ] Registry: >85% statement coverage
- [ ] Audit: >85% statement coverage
- [ ] Integration: All workflows tested
- [ ] System: Load, failover, recovery tested

**Step 7.3: Documentation Compliance**
- [ ] All public methods documented
- [ ] All APIs have examples
- [ ] All data schemas documented
- [ ] All workflows documented with diagrams
- [ ] All error conditions documented

**Step 7.4: Governance Compliance**
- [ ] No violations of canonical specification
- [ ] All layer 1 requirements met (from canonical spec)
- [ ] All KAIZA audit sections complete
- [ ] All deviations documented and justified

### Phase 1h: Final Artifacts

**Step 8.1: Build Verification**
- [ ] `npm test` passes (all tests)
- [ ] `pytest tests/` passes (all tests)
- [ ] Linter passes (no violations)
- [ ] Type checker passes (if applicable)
- [ ] Forbidden markers scan passes (no TODOs)

**Step 8.2: Audit Trail Integrity**
- [ ] Ledger is append-only (no modifications)
- [ ] All Phase 1 events are logged
- [ ] Event hashes verify (chain is intact)
- [ ] Queries return consistent results
- [ ] Export is complete and verifiable

**Step 8.3: Phase 1 Completion Report**
- [ ] Create `/PHASE_1_COMPLETION_REPORT.md`
- [ ] Document all systems delivered
- [ ] Document all tests passing
- [ ] Document all documentation complete
- [ ] Record plan hash and execution details
- [ ] Sign with KAIZA-AUDIT block

**Step 8.4: Artifacts Archive**
- [ ] Save plan to `/.kaiza/approved_plans/PHASE_1_CORE_OS_FINAL.md`
- [ ] Save completion report to `/.kaiza/phase_1_completion.json`
- [ ] Update `/.kaiza/governance.json` (Phase 1 complete)

---

## 8. VALIDATION & STOP CONDITIONS

### Phase 1 Completion Criteria

**Phase 1 is complete when ALL of the following are true:**

1. **Governor System Operational**
   - [ ] Governor class exists with all required methods
   - [ ] Policies are loaded from registry
   - [ ] Decision logic evaluates policies (in priority order)
   - [ ] Budget limits are enforced (hard cap)
   - [ ] Kill switch instantly halts all requests
   - [ ] Every decision is logged with reasoning
   - [ ] Tests pass (>90% coverage)

2. **Runtime System Operational**
   - [ ] JobExecutor class exists with all required methods
   - [ ] Jobs are queued (FIFO, with priority)
   - [ ] Steps are executed atomically
   - [ ] Failures are detected and logged
   - [ ] Idempotent steps are retried (non-idempotent fail immediately)
   - [ ] Jobs can be replayed from checkpoint
   - [ ] Timeout is enforced
   - [ ] Tests pass (>90% coverage)

3. **Registry System Operational**
   - [ ] Registry class exists with all required methods
   - [ ] Agents, policies, assets are stored and retrieved
   - [ ] Configuration is persisted (survives reboot)
   - [ ] State is versioned (all changes tracked)
   - [ ] Queries are consistent (same value returned to all readers)
   - [ ] Concurrent reads work (no blocking)
   - [ ] Concurrent writes detect conflicts
   - [ ] Tests pass (>85% coverage)

4. **Audit Engine Operational**
   - [ ] AuditEngine class exists with all required methods
   - [ ] Events are logged to ledger (immutably)
   - [ ] Events are hash-linked (tamper-evident)
   - [ ] Queries work (by actor, action, date, resource)
   - [ ] Audit trail is exportable
   - [ ] Integrity verification works (detects corruption)
   - [ ] Tests pass (>85% coverage)

5. **Full System Integration**
   - [ ] Governor → Registry: Policies loaded and evaluated
   - [ ] Runtime → Registry: Job config retrieved
   - [ ] All systems → Audit: Every action logged
   - [ ] All systems → Kill switch: Instantly stop on freeze
   - [ ] Integration tests pass

6. **Documentation Complete**
   - [ ] Governor API documented
   - [ ] Runtime API documented
   - [ ] Registry API documented
   - [ ] Audit API documented
   - [ ] All public methods have docstrings
   - [ ] All workflows documented with examples
   - [ ] Configuration defaults documented

7. **Reality Lock Compliance**
   - [ ] No stub functions exist
   - [ ] No mock code exists
   - [ ] Forbidden markers scan passes (no TODO/FIXME)
   - [ ] All error paths implemented
   - [ ] Build succeeds (npm test, pytest, lint, type check)

8. **Governance Compliance**
   - [ ] All systems match canonical specification (Section 2, Layer 1)
   - [ ] No deviations from scope lock (Section 4)
   - [ ] All required APIs exist (Section 5)
   - [ ] All data schemas implemented (Section 6)
   - [ ] Execution checklist all items checked (Section 7)
   - [ ] All validation criteria met (Section 8)
   - [ ] KAIZA-AUDIT block complete (Section 9)
   - [ ] Handoff requirements met (Section 10)

### Explicit Failure Conditions

**Phase 1 FAILS immediately if:**

- Any skill fails to load (Section 0)
- Phase 0 artifacts are missing or corrupted
- Ledger cannot be appended to (write failure)
- Build fails (npm test, pytest, lint, type check)
- Any test fails (0% tolerance)
- Forbidden markers detected (TODOs in production code)
- Kill switch cannot halt all jobs instantly
- Audit trail shows missing events (gaps in log)
- Governor decisions are not logged
- Registry is not single source of truth
- Concurrent writes cause data inconsistency
- Any stub or mock code detected

**If any failure condition is true, execution stops immediately and plan is considered INVALID.**

---

## 9. OBSERVABILITY & AUDIT REQUIREMENTS

### Required Logs

All systems must emit structured logs conforming to the logging schema at `/observability/logging_schema.md`.

**Governor Logs:**
```json
{
  "timestamp": "2026-01-15T12:34:56.789Z",
  "level": "info",
  "message": "decision_made",
  "service": "governor",
  "op": "governor.approve_request",
  "actor": "agent:scout",
  "action": "create_asset",
  "decision": "APPROVE",
  "policy_matched": "policy:007",
  "reasoning": "Under budget, routine action",
  "request_id": "req_abc123"
}
```

**Runtime Logs:**
```json
{
  "timestamp": "2026-01-15T12:34:56.789Z",
  "level": "info",
  "message": "job_started",
  "service": "runtime",
  "op": "runtime.execute_job",
  "job_id": "job_xyz789",
  "actor": "agent:builder",
  "step_count": 5,
  "timeout_seconds": 300,
  "request_id": "req_abc123"
}
```

**Registry Logs:**
```json
{
  "timestamp": "2026-01-15T12:34:56.789Z",
  "level": "info",
  "message": "config_updated",
  "service": "registry",
  "op": "registry.set_agent",
  "agent_id": "agent:scout",
  "changes": {"enabled": true},
  "previous_version": 1,
  "new_version": 2,
  "request_id": "req_abc123"
}
```

**Audit Logs:**
```json
{
  "timestamp": "2026-01-15T12:34:56.789Z",
  "level": "info",
  "message": "audit_event_logged",
  "service": "audit",
  "op": "audit.log_event",
  "event_id": "evt_12345",
  "event_type": "governor_decision",
  "actor": "agent:scout",
  "action": "create_asset",
  "hash": "0x7f2e1a3b...",
  "request_id": "req_abc123"
}
```

### Required Events

Every system action must emit an event to the audit ledger:

1. **Governor Events**
   - `governor.request_received` (inputs, actor, action)
   - `governor.policy_evaluated` (policy matched, decision)
   - `governor.budget_checked` (resource, used, limit, result)
   - `governor.decision_made` (final decision, reasoning)
   - `governor.kill_switch_engaged` (by whom, timestamp)
   - `governor.kill_switch_disengaged` (by whom, timestamp)

2. **Runtime Events**
   - `runtime.job_submitted` (job_id, actor, steps, timeout)
   - `runtime.job_started` (job_id, first step)
   - `runtime.step_started` (job_id, step_id)
   - `runtime.step_completed` (job_id, step_id, duration, result)
   - `runtime.step_failed` (job_id, step_id, error)
   - `runtime.retry_attempted` (job_id, step_id, attempt_num)
   - `runtime.job_completed` (job_id, status, duration, result)
   - `runtime.job_halted` (job_id, reason, timestamp)

3. **Registry Events**
   - `registry.agent_created` (agent_id, permissions, budget)
   - `registry.agent_updated` (agent_id, changes, previous_version)
   - `registry.agent_deleted` (agent_id, timestamp)
   - `registry.policy_created` (policy_id, rule, decision)
   - `registry.policy_updated` (policy_id, changes, previous_version)
   - `registry.asset_created` (asset_id, owner, type)
   - `registry.asset_updated` (asset_id, changes, previous_version)
   - `registry.config_changed` (key, old_value, new_value)

4. **Audit Events**
   - `audit.integrity_verified` (event_count, first_hash, last_hash)
   - `audit.corruption_detected` (hash_mismatch_at_event, details)
   - `audit.export_requested` (date_range, event_count)

### Required Admin UI Surfaces (Read-Only)

Phase 7 will implement the interactive UI. Phase 1 must emit audit events that Phase 7 will display.

For now, Phase 1 must ensure:
- All audit events are queryable
- Governor decisions are searchable (by actor, action, decision, date)
- Runtime jobs are searchable (by job_id, actor, status, date)
- Budget usage is queryable (by agent, period, current_used)
- Kill switch status is queryable

**APIs for Phase 7:**
- `GET /api/audit/decisions?actor=&action=&decision=&start_date=&end_date=` → [Decision]
- `GET /api/audit/jobs?actor=&status=&start_date=&end_date=` → [Job]
- `GET /api/governance/budgets?agent_id=` → BudgetStatus
- `GET /api/governance/kill_switch` → {engaged: boolean, last_toggle: timestamp}
- `GET /api/registry/policies` → [Policy]
- `GET /api/registry/agents` → [AgentDefinition]

---

## 10. HANDOFF TO PHASE 2

### What Phase 2 is Allowed to Assume

Phase 2 (Agent Economy) begins with these guarantees from Phase 1:

1. **Governor is Authority**
   - Every agent action is approved by Governor first
   - No agent can bypass approval
   - Kill switch halts all agents instantly
   - Budget limits are enforced per-agent

2. **Registry is Single Source of Truth**
   - Agent definitions exist and are current
   - Budget allocations are enforced
   - Asset metadata is maintained
   - Configuration changes are versioned

3. **Runtime is Deterministic**
   - Jobs are queued and executed in order
   - Steps are logged and replayable
   - Failures are explicit (not silent)
   - Retries are bounded (no infinite loops)

4. **Audit Trail is Complete**
   - Every decision is logged
   - Every action is attributed
   - Ledger is tamper-evident
   - Queries work (by actor, action, date, resource)

5. **Kill Switch Works**
   - Owner can halt all jobs
   - System enters safe state immediately
   - No corruption on halt
   - No jobs resume without owner approval

### What Artifacts Phase 2 Depends On

Phase 2 requires these Phase 1 artifacts to exist and be functional:

1. **Governor API** (`/src/governor/__init__.py`)
   - `approve_request(actor, action, resource, budget) -> Decision`
   - `check_budget(agent_id) -> BudgetStatus`
   - All other methods from Section 5

2. **Runtime API** (`/src/runtime/__init__.py`)
   - `submit_job(job: Job) -> JobID`
   - `execute_job(job_id: JobID) -> Result`
   - All other methods from Section 5

3. **Registry API** (`/src/registry/__init__.py`)
   - `set_agent(agent: AgentDefinition) -> Result`
   - `get_agent(agent_id) -> AgentDefinition`
   - All CRUD methods for agents, policies, assets, config

4. **Audit API** (`/src/core/audit.py`)
   - `log_event(event: AuditEvent) -> EventID`
   - `query_events(filter: dict) -> [AuditEvent]`
   - `search_events(...) -> [AuditEvent]`

5. **Configuration Templates**
   - `/config/phase_1_defaults.json` (defaults for policies, budgets, agents)
   - Agent definition schema (template for Phase 2 to use)
   - Policy schema (template for Phase 2 to use)

6. **Documentation**
   - `/docs/GOVERNOR.md` (API reference)
   - `/docs/RUNTIME.md` (API reference)
   - `/docs/REGISTRY.md` (API reference)
   - `/docs/AUDIT.md` (API reference)

### What Guarantees are Provided

Phase 2 is guaranteed:

1. **Autonomy Infrastructure**
   - All agents will be approved by Governor before acting
   - All actions will be logged
   - Budget limits will be enforced
   - Kill switch is always available

2. **Reliability**
   - Jobs will not be lost (queued in registry)
   - Jobs can be replayed if needed
   - Failures are explicit (not silent)
   - System survives reboot

3. **Observability**
   - Every decision is visible in audit trail
   - Every action is attributed to an agent
   - Budget usage is trackable
   - Performance metrics are available (duration, retries)

4. **Authority**
   - Owner can always intervene
   - Owner can freeze all agents
   - Owner can kill any job
   - Owner can adjust budgets/policies

5. **No Hidden Debt**
   - Reality Lock ensures all Phase 1 systems are real (not mocks)
   - All error paths are implemented
   - All tests pass (>85% coverage)
   - All documentation is complete

---

## 11. KAIZA-AUDIT BLOCK

```
KAIZA-AUDIT
Plan: PHASE_1_CORE_OS_KAIZA_EXECUTABLE_FINAL
Scope: 
  - `/src/governor/` (new system)
  - `/src/runtime/` (new system)
  - `/src/registry/` (expanded from Phase 0)
  - `/src/core/audit.py` (new audit engine)
  - `/src/core/kill_switch.py` (new kill switch)
  - `/config/phase_1_defaults.json` (new config)
  - `/tests/test_governor_*.py` (new tests)
  - `/tests/test_runtime_*.py` (new tests)
  - `/tests/test_registry_*.py` (new tests)
  - `/tests/test_audit_*.py` (new tests)
  - `/tests/test_integration_*.py` (new tests)
  - `/docs/GOVERNOR.md` (new docs)
  - `/docs/RUNTIME.md` (new docs)
  - `/docs/REGISTRY.md` (new docs)
  - `/docs/AUDIT.md` (new docs)

Intent:
  Implement the minimum autonomous executive (Governor, Runtime, Registry, Audit) that can later control money. 
  Phase 1 provides policy enforcement, deterministic job execution, single source of truth, and complete auditability.
  NO revenue generation (Phase 3). NO agent logic (Phase 2). NO UI (Phase 7).

Key Decisions:
  1. Governor uses policy priority ordering (deterministic decision logic)
  2. Budget limits are hard caps (no exceptions except owner override)
  3. Kill switch is global (halts all jobs, not per-agent)
  4. Registry is single source of truth (agents/policies/assets retrieved from registry, never cached)
  5. Audit events are immutable (appended to ledger, never modified)
  6. Job retry is bounded (max_retries enforced, no infinite loops)
  7. Runtime resumes from checkpoint (idempotent step execution)
  8. All errors are explicit (no silent failures, all logged)
  9. All systems integrate with audit (every decision logged)
  10. Reality Lock enforced (no stubs, mocks, placeholders)

Verification:
  - npm test: ALL PASS (>90% coverage for Governor, Runtime; >85% for Registry, Audit)
  - pytest tests/: ALL PASS (same coverage targets)
  - Linter: 0 violations
  - Type checker: 0 errors
  - Forbidden markers scan: 0 markers (no TODO/FIXME)
  - Build: succeeds (no errors, no warnings)
  - Ledger integrity: verified (no corruption, all events logged)
  - Concurrent tests: PASS (no race conditions, no data loss)

Results: READY_FOR_EXECUTION
  - All systems specified in Section 5
  - All checklist items actionable
  - All validation criteria testable
  - All dependencies declared
  - No ambiguities remaining

Risk Notes:
  1. Ledger write failures will block Governor decisions (mitigation: retry logic, alerting)
  2. Concurrent policy updates could race (mitigation: version check, conflict resolution)
  3. Registry performance at scale (100k+ agents) untested (Phase 8 will optimize)
  4. Audit export on very large ledgers (1GB+) may be slow (Phase 7 will add streaming)
  5. No persistence across process restart for in-flight jobs (Phase 1c handles via registry)

Rollback: 
  Phase 1 is self-contained. If critical failures occur:
  1. Owner disengages kill switch (unfreezes system)
  2. Owner restores Governor to previous policy version (from registry history)
  3. Owner restores Registry to previous snapshot (from audit trail)
  4. Owner restores jobs from audit trail (replay mechanism)
  5. No data loss (all state in persistent ledger)

KAIZA-AUDIT-END
```

---

## END OF PLAN

**Plan Status:** READY FOR EXECUTION  
**Authority:** Windsurf + Kaiza MCP  
**Next Step:** Load skills (Section 0), verify dependencies (Section 2), begin Phase 1a

**For questions or amendments:** Reference the specific section number and quote the relevant text.

