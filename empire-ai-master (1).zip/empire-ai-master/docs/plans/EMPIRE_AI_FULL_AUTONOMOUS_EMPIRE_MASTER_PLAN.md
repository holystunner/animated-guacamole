# EMPIRE AI: FULL AUTONOMOUS BUSINESS EMPIRE — MASTER PLAN

**AUTHORITY**: LOCKED  
**STATUS**: IMMUTABLE LAW  
**EXECUTION**: WINDSURF AGENT ONLY  
**DATE**: 2026-01-05

---

## 1. Authority Model & Governance Doctrine

### 1.1. Decision Boundaries
The system operates under a doctrine of **Data Supremacy**.
- **Rule 1**: If a decision can be derived from accessible data, the System makes it.
- **Rule 2**: Human intuition is considered "noise" unless codified as a risk parameter.
- **Rule 3**: Humans interact ONLY via the *Governor Interface* to set high-level constraints (Risk Ceilings, Capital Limits, Legal Boundaries).

### 1.2. Override Rules
Human overrides are treated as **System Failures**.
- Any manual intervention must be logged in the `Audit Ledger`.
- Manual overrides DO NOT set precedents for future autonomous decisions.
- Overrides are valid for a single batch cycle only, unless the underlying *parameter* is updated.

### 1.3. Emergency Powers
The System possesses **Autonomic Kill Switches**:
- **Fiscal Hemorrhage**: If total portfolio burn rate > `GLOBAL_BURN_LIMIT`, all non-profitable spending freezes immediately.
- **Platform Risk**: If > `RISK_THRESHOLD` % of assets receive search console warnings/ban signals, the affected cluster immediately enters `STASIS` mode (read-only, zero updates).

### 1.4. Audit Truth vs Process Truth
- **Audit Truth**: The immutable log of what *actually happened* (Ledger).
- **Process Truth**: The internal state application logic believes to be true.
- **Doctrine**: In conflict, the Audit Ledger is the source of reconstruction. The System must be able to rebuild its state strictly from the Audit Ledger.

---

## 2. Global System Architecture

### 2.1. Command Plane
The central nervous system.
- **Input**: Signals (Market Data, Performance Metrics, System Health).
- **Processing**: Logic Core (The "Brain" running strictly defined heuristics).
- **Output**: Directives (Spawn, Fund, Prune, Kill).
- **hosting**: Hetzner Dedicated Server (Primary).

### 2.2. Governor
The Constraint Enforcement Module.
- Intercepts all DIRECTIVES from the Command Plane.
- Validates against `CONSTITUTION.json` (Risk limits, Capital caps).
- **Pass**: Forwards to Executors.
- **Reject**: Logs incident, halts directive, notifies Command Plane to re-plan.

### 2.3. Registry
The System State Database.
- **Portfolio Registry**: Active Business Units and their states.
- **Asset Registry**: Domain ownership, content map, deployment status.
- **Financial Registry**: Real-time P&L per unit.

### 2.4. Executors
Dumb, stateless workers.
- **Crawler**: Scrapes internet for demand signals.
- **Builder**: Deploys code/assets to hosting.
- **Publisher**: Pushes content to endpoints.
- **Analyst**: Aggregates performance data.

### 2.5. Runtime Enforcement & Data Flows
`Signal` -> `Command Plane` -> `Draft Directive` -> `Governor` -> `Validated Directive` -> `Executor` -> `Outcome` -> `Audit Log` -> `Registry Update`.

---

## 3. Portfolio Model

### 3.1. Definition of a “Business Unit” (BU)
A standardized, atomic economic vehicle.
- **Identity**: Unique ID (UUID).
- **Scope**: Single Niche / Vertical.
- **Assets**: 1+ Domains, N+ Content Pages, 1+ Monetization IDs.
- **Economics**: Independent P&L.
- **Isolation**: Shared infrastructure, but logically isolated reputation/link profiles.

### 3.2. Lifecycle States
1.  **SPAWN**: Hypothesis formed, domain acquired, MVP assets deployed.
2.  **TEST**: Traffic acquisition mode. Low spend cap. 3-month probation.
3.  **SCALE**: Profitability proven. Cap removed. Aggressive expansion.
4.  **PRUNE**: Performance dipping. Contraction of non-performing assets.
5.  **KILL**: Negative Unit Economics > Threshold. Liquidation/Deletion.

### 3.3. Isolation Guarantees
- No cross-linking between BUs unless explicitly authorized by `Synergy Matrix` (rare).
- Separate hosting containers/IPs where beneficial for SEO hygiene.
- Independent Amazon Associate Tags (or at least Sub-IDs) to track attribution granularity.

---

## 4. Demand Intelligence Layer

### 4.1. Inputs
- **Search Volume**: (APIs/Scrapers) for intent keywords.
- **CPC Data**: Proxy for monetization value.
- **Social Trends**: Reddit/Twitter velocity on topics.
- **Competition Density**: Number of incumbent results, "Allintitle" ratios.

### 4.2. Signal Validation
- **Noise Filter**: Discard "flash in the pan" spikes (e.g., viral memes) unless Short-Term Arbitrage mode is active.
- **Longevity Score**: Historical trend analysis (Google Trends slope).
- **Commercial Intent Classifier**: Transactional vs. Informational queries.

### 4.3. Demand Graph
- A directed graph mapping `Topic` -> `Sub-topics` -> `Keywords` -> `Commercial Value`.
- Used to identify "White Space" (High Volume / Low Competition).

---

## 5. Autonomous Niche Discovery Engine

### 5.1. Niche Clustering
- Niches are clusters of semantically related intent, NOT just single keywords.
- Example: "Home Espresso" is a niche; "Best espresso machine" is a keyword.
- **Method**: Semantic embedding clustering of potential topics.

### 5.2. Scoring Formula
`Score = (Volume * CPC_Proxy * Longevity) / (Competition_Density ^ 2)`
- Penalizes competition heavily.
- Favors proven commercial durability.

### 5.3. Rejection Rules
- **YMYL (Your Money Your Life)**: Health/Finance niches REJECTED by default (High Compliance Risk).
- **Adult/Illegal**: Hard Blacklist.
- **Brand Dominated**: If Top 10 results are >= 70% Big Brands, REJECT.

### 5.4. Automatic Site Spawning
- If `Score > SPAWN_THRESHOLD` AND `Budget_Available > 0`:
    - Auto-buy domain (via registrar API).
    - Auto-provision minimal hosting.
    - Set State: `SPAWN`.

---

## 6. Asset Generation Engine

### 6.1. Template-Locked Generation
- NO custom design per site.
- **Master Templates**: 3-4 High-Performance, Accessible, Semantic HTML/CSS templates.
- **Vary**: Color palette, Typography, Logo (Procedural Generation).

### 6.2. Content Expansion Logic
- **Input**: Validated Keyword List.
- **Structure**: Hub & Spoke model.
- **Generation**: LLM-based writing, verified for facts (via cross-referencing), formatted for "Skimmability" (tables, bullet points, verdict boxes).

### 6.3. Click-Optimized Structure
- "Answer First" architecture.
- Comparison Tables above the fold.
- Sticky Call-To-Actions (CTAs).
- **Goal**: Minimizing "Time to Click" (TTC).

---

## 7. Distribution & Growth Engines

### 7.1. Search-First Strategy
- Primary distribution channel is Organic Search (Google/Bing).
- **Tactics**: Long-tail keyword dominance, Programmatic SEO (thousands of landing pages for structured data permutations).

### 7.2. Indexation Assistance
- Auto-submission of Sitemaps.
- Internal linking optimization (Graph theory based).
- Ping services.

### 7.3. Amplification (Winners Only)
- If a page hits `TRAFFIC_VELOCITY_THRESHOLD`:
    - System may trigger "Boost" actions (e.g., auto-sharing to social accounts, or creating satellite support pages).
    - **Rule**: Never amplify zeros. Only multiply non-zeros.

---

## 8. Monetization Stack

### 8.1. Amazon Affiliate (Primary)
- Integration of Amazon Associates API.
- Dynamic localized redirection.
- Real-time stock checking (don't send traffic to out-of-stock items).

### 8.2. Basket Leakage Exploitation
- Promote "Gateway Products" (High volume, low friction) to get the cookie.
- Rely on 24-hour cookie for unrelated purchases.

### 8.3. Display Ads (Secondary)
- Fallback monetization for high-traffic / low-intent pages (e.g., Info articles).
- **Providers**: Programmatic Ad networks (zero-maintenance).

### 8.4. Compliance
- Auto-injection of Affiliate Disclosures on EVERY page.
- Strict adherence to Amazon Operating Agreement (no cloaking, no offline promotion).

---

## 9. Capital & Resource Allocation

### 9.1. Global Caps
- `MAX_MONTHLY_BURN`: Hard ceiling on server/LLM/domain costs ($0 external, but tracks internal "credits" or token usage if applicable).
- `MAX_ACTIVE_PROJECTS`: To prevent resource dilution.

### 9.2. Per-Unit Caps
- `SPAWN_BUDGET`: Fixed allocation for new probes.
- `SCALE_BUDGET`: Function of trailing 30-day profit. (Reinvest X% of profit).

### 9.3. Anti-Concentration
- No single BU shall consume > 40% of total system resources (unless it generates > 80% of profit).
- Forced diversification if concentration risk detected.

---

## 10. Failure Ceilings & Emergency Controls

### 10.1. Negative ROI Thresholds
- **Probation**: If BU is unprofitable for > 3 months (TEST phase), it enters PRUNE list.
- **Kill**: If Scale-mode BU drops to < -10% ROI for 2 consecutive months, it is downgraded to TEST or KILLED.

### 10.2. Resource Burn Ceilings
- Circuit breaker: If API costs spike 200% in 1 hour -> EMERGENCY PAUSE.

### 10.3. Escalation Ladder
1.  **Warning**: Logged anomaly.
2.  **Pause**: Suspend updates/spending for specific BU.
3.  **Freeze**: Global suspend (requires Human Clearance).
4.  **Shutdown**: Graceful degradation.

### 10.4. Clearance Key Doctrine
- Critical destructive actions (Delete entire database, Transfer domain) require Cryptographic Sign-off (Simulated or Real Key).

---

## 11. Autonomy Modes

### 11.1. Mode 1: 3-Month Sprint (Exploration)
- **Focus**: High Spawn Rate, Low Kill Threshold.
- **Goal**: Gather data, find winners.
- **Behavior**: Aggressive probing of niches.

### 11.2. Mode 2: 6-Month Cruise (Exploitation)
- **Focus**: Scale Winners, Aggressive Pruning.
- **Goal**: Maximize Free Cash Flow (FCF).
- **Behavior**: Reinvest profits into deep content for top 20% BUs.

### 11.3. Mode 3: 12-Month Orbit (Maintenance)
- **Focus**: Stability, Defense.
- **Goal**: Low-maintenance yield.
- **Behavior**: Minimal changes. Update only when rankings drop.

---

## 12. Phase & Batch Execution Model

### 12.1. Phases (0 → N)
- **Phase 0**: Infrastructure & Core Systems (The Brain).
- **Phase 1**: First Spawn (Pilot Batch).
- **Phase 2**: Calibration (Feedback loop tuning).
- **Phase 3**: Full Autonomy (Locks engaged).

### 12.2. Batch Granularity
- Operations run in **Batches** (e.g., "Daily Update Batch", "Weekly Spawn Batch").
- Atomic transaction style: All succeeds or All rolls back.

### 12.3. Verification Gates
- No Phase transition without satisfying entrance criteria (e.g., "3 sites profitable" to enter Phase 2).

---

## 13. Audit & Forensics System

### 13.1. Required Artifacts
- `ledger.jsonl`: Append-only log of every decision.
- `financials.csv`: Daily snapshots of cost/rev per BU.
- `decisions/`: Folder containing rationale files for major actions (Spawn/Kill).

### 13.2. Truth Preservation
- The Ledger IS the history. It cannot be edited.
- "Retroactive Invalidation": If a data source is found corrupt, mark affected decisions in ledger as `TAINTED` but do not delete.

---

## 14. Allowed Business Classes

### 14.1. Whitelist (Permitted)
- **Affiliate Content Sites**: Reviews, lists, guides.
- **Programmatic Data Sites**: Stats, calculations, converters.
- **Arbitrage Media**: Viral news agglutinators (if within policy).

### 14.2. Blacklist (Banned)
- **E-commerce**: No physical inventory, no shipping, no customer support.
- **SaaS**: No code maintenance for users, no churn management.
- **User-Generated Content**: No moderation overhead.
- **High-Risk**: Gambling, Pharma, Adult, Hate Speech.

---

## 15. Operational Runbook

### 15.1. "Hands-Off" Definition
- Human does NOT: Pick niches, write content, build links, update plugins.
- Human DOES: Pay Hetzner bill, Withdraw profits, Set Risk Config.

### 15.2. Monitoring & Alerts
- **Green**: System functioning within parameters. Silent.
- **Amber**: Deviation detected (e.g., ROI drop). Summary report generated.
- **Red**: Structural failure or Risk Breach. SMS/Email interrupt.

### 15.3. Restart Doctrine
- In case of crash:
    1.  Reboot Infrastructure.
    2.  Load state from Registry.
    3.  Replay verify against Audit Ledger.
    4.  Resume pending Batch.

---

## 16. System-Level Acceptance Criteria

### 16.1. Economic Evidence
- System generates > $1.00 profit without human intervention in a 30-day window (Proof of life).
- System successfully kills a losing site without human intervention (Proof of discipline).

### 16.2. Autonomy Evidence
- Run continuously for 72 hours with ZERO human input commands.
- Successfully complete a full `Scan -> Opportunity -> Spawn -> Deploy` cycle autonomously.

### 16.3. Usage
System is considered "delivered" when Phase 3 is reached and ownership is transferred to the `Governor`.

---

## 17. Non-Goals

- **Brand Building**: We build assets, not brands.
- **Community**: We do not crave engagement.
- **Perfection**: "Good enough to rank" is the target.
- **Innovation**: We use what works. We do not invent new business models.

---
**END OF MASTER PLAN**
