# ATLAS PRODUCTION EXECUTION BLUEPRINT — END-TO-END REALITY REMEDIATION

**PLANE HASH**: 0926f5ab2a85208b20674dff00b440bde034488f7b879fae3bb9933235ab8dfa
**STATUS**: APPROVED
**SUPERVISOR**: KAIZA MCP
**PLAN IDENTIFIER**: ATLAS-E2E-REALITY-REMED-v1

---

## 0. GOVERNANCE DECLARATIONS (LAW)

### 0.1 Zero-Mock Reality Law

Execution MUST NOT introduce or retain any mock, stub, or placeholder logic. All system metrics, health states, and economic data MUST originate from real hardware, OS telemetry, or live database state. static returns for dynamic attributes are forbidden.

### 0.2 Authentication Reality Law

Authentication MUST be unified under the OIDC model. Every request MUST validate the token against live operator state. Skipping existence checks is a critical security failure.

### 0.3 Hive UI Truth Law

Every Hive UI control MUST trigger a real backend side effect and reflect real backend state. Visual-only simulations are forbidden.

### 0.4 Hard Failure Law

All failures MUST hard-stop execution and emit stable error codes. Silent fallbacks or "fail-open" logic is prohibited.

---

## 1. REMEDIATION PHASES

### PHASE R1: Authentication Integrity & Unification

**Objective**: Eliminate auth bypasses and unify the split-brain authentication model.
**Allowed Operations**:

- MODIFY: [token_validator.py](file:///home/lin/Documents/empire-ai/src/gateway/token_validator.py) (Restore operator existence check)
- MODIFY: [main_api.py](file:///home/lin/Documents/empire-ai/src/main_api.py) (Fix AttributeError: is_valid -> valid)
- DELETE: [admin_auth.py](file:///home/lin/Documents/empire-ai/src/middleware/admin_auth.py) (Remove split-brain local auth)
**Governance**: Auth Reality Law enforced. No token bypass allowed.

### PHASE R2: Backend Reality Restoration

**Objective**: Replace all hardcoded metrics and budget mocks with real system calls.
**Allowed Operations**:

- MODIFY: [action_envelope.py](file:///home/lin/Documents/empire-ai/src/execution/action_envelope.py) (Integrate real psutil metrics)
- MODIFY: [db.py](file:///home/lin/Documents/empire-ai/src/db.py) (Link health object to live monitoring)
- MODIFY: [agent_permissions.py](file:///home/lin/Documents/empire-ai/src/agent_permissions.py) (Connect budget usage to real ledger)
**Governance**: Zero-Mock Reality Law enforced.

### PHASE R3: Functional Kill Command

**Objective**: Implement real side-effects for the `kill.system` endpoint.
**Allowed Operations**:

- MODIFY: [main_api.py](file:///home/lin/Documents/empire-ai/src/main_api.py) (Implement persistent halt signal and process termination)
**Governance**: Hive UI Truth Law enforced. Control MUST cause process death.

### PHASE R4: Documentation & Intent Artifacts

**Objective**: Guarantee auditability for all changes.
**Allowed Operations**:

- CREATE: `<file>.intent.md` for every modified file.
**Governance**: Mandatory Commentary Law enforced.

---

## 2. VERIFICATION GATES

### 2.1 E2E Auth Reality

- **Command**: `npx playwright test tests/e2e/auth_reality.spec.ts`
- **Requirement**: Test MUST verify that a revoked/deleted operator token is rejected by the backend.

### 2.2 Metric Reality

- **Command**: `scripts/verify_metric_entropy.sh`
- **Requirement**: Verify that metrics change over time and correlate with system activity, failing if static values are detected.

### 2.3 Kill Command Side-Effect

- **Command**: `scripts/verify_kill_switch.sh`
- **Requirement**: Verify backend process death and state lock upon activation.

---

## 3. STOP CONDITIONS

- Presence of `mock`, `stub`, or `placeholder` strings in functional code.
- Any auth bypass detected in testing.
- Missing `.intent.md` file for any change.

**BLUEPRINT STATUS: LOCKED**
