# ATLAS PHASE 1.3 ASSET FACTORY BLOCKER REMEDIATION PLAN

# HASH: ae9233813b01b3c2132ce70e02dfda603d088875136f1a06044b68d317eaeed0

# STATUS: APPROVED / IMMUTABLE

## 1. Goal Description

The purpose of this plan is to resolve a single critical blocking defect in the Asset Factory pipeline identified during Phase 1–3 verification. Specifically, `src/factory/spec_writer.py` invokes a non-existent method `_calculate_feasibility`, causing asset generation to fail with an `AttributeError`. This plan corrects the call to the actual method `_calculate_feasibility_score`.

## 2. Proposed Changes

---

### Asset Factory System

#### [MODIFY] spec_writer.py (file:///home/lin/Documents/empire-ai/src/factory/spec_writer.py)

Summary of changes:

- Correct the method call on line 56 from `self._calculate_feasibility` to `self._calculate_feasibility_score`.

---

## 3. Forbidden Actions

- ⛔ DO NOT modify `scripts/` or `tests/`.
- ⛔ DO NOT perform unrelated refactoring or formatting.
- ⛔ DO NOT alter the `_calculate_feasibility_score` method definition.
- ⛔ DO NOT add any new dependencies or configuration parameters.

---

## 4. Execution Phases

### Phase R1 — Fix Blocking Callsite

- **Objective**: Correct the method name mismatch in the SpecWriter.
- **Allowed File Operations**:
  - `MODIFY`: src/factory/spec_writer.py
- **Required Verification Gates**:
  - **Static Check**: `python3 -m compileall src/factory/spec_writer.py`
  - **Unit Test**: `pytest tests/test_factory.py::TestSpecWriter`
- **Stop Condition**: Any failure in static checks or unit tests.

### Phase R2 — Re-Verify Phase 1–3

- **Objective**: Execute the full Phase 1–3 verification pipeline to confirm system integrity.
- **Allowed File Operations**:
  - `NONE`
- **Required Verification Gates**:
  - **Script**: `scripts/verify`
  - **Expected Result**: "VERIFY PASSED — SAFE TO SHIP"
- **Mandatory Report Artifacts**:
  - `docs/reports/verification/PHASE_1_3_ASSET_PIPELINE_VERIFICATION_REPORT_RETEST.md`
- **Stop Condition**: Any failure in scripts/verify.

---

**PLANID: ATLAS-REMED-P13-BLOCKER**
**CREATED: 2026-01-18**
