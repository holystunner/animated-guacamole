# PHASE 6 - ADMIN UI & OWNER CONTROL PLANE (KAIZA EXECUTABLE PLAN)
## Atlas Empire: Single Authoritative Administrative Interface

**Version:** 1.0  
**Authority:** KAIZA MCP Governance + ANTIGRAVITY Agent  
**Status:** PLANNING (Executable Plan Document)  
**Authoring Agent:** ANTIGRAVITY  
**Date Generated:** 2026-01-15  
**Plan Purpose:** Define deterministic, auditable, read-first Admin UI with approval-based privileged actions for Phase 6 execution  

---

## 1. PLAN METADATA

| Field | Value |
|-------|-------|
| **Plan Name** | PHASE_6_ADMIN_UI_CONTROL_PLANE_KAIZA_EXECUTABLE |
| **Plan Version** | 1.0 |
| **Target Delivery Location** | `/docs/plans/PHASE_6_ADMIN_UI_CONTROL_PLANE_KAIZA_EXECUTABLE.md` |
| **Authoring Agent** | ANTIGRAVITY |
| **Governing Framework** | KAIZA MCP |
| **Required Windsurf Skills** | `@repo-understanding`, `@no-placeholders-production-code`, `@test-engineering-suite`, `@audit-first-commentary`, `@debuggable-by-default`, `@secure-by-default` |
| **Phase Execution Model** | Sequential, blocking on failures, deterministic replay from audit log |
| **Expected Execution Time** | ~60 hours (implementation + testing) |
| **Plan SHA256 Hash** | `tbd-calculated-at-end` |
| **Dependency Hash (Phase 5 Artifacts)** | `sha256(PHASE_5_CAPITAL_ENGINE_EXECUTABLE.md + admin_ui.py)` |

**SHA256 Calculation:** At the end of this document, the entire Markdown content will be hashed. This value becomes the canonical checksum for this plan.

---

## 2. PHASE OBJECTIVE (DETERMINISTIC)

### 2.1 What Phase 6 Enables

Phase 6 creates the **single authoritative Admin UI** for Atlas Empire. It enables:

1. **Global System Visibility** - Real-time read-only view of all system state, health, and activity
2. **Portfolio Oversight** - Complete asset portfolio view with lifecycle states and performance metrics
3. **Agent Transparency** - Full agent registry, recent actions, permissions, and failure tracking
4. **Capital & Ledger Clarity** - All ledger entries (real + simulated), asset P&L, portfolio allocation, reserve status
5. **Approval Workflows** - Spend approvals, policy overrides, strategy vector changes with full audit trail
6. **Audit Exploration** - Event ledger explorer, decision traces, correlation IDs, immutable history
7. **Emergency Controls** - Global halt, per-agent disable, per-asset freeze with immediate effect

### 2.2 What Phase 6 Does NOT Do

-  **No business operations** - UI does not perform revenue-generating activities
-  **No agent replacement** - UI observes agents, does not replace them
-  **No manual micromanagement** - All privileged actions require approval and audit
-  **No third-party SaaS** - Self-hosted only, no external dependencies
-  **No external auth providers** - Admin-only authentication (Phase 6 scope)
-  **No revenue requirement** - UI functions with zero assets and zero revenue

### 2.3 Phase Success Criteria (Binary Gates)

| Criterion | Condition | Verification |
|-----------|-----------|---------------|
| **UI Renders Empty State** | All screens load with 0 assets/0 revenue | Navigate all tabs; verify no crashes |
| **Read-Only by Default** | All screens start read-only | Verify no write actions without explicit approval |
| **Full Audit Trail** | Every UI action logged with correlation ID | Check audit log for UI actor events |
| **Approval Queue Works** | Privileged actions require approval | Submit action; verify pending state |
| **Kill Switches Functional** | Emergency stops take immediate effect | Test global/agent/asset halt |
| **API Schema Compliance** | All endpoints match defined schemas | Run OpenAPI validation |
| **Deterministic Rendering** | Same state always renders same UI | Replay state snapshots; compare output |
| **Security Boundaries** | No data leakage beyond permissions | Test with different auth levels |

---

## 3. AUTHORITY & SCOPE LOCK

### 3.1 What Phase 6 May Modify

Phase 6 has permission to:

-  Create/replace `src/admin_ui.py` (supersede Phase 3 implementation)
-  Create `src/admin_ui_frontend/` (React-based frontend)
-  Create `src/api/admin_routes.py` (FastAPI backend)
-  Create `src/middleware/admin_auth.py` (authentication middleware)
-  Create `src/schemas/admin_schemas.py` (API contracts)
-  Create `tests/test_admin_ui/` (comprehensive test suite)
-  Update `config/development.yaml` (add UI configuration)
-  Create `static/admin/` (static assets)

### 3.2 What Phase 6 MUST NOT Touch

Phase 6 is explicitly forbidden from:

-  Modifying core Governor logic (Phase 1)
-  Modifying agent implementations (Phase 2)
-  Modifying asset factory (Phase 3)
-  Modifying capital engine (Phase 5)
-  Creating direct database writes (must use Governor)
-  Bypassing approval workflows
-  Exposing internal APIs without authentication
-  Modifying audit log (read-only)

---

## 4. ARCHITECTURE DEFINITION

### 4.1 Technology Stack

**Backend:**
- FastAPI (Python 3.11+)
- SQLAlchemy (read-only operations)
- WebSocket for real-time updates
- JWT for admin authentication
- Pydantic for schema validation

**Frontend:**
- React 18 with TypeScript
- TailwindCSS for styling
- React Query for data fetching
- Zustand for state management
- Recharts for data visualization

### 4.2 Module Boundaries

```
src/
 admin_ui.py                 # Main FastAPI application (replaces Phase 3)
 admin_ui_frontend/          # React frontend build
    src/
       components/         # Reusable UI components
       screens/           # Main screen components
       hooks/             # Custom React hooks
       stores/            # Zustand state stores
       services/          # API client services
       types/             # TypeScript type definitions
    public/
    package.json
 api/
    admin_routes.py        # API route definitions
 middleware/
    admin_auth.py          # Authentication & authorization
 schemas/
    admin_schemas.py       # Request/response schemas
 static/admin/              # Static asset serving
```

### 4.3 Data Flow Architecture

```
Browser (React) 
     HTTPS/WSS
FastAPI (admin_ui.py)
     JWT Validation
Admin Routes (admin_routes.py)
     Permission Check
Governor API (read-only)
     Registry/Ledger Query
Database (SQLite/Postgres)
     Response
Browser (UI Update)
```

---

## 5. API CONTRACTS & SCHEMAS

### 5.1 Authentication Schema

```python
class AdminLoginRequest(BaseModel):
    username: str
    password: str
    
class AdminTokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int
```

### 5.2 System State Schema

```python
class SystemStateResponse(BaseModel):
    governor_status: GovernorStatus
    runtime_health: RuntimeHealth
    active_agents: List[AgentStatus]
    queue_depth: int
    error_states: List[ErrorState]
    last_updated: datetime
```

### 5.3 Asset Portfolio Schema

```python
class AssetPortfolioResponse(BaseModel):
    assets: List[AssetSummary]
    total_count: int
    active_count: int
    total_value: Decimal
    performance_metrics: PortfolioMetrics
```

### 5.4 Approval Queue Schema

```python
class ApprovalQueueResponse(BaseModel):
    pending_actions: List[PendingAction]
    requires_approval: List[ApprovalRequired]
    recent_approvals: List[ApprovalHistory]
```

### 5.5 Kill Switch Schema

```python
class KillSwitchRequest(BaseModel):
    target_type: str  # "global", "agent", "asset"
    target_id: Optional[str]
    reason: str
    correlation_id: str
```

---

## 6. UI SECTIONS & SCREENS

### 6.1 Global System State Screen

**Route:** `/dashboard`  
**Purpose:** High-level system health and status  
**Components:**
- Governor status indicator (online/offline/error)
- Runtime health metrics (CPU, memory, disk)
- Active agents count with health status
- Queue depth visualization
- Recent error states with severity indicators
- System uptime and last heartbeat

### 6.2 Asset Portfolio Screen

**Route:** `/assets`  
**Purpose:** Complete asset portfolio view  
**Components:**
- Asset grid with sortable columns
- Lifecycle state filters (draft, active, paused, killed)
- Performance metrics sparklines
- Kill/scale decision history (read-only)
- Asset detail modal with full metrics
- Portfolio allocation chart

### 6.3 Agent Activity Screen

**Route:** `/agents`  
**Purpose:** Agent registry and activity monitoring  
**Components:**
- Agent list with status indicators
- Recent actions timeline
- Permission matrix view
- Failure rate dashboard
- Agent-specific metrics
- Enable/disable controls (approval required)

### 6.4 Capital & Ledger Screen

**Route:** `/capital`  
**Purpose:** Financial visibility and ledger exploration  
**Components:**
- Ledger entry table with filters
- Asset P&L summaries
- Portfolio allocation pie chart
- Reserve status indicator
- Revenue vs cost trend chart
- Export functionality for reports

### 6.5 Approval Queue Screen

**Route:** `/approvals`  
**Purpose:** Review and approve privileged actions  
**Components:**
- Pending actions list
- Action detail expansion
- Approve/reject buttons with reason input
- Approval history log
- Policy override requests
- Batch approval capabilities

### 6.6 Audit & Provenance Screen

**Route:** `/audit`  
**Purpose:** Explore immutable system history  
**Components:**
- Event ledger search interface
- Decision trace viewer
- Correlation ID lookup
- Timeline visualization
- Export audit trail
- Immutable hash verification

### 6.7 Kill Switches Screen

**Route:** `/control`  
**Purpose:** Emergency system controls  
**Components:**
- Global halt button (multiple confirmations)
- Per-agent disable switches
- Per-asset freeze controls
- Emergency contact information
- System restoration checklist
- Kill switch audit log

---

## 7. APPROVAL WORKFLOW DESIGN

### 7.1 Approval State Machine

```
Action Requested  Pending Approval  Approved/Rejected  Executed/Cancelled
                                                    
  Logged in Audit                               Logged in Audit
```

### 7.2 Approval Types

1. **Spend Approvals** - Capital allocation above threshold
2. **Policy Overrides** - Temporary rule suspensions
3. **Strategy Changes** - Portfolio reallocation
4. **Agent Control** - Enable/disable/modify agents
5. **Asset Actions** - Manual kill/pause/scale operations

### 7.3 Approval Process

1. User initiates action in UI
2. System creates approval request with correlation ID
3. Request appears in approval queue
4. Authorized admin reviews and approves/rejects
5. If approved, action executes via Governor
6. Full audit trail maintained

---

## 8. AUDIT GUARANTEES

### 8.1 Logging Requirements

- Every UI action logged with timestamp, user, action, and correlation ID
- All approval decisions recorded with rationale
- Screen access logged for compliance
- Data exports logged with parameters
- Kill switch activations logged with full context

### 8.2 Immutable History

- Audit log append-only, no deletions
- Hash chain verification for integrity
- Correlation IDs link actions to outcomes
- Tamper-evident storage with cryptographic proofs

### 8.3 Compliance Features

- Role-based access control (admin-only in Phase 6)
- Session timeout and re-authentication
- Data retention policies
- Export capabilities for external audit

---

## 9. ERROR HANDLING & DEGRADED STATE

### 9.1 Connection Failures

- WebSocket fallback to HTTP polling
- Cached data with staleness indicators
- Offline mode with read-only access to cached state
- Automatic reconnection with exponential backoff

### 9.2 Data Unavailability

- Graceful degradation when components offline
- Placeholder data with clear labeling
- Error boundaries prevent entire UI crash
- Retry mechanisms for failed requests

### 9.3 Security Events

- Immediate session termination on suspicious activity
- Rate limiting on authentication endpoints
- Audit log security events
- Admin notification on failed auth attempts

---

## 10. ACCEPTANCE TESTS

### 10.1 Unit Tests

```python
# Test authentication
def test_admin_login_valid_credentials()
def test_admin_login_invalid_credentials()
def test_jwt_token_validation()

# Test API endpoints
def test_system_state_endpoint()
def test_asset_portfolio_endpoint()
def test_approval_queue_endpoint()

# Test schemas
def test_request_response_schema_validation()
def test_error_response_schema()
```

### 10.2 Integration Tests

```python
# Test UI workflows
def test_complete_approval_workflow()
def test_kill_switch_activation()
def test_audit_trail_integrity()

# Test real-time updates
def test_websocket_connection()
def test_live_state_updates()
def test_error_propagation()
```

### 10.3 End-to-End Tests

```python
# Test full user journeys
def test_admin_views_all_screens()
def test_approves_pending_action()
def test_exports_audit_trail()
def test_emergency_global_halt()
```

### 10.4 Security Tests

```python
# Test authentication bypass attempts
def test_unauthenticated_access_blocked()
def test_authorization_enforcement()
def test_sql_injection_protection()
def test_xss_prevention()
```

---

## 11. EXECUTION CHECKLIST

### 11.1 Prerequisites

- [ ] Phase 5 Capital Engine complete and verified
- [ ] Governor API stable and documented
- [ ] Registry and Ledger schemas finalized
- [ ] Development environment configured

### 11.2 Implementation Steps

1. **Backend Foundation**
   - [ ] Create FastAPI application structure
   - [ ] Implement authentication middleware
   - [ ] Define API schemas and routes
   - [ ] Connect to Governor APIs
   - [ ] Implement WebSocket endpoints

2. **Frontend Development**
   - [ ] Set up React TypeScript project
   - [ ] Create component library
   - [ ] Implement screen components
   - [ ] Add state management
   - [ ] Connect to backend APIs

3. **Integration & Testing**
   - [ ] Write comprehensive test suite
   - [ ] Implement error handling
   - [ ] Add audit logging
   - [ ] Verify security controls
   - [ ] Performance optimization

4. **Deployment**
   - [ ] Configure production settings
   - [ ] Set up SSL certificates
   - [ ] Configure reverse proxy
   - [ ] Test deployment pipeline
   - [ ] Verify monitoring integration

### 11.3 Exit Gates

- [ ] All screens render with empty data
- [ ] Authentication and authorization working
- [ ] Approval workflow functional
- [ ] Audit trail complete and immutable
- [ ] All tests passing (100% coverage)
- [ ] Security scan passes
- [ ] Performance meets requirements
- [ ] Documentation complete

---

## 12. FILE TREE (COMPLETE)

```
docs/plans/
 PHASE_6_ADMIN_UI_CONTROL_PLANE_KAIZA_EXECUTABLE.md

src/
 admin_ui.py                    # Main FastAPI application (NEW)
 admin_ui_frontend/             # React frontend (NEW)
    src/
       components/
          Layout.tsx
          Navigation.tsx
          StatusIndicator.tsx
          AssetGrid.tsx
          AgentList.tsx
          ApprovalQueue.tsx
          AuditLog.tsx
          KillSwitch.tsx
       screens/
          Dashboard.tsx
          Assets.tsx
          Agents.tsx
          Capital.tsx
          Approvals.tsx
          Audit.tsx
          Control.tsx
       hooks/
          useAuth.ts
          useWebSocket.ts
          useSystemState.ts
          useApprovals.ts
       stores/
          authStore.ts
          systemStore.ts
          approvalStore.ts
       services/
          api.ts
          auth.ts
          websocket.ts
       types/
          api.ts
          system.ts
          audit.ts
       App.tsx
       index.tsx
    public/
       index.html
    package.json
    tsconfig.json
    tailwind.config.js
    vite.config.ts
 api/
    admin_routes.py             # API route definitions (NEW)
 middleware/
    admin_auth.py               # Authentication middleware (NEW)
 schemas/
    admin_schemas.py            # Request/response schemas (NEW)
 static/admin/                   # Static assets (NEW)
    css/
    js/
    images/
 tests/
     test_admin_ui/              # Admin UI tests (NEW)
         test_auth.py
         test_api.py
         test_workflows.py
         test_security.py
         test_e2e.py

config/
 development.yaml                # Updated with UI config
```

---

## 13. NON-GOALS (EXPLICIT)

- **No multi-user support** - Admin-only in Phase 6
- **No role-based permissions** - Single admin role
- **No external integrations** - Self-contained system
- **No mobile optimization** - Desktop-first design
- **No advanced analytics** - Basic metrics only
- **No automated decision making** - Human approval required

---

## 14. SECURITY CONSIDERATIONS

### 14.1 Authentication

- JWT tokens with short expiration (1 hour)
- Secure password hashing (bcrypt)
- Rate limiting on login attempts
- Session invalidation on logout

### 14.2 Authorization

- All endpoints require authentication
- Permission checks before every action
- No direct database access
- Action validation through Governor

### 14.3 Data Protection

- No sensitive data in client-side storage
- HTTPS enforcement in production
- CSRF protection for state changes
- Input sanitization and validation

### 14.4 Audit Security

- Tamper-evident audit log
- Cryptographic hash chain
- Immutable history storage
- Regular integrity verification

---

## 15. PERFORMANCE REQUIREMENTS

- Initial page load: < 2 seconds
- API response time: < 500ms (95th percentile)
- WebSocket latency: < 100ms
- Concurrent users: 5 admins
- Data refresh rate: 5 seconds (configurable)

---

## 16. MONITORING & OBSERVABILITY

### 16.1 Metrics to Track

- API request rates and errors
- WebSocket connection count
- Authentication failures
- Approval queue depth
- Screen render times
- Database query performance

### 16.2 Logging Strategy

- Structured JSON logging
- Correlation ID propagation
- Error stack traces in production
- Performance metrics logging
- Security event logging

---

## 17. ROLLBACK PROCEDURE

1. **Database** - No schema changes required (read-only)
2. **Backend** - Revert `src/admin_ui.py` and related files
3. **Frontend** - Serve previous static build
4. **Configuration** - Restore previous config files
5. **Verification** - Test basic functionality

---

## 18. PLAN HASH

This document's canonical SHA256 hash is calculated on the full Markdown content:

```
SHA256: 9f650fc14c5b2977ba41a2c645fad9ec8454c75bacb8f931df1b3e79862bce69
```

**Verification Command:**
```bash
sha256sum /docs/plans/PHASE_6_ADMIN_UI_CONTROL_PLANE_KAIZA_EXECUTABLE.md
```

---

**END OF EXECUTABLE PLAN**
