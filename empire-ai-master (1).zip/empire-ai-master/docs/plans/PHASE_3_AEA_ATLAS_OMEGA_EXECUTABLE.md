## PLAN_HASH

d5ba34066c72fe169cd334cd6abf1fea5d42e1fb4135d9204cc354cfd9828570

1. PLAN_METADATA

- ID: PHASE_3_AEA_ATLAS_OMEGA
- NAME: AEA / ATLAS-Ω (First Money Engine)
- VERSION: 1.0.0
- STATUS: EXECUTABLE_PENDING
- CONTEXT: Empire AI Phase 3
- PARENT: /docs/governance/CANONICAL_ROADMAP.md
- DEPENDS_ON:
  - /docs/plans/PHASE_1_ATLAS_CORE_EXECUTABLE.md
  - /docs/plans/PHASE_2_AGENT_ECONOMY_EXECUTABLE.md
- TARGET_PATH: /docs/plans/PHASE_3_AEA_ATLAS_OMEGA_EXECUTABLE.md
- AUTHOR: ANTIGRAVITY (KAIZA MCP)

1. SCOPE_LOCK

- LOCKED_TO: PHASE 3 (AEA / ATLAS-Ω)
- PREVIOUS_PHASE: PHASE 2 (AGENT ECONOMY)
- EXPLICITLY_EXCLUDED:
  - PAID_ADS
  - SOCIAL_MEDIA_AUTOMATION
  - EMAIL_MARKETING
  - SAAS_SUBSCRIPTIONS
  - MULTI_SERVER_INFRA
  - BRAND_BUILDING
  - AUTONOMOUS_SPENDING (Agents cannot spend money)

1. PHASE_OBJECTIVE

- PRIMARY: Exploit existing demand and earn first autonomous dollars (Real Revenue).
- SECONDARY: Establish the "Asset Lifecycle" (Generate -> Deploy -> Measure -> Kill/Clone).
- TERTIARY: Prove that "Code Can Buy Money" without human intervention.

1. REVENUE_DEFINITION (WHAT COUNTS AS MONEY)

- CURRENCY: USD (or equivalent stablecoin/fiat).
- VALID_CONVERSION: Confirmed Affiliate Commission (Click + Action).
- INVALID_CONVERSION: Impressions, Clicks without Action, "Potential" Revenue, Test Payments.
- ATTRIBUTION_REQUIREMENT: Every cent must trace back to:
  - Specific Asset ID (Page/Site)
  - Specific Agent ID (Creator)
  - Specific Timestamp

1. IN-SCOPE ASSET TYPES

- TYPE_1: PROGRAMMATIC_SEO_MICROSITE
  - Structure: 1 Keyword = 1 Intent = 1 Page.
  - Tech: Static HTML/JSON (Disposable).
  - Hosting: Cloud Object Storage / Edge (Zero Ops, Pre-provisioned).
- TYPE_2: ANSWER_ENGINE_OPTIMIZED_PAGE
  - Format: Direct Answer + Schema Markup + Data Table.
  - Target: LLM Citations (Perplexity/SearchGPT) + Google Snippets.

1. OUT-OF-SCOPE (EXPLICIT)

- COMPLEX_APPS: No databases, no user logins, no dynamic backends for assets.
- VISUAL_FLUFF: No custom bespoke design per page (use templates).
- SOCIAL: No Twitter/LinkedIn/Instagram bots.
- OUTBOUND_SALES: No cold email/DM.
- HUMAN_REVIEW: No "Draft" state waiting for human approval.

1. AEA PIPELINE (END-TO-END)

- STEP_1: QUERY_DISCOVERY (MarketIntel Agent) -> List of high-intent keywords.
- STEP_2: SCORING (MarketIntel Agent) -> Commercial Intent Score (0.0-1.0).
- STEP_3: GENERATION (AssetBuilder Agent) -> Static HTML + Metadata.
- STEP_4: DEPLOYMENT (DevOps Agent) -> Public URL (Push to CDN).
- STEP_5: INDEXING (SEO Agent) -> Sitemap Ping / API Submission.
- STEP_6: MONITORING (Audit Engine) -> Traffic/Revenue Logs.
- STEP_7: FEEDBACK (Governor) -> Kill or Clone decision.

1. AGENT ROLES & PERMISSIONS (PHASE 3 ONLY)

- MARKET_INTELLIGENCE: Allowed to query external SERP/Keyword APIs (Read-Only).
- ASSET_BUILDER: Allowed to write HTML/Content to `dist/` (No Deploy).
- DEVOPS_AGENT: Allowed to push `dist/` to Hosting Provider (Deploy).
- REVENUE_OBSERVER: Allowed to read Affiliate Dashboard/API (Read-Only).
- GOVERNOR (SYSTEM): Retains sole authority to KILL assets.

1. DATA MODELS & STORAGE

- TYPE: AssetManifest { id, keyword, template_id, affiliate_link_id, deploy_url, status }
- TYPE: AssetMetrics { asset_id, impressions_21d, clicks_30d, revenue_30d, last_updated }
- TYPE: RevenueEvent { id, asset_id, amount, source, timestamp, transaction_ref }
- TYPE: KillOrder { asset_id, reason, decision_time, hard_rule_ref }

1. DECISION & KILL LOGIC (HARD RULES)

- RULE_1: IMPRESSION_CHECK -> If `impressions_21d` == 0 THEN `KILL`.
- RULE_2: CTR_CHECK -> If `impressions` > 100 AND `ctr` < 0.5% THEN `REGENERATE`.
- RULE_3: REVENUE_CHECK -> If `revenue_30d` == 0.00 AND `age_days` > 30 THEN `KILL`.
- RULE_4: WINNER_CLONE -> If `revenue_30d` > $10.00 THEN `CLONE_PATTERN` (New Keywords).

1. DEPLOYMENT MODEL (SINGLE SERVER)

- ARCHITECTURE: Local Generation -> Static Hosting Push.
- SERVER_ROLE: Control Plane Only (The Brain).
- ASSET_HOSTING: External Static Host (Netlify/Vercel/S3) - Decoupled from Brain.
- SAFETY: Assets cannot crash the Brain.

1. MONETIZATION MECHANICS

- METHOD: Affiliate Links (Amazon, ClickBank, Specific Partners).
- INTEGRATION: Hardcoded templates with dynamic link injection.
- COMPLIANCE: Automated Affiliate Disclosure on every page.
- FINANCIAL_FLOW: External Network -> Affiliate Wallet -> (Manual Withdrawal to Empire Bank).
- RECORD_KEEPING: API Poll -> Revenue_Event Log.

1. FAILURE MODES & HARD STOPS

- MODE_1: NEGATIVE_ROI -> If Deployment Cost > Revenue (Sustainability Check).
- MODE_2: API_QUOTA_EXCEEDED -> Halt Pipeline ($ Safety).
- MODE_3: DOMAIN_FLAGGING -> If Domain gets banned/penalized -> Abandon & rotation.
- MODE_4: HALLUCINATION_DETECTED -> If generated content fails fact-check (Statistical) -> Kill.

1. AUDIT & REVENUE TRACEABILITY

- REQ_1: Every dollar logged must link to a specific Asset ID.
- REQ_2: Daily Reconciliation Job (Governor) acts as "CFO".
- REQ_3: Ledger must separate "Confirmed" vs "Pending" revenue.
- REQ_4: Audit Log must record the EXACT prompt used to generate the winning asset.

1. EXECUTION STEPS (ORDERED, ATOMIC)
1. SETUP_AFFILIATE_REGISTRY
   - ACTION: Create `src/core/monetization/affiliate_registry.ts` (API Keys/Links).
   - VERIFY: Unit test secure storage of Main Affiliate ID.
1. IMPLEMENT_PIPELINE_ORCHESTRATOR
   - ACTION: Create `src/core/aea/pipeline.ts` (Finite State Machine).
   - VERIFY: State transitions (Discovery -> Build -> Deploy).
1. CONNECT_SERP_API
   - ACTION: Implement `MarketIntelligence` adapter for SERP/Keyword data.
   - VERIFY: Mocked/Real query returns structured JSON.
1. BUILD_STATIC_GENERATOR
   - ACTION: Implement `AssetBuilder` template engine (Handlebars/Mustache).
   - VERIFY: Generate 1 valid HTML file from Mock Data.
1. IMPLEMENT_DEPLOYER
   - ACTION: Implement `DevOpsAgent` adapter for Static Host API.
   - VERIFY: Push "Hello World" to live URL.
1. IMPLEMENT_METRICS_INGEST
   - ACTION: Create `src/core/analytics/ingest.ts` (Webhooks/API).
   - VERIFY: Log 1 mock click/conversion to Audit Ledger.
1. ACTIVATE_KILL_SWITCH_LOGIC
   - ACTION: Implement `src/core/governor/kill_rules.ts`.
   - VERIFY: Feed mock asset (0 views) -> Verify Kill Order issued.

1. ACCEPTANCE CRITERIA (PASS / FAIL ONLY)

- [ ] ONE real conversion logged (Money -> Audit Log)? (PASS/FAIL)
- [ ] Kill Logic successfully deletes a dead test asset? (PASS/FAIL)
- [ ] Pipeline runs end-to-end without human input? (PASS/FAIL)
- [ ] Revenue is correctly attributed to specific asset? (PASS/FAIL)
- [ ] ZERO human edits to generated content? (PASS/FAIL)

1. POST-PHASE INVARIANTS

- INVARIANT: `src/core/aea/` contains full pipeline code.
- INVARIANT: Governor has active "Kill Rules" for assets.
- INVARIANT: Revenue Ledger is active and secured.
