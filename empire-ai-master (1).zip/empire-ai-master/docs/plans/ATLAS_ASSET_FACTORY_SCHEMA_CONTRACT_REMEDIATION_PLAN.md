# ATLAS ASSET FACTORY SCHEMA CONTRACT REMEDIATION PLAN

# HASH: f14d766cd9804096ddd8868dfa7f6b584cd3270e73b780a271ed36c2ae66994f

# STATUS: APPROVED / IMMUTABLE

## 1. Goal Description

This plan resolves the schema contract ambiguity in the Asset Factory identified during Phase 1–3 verification. The `SpecWriter` currently emits `specification.title`, while the `AssetValidator` and unit tests expect `specification.topic`. This plan aligns the factory output with the authoritative schema contract by ensuring `topic` is included in all content site specifications.

## 2. Authority Decision (Phase S1)

Based on inspection of `src/factory/asset_types/__init__.py` (AssetValidator) and `tests/test_factory.py`, the authoritative field for asset identification and validation is **`topic`**.

**Decision**: The Asset Factory output must be corrected to include the `topic` field. The `title` field will be preserved for backward compatibility and display purposes.

## 3. Execution Phases

### Phase S2 — Contract Alignment Remediation

- **Objective**: Align `SpecWriter` output with the authoritative `topic` schema.
- **Allowed File Operations**:
  - `MODIFY`: src/factory/spec_writer.py
- **Forbidden Actions**:
  - ⛔ DO NOT modify tests or other factory components.
  - ⛔ DO NOT remove the `title` field.
  - ⛔ DO NOT perform unrelated refactoring.
- **Required Verification Gates**:
  - **Static Check**: `python3 -m compileall src/factory/spec_writer.py`
  - **Unit Test**: `pytest tests/test_factory.py::TestSpecWriter::test_generate_content_site_spec`
- **Stop Condition**: Any failure in static checks or unit tests.

### Phase S3 — Re-Verification (Phase 1–3)

- **Objective**: Execute the full Phase 1–3 verification pipeline to confirm system integrity.
- **Allowed File Operations**:
  - `NONE`
- **Required Verification Gates**:
  - **Script**: `scripts/verify`
  - **Expected Result**: "VERIFY PASSED — SAFE TO SHIP"
- **Mandatory Report Artifacts**:
  - `docs/reports/verification/PHASE_1_3_ASSET_PIPELINE_VERIFICATION_REPORT_RETEST_V2.md`
- **Stop Condition**: Any failure in scripts/verify.

---

**PLANID: ATLAS-REMED-ASSET-SCHEMA**
**CREATED: 2026-01-18**
