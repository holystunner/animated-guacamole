# ATLAS ENTERPRISE PRODUCTION READINESS PLAN

**Plan ID:** ATLAS-ENT-PROD-001
**Authority:** ATLAS_POST_A4_EXECUTION_PLAN.md
**Status:** APPROVED
**Hash-Lock:** dfc89dbcd62d747f2dd36fa4e28babafef46052372c9b3588126eebc788af26d

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🎯 MISSION OBJECTIVE

Transition Atlas Empire to a production-ready, enterprise-grade state by enforcing zero-stub reality lock, hardening authentication, and wiring the Hive UI to live backend data with absolute auditability.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE 1: DATABASE SCHEMA & RESOURCE INTEGRITY

**Phase ID:** AE-PROD-P1
**Objective:** Replace stubbed licensing counts with real database queries against the enterprise schema.

**Explicit File Operations:**

- **CREATE** [init_enterprise_schema.sql](file:///home/lin/Documents/empire-ai/scripts/db/init_enterprise_schema.sql)
  - Define production schema: `agents`, `assets`, `registries`, `action_audit_log`.
- **MODIFY** [license_manager.py](file:///home/lin/Documents/empire-ai/src/licensing/license_manager.py)
  - Replace `_get_current_asset_count`, `_get_current_agent_count`, etc. with real PostgreSQL queries via `DatabaseManager`.
  - Ensure all limit checks are enforced against live data.

**Explicit Forbidden Actions:**

- Do NOT allow hardcoded `return 0` or any other constant numeric placeholders.
- Do NOT use SQLite for enterprise resource tracking; use PostgreSQL via `DatabaseManager`.

**Required Verification Gates:**

- **Command:** `python3 -c "import asyncio; from src.database import get_database; asyncio.run(get_database().execute(open('scripts/db/init_enterprise_schema.sql').read()))"`
- **Command:** `pytest tests/execution/test_execution_protection.py`
- **Expected:** Success (0) for schema application and tests.

**Mandatory Report Artifact:** `docs/reports/AE-PROD-P1-EXECUTION.md`
**Stop Conditions:** SQL execution failures or database connectivity issues.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE 2: AUTHENTICATION HARDENING & UI WIRING

**Phase ID:** AE-PROD-P2
**Objective:** Remove demo credentials and wire Hive UI to real authentication and topology data.

**Explicit File Operations:**

- **MODIFY** [hive-login.html](file:///home/lin/Documents/empire-ai/hive-login.html)
  - Remove hardcoded `value="admin"` and `value="admin123"`.
  - Remove "Demo: admin / admin123" footer text.
  - Wire login button to the real `src/auth/` backend endpoints.
- **MODIFY** [hive_backend.py](file:///home/lin/Documents/empire-ai/src/hive_backend.py)
  - Ensure topology data is served from the live PostgreSQL `registries` table rather than local SQLite seed data.

**Explicit Forbidden Actions:**

- Do NOT keep any "admin/admin123" default credentials in the UI.
- Do NOT use simulated state for hive cell visualization.

**Required Verification Gates:**

- **Command:** `grep -r "admin123" hive-login.html`
- **Expected:** Empty result.
- **Command:** `bash scripts/verify_production_readiness.sh`
- **Expected:** Success (0).

**Mandatory Report Artifact:** `docs/reports/AE-PROD-P2-EXECUTION.md`

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE 3: FINAL REALITY LOCK CERTIFICATION

**Phase ID:** AE-PROD-P3
**Objective:** Execute final end-to-end verification gates to certify production readiness.

**Required Verification Gates:**

- **Command:** `python3 scripts/verify`
- **Command:** `python3 scripts/ci/enforce_forbidden_markers.py .`
- **Command:** `python3 scripts/audit_integrity_checker.py`

**Mandatory Report Artifact:** `docs/reports/AE-PROD-P3-FINAL_CERTIFICATION.md`
**Stop Conditions:** Any gate failure or detection of forbidden markers (TODO/mock/stub).

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
