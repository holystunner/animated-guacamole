# ATLAS MASTER SECURITY EXECUTION PLAN

## HASH: 957214f819a2857ebdeeaa5e6362e19d929a6e5500fff39544f39b99030b40e3

## STATUS: APPROVED

## SUPERVISOR: KAIZA MCP

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🎯 MISSION OBJECTIVE

Execute a consolidated, deterministic security remediation of the Atlas Empire system by implementing enterprise-grade infrastructure hardening, OIDC gateway authentication, WebAuthn cryptography, session security, and end-to-end encryption in a single, immutable execution sequence.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 EXECUTION PHASE SEQUENCE

### PHASE MS-1: INFRASTRUCTURE HARDENING
**Derived From:** ATLAS_SECURITY_ENTERPRISE_REMEDIATION_PLAN.md → SEC-1
**Objective:** Harden network exposure, secrets handling, and runtime boundaries.

**Explicit Allowed File Operations:**
- **MODIFY** infra/nginx/empire-ai.conf
  - Enforce SSL/TLS strictly on port 443/8443
  - Implement permanent 301 redirect from HTTP (80/8081) to HTTPS
  - Add security headers: Strict-Transport-Security, Content-Security-Policy, X-Frame-Options
- **MODIFY** infra/docker-compose.yml
  - Replace environment variables for POSTGRES_PASSWORD and REDIS_PASSWORD with file-based secrets
  - Enforce no-new-privileges: true for all containers

**Explicit Forbidden Actions:**
- Do NOT allow unencrypted (HTTP) traffic to REACH application services
- Do NOT use hardcoded credentials in any configuration file

**Verification Gates:**
- **Command:** curl -k -I http://localhost:8081
- **Expected:** HTTP/1.1 301 Moved Permanently pointing to https://
- **Command:** docker inspect empire-governor | grep NoNewPrivileges
- **Expected:** "NoNewPrivileges": true

**Mandatory Report Artifact:** docs/reports/MS-1-INFRASTRUCTURE_EXECUTION.md

---

### PHASE MS-2: OIDC GATEWAY REALITY LOCK
**Derived From:** ATLAS_HIVE_OIDC_REMEDIATION_PLAN.md → P1
**Objective:** Standardize token validation strictly on Keycloak-issued OIDC/JWT claims.

**Explicit Allowed File Operations:**
- **MODIFY** src/gateway/token_validator.py
  - Remove direct database calls to `operators` table for `_get_operator` if JWT is from trusted issuer
  - Enforce RS256 signature verification using Keycloak's JWKS endpoint as ONLY trusted source
  - Ensure `capabilities` and `policy_epoch` claims are extracted strictly from JWT
  - Fail-closed on any OIDC/JWKS connectivity issues

**Explicit Forbidden Actions:**
- Do NOT allow "Bypass" tokens or hardcoded secrets
- Do NOT use internal database states to override OIDC authority results during validation phase

**Verification Gates:**
- **Command:** pytest tests/test_phase4_gateway_pep.py
- **Expected:** 100% PASS on JWT validation tests

**Mandatory Report Artifact:** docs/reports/MS-2-OIDC_GATEWAY_EXECUTION.md

---

### PHASE MS-3: GATEWAY RATE LIMITING (FAIL-CLOSED)
**Derived From:** ATLAS_SECURITY_ENTERPRISE_REMEDIATION_PLAN.md → SEC-2
**Objective:** Enforce deterministic, identity-aware request throttling that fails closed on infrastructure failure.

**Explicit Allowed File Operations:**
- **MODIFY** src/gateway/rate_limiter.py
  - Change RateLimitResult to default to allowed=False on initialization
  - Modify check_rate_limit to return allowed=False (Fail-Closed) if Redis is unavailable or any error occurs
  - Ensure sub claim from OIDC token is SOLE identifier for user-based limiting
- **MODIFY** src/gateway/gateway_pep.py
  - Remove "Fail Open" logging; replace with "Enforcement Denial" logging

**Explicit Forbidden Actions:**
- Do NOT allow "fail-open" behavior for rate limiting under any circumstances
- Do NOT use IP-based limiting as primary identifier for authenticated requests

**Verification Gates:**
- **Command:** docker stop empire-redis && pytest tests/test_phase4_gateway_pep.py
- **Expected:** 100% of requests must be REJECTED with 403/429 while Redis is down

**Mandatory Report Artifact:** docs/reports/MS-3-RATE_LIMITING_EXECUTION.md

---

### PHASE MS-4: WEBAUTHN & IDENTITY REALITY LOCK
**Derived From:** ATLAS_SECURITY_HIVE_AUTH_ENCRYPTION_PLAN.md → P1
**Objective:** Replace stubbed WebAuthn verification with cryptographically sound attestation and signature verification.

**Explicit Allowed File Operations:**
- **MODIFY** src/api/auth_endpoints.py
  - Remove "skip full attestation verification" fallback
  - Enforce `webauthn` library calls for all registration/authentication steps
  - Implement hard reject on `ImportError` for cryptographic dependencies
- **MODIFY** src/auth/device_binding.py
  - Replace "simulated" `_verify_webauthn_signature` with production-grade `webauthn-py` implementation
  - Enforce strict JWK format validation and sign count tracking for replay protection

**Explicit Forbidden Actions:**
- Do NOT use simulated or "simplified" signature verification
- Do NOT allow registration without verified attestation

**Verification Gates:**
- **Command:** pytest tests/auth/test_webauthn_reality.py
- **Expected:** Success (0)

**Mandatory Report Artifact:** docs/reports/MS-4-WEBAUTHN_EXECUTION.md

---

### PHASE MS-5: SESSION SECURITY & REVOCATION ENFORCEMENT
**Derived From:** ATLAS_SECURITY_HIVE_AUTH_ENCRYPTION_PLAN.md → P2
**Objective:** Hard-lock session security with rotating refresh tokens and mandatory revocation checks.

**Explicit Allowed File Operations:**
- **MODIFY** src/token_revocation.py
  - Enforce periodic Redis synchronization for revocation cache
  - Implement "Fail-Closed" behavior: if Redis is unavailable and local cache is stale (>60s), reject all write-operation tokens
- **MODIFY** src/gateway/gateway_pep.py
  - Wire all incoming requests through `TokenRevocationList.is_revoked()`
  - Enforce maximum session age of 12 hours for all Operator IDs

**Explicit Forbidden Actions:**
- Do NOT allow "Fail-Open" on revocation list connectivity issues
- Do NOT use persistent tokens; all access tokens must expire in <15 minutes

**Verification Gates:**
- **Command:** python3 scripts/verify_session_lock.py
- **Expected:** Success (0) - verified token rejection after revocation

**Mandatory Report Artifact:** docs/reports/MS-5-SESSION_SECURITY_EXECUTION.md

---

### PHASE MS-6: JWT-BOUND AUDIT LOGGING
**Derived From:** ATLAS_SECURITY_ENTERPRISE_REMEDIATION_PLAN.md → SEC-3
**Objective:** Record all privileged and mutating actions with cryptographic attribution bound to authorizing token.

**Explicit Allowed File Operations:**
- **MODIFY** src/observability/audit_logger.py
  - Extend AuditEvent to include auth_token_hash (SHA256 of JWT signature)
  - Modify log_event to require auth_token_hash for any action involving operation or resource mutation
- **MODIFY** src/gateway/gateway_pep.py
  - Extract JWT signature from validated token
  - Hash the signature and pass it to audit_logger during decision enforcement

**Explicit Forbidden Actions:**
- Do NOT log the JWT content or raw signature
- Do NOT allow mutating actions to proceed if audit log entry fails to bind to auth_token_hash

**Verification Gates:**
- **Command:** sqlite3 data/audit.db "SELECT auth_token_hash FROM audit_logs WHERE operation='action_execute' LIMIT 1;"
- **Expected:** A non-null, valid SHA256 hex string

**Mandatory Report Artifact:** docs/reports/MS-6-AUDIT_LOGGING_EXECUTION.md

---

### PHASE MS-7: AUTH API CONVERGENCE (DE-STUBBING)
**Derived From:** ATLAS_HIVE_OIDC_REMEDIATION_PLAN.md → P2
**Objective:** Remove all native WebAuthn/TOTP implementation logic from backend API.

**Explicit Allowed File Operations:**
- **MODIFY** src/api/auth_endpoints.py
  - **DELETE** all endpoints related to native WebAuthn registration/verification (`/webauthn/register`, `/webauthn/authenticate`)
  - **DELETE** native TOTP verification logic
  - **CREATE** `/api/v1/auth/session/me` (Session Bootstrap) endpoint that mirrors JWT claims to UI
  - Refactor `/callback` to be pure OIDC code-exchange proxy

**Explicit Forbidden Actions:**
- Do NOT maintain dual-auth paths (Keycloak AND Native)
- Do NOT keep "Stubbed" WebAuthn validation logic in codebase

**Verification Gates:**
- **Command:** grep -r "webauthn" src/api/auth_endpoints.py
- **Expected:** Result limited only to OIDC-related proxying/hints, no registration/verification code

**Mandatory Report Artifact:** docs/reports/MS-7-AUTH_API_EXECUTION.md

---

### PHASE MS-8: UI SECURITY INTEGRATION (HIVE LOGIN)
**Derived From:** ATLAS_SECURITY_HIVE_AUTH_ENCRYPTION_PLAN.md → P3
**Objective:** Integrate production-grade authentication into Hive UI, replacing demo credentials.

**Explicit Allowed File Operations:**
- **MODIFY** hive-login.html
  - Remove any remaining hardcoded demo text or "admin/admin123" logic
  - Integrate WebAuthn "Passkey" login flow consistent with Hive aesthetic
- **MODIFY** src/admin_ui_frontend/src/ui/state/useHiveState.ts
  - Enforce authentication state check before any backend data fetch
  - Redirect to `/login` immediately on 401/403 responses

**Explicit Forbidden Actions:**
- Do NOT keep "Demo" or "Bypass" buttons in the UI
- Do NOT store raw access codes or passwords in local storage

**Verification Gates:**
- **Command:** grep -r "admin123" .
- **Expected:** Empty result

**Mandatory Report Artifact:** docs/reports/MS-8-UI_SECURITY_EXECUTION.md

---

### PHASE MS-9: HIVE UI IDENTITY GATING
**Derived From:** ATLAS_HIVE_OIDC_REMEDIATION_PLAN.md → P3
**Objective:** Enforce identity-before-UI-render in Hive UI (React), ensuring dashboard is unreachable without valid OIDC session.

**Explicit Allowed File Operations:**
- **MODIFY** src/admin_ui_frontend/src/index.tsx
  - Wrap main application render in `AuthenticationProvider` or `Gatekeeper` component
- **MODIFY** src/admin_ui_frontend/src/AtlasUI.tsx
  - Ensure all data fetching is blocked until authentication state is confirmed via `/session/me`
  - Implement immediate redirect to OIDC Provider (Keycloak) on 401/403

**Explicit Forbidden Actions:**
- Do NOT allow UI to render "Demo" or "Placeholder" data while waiting for auth
- Do NOT store JWTs in local storage (session storage or HTTP-only cookies only)

**Verification Gates:**
- **Manual Verification:** Verify browser loop redirects to Keycloak when visiting root path without active session

**Mandatory Report Artifact:** docs/reports/MS-9-UI_IDENTITY_EXECUTION.md

---

### PHASE MS-10: ENCRYPTION & SECRETS LOCKDOWN
**Derived From:** ATLAS_SECURITY_HIVE_AUTH_ENCRYPTION_PLAN.md → P4
**Objective:** Implement at-rest encryption for sensitive DB fields and secure secret injection at runtime.

**Explicit Allowed File Operations:**
- **MODIFY** src/database.py
  - Implement transparent field encryption for `operator_attributes` and `secret_keys` using `cryptography.fernet`
- **CREATE** src/auth/prod_secrets_loader.py
  - Implement mandatory environment-only secret loading (no .env fallback in production)

**Explicit Forbidden Actions:**
- Do NOT commit encryption keys to repository
- Do NOT store secrets in plaintext logs

**Verification Gates:**
- **Command:** python3 scripts/verify_encryption_lock.py
- **Expected:** Success (0) - verified cipher-text in DB for sensitive fields

**Mandatory Report Artifact:** docs/reports/MS-10-ENCRYPTION_EXECUTION.md

---

### PHASE MS-11: FINAL REALITY LOCK CERTIFICATION
**Derived From:** ATLAS_HIVE_OIDC_REMEDIATION_PLAN.md → P4
**Objective:** Terminal verification of Atlas Empire auth posture.

**Explicit Allowed Operations:**
- **NONE** (Verification and Documentation only)

**Verification Gates:**
- **Command:** bash scripts/verify
- **Expected:** 0 violations for "mock", "stub", "placeholder", or "pass" in all auth/gateway modules
- **Criteria:** All phases must achieve "AUTH PASS - OIDC ENFORCED" status

**Mandatory Report Artifact:** docs/reports/MS-11-FINAL_CERTIFICATION.md

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🚦 GLOBAL STOP CONDITIONS

**IMMEDIATE HALT** if ANY of the following occur:
- Any phase fails its verification gate
- SSL certificate injection into empire-nginx fails
- auth_token_hash binding results in performance degradation > 50ms
- Redis fail-closed logic allows a single unauthorized request
- Keycloak (OIDC Provider) cannot be contacted for JWKS retrieval
- "Security Theater" (bypass logic) is detected during regression
- JWT without `device_verified=true` is accepted for high-value actions

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 📋 EXECUTION AUTHORITY MATRIX

| Phase | Source Document | Priority | Dependencies |
|-------|-----------------|----------|--------------|
| MS-1 | ENTERPRISE → SEC-1 | 1 | None |
| MS-2 | OIDC → P1 | 2 | MS-1 |
| MS-3 | ENTERPRISE → SEC-2 | 3 | MS-2 |
| MS-4 | ENCRYPTION → P1 | 4 | MS-2 |
| MS-5 | ENCRYPTION → P2 | 5 | MS-4 |
| MS-6 | ENTERPRISE → SEC-3 | 6 | MS-5 |
| MS-7 | OIDC → P2 | 7 | MS-6 |
| MS-8 | ENCRYPTION → P3 | 8 | MS-7 |
| MS-9 | OIDC → P3 | 9 | MS-8 |
| MS-10 | ENCRYPTION → P4 | 10 | MS-9 |
| MS-11 | OIDC → P4 | 11 | All Previous |

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🔐 AUTHORITY PRECEDENCE RESOLUTION

**Conflicts Resolved:**
1. **Phase ID Collisions:** Renamed all phases to MS-* (Master Security) format
2. **WebAuthn Implementation:** MS-4 (cryptographic) takes precedence over MS-7 (API cleanup)
3. **UI Authentication:** MS-8 (Hive login) integrated with MS-9 (identity gating)
4. **Rate Limiting:** MS-3 positioned after OIDC validation (MS-2) but before session security (MS-5)

**No Deferrals Required:** All phases are Windsurf-safe with explicit file operations and verification gates.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🏆 MASTER ACCEPTANCE CRITERIA

1. **Infrastructure Hardening:** All traffic encrypted, secrets managed via file-based injection
2. **OIDC Authority:** Keycloak as sole identity provider, JWT validation only
3. **Fail-Secure:** Rate limiting and session revocation fail-closed on infrastructure failure
4. **Cryptographic Binding:** All mutating actions bound to JWT signature hashes in audit logs
5. **Production Auth:** WebAuthn/TOTP fully implemented, no demo/stub credentials
6. **UI Security:** Identity-before-render enforced, no data without valid session
7. **Encryption at Rest:** Sensitive DB fields encrypted, secrets loaded from environment only
8. **Zero Security Theater:** Verification scripts pass with zero violations

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 📊 REPORTING REQUIREMENTS

Each phase MUST generate its mandatory report artifact before proceeding to the next phase. The final certification (MS-11) will consolidate all phase reports into a master security posture assessment.

**Final Deliverable:** docs/reports/ATLAS_MASTER_SECURITY_EXECUTION_COMPLETE.md

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🔒 IMMUTABILITY CLAUSE

This plan is hash-addressed and immutable. Any deviation requires a new master plan with new hash. Execution must proceed in the exact sequence specified with no phase skipping or reordering.

**PLAN LOCKED:** 957214f819a2857ebdeeaa5e6362e19d929a6e5500fff39544f39b99030b40e3
