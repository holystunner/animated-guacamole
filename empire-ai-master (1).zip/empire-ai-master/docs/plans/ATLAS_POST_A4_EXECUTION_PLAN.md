# ATLAS POST-A4 EXECUTION PLAN

**Plan ID:** ATLAS-POSTA4-001
**Authority:** ENTERPRISE_REMEDIATION_PLAN.md
**Status:** APPROVED
**Hash-Lock:** 09990288eadff02af1193e365cb751caa20d0a55428b2333ce5edc5bf4927215

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🎯 MISSION OBJECTIVE

Restore absolute "Reality Lock" parity by integrating production-grade verification gates, resolving repository hygiene regressions, and implementing database-backed resource auditing. This plan transitions Atlas Empire from "Security Theater" to "Enterprise Reality".

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE P1: VERIFICATION GATE HARDENING

**Phase ID:** AE-POST-A4-P1
**Objective:** Restore the master verification script and install missing test infrastructure.

**Explicit File Operations:**

- **MODIFY** [verify](file:///home/lin/Documents/empire-ai/scripts/verify)
  - Correct the broken `VIOLATION_PATTERN` bash syntax (remove invalid `+` concatenation).
  - Add explicit check for `psutil` and `asyncpg` availability.
- **CREATE** [verify_production_readiness.sh](file:///home/lin/Documents/empire-ai/scripts/verify_production_readiness.sh)
  - Implement real-world health checks:
    - `POSTGRES_READY`: Attempt a basic query via `asyncpg`.
    - `REDIS_READY`: Ping the Redis server.
    - `RESOURCE_READY`: Check disk space and memory usage against P7 thresholds.
    - `AUTH_READY`: Validate `ATLAS_MASTER_SECRET` and `ATLAS_LICENSE_KEY` presence.

**Explicit Forbidden Actions:**

- Do NOT skip any dependency in `requirements.txt`.
- Do NOT use mock handlers in `verify_production_readiness.sh`.

**Required Verification Gates:**

- **Command:** `pip install -r requirements.txt`
- **Command:** `bash scripts/verify_production_readiness.sh --dry-run`
- **Expected:** Success (0) for dry-run.

**Mandatory Report Artifact:** `docs/reports/AE-REMED-P1-EXECUTION.md`
**Stop Conditions:** `pip install` failures or script syntax errors.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE P2: REPOSITORY HYGIENE RECLAMATION

**Phase ID:** AE-POST-A4-P2
**Objective:** Eliminate root directory clutter and enforce "Reality Lock" file structure.

**Explicit File Operations:**

- **CREATE** directory `docs/archive/execution/`
- **CREATE** directory `scripts/archive/`
- **MODIFY** [Root Directory](file:///home/lin/Documents/empire-ai/)
  - **MOVE** all `PHASE*_EXECUTION_REPORT.*` and `PHASE*_VALIDATION_RESULTS.*` from root to `docs/archive/execution/`.
  - **MOVE** all `fix_*.py`, `test_*.js`, and `deploy_*.sh` from root to `scripts/archive/`.
  - **DELETE** orphan `.txt` status files (`DEPLOYMENT_STATUS_FINAL.txt`, etc.) after verifying they are indexed in reports.

**Explicit Forbidden Actions:**

- Do NOT delete the `docs/` or `src/` directories.
- Do NOT move `requirements.txt`, `package.json`, or the `Dockerfile`.

**Required Verification Gates:**

- **Command:** `ls -F | grep -v / | wc -l`
- **Expected:** File count (excluding directories) <= 15.
- **Artifact:** `docs/reports/AE-REMED-P2-EXECUTION.md`

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE P3: PRODUCTION SCHEMA & RESOURCE INTEGRITY

**Phase ID:** AE-POST-A4-P3
**Objective:** Replace stubbed licensing counts with real database queries.

**Explicit File Operations:**

- **CREATE** [init_enterprise_schema.sql](file:///home/lin/Documents/empire-ai/scripts/db/init_enterprise_schema.sql)
  - Create tables: `agents`, `assets`, `registries`, `action_audit_log`.
- **MODIFY** [license_manager.py](file:///home/lin/Documents/empire-ai/src/licensing/license_manager.py)
  - Implement `_get_current_asset_count`, `_get_current_agent_count`, etc., using `self.db_pool`.
- **MODIFY** [control_api.py](file:///home/lin/Documents/empire-ai/src/execution/control_api.py)
  - Ensure all database queries for preconditions are verified against the standard schema.

**Explicit Forbidden Actions:**

- Do NOT allow hardcoded `0` returns in `license_manager.py`.

**Required Verification Gates:**

- **Command:** `python3 scripts/db/init_enterprise_schema.sql` (Schema application)
- **Command:** `pytest tests/execution/test_execution_protection.py`

**Mandatory Report Artifact:** `docs/reports/AE-REMED-P3-EXECUTION.md`

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE P4: FINAL ENTERPRISE CERTIFICATION

**Phase ID:** AE-POST-A4-P4
**Objective:** Execute final end-to-end verification gates.

**Required Verification Gates:**

- **Command:** `python3 scripts/verify`
- **Command:** `bash scripts/verify_production_readiness.sh`
- **Command:** `python3 scripts/ci/forbidden_markers_scan.py .`

**Mandatory Report Artifact:** `docs/reports/AE-REMED-P4-FINAL_CERTIFICATION.md`
**Stop Conditions:** Any gate failure.
