# PHASE 3: ASSET FACTORY KAIZA EXECUTABLE PLAN

**Plan Name:** PHASE_3_ASSET_FACTORY_KAIZA_EXECUTABLE  
**Version:** 1.0  
**Date:** January 15, 2026  
**Authoring Agent:** Antigravity  
**Governing Framework:** KAIZA MCP + Empire AI Canonical Specification  
**Plan Status:** PLANNING ONLY (No production code)

---

## 1. PLAN METADATA

**Plan Identity:**
- Name: PHASE_3_ASSET_FACTORY_KAIZA_EXECUTABLE
- Location: `/docs/plans/PHASE_3_ASSET_FACTORY_KAIZA_EXECUTABLE.md`
- Version: 1.0
- Authority: Canonical Specification (PART II, PHASE 3)
- Governance: KAIZA MCP + Definition of Done rules
- Dependency: PHASE_2_AGENT_ECONOMY_KAIZA_EXECUTABLE (all 6 agents must be operational)

**Authoring Signature:**
- Agent: Antigravity (planning authority)
- Framework: Windsurf KAIZA MCP
- Execution Permission: Windsurf using KAIZA write tools
- Audit Trail: Universal Ledger (Phase 1 artifact)

**SHA256 Hash (computed after content lock):**
- Hash: `b27125ab0cde815b8cdabd2d3951ebce0bdda23b820a88583b2359749a5963e4`
- Verification method: `sha256sum -c PHASE_3_ASSET_FACTORY_KAIZA_EXECUTABLE.md.sha`
- Recompute after any modification to ensure integrity

**Required Windsurf Skills (load during execution):**
1. `@no-placeholders-production-code` — No stubs, all implementations complete
2. `@test-engineering-suite` — Comprehensive test coverage (unit, integration, system)
3. `@audit-first-commentary` — Document decision rationale with KAIZA-AUDIT blocks
4. `@secure-by-default` — Input validation, no code injection, safe templating
5. `@debuggable-by-default` — Structured logging, observability, error tracing

**Pre-Execution Dependencies Satisfied:**
- Phase 0: Kernel daemon, audit log, kill switch ✓
- Phase 1: Governor, Registry, Runtime, Audit engine ✓
- Phase 2: All 6 agents registered and tested ✓

---

## 2. PHASE OBJECTIVE (REVENUE-CAPABLE, DETERMINISTIC)

**What Phase 3 Accomplishes (Exact Definition):**

Phase 3 implements an **autonomous asset factory system** that:

1. **Ingests opportunities** from Scout agent (discovery engine)
2. **Generates specifications** for candidate assets
3. **Produces complete asset code** using Builder agent (with 100% test pass requirement)
4. **Validates compliance** using Verifier agent (no malicious claims)
5. **Deploys to staging** for indexing verification
6. **Measures baseline performance** (SEO, load time, structure health)
7. **Publishes production snapshots** for bootstrap measurement

**Asset Capability (End-of-Phase 3):**

The system produces **revenue-capable but unscaled** assets:
- Static websites with embedded monetization (affiliate links, product links)
- Content sites with indexable structure (SEO-valid HTML, sitemaps)
- Micro-tools running client-side (calculators, validators, converters—no backend)
- Landing pages with conversion tracking (UTM parameters, analytics hooks)

**Revenue Capability (Not Revenue Generation):**

Each asset:
- Contains at least ONE monetization path (affiliate OR product link OR lead capture)
- Has metadata for cost attribution (build cost, server cost)
- Has measurement hooks for revenue attribution (UTM source, referrer tracking)
- Is deployable to production infrastructure (Phase 4)

**Deterministic Output:**

- Minimum 5 assets deployed by phase end (proof of factory)
- 100% of generated code passes unit tests (non-negotiable)
- 0% security vulnerabilities (SAST pass required)
- 0% compliance violations (Verifier sign-off required)
- 100% audit trail present (every asset build decision logged)

**What Phase 3 is NOT:**

- NOT a customer-facing platform
- NOT a growth optimization system (Phase 6 domain)
- NOT a scaling/distribution system (Phase 4-5 domain)
- NOT a revenue collection system (Phase 5 domain)
- NOT a monetization optimization engine (Phase 9 domain)

---

## 3. AUTHORITY & SCOPE LOCK

**Directories & Files Phase 3 is ALLOWED to Create:**

```
src/factory/
├── spec_writer.py          (Specification generation from opportunities)
├── asset_builder.py        (Asset code generation coordinator)
├── asset_types/            (Asset type definitions)
│   ├── content_site.py     (Programmatic content site type)
│   ├── affiliate_page.py    (Affiliate landing page type)
│   ├── micro_tool.py        (Client-side tool type)
│   └── __init__.py
├── templates/              (Safe template library)
│   ├── content_base.html
│   ├── affiliate_base.html
│   ├── tool_base.html
│   └── monetization_helpers.py
├── validators/             (Asset validation library)
│   ├── seo_validator.py
│   ├── compliance_validator.py
│   ├── security_validator.py
│   └── __init__.py
├── deployment/             (Staging deployment coordinator)
│   ├── asset_deployer.py
│   ├── health_checker.py
│   └── measurement_bootstrap.py
└── __init__.py

src/artifact_store/         (Asset artifact storage)
├── store.py                (File-based artifact versioning)
└── __init__.py

tests/test_factory_*.py     (Comprehensive factory tests)
├── test_spec_writer.py
├── test_asset_builder.py
├── test_asset_types.py
├── test_validators.py
├── test_deployment.py
├── test_integration_factory.py
└── test_system_factory.py

config/
├── factory_defaults.json   (Factory configuration and asset definitions)
└── asset_templates.json    (Safe asset templates)

docs/
├── PHASE_3_ASSET_FACTORY_SPECIFICATION.md
├── PHASE_3_ASSET_TYPES.md
├── PHASE_3_PIPELINE_REFERENCE.md
└── PHASE_3_MONETIZATION_RULES.md

observability/
└── asset_schema.json       (Asset telemetry schema)
```

**Directories & Files Phase 3 is FORBIDDEN from Modifying:**

- ❌ `src/governor/` (Phase 1—immutable)
- ❌ `src/runtime/` (Phase 1—immutable)
- ❌ `src/registry.py` (Phase 1—immutable core)
- ❌ `src/core/audit.py` (Phase 1—append-only)
- ❌ `src/core/kill_switch.py` (Phase 1—frozen)
- ❌ `src/agents/` (Phase 2—agent definitions frozen)
- ❌ `src/universal_ledger.py` (Phase 1—immutable)
- ❌ Any Phase 0-2 test files
- ❌ AGENTS.md (governance configuration)

**Scope Violation Triggers (HARD STOP):**

1. **Modifying Governor policy logic** → Execution halts
2. **Removing or weakening verification steps** → Execution halts
3. **Deploying asset to production directly** (Phase 4 domain) → Execution halts
4. **Creating monetization without Registry entry** → Asset rejected
5. **Generating code that fails unit tests** → Asset rejected
6. **Skipping SAST security scan** → Asset rejected
7. **Creating asset type not in canonical list** → Execution halts
8. **Attempting to modify Registry schema** → Execution halts

**Enforcement Mechanism:**

- Code review gate: All modified files scanned for Governor/Registry/Runtime imports
- Policy gate: All asset creation requests must pass Governor approval
- Test gate: Asset code must pass 100% unit test suite
- Security gate: SAST scan must report 0 critical vulnerabilities
- Audit gate: All decisions logged to universal ledger with asset_id traceability

---

## 4. PRECONDITIONS (HARD GATES)

**Phase 2 Artifacts Required (Blocking):**

If ANY of these are missing, non-functional, or unverified, Phase 3 MUST NOT EXECUTE:

### Gate 1: Scout Agent Operational
**File:** `src/agents/scout_agent.py`  
**Requirement:** Can discover opportunities and write to Registry  
**Verification:**
```bash
python3 -c "
from src.agents.scout_agent import ScoutAgent
scout = ScoutAgent()
opp = scout.discover_opportunity(segment='test')
assert opp['asset_id'] is not None
print('Scout Agent: OK')
"
```
**Status Phase 2:** ✓ Complete

### Gate 2: Builder Agent Operational
**File:** `src/agents/builder_agent.py`  
**Requirement:** Can generate and test code  
**Verification:**
```bash
python3 -c "
from src.agents.builder_agent import BuilderAgent
builder = BuilderAgent()
spec = {'template': 'content_site', 'topic': 'test'}
artifact = builder.build(spec)
assert artifact['test_pass_rate'] == 1.0
print('Builder Agent: OK')
"
```
**Status Phase 2:** ✓ Complete

### Gate 3: Writer Agent Operational
**File:** `src/agents/writer_agent.py`  
**Requirement:** Can generate content variants  
**Verification:**
```bash
python3 -c "
from src.agents.writer_agent import WriterAgent
writer = WriterAgent()
content = writer.generate_copy(asset_id='test', variant_count=3)
assert len(content['variants']) == 3
print('Writer Agent: OK')
"
```
**Status Phase 2:** ✓ Complete

### Gate 4: Verifier Agent Operational
**File:** `src/agents/verifier_agent.py`  
**Requirement:** Can validate claims and compliance  
**Verification:**
```bash
python3 -c "
from src.agents.verifier_agent import VerifierAgent
verifier = VerifierAgent()
result = verifier.verify_content(content_id='test')
assert result['status'] in ['pass', 'fail']
print('Verifier Agent: OK')
"
```
**Status Phase 2:** ✓ Complete

### Gate 5: Governor Policy Enforcement
**File:** `src/governor/main_governor.py`  
**Requirement:** Approves/denies asset creation requests  
**Verification:**
```bash
python3 -c "
from src.governor.main_governor import Governor
gov = Governor()
result = gov.approve_request(
  actor='phase3_factory',
  action='create_asset',
  resource='content_site'
)
assert result in ['allow', 'deny']
print('Governor: OK')
"
```
**Status Phase 1:** ✓ Complete

### Gate 6: Registry Asset Tables Present
**File:** `src/registry.py`  
**Requirement:** Registry has asset, artifact, monetization tables  
**Verification:**
```bash
python3 -c "
from src.registry import Registry
reg = Registry()
# Verify asset table schema
schema = reg.get_schema('assets')
assert 'asset_id' in schema
assert 'asset_type' in schema
print('Registry Asset Schema: OK')
"
```
**Status Phase 2:** ✓ Complete

### Gate 7: Audit Ledger Operational
**File:** `src/universal_ledger.py`  
**Requirement:** Can log asset creation events  
**Verification:**
```bash
python3 -c "
from src.universal_ledger import UniversalLedger
ledger = UniversalLedger('data/universal_ledger.db')
event_id = ledger.log_event({
  'event_type': 'asset.test.created',
  'asset_id': 'test',
  'timestamp': 'now'
})
assert event_id is not None
print('Audit Ledger: OK')
"
```
**Status Phase 1:** ✓ Complete

### Gate 8: Kill Switch Armed
**File:** `src/core/kill_switch.py`  
**Requirement:** Can halt all asset creation instantly  
**Verification:**
```bash
python3 -c "
from src.core.kill_switch import KillSwitch
ks = KillSwitch()
assert ks.is_armed()
assert ks.check_before_action('phase3_factory', 'create_asset') == True
print('Kill Switch: OK')
"
```
**Status Phase 1:** ✓ Complete

**Pre-Execution Checklist (MANDATORY):**

```bash
#!/bin/bash
set -e

echo "PHASE 3 PRECONDITION VERIFICATION"
echo "================================="

# Verify all Phase 2 agents registered
python3 -c "
from src.registry import Registry
r = Registry()
agents = ['scout', 'builder', 'writer', 'verifier', 'growth', 'finance']
for agent in agents:
  config = r.get_agent(f'{agent}_1')
  assert config is not None, f'Agent {agent}_1 not found'
print('✓ All 6 Phase 2 agents registered')
"

# Verify Governor operational
python3 -c "
from src.governor.main_governor import Governor
g = Governor()
assert g.is_operational()
print('✓ Governor operational')
"

# Verify Registry asset schema
python3 -c "
from src.registry import Registry
r = Registry()
assert r.get_schema('assets') is not None
print('✓ Registry asset tables present')
"

# Verify Audit ledger
python3 -c "
from src.universal_ledger import UniversalLedger
l = UniversalLedger('data/universal_ledger.db')
assert l.verify_integrity()
print('✓ Audit ledger verified')
"

# Verify Kill switch
python3 -c "
from src.core.kill_switch import KillSwitch
ks = KillSwitch()
assert ks.is_armed()
print('✓ Kill switch armed')
"

# Verify no forbidden markers in Phase 1-2
grep -r "TODO\|FIXME\|XXX\|HACK" src/governor/ src/runtime/ src/agents/ \
  && exit 1 || echo "✓ No forbidden markers in Phase 0-2"

echo ""
echo "ALL PRECONDITIONS MET - PHASE 3 EXECUTION CLEARED"
```

**Gate Failure Resolution:**

- If any agent unavailable: Stop. Debug Phase 2.
- If Governor unavailable: Stop. Debug Phase 1.
- If Registry unavailable: Stop. Debug Phase 1.
- If Audit ledger corrupted: Stop. Run recovery (Phase 0 procedure).
- If Kill switch not responding: EMERGENCY STOP. Engage manual override.

---

## 5. ASSET MODEL (CANONICAL)

**System Definition:**

An **Asset** is a deployable digital product created by the factory that:
- Has a distinct asset_type (one of three canonical types)
- Contains exactly ONE monetization path
- Passes 100% unit test coverage
- Passes security validation (SAST 0 critical vulns)
- Passes compliance validation (Verifier sign-off)
- Is deployable to staging without modification
- Has complete audit trail from conception to deployment
- Can be measured for revenue attribution
- Can be killed/paused/modified by Registry decision

**Asset Lifecycle:**

```
[1. Opportunity Intake] → [2. Feasibility Score] → [3. Spec Generation] →
[4. Code Generation] → [5. Test Execution] → [6. Security Scan] →
[7. Compliance Verification] → [8. Artifact Creation] → [9. Staging Deployment] →
[10. Health Check] → [11. Measurement Bootstrap] → [READY FOR PHASE 4]
```

---

### ASSET CLASS 1: PROGRAMMATIC CONTENT SITE

**Purpose:**
Autonomous publication of structured content (articles, guides, comparisons) with affiliate links embedded systematically. Target: SEO-discoverable content for niche keywords.

**Constraints:**
- Input: Topic (string), keyword list, competitor URLs (dry-run—no actual crawl)
- Output: Complete HTML/CSS website, structured data (JSON-LD), sitemap, robots.txt
- Monetization: Affiliate links (required ≥3 per page)
- Content Generation: LLM-driven with claim validation
- Indexing: SEO-valid HTML5, sitemap.xml, structured data markup
- Client-Only: All state client-side (no backend required)

**Required Inputs:**
1. **topic** (string): Primary content topic (e.g., "best laptop backpacks")
2. **keywords** (list): Target keywords for SEO (min 5, max 50)
3. **depth** (enum): Content depth—"overview", "detailed", "expert"
4. **page_count** (int): Number of pages to generate (min 3, max 20)
5. **affiliate_programs** (list): Allowed affiliate networks (Amazon, specific partners only)

**Generated Outputs:**
1. **index.html** — Landing page with hero, value prop, CTA
2. **pages/guide.html** — Main content page with affiliate links
3. **pages/comparison.html** — Product comparison table with affiliate links
4. **pages/reviews.html** — Review aggregation page
5. **styles/site.css** — Mobile-responsive styles
6. **scripts/analytics.js** — UTM parameter tracking (client-side)
7. **sitemap.xml** — URL index for search engines
8. **robots.txt** — Crawler directives
9. **data/structured.json** — JSON-LD schema (BreadcrumbList, Article, Review)
10. **metadata.json** — Asset metadata (keywords, topics, monetization info)

**Deployment Model:**
- Static hosting (Phase 4): Serve from CDN or static file server
- No backend required (pure HTML/CSS/JS)
- Asset size: ≤ 10 MB uncompressed

**Monetization Mechanism:**
- Affiliate links (required): ≥3 per page, tracked via UTM
- No ads, no subscriptions, no paywalls
- Link placement: Natural within content, contextually relevant
- Tracking: UTM source=`asset_id`, medium=`affiliate`, campaign=`page_name`

**Registry Representation:**
```json
{
  "asset_id": "content_site_1",
  "asset_type": "content_site",
  "topic": "best laptop backpacks",
  "keywords": ["laptop backpack", "travel backpack", "..."],
  "page_count": 5,
  "affiliate_programs": ["amazon_associates"],
  "monetization_path": "affiliate_links",
  "created_at": "2026-01-15T14:30:00Z",
  "deployment_status": "staged",
  "test_pass_rate": 1.0,
  "sast_score": 0,
  "verifier_status": "approved",
  "artifact_hash": "sha256:...",
  "cost_estimate": {"build_hours": 0.5, "serve_mb_per_month": 10},
  "health_score": 0.95,
  "indexable": true
}
```

**Audit Events Emitted:**
- `asset.content_site.registered`
- `asset.content_site.spec_generated`
- `asset.content_site.code_generated`
- `asset.content_site.tests_executed`
- `asset.content_site.security_scanned`
- `asset.content_site.compliance_verified`
- `asset.content_site.deployed_staging`
- `asset.content_site.health_checked`
- `asset.content_site.ready_for_production`

---

### ASSET CLASS 2: AFFILIATE LANDING PAGE

**Purpose:**
Highly-targeted landing page for single product/offer with conversion funnel (lead capture or direct affiliate link). Target: Email traffic, paid channel test pages, organic referral landing.

**Constraints:**
- Input: Product name, offer description, target audience
- Output: Single-page HTML, conversion tracking, lead capture form (optional)
- Monetization: Direct affiliate link OR lead capture form
- Content Generation: Marketing copy generation + A/B variant support
- Indexing: SEO-minimal (no requirement for organic search)
- Client-Only: All state client-side; optional backend for form submission (Phase 4)

**Required Inputs:**
1. **product_name** (string): Product or offer name
2. **offer_type** (enum): "affiliate_link" or "lead_capture"
3. **target_audience** (string): Audience description (e.g., "small business owners")
4. **call_to_action** (string): CTA text (e.g., "Get Started Free")
5. **affiliate_url** (string, conditional): Affiliate link if offer_type = "affiliate_link"
6. **form_fields** (list, conditional): Form fields if offer_type = "lead_capture"

**Generated Outputs:**
1. **index.html** — Full landing page
2. **styles/landing.css** — Responsive design
3. **scripts/tracking.js** — Conversion tracking (UTM, pixel, form)
4. **scripts/forms.js** (conditional) — Form validation and submission
5. **metadata.json** — Asset metadata and tracking IDs
6. **variants.json** — A/B test variants (copy alternations)

**Deployment Model:**
- Static hosting + optional form backend (Phase 4)
- Single-page application (SPA-light)
- Asset size: ≤ 2 MB uncompressed

**Monetization Mechanism:**
- **Type A (Affiliate):** Direct link to affiliate product with UTM tracking
- **Type B (Lead Capture):** Email/phone form with submission webhook (Phase 4)
- Conversion tracking: UTM parameters + JavaScript pixel
- No ads, no alternative monetization paths

**Registry Representation:**
```json
{
  "asset_id": "landing_page_1",
  "asset_type": "affiliate_landing_page",
  "product_name": "ProductName",
  "offer_type": "affiliate_link",
  "affiliate_url": "https://partner.com/aff?ref=empire...",
  "monetization_path": "affiliate_link",
  "created_at": "2026-01-15T14:30:00Z",
  "deployment_status": "staged",
  "test_pass_rate": 1.0,
  "sast_score": 0,
  "verifier_status": "approved",
  "variant_count": 3,
  "expected_conversion_rate": 0.02,
  "artifact_hash": "sha256:...",
  "cost_estimate": {"build_hours": 0.25},
  "health_score": 0.98
}
```

**Audit Events Emitted:**
- `asset.landing_page.registered`
- `asset.landing_page.spec_generated`
- `asset.landing_page.code_generated`
- `asset.landing_page.tests_executed`
- `asset.landing_page.security_scanned`
- `asset.landing_page.compliance_verified`
- `asset.landing_page.variants_generated`
- `asset.landing_page.deployed_staging`
- `asset.landing_page.ready_for_production`

---

### ASSET CLASS 3: MICRO-TOOL (CLIENT-SIDE)

**Purpose:**
Utility tool (calculator, converter, validator, checker) that runs entirely client-side with embedded utility value. Target: Long-tail SEO keywords, user referral loops.

**Constraints:**
- Input: Tool type, calculation logic, input/output specification
- Output: Single-page HTML/JS tool, no backend dependency
- Monetization: Adjacent content links, embedded recommendations
- Content Generation: Tool logic from template + custom logic injection
- Indexing: SEO-minimal (organic discoverability not primary goal)
- Client-Only: 100% client-side execution; no server calls except tracking

**Allowed Tool Types:**
- **calculator**: Math-based (loan, ROI, sizing, cost estimator)
- **converter**: Unit conversion, format conversion
- **validator**: Email, domain, syntax validator
- **comparison**: Side-by-side comparison table
- **checker**: Health check, compatibility checker, score calculator

**Required Inputs:**
1. **tool_type** (enum): One of allowed types
2. **tool_name** (string): Display name (e.g., "Loan Payment Calculator")
3. **input_schema** (json): Input field definitions
4. **calculation_logic** (string): Specification of calculation (pseudocode/formula)
5. **recommendation_links** (list): Related product/content links

**Generated Outputs:**
1. **index.html** — Tool interface
2. **styles/tool.css** — Responsive styles
3. **scripts/calculator.js** — Tool logic (auto-generated from schema)
4. **scripts/tracking.js** — Usage tracking
5. **metadata.json** — Asset and monetization metadata

**Deployment Model:**
- Static hosting only
- Asset size: ≤ 1 MB uncompressed
- Response time: ≤ 100ms input → result

**Monetization Mechanism:**
- Related content links (contextual recommendations)
- Partner product links (embedded in results)
- No ads, no paywalls, no lead capture (unless explicitly designed)

**Registry Representation:**
```json
{
  "asset_id": "tool_1",
  "asset_type": "micro_tool",
  "tool_name": "Loan Payment Calculator",
  "tool_type": "calculator",
  "calculation_type": "simple_amortization",
  "monetization_path": "embedded_links",
  "link_count": 2,
  "created_at": "2026-01-15T14:30:00Z",
  "deployment_status": "staged",
  "test_pass_rate": 1.0,
  "sast_score": 0,
  "verifier_status": "approved",
  "artifact_hash": "sha256:...",
  "cost_estimate": {"build_hours": 0.25},
  "health_score": 0.96
}
```

**Audit Events Emitted:**
- `asset.micro_tool.registered`
- `asset.micro_tool.spec_generated`
- `asset.micro_tool.logic_generated`
- `asset.micro_tool.tests_executed`
- `asset.micro_tool.security_scanned`
- `asset.micro_tool.compliance_verified`
- `asset.micro_tool.deployed_staging`
- `asset.micro_tool.ready_for_production`

---

## 6. ASSET FACTORY PIPELINE

**Deterministic Step-by-Step Execution:**

### STEP 1: OPPORTUNITY INTAKE

**Input Source:** Scout Agent Registry entries  
**Process:**
1. Poll Registry for new opportunities (`opportunities.{opportunity_id}`)
2. Filter by feasibility criteria (clear market, existing affiliate programs, low complexity)
3. Rank by estimated ROI (simple: keyword search volume × expected conversion rate)
4. Select top opportunity for batch processing

**Registry Mutation:**
- Write: `assets.{asset_id}` (new asset record, status: `planning`)
- Update: `opportunities.{opportunity_id}` (mark: `scheduled_for_build`)

**Ledger Event:**
```json
{
  "timestamp": "now",
  "event_type": "asset_factory.opportunity_intake",
  "asset_id": "{new_asset_id}",
  "opportunity_id": "{opportunity_id}",
  "decision": "accepted_for_build",
  "feasibility_score": 0.87,
  "estimated_roi": 0.34
}
```

**Responsible Agent:** None (factory subsystem)  
**Runtime:** Scheduled batch job (once per hour)  
**Failure Handling:** Skip opportunity, continue to next

---

### STEP 2: FEASIBILITY SCORING & ASSET TYPE SELECTION

**Input:** Opportunity record from Registry  
**Process:**
1. Analyze opportunity keywords, market signals, competition level
2. Determine best asset type match:
   - Broad topic + research intent → content_site
   - Single product + conversion focus → affiliate_landing_page
   - Utility/tool category + long-tail → micro_tool
3. Calculate feasibility score (0.0–1.0)
4. Accept only if score ≥ 0.70

**Feasibility Scoring Rubric:**
```
score = (market_clarity × 0.3) + (affiliate_availability × 0.3) + 
        (estimated_demand × 0.2) + (competition_level_inverse × 0.2)

market_clarity: 0.0–1.0 (how well-defined is the market segment?)
affiliate_availability: 0.0–1.0 (are there suitable affiliate programs?)
estimated_demand: 0.0–1.0 (keyword search volume proxy)
competition_level_inverse: 1.0 - (competition_strength / 100)
```

**Registry Mutation:**
- Update: `assets.{asset_id}` (status: `feasibility_scored`, asset_type assigned)

**Ledger Event:**
```json
{
  "event_type": "asset_factory.feasibility_scored",
  "asset_id": "{asset_id}",
  "feasibility_score": 0.82,
  "assigned_asset_type": "content_site",
  "decision": "approved_for_spec"
}
```

**Failure Handling:** If score < 0.70, mark opportunity as `rejected`, continue to next

---

### STEP 3: SPECIFICATION GENERATION

**Agent:** Spec Writer (automated, no agent overhead; direct factory subsystem call)  
**Input:** Opportunity + assigned asset type  
**Process:**
1. Load asset type template (content_site, landing_page, or tool)
2. Extract opportunity data (topic, keywords, affiliate programs)
3. Generate detailed specification:
   - Outline/structure
   - Required pages/sections
   - Content topics
   - Affiliate link placement strategy
   - Monetization configuration
4. Write specification to Registry

**Spec Output Format:**
```json
{
  "asset_id": "{asset_id}",
  "asset_type": "content_site",
  "specification": {
    "title": "Best Laptop Backpacks for Remote Workers 2026",
    "description": "Comprehensive guide to lightweight, durable laptop backpacks",
    "target_keywords": ["laptop backpack", "travel backpack", "..."],
    "outline": [
      {"page": "index", "topic": "Intro & Top Picks", "affiliate_links": 3},
      {"page": "guide", "topic": "Buyer's Guide", "affiliate_links": 5},
      {"page": "comparison", "topic": "Product Comparison", "affiliate_links": 4},
      {"page": "reviews", "topic": "Community Reviews", "affiliate_links": 2}
    ],
    "monetization": {
      "type": "affiliate_links",
      "programs": ["amazon_associates"],
      "placement_strategy": "contextual_within_content"
    },
    "build_parameters": {
      "template": "content_site_v1",
      "page_count": 4,
      "estimated_build_time": 30,
      "content_depth": "detailed"
    }
  }
}
```

**Registry Mutation:**
- Update: `assets.{asset_id}` (specification attached, status: `spec_approved`)
- Write: `specifications.{spec_id}` (full specification record)

**Ledger Event:**
```json
{
  "event_type": "asset_factory.spec_generated",
  "asset_id": "{asset_id}",
  "spec_id": "{spec_id}",
  "page_count": 4,
  "affiliate_links_planned": 14
}
```

**Failure Handling:** If specification generation fails (malformed opportunity), log error, skip asset

---

### STEP 4: CODE GENERATION & TESTING

**Agent:** Builder Agent  
**Input:** Specification from Registry  
**Process:**
1. Builder Agent called via Governor approval gate (phase3_factory → create_asset)
2. Builder receives specification + template
3. Builder executes generation:
   - Content generation (via Writer Agent, pre-populated)
   - Code scaffolding from template
   - Affiliate link injection (URL-safe, tracked)
   - SEO metadata generation (JSON-LD, sitemap)
   - CSS/JS bundle (minified)
4. Execute unit tests (HTML valid, links present, structure correct)
5. Assert test pass rate = 100% (non-negotiable)
6. Create artifact record

**Build Artifact Output:**
```json
{
  "artifact_id": "{uuid}",
  "asset_id": "{asset_id}",
  "build_timestamp": "2026-01-15T14:32:00Z",
  "template_version": "content_site_v1",
  "build_status": "success",
  "test_results": {
    "total_tests": 24,
    "passed": 24,
    "failed": 0,
    "pass_rate": 1.0,
    "coverage": 0.98
  },
  "artifacts": {
    "html_pages": ["index.html", "pages/guide.html", "..."],
    "stylesheets": ["styles/site.css"],
    "scripts": ["scripts/analytics.js"],
    "data_files": ["sitemap.xml", "robots.txt", "data/structured.json"],
    "total_size_kb": 245
  },
  "checksums": {
    "artifact_hash": "sha256:...",
    "build_log_hash": "sha256:..."
  }
}
```

**Registry Mutation:**
- Update: `assets.{asset_id}` (artifact_id linked, status: `code_generated`)
- Write: `artifacts.{artifact_id}` (artifact metadata)
- Write: `builds.{build_id}` (build log record)

**Ledger Event:**
```json
{
  "event_type": "asset_factory.code_generated",
  "asset_id": "{asset_id}",
  "artifact_id": "{artifact_id}",
  "test_pass_rate": 1.0,
  "build_time_seconds": 32
}
```

**Failure Handling:**
- If tests fail: Retry once (rerun code generation)
- If retried build still fails: Mark asset as `build_failed`, escalate for investigation

---

### STEP 5: SECURITY SCAN (SAST)

**Agent:** None (automated security tool)  
**Input:** Artifact files from Step 4  
**Process:**
1. Run static analysis on generated code:
   - No SQL injection patterns (templates prevent this)
   - No XSS vulnerabilities (template-safe escaping)
   - No hardcoded secrets (scan for API keys)
   - No unsafe external script imports
2. Generate SAST report
3. Fail if ANY critical or high-severity issues found
4. Warn if medium issues found (require Verifier review)

**SAST Report Output:**
```json
{
  "scan_id": "{uuid}",
  "artifact_id": "{artifact_id}",
  "scan_timestamp": "2026-01-15T14:33:00Z",
  "status": "passed",
  "vulnerabilities": {
    "critical": 0,
    "high": 0,
    "medium": 0,
    "low": 2
  },
  "issues": [
    {"severity": "low", "type": "unused_variable", "location": "scripts/analytics.js:42"}
  ],
  "recommendation": "approved_for_next_stage"
}
```

**Registry Mutation:**
- Update: `artifacts.{artifact_id}` (sast_score: 0, status: `security_passed`)

**Ledger Event:**
```json
{
  "event_type": "asset_factory.security_scanned",
  "artifact_id": "{artifact_id}",
  "critical_vulns": 0,
  "high_vulns": 0,
  "medium_vulns": 0
}
```

**Failure Handling:** If critical/high vulns found, asset marked `security_failed`, escalate

---

### STEP 6: COMPLIANCE VERIFICATION

**Agent:** Verifier Agent  
**Input:** Artifact + Specification from Registry  
**Process:**
1. Verifier Agent called via Governor approval gate
2. Verifier checks:
   - All affiliate links are legitimate (from approved programs)
   - No false/misleading claims about products
   - No prohibited content (violence, illegal activity, hate speech)
   - Affiliate disclosures present (if required by FTC/local law)
   - No GDPR violations (cookie consent if tracking enabled)
   - Monetization path matches specification
3. Generate verification report
4. Only approve if ALL checks pass

**Verification Report Output:**
```json
{
  "verification_id": "{uuid}",
  "artifact_id": "{artifact_id}",
  "verifier_agent": "verifier_1",
  "verification_timestamp": "2026-01-15T14:34:00Z",
  "checks": {
    "affiliate_legitimacy": "pass",
    "claims_accuracy": "pass",
    "prohibited_content": "pass",
    "affiliate_disclosure": "pass",
    "gdpr_compliance": "pass",
    "monetization_mapping": "pass"
  },
  "result": "approved",
  "notes": "All compliance gates passed. Ready for deployment."
}
```

**Registry Mutation:**
- Update: `assets.{asset_id}` (verifier_status: `approved`, status: `compliance_verified`)

**Ledger Event:**
```json
{
  "event_type": "asset_factory.compliance_verified",
  "asset_id": "{asset_id}",
  "verifier_agent": "verifier_1",
  "result": "approved"
}
```

**Failure Handling:** If verification fails, asset marked `compliance_failed`, escalate to admin

---

### STEP 7: STAGING DEPLOYMENT & HEALTH CHECK

**Agent:** Deployment subsystem (factory component)  
**Input:** Artifact from Step 4, passed Steps 5-6  
**Process:**
1. Copy artifact files to staging environment (`/staging/assets/{asset_id}/`)
2. Verify file structure is complete
3. Run health checks:
   - All HTML files serve (200 status)
   - CSS loads, renders correctly
   - JavaScript executes without errors
   - Links are valid (internal + external affiliate links)
   - Page load time < 2s
   - Mobile responsive (CSS media queries present)
4. Generate health report

**Health Check Report Output:**
```json
{
  "deployment_id": "{uuid}",
  "asset_id": "{asset_id}",
  "environment": "staging",
  "deployed_at": "2026-01-15T14:35:00Z",
  "health_checks": {
    "file_integrity": "pass",
    "http_status": "pass",
    "css_rendering": "pass",
    "javascript_execution": "pass",
    "link_validity": "pass",
    "page_load_time": {"p50": 0.8, "p95": 1.4, "p99": 1.9},
    "mobile_responsive": "pass"
  },
  "overall_health": 0.96,
  "status": "healthy"
}
```

**Registry Mutation:**
- Update: `assets.{asset_id}` (deployment_status: `staged`, health_score: 0.96)
- Write: `deployments.{deployment_id}` (deployment record)

**Ledger Event:**
```json
{
  "event_type": "asset_factory.deployed_staging",
  "asset_id": "{asset_id}",
  "health_score": 0.96,
  "page_load_p95_ms": 1400
}
```

**Failure Handling:** If health check fails, troubleshoot in artifact, rebuild

---

### STEP 8: MEASUREMENT BOOTSTRAP

**Agent:** Finance Agent (automated, read-only)  
**Input:** Deployed asset in staging  
**Process:**
1. Initialize measurement tracking:
   - UTM parameters configured (source, medium, campaign)
   - Analytics pixel/tag configured (page view tracking)
   - Conversion goals defined (affiliate click, lead form submission)
2. Snapshot baseline metrics (before production deployment):
   - Asset created date
   - Expected cost (based on asset type + size)
   - Cost allocation (% to build, % to hosting)
3. Write measurement initialization record

**Measurement Config Output:**
```json
{
  "measurement_id": "{uuid}",
  "asset_id": "{asset_id}",
  "initialized_at": "2026-01-15T14:36:00Z",
  "utm_tracking": {
    "source": "empire_ai",
    "medium": "{asset_type}",
    "campaign": "{asset_id}"
  },
  "analytics_events": [
    {"event": "page_view", "tracked": true},
    {"event": "affiliate_click", "tracked": true},
    {"event": "form_submission", "tracked": true}
  ],
  "cost_model": {
    "build_cost_usd": 15,
    "monthly_hosting_cost_usd": 2,
    "total_month_1_cost": 17
  },
  "baseline_snapshot": {
    "created_at": "2026-01-15T14:36:00Z",
    "status": "staged",
    "page_count": 4
  }
}
```

**Registry Mutation:**
- Update: `assets.{asset_id}` (measurement_id linked, status: `ready_for_production`)
- Write: `measurements.{measurement_id}` (measurement configuration)

**Ledger Event:**
```json
{
  "event_type": "asset_factory.measurement_bootstrapped",
  "asset_id": "{asset_id}",
  "measurement_id": "{measurement_id}",
  "build_cost_usd": 15,
  "monthly_hosting_cost_usd": 2
}
```

**Failure Handling:** Measurement initialization failures are non-blocking; continue to handoff

---

## 7. MONETIZATION RULES (STRICT)

**Allowed Monetization Types (Canonical):**

| Type | Asset Classes | Requirement | Example |
|------|---|---|---|
| **Affiliate Links** | content_site, affiliate_landing_page, micro_tool | ≥3 per asset, tracked via UTM | Amazon, niche product programs |
| **Lead Capture** | affiliate_landing_page | Form submission with email, tracked | Email list building |
| **Embedded Recommendations** | micro_tool | Related product/content links | Tool result → recommendation |

**Forbidden Monetization Types (Non-Negotiable):**
- ❌ Display advertising (banner ads, programmatic)
- ❌ Paid traffic (paid search, paid social)
- ❌ Subscriptions or paywalls
- ❌ Cryptocurrency or blockchain
- ❌ Gambling or betting
- ❌ MLM or affiliate spam networks
- ❌ Scams, counterfeit, or illegal goods
- ❌ Pharma, medical claims (unsubstantiated)
- ❌ Financial advice (unregistered)

**Monetization Path Lock (One Per Asset):**

Each asset has exactly ONE monetization path:
```
asset.monetization_path ∈ {
  "affiliate_links",
  "lead_capture",
  "embedded_recommendations"
}
```

No asset may have multiple paths (revenue attribution requires clarity).

**Affiliate Link Placement Rules:**

1. **Context Match:** Link must be contextually relevant to surrounding content
2. **Disclosure:** FTC disclosure required ("This is an affiliate link")
3. **URL Safety:** Links must be:
   - Escaped (no XSS injection vectors)
   - Tracked (UTM parameters appended)
   - Verified (domain must match approved program)
4. **Density:** Max 1 affiliate link per 200 words of content
5. **No Deception:** Never use misleading text or hidden links

**Revenue Attribution Logic:**

```
Revenue Flow:
Affiliate Click → UTM Tracking (source=empire_ai, campaign=asset_id)
  ↓
[Phase 5: Payment Gateway] Captures conversion
  ↓
Ledger: attribution_id → asset_id (permanent record)
  ↓
Monthly: Revenue Report by asset_id
```

**Cost Attribution Model:**

```
Per-Asset Economics:
Revenue (attributed to asset via UTM) - Build Cost - Hosting Cost = Profit

Build Cost: Estimated at asset creation, recorded in measurement_id
Hosting Cost: Per asset type (content_site ≈ $2/month, landing_page ≈ $1/month)
```

---

## 8. KILL RULES & SURVIVAL THRESHOLDS

**Automated Kill Criteria (Non-Discretionary):**

Phase 3 assets may be KILLED (permanently retired) under these deterministic conditions:

### KILL CONDITION 1: Time-Based Failure (90-day window)

```
IF asset.deployment_status == "staging" AND time_since_deployment > 90 days:
  KILL asset, mark as "deployment_failed"
  ESCALATE: Manual review required (why is this still in staging?)
```

**Rationale:** Staging is a temporary state. If not promoted to production within 90 days, assume permanent issue.

### KILL CONDITION 2: Build Failure Repeat

```
IF asset.build_failed_count >= 3:
  KILL asset, mark as "build_failed"
  ESCALATE: Debug asset specification
```

**Rationale:** Three rebuild attempts suggest fundamental issue with spec or template.

### KILL CONDITION 3: Compliance Violation (Permanent)

```
IF asset.compliance_status == "failed" AND appeal_count == 0:
  KILL asset, mark as "compliance_violation"
  ESCALATE: Understand why asset cannot pass verification
```

**Rationale:** Compliance failures cannot be auto-remediated; asset must be redesigned.

### KILL CONDITION 4: Zero Signal in Production (Phase 4+)

```
IF asset.deployment_status == "production" AND 
   time_in_production >= 30 days AND
   clicks == 0 AND
   page_views < 10:
  KILL asset, mark as "zero_signal"
  ESCALATE: Understand why asset gets no traffic
```

**Rationale:** Production assets should get some baseline discovery (SEO, referral). Zero signal indicates structural issue.

**Kill Enforcement:**

```python
def check_kill_conditions(asset_id):
    asset = registry.get_asset(asset_id)
    
    # Condition 1: Staging timeout
    if (asset.deployment_status == "staging" and 
        time.now() - asset.deployed_at > timedelta(days=90)):
        ledger.log_event({
            "event_type": "asset.killed",
            "asset_id": asset_id,
            "reason": "staging_timeout",
            "action": "kill_asset"
        })
        registry.update_asset(asset_id, {"status": "killed"})
        return "killed"
    
    # Condition 2: Build failure repeat
    if asset.build_failed_count >= 3:
        ledger.log_event({
            "event_type": "asset.killed",
            "asset_id": asset_id,
            "reason": "build_failures_exhausted",
            "failed_attempts": asset.build_failed_count
        })
        registry.update_asset(asset_id, {"status": "killed"})
        return "killed"
    
    # Condition 3: Compliance violation
    if asset.compliance_status == "failed":
        ledger.log_event({
            "event_type": "asset.killed",
            "asset_id": asset_id,
            "reason": "compliance_failed"
        })
        registry.update_asset(asset_id, {"status": "killed"})
        return "killed"
    
    # Condition 4: Zero signal (Phase 4+)
    if (asset.deployment_status == "production" and
        asset.deployed_at < now - timedelta(days=30) and
        asset.page_views < 10 and
        asset.clicks == 0):
        ledger.log_event({
            "event_type": "asset.killed",
            "asset_id": asset_id,
            "reason": "zero_signal_production"
        })
        registry.update_asset(asset_id, {"status": "killed"})
        return "killed"
    
    return "alive"
```

**Kill Verification:**

Every asset killed MUST have:
1. Ledger event with reason code
2. Registry status update (status: "killed")
3. Escalation notification (if applicable)

---

## 9. FAILURE TAXONOMY

**Enumeration of Asset Factory Failures:**

### FAILURE CLASS A: Specification Failures (Non-Retryable)

| Failure Type | Cause | Action | Audit Event | Recovery |
|---|---|---|---|---|
| `malformed_opportunity` | Opportunity missing required fields | Reject opportunity | `asset_factory.opportunity_rejected` | Skip to next opportunity |
| `feasibility_rejected` | Feasibility score < 0.70 | Reject asset | `asset_factory.feasibility_rejected` | Escalate opportunity for manual review |
| `asset_type_unknown` | Asset type not in canonical list | Reject specification | `asset_factory.asset_type_invalid` | Manual correction required |
| `spec_generation_error` | Specification writer fails | Retry once, then fail | `asset_factory.spec_generation_failed` | Debug spec writer |

### FAILURE CLASS B: Code Generation Failures (Retryable up to 2x)

| Failure Type | Cause | Action | Audit Event | Recovery |
|---|---|---|---|---|
| `build_timeout` | Builder takes > 2x estimated time | Retry | `asset_factory.build_timeout` | After 2 retries: mark `build_failed` |
| `test_failure` | Unit test(s) fail in generated code | Retry (rerun builder) | `asset_factory.test_failure` | After 2 retries: mark `build_failed` |
| `template_error` | Template missing or corrupted | Fail immediately | `asset_factory.template_error` | Restore template, retry builder |
| `artifact_creation_failed` | Artifact writing fails | Retry with backoff | `asset_factory.artifact_write_failed` | After 3 retries: escalate |

### FAILURE CLASS C: Security/Compliance Failures (Non-Retryable)

| Failure Type | Cause | Action | Audit Event | Recovery |
|---|---|---|---|---|
| `sast_critical_vuln` | Critical security vulnerability found | Reject artifact | `asset_factory.security_failed` | Fix vulnerability in template, retry builder |
| `verification_failed` | Verifier rejects artifact | Reject asset | `asset_factory.compliance_failed` | Manual investigation required |
| `affiliate_program_invalid` | Specified affiliate program not approved | Reject asset | `asset_factory.invalid_affiliate_program` | Update spec, retry builder |
| `disclosure_missing` | Required affiliate disclosure absent | Reject artifact | `asset_factory.disclosure_missing` | Fix template, retry builder |

### FAILURE CLASS D: Deployment Failures (Retryable, then manual)

| Failure Type | Cause | Action | Audit Event | Recovery |
|---|---|---|---|---|
| `staging_unavailable` | Staging environment not responding | Retry with backoff | `asset_factory.staging_unavailable` | After 3 retries: escalate |
| `health_check_failed` | Health checks fail after deployment | Retry deployment | `asset_factory.health_check_failed` | After 3 retries: investigate asset |
| `file_copy_failed` | Artifact files cannot be copied to staging | Retry with backoff | `asset_factory.file_copy_failed` | After 3 retries: check disk space |
| `measurement_init_failed` | Measurement setup fails | Warn (non-blocking) | `asset_factory.measurement_init_failed` | Can still proceed to Phase 4 |

**Retry Logic (Deterministic):**

```python
def execute_with_retries(operation, max_retries=2, is_retryable=True):
    attempt = 0
    
    while attempt <= max_retries:
        try:
            result = operation()
            ledger.log_event({
                "event_type": "factory.operation_success",
                "operation": operation.__name__,
                "attempt": attempt + 1
            })
            return result
        
        except RetryableError as e:
            attempt += 1
            if attempt > max_retries:
                ledger.log_event({
                    "event_type": "factory.operation_failed",
                    "operation": operation.__name__,
                    "reason": str(e),
                    "retries_exhausted": True
                })
                raise FatalError(f"{operation.__name__} failed after {max_retries} retries")
            
            wait_time = exponential_backoff(attempt)
            time.sleep(wait_time)
        
        except NonRetryableError as e:
            ledger.log_event({
                "event_type": "factory.operation_failed",
                "operation": operation.__name__,
                "reason": str(e),
                "non_retryable": True
            })
            raise
```

**Failure Escalation Rules:**

```
IF failure_class == A (Specification):
  → Skip asset, continue to next opportunity

IF failure_class == B (Code Generation):
  → Retry up to 2x
  → If still failing: Mark asset `build_failed`, escalate for investigation

IF failure_class == C (Security/Compliance):
  → Do NOT retry (requires explicit fix)
  → Escalate for manual remediation

IF failure_class == D (Deployment):
  → Retry up to 3x with exponential backoff
  → If still failing: Investigate artifact vs. environment
```

---

## 10. OBSERVABILITY & AUDIT GUARANTEES

**Logging Schema (Per Asset):**

```json
{
  "timestamp": "2026-01-15T14:30:45.123Z",
  "level": "info|warn|error",
  "service": "asset_factory",
  "asset_id": "content_site_1",
  "asset_type": "content_site",
  "message": "asset deployment completed",
  "op": "asset_factory.deploy",
  "step": 7,
  "duration_ms": 1234,
  "status": "success|failure",
  "context": {
    "artifact_id": "{uuid}",
    "deployment_id": "{uuid}",
    "build_time_seconds": 32,
    "test_results": {"passed": 24, "failed": 0},
    "security_score": 0,
    "compliance": "approved",
    "health_score": 0.96
  },
  "resources": {
    "artifact_size_kb": 245,
    "compute_time_ms": 32000,
    "disk_bytes": 256000
  }
}
```

**Metrics Per Asset (Per Day):**

```
asset.{asset_id}.build_time_seconds        (histogram)
asset.{asset_id}.test_pass_rate            (gauge: %)
asset.{asset_id}.security_score            (gauge: 0–100)
asset.{asset_id}.compliance_status         (enum: pass/fail)
asset.{asset_id}.deployment_status         (enum: planning/staged/production/killed)
asset.{asset_id}.health_score              (gauge: 0.0–1.0)
asset.{asset_id}.page_load_time_ms         (histogram)
asset.{asset_id}.artifact_size_kb          (gauge)
asset_factory.assets_created_24h           (counter)
asset_factory.assets_failed_24h            (counter)
asset_factory.assets_in_staging            (gauge)
asset_factory.assets_ready_for_production  (gauge)
```

**Registry Health Markers (Per Asset):**

```json
{
  "asset_id": "content_site_1",
  "health": {
    "status": "healthy|warning|critical",
    "last_checked": "2026-01-15T14:35:00Z",
    "checks": {
      "specification_complete": true,
      "code_generated": true,
      "tests_passing": true,
      "security_passed": true,
      "compliance_verified": true,
      "deployment_health": true
    },
    "score": 0.96
  }
}
```

**Required Ledger Events (Per Asset):**

Every asset MUST emit these audit events:

1. `asset.{type}.registered` — Asset created with ID
2. `asset.{type}.opportunity_accepted` — Opportunity selected for build
3. `asset.{type}.feasibility_scored` — Score assigned
4. `asset.{type}.spec_generated` — Specification complete
5. `asset.{type}.code_generated` — Build artifact created
6. `asset.{type}.tests_executed` — Test results logged
7. `asset.{type}.security_scanned` — SAST results logged
8. `asset.{type}.compliance_verified` — Verifier approval
9. `asset.{type}.deployed_staging` — Asset in staging environment
10. `asset.{type}.health_checked` — Health check results
11. `asset.{type}.measurement_bootstrapped` — Measurement initialized
12. `asset.{type}.ready_for_production` — Asset handoff to Phase 4

**Audit Trail Integrity:**

All events written to `universal_ledger.py` (Phase 1 system):
- Hash-chained for tamper detection
- Immutable post-write
- Queryable by asset_id, timestamp, event_type
- No event may be deleted (only appended)

**Dashboard Queries (Admin UI):**

1. **Asset Creation Pipeline**
   - Query: Assets at each stage (planning → spec → build → test → staging → ready)
   - Refresh: 5 minutes

2. **Failure Analysis**
   - Query: Failed assets, failure type, retry count
   - Refresh: 10 minutes

3. **Build Performance**
   - Query: Build time distribution, test coverage, security score
   - Refresh: 15 minutes

4. **Deployment Health**
   - Query: Staging assets, health scores, page load times
   - Refresh: 5 minutes

5. **Cost Attribution**
   - Query: Build cost vs. expected hosting cost, per asset type
   - Refresh: Daily

6. **Audit Trail Browser**
   - Query: Recent events (searchable by asset_id, event_type)
   - Refresh: Real-time

---

## 11. COMPLETION CRITERIA (EXACT, TESTABLE)

**Phase 3 is COMPLETE when ALL of the following are met:**

### Criterion 1: Factory Pipeline Operational
- [ ] Opportunity intake process working (Scout input → asset creation)
- [ ] Feasibility scoring algorithm implemented
- [ ] Asset type selection working correctly
- [ ] Specification generation producing valid specs
- **Verification:** Pipeline dry-run with 3 test opportunities → 3 assets created

### Criterion 2: Code Generation at 100% Test Pass Rate
- [ ] Builder Agent integration with factory working
- [ ] All generated assets pass 100% unit test coverage
- [ ] No asset with < 1.0 test_pass_rate deployed
- **Verification:** `pytest tests/test_factory_code_generation.py::test_all_assets_100_percent -v`

### Criterion 3: Security Scanning Mandatory
- [ ] SAST scanning integrated into pipeline
- [ ] 0 critical vulnerabilities in any asset
- [ ] Security report generated per artifact
- **Verification:** All assets have sast_score == 0

### Criterion 4: Compliance Verification Mandatory
- [ ] Verifier Agent integration working
- [ ] Affiliate link legitimacy checked per asset
- [ ] Claims accuracy validated per asset
- [ ] All assets have verifier_status == "approved"
- **Verification:** `registry.query_assets(verifier_status='approved')` returns ≥5 assets

### Criterion 5: Staging Deployment Functional
- [ ] Assets deployed to staging environment
- [ ] Health checks executed (HTTP status, CSS rendering, JS execution)
- [ ] All staging assets have health_score ≥ 0.95
- **Verification:** Curl test: `curl -s http://staging/assets/content_site_1/index.html | grep -q "<html>"`

### Criterion 6: Three Asset Types Implemented
- [ ] content_site assets generated and deployed (≥2 assets)
- [ ] affiliate_landing_page assets generated and deployed (≥2 assets)
- [ ] micro_tool assets generated and deployed (≥1 asset)
- **Verification:** `registry.query_assets(asset_type='content_site')` returns ≥2; similar for other types

### Criterion 7: Monetization Rules Enforced
- [ ] All assets have exactly ONE monetization_path
- [ ] Affiliate links verified as legitimate (approved programs only)
- [ ] Affiliate disclosures present where required
- [ ] Zero non-approved monetization detected
- **Verification:** Audit asset specs: all pass monetization validation

### Criterion 8: Kill Rules Implemented
- [ ] Kill condition logic implemented (time-based, build failure, compliance, zero-signal)
- [ ] At least one asset killed during testing (demonstrates kill logic)
- [ ] Kill event logged to ledger with reason code
- **Verification:** `ledger.query_events(event_type='asset.killed')` returns ≥1 record

### Criterion 9: Failure Taxonomy Complete
- [ ] All 14 failure types defined with retry/recovery rules
- [ ] Retry logic tested (max 2–3 retries with exponential backoff)
- [ ] Non-retryable failures escalated correctly
- **Verification:** Test suite: `pytest tests/test_factory_failures.py -v` passes

### Criterion 10: Measurement Bootstrap Configured
- [ ] UTM parameters configured per asset
- [ ] Analytics events defined (page_view, affiliate_click, form_submission)
- [ ] Cost model calculated (build cost + hosting cost)
- [ ] Measurement_id linked to each asset
- **Verification:** All staging assets have measurement_id in Registry

### Criterion 11: Complete Audit Trail
- [ ] All 12 mandatory ledger events logged per asset
- [ ] Ledger integrity verified (hash chain valid)
- [ ] No asset missing any event
- **Verification:** `for asset_id in assets: assert len(ledger.query_events(asset_id)) >= 12`

### Criterion 12: Comprehensive Test Coverage
- [ ] Unit tests: ≥50 tests covering pipeline steps
- [ ] Integration tests: ≥5 end-to-end workflows (opportunity → staging)
- [ ] Failure tests: ≥3 failure scenarios per failure class
- [ ] All tests passing with 0 warnings
- **Verification:** `pytest tests/test_factory_*.py -v --cov=src/factory --cov-report=html`

### Criterion 13: Zero Forbidden Markers
- [ ] No TODO/FIXME/XXX/HACK in factory code
- [ ] No stubs or mock implementations
- [ ] All functions fully implemented
- **Verification:** `grep -r "TODO\|FIXME\|XXX\|HACK" src/factory/ && exit 1 || echo "OK"`

### Criterion 14: Documentation Complete
- [ ] Asset factory specification guide
- [ ] Asset types reference (3 types × 5 properties = 15 documented)
- [ ] Pipeline step-by-step documentation
- [ ] Monetization rules specification
- [ ] Failure taxonomy and recovery procedures
- [ ] Observability and metrics guide
- **Verification:** `docs/PHASE_3_*.md` files present and non-empty

**Completion Verification Script:**

```bash
#!/bin/bash
set -e

echo "PHASE 3 COMPLETION VERIFICATION"
echo "================================"

# 1. Pipeline Operational
echo "✓ Pipeline operational..."
python3 -c "
from src.factory.asset_builder import AssetFactory
factory = AssetFactory()
assert factory.is_operational()
print('Factory operational')
"

# 2. Code Generation 100%
echo "✓ Code generation..."
pytest tests/test_factory_code_generation.py -v -x

# 3. Security Scanning
echo "✓ Security scanning..."
python3 -c "
from src.registry import Registry
r = Registry()
assets = r.query_assets(asset_type='*')
for asset in assets:
  assert asset.get('sast_score') == 0, f'Asset {asset[\"asset_id\"]} has vulns'
print(f'All {len(assets)} assets passed security')
"

# 4. Compliance Verification
echo "✓ Compliance verification..."
python3 -c "
from src.registry import Registry
r = Registry()
assets = r.query_assets(verifier_status='approved')
assert len(assets) >= 5, f'Only {len(assets)} assets approved'
print(f'{len(assets)} assets verified')
"

# 5. Staging Deployment
echo "✓ Staging deployment..."
pytest tests/test_factory_deployment.py -v -x

# 6. Asset Types
echo "✓ Asset types..."
python3 -c "
from src.registry import Registry
r = Registry()
types = ['content_site', 'affiliate_landing_page', 'micro_tool']
for asset_type in types:
  assets = r.query_assets(asset_type=asset_type)
  print(f'{asset_type}: {len(assets)} assets')
"

# 7. Monetization Rules
echo "✓ Monetization rules..."
pytest tests/test_factory_monetization.py -v

# 8. Kill Rules
echo "✓ Kill rules..."
pytest tests/test_factory_kill_rules.py -v

# 9. Failure Taxonomy
echo "✓ Failure taxonomy..."
pytest tests/test_factory_failures.py -v

# 10. Measurement Bootstrap
echo "✓ Measurement bootstrap..."
python3 -c "
from src.registry import Registry
r = Registry()
assets = r.query_assets(measurement_id='*')
assert len(assets) == len(r.query_assets(asset_type='*')), 'Not all assets measured'
print(f'{len(assets)} assets with measurement config')
"

# 11. Audit Trail
echo "✓ Audit trail..."
python3 -c "
from src.universal_ledger import UniversalLedger
ledger = UniversalLedger('data/universal_ledger.db')
events = ledger.query_events(event_type='asset.*.created')
assert len(events) >= 5, f'Only {len(events)} asset.created events'
print(f'{len(events)} asset creation events logged')
"

# 12. Test Coverage
echo "✓ Test coverage..."
pytest tests/test_factory_*.py -v --cov=src/factory --cov-report=term-missing

# 13. Forbidden Markers
echo "✓ Forbidden markers scan..."
! grep -r "TODO\|FIXME\|XXX\|HACK" src/factory/ || exit 1
echo "No forbidden markers"

# 14. Documentation
echo "✓ Documentation..."
test -f docs/PHASE_3_ASSET_FACTORY_SPECIFICATION.md || exit 1
test -f docs/PHASE_3_ASSET_TYPES.md || exit 1
test -f docs/PHASE_3_PIPELINE_REFERENCE.md || exit 1
test -f docs/PHASE_3_MONETIZATION_RULES.md || exit 1
echo "Documentation complete"

echo ""
echo "ALL PHASE 3 CRITERIA MET ✓"
```

---

## 12. EXPLICIT NON-GOALS

**What Phase 3 Does NOT Do:**

### Infrastructure & Distribution
- ❌ Multi-server deployment (single staging server only)
- ❌ Global CDN or edge distribution
- ❌ Automatic replication of assets
- ❌ Load balancing or failover systems

### Growth & Optimization
- ❌ A/B testing (Phase 9 domain)
- ❌ SEO optimization (Phase 6 domain)
- ❌ Traffic acquisition (Phase 6 domain)
- ❌ Content variant testing (Phase 9 domain)
- ❌ Conversion rate optimization
- ❌ Performance tuning beyond baseline health checks

### Capital & Scaling
- ❌ Asset replication or clustering
- ❌ Scaling decision automation (Phase 9 domain)
- ❌ Capital reallocation logic (Phase 5 domain)
- ❌ Revenue forecasting (Phase 8 domain)
- ❌ ROI-based kill decisions (Finance Agent domain)

### Advanced Monetization
- ❌ Subscription models
- ❌ Advertising networks (Google Ads, etc.)
- ❌ Payment processing (Phase 5 domain)
- ❌ Complex pricing strategies
- ❌ Upsell/cross-sell logic

### External Integrations
- ❌ Real API calls (all dry-run/mock)
- ❌ Live third-party data feeds
- ❌ Real payment processing
- ❌ Actual customer data
- ❌ Real traffic/SEO results

### Advanced Observability
- ❌ Machine learning-based anomaly detection
- ❌ Predictive analytics
- ❌ Real-time dashboarding (Phase 8 domain)
- ❌ Custom metrics aggregation

---

## 13. HANDOFF TO PHASE 4

**Phase 4 (Zero-Human Value Delivery System) Dependency List:**

Phase 4 requires these Phase 3 artifacts to operate:

### Registry Entries Required
- `assets.{asset_id}` — All created assets with complete metadata
  - Fields: asset_type, created_at, deployment_status, artifact_id, measurement_id, health_score
- `artifacts.{artifact_id}` — All artifact records
  - Fields: build_timestamp, test_results, sast_score, verifier_status
- `measurements.{measurement_id}` — Measurement configuration per asset
  - Fields: utm_tracking, analytics_events, cost_model, baseline_snapshot

### Governor Policies Required
- `policy.factory.create_asset` — Asset creation policy (already exists from Phase 2)
- `policy.factory.deploy_staging` — Staging deployment approval
- `policy.factory.health_check` — Health check authorization
- `policy.factory.measurement_init` — Measurement bootstrap authorization

### Audit Trail Required
- ≥50 asset factory events in universal ledger (proof of operation)
- All 12 mandatory event types per asset (proof of completeness)
- Hash chain integrity verified (proof of tamper-resistance)

### Artifact Files Required
- Staging directory populated: `/staging/assets/{asset_id}/index.html` + dependencies
- All asset files present (HTML, CSS, JS, data files, sitemap, robots.txt)
- All artifacts < 10 MB (uncompressed, per asset)

### Documentation Required
- Asset Factory Specification (architecture, pipeline)
- Asset Types Reference (3 types, properties, outputs)
- Pipeline Reference (8 steps, each with inputs/outputs)
- Monetization Rules (allowed types, enforcement)
- Failure Taxonomy (14 failure types + recovery)

**Guarantees Phase 4 Can Rely On:**

1. **Assets Are Production-Ready**
   - 100% test pass rate
   - 0 security vulnerabilities
   - Verifier approval on all
   - Health check > 0.95

2. **Asset Registry Is Authoritative**
   - All asset metadata in Registry
   - No assets outside Registry system
   - All Registry entries validated

3. **Monetization Is Configured**
   - Each asset has exactly ONE monetization_path
   - UTM parameters set up for tracking
   - Affiliate programs verified legitimate

4. **Measurement Is Bootstrapped**
   - Cost model established (build + hosting)
   - Analytics events configured
   - Baseline metrics captured

5. **Audit Trail Is Complete**
   - Every asset decision logged
   - Ledger is tamper-evident (hash chain)
   - All failures recorded with recovery actions

6. **Asset Lifecycle Is Managed**
   - Kill rules implemented and tested
   - Auto-retirement working for failed assets
   - Manual override capability present

7. **Factory Output Is Deterministic**
   - Same specification → same artifact (reproducible)
   - All randomness seeded/controlled
   - Builds are idempotent

**What Phase 4 Will Assume About Phase 3:**

- Phase 3 has produced at least 5 assets (proof of scale)
- All staging assets are health-checked and ready
- All artifacts are stored in staging environment
- Registry is source-of-truth for asset metadata
- Ledger contains complete audit trail
- No manual intervention required to promote assets to production

**What Phase 4 is NOT Responsible For:**

- Asset creation (Phase 3 domain)
- Code generation (Phase 3 domain)
- Compliance verification (Phase 3/Verifier Agent domain)
- Cost attribution (Phase 3 measurement domain)

---

## DOCUMENT HASH & INTEGRITY

**SHA256 Computation (Post-Content-Lock):**

```bash
sha256sum /docs/plans/PHASE_3_ASSET_FACTORY_KAIZA_EXECUTABLE.md > \
  /docs/plans/PHASE_3_ASSET_FACTORY_KAIZA_EXECUTABLE.md.sha

# Verify:
sha256sum -c /docs/plans/PHASE_3_ASSET_FACTORY_KAIZA_EXECUTABLE.md.sha
```

**Final Hash (Content Lock Complete):**
`b27125ab0cde815b8cdabd2d3951ebce0bdda23b820a88583b2359749a5963e4`

**Integrity Chain:**
- This document is the Source of Truth
- SHA256 hash verifies no modifications post-completion
- Ledger records Phase 3 plan commit timestamp
- Any changes trigger re-hash and version bump

---

**END PHASE 3 PLAN**

Status: PLANNING ONLY (No code written)  
Authority: KAIZA MCP / Antigravity  
Next: Await Windsurf execution authorization
