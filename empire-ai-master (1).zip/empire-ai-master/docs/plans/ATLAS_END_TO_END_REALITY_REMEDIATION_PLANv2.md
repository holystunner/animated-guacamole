# ATLAS PRODUCTION EXECUTION BLUEPRINT (v2)

**PLAN HASH**: 869728a9f5e0f5e3e7be404e42fd20f6f1ef6472f6806e1535ac9068d256fa54
**STATUS**: APPROVED
**GOVERNANCE**: KAIZA MCP
**SCOPE**: ATLAS EMPIRE PROJECT (FULL REPO)

---

## 0. MANDATORY GOVERNANCE LAW (NON-NEGOTIABLE)

### 0.1 Zero-Mock Reality Law
Execution MUST NOT introduce or retain:
- `mock`, `stub`, `placeholder`, `TBD`, `FIXME`
- Hardcoded credentials or secrets
- Static return values for dynamic operations (e.g., `return "healthy"`)
- Deterministic simulations (e.g., hash-based metrics masquerading as real telemetry)

Presence of any of the above → EXECUTION INVALID.

### 0.2 Authentication Reality Law
Authentication MUST:
- Be backed by a real identity provider (OIDC)
- Be enforced server-side (Gateway PEP)
- Be impossible to bypass for any UI or API action
- Produce verifiable auth signals (JWT/Audit logs)

Client-side auth simulation → EXECUTION INVALID.

### 0.3 Data Reality Law
All UI state and system metrics MUST:
- Derive exclusively from real backend APIs and live system telemetry (`psutil`, DB)
- Reflect verifiable side effects in the system state
- Not be initialized or modified by UI-side "for now" logic

UI-initialized state → EXECUTION INVALID.

### 0.4 Hard-Error Semantics
All failures MUST:
- Hard-stop execution immediately
- Emit a stable, unique error code
- Identify the specific violated invariant
- Attribute failure to Phase + Component

Silent failure or vague error messages → EXECUTION INVALID.

### 0.5 Mandatory Intent Artifacts
For EVERY file created or modified:
- `<file>.intent.md` MUST exist
- Must explain purpose, invariants, failure modes, and debug signals
- Must link to this Law defining authority

Missing intent artifact → EXECUTION INVALID.

---

## 1. REMEDIATION PHASES

### Phase R1: Zero-Mock Eradication
- **Objective**: Structural removal of identified mocks in core agents and executors.
- **Allowed Operations**:
  - `MODIFY` `src/phase3_executor.js` (Replace deterministic mocks with real DB-backed logic)
  - `MODIFY` `src/core/agents/operations.ts` (Replace hardcoded health strings with real component checks)
  - `MODIFY` `src/core/agents/growth.ts` (Implement real evaluation logic)
- **Forbidden Actions**: Any implementation using `Math.random()` or hardcoded status flags.
- **Verification Gates**: `scripts/verify_reality.sh` + `grep -rE "mock|stub|placeholder" src/`
- **Required Report**: `docs/reports/AE-REMED-R1-MOCK_ERADICATION.md`

### Phase R2: Auth & Identity Lockdown
- **Objective**: Forcing real OIDC identity signals in all core pathways.
- **Allowed Operations**:
  - `MODIFY` `src/licensing/license_manager.py` (Replace "for demonstration" keys with real signed license validation)
  - `MODIFY` `src/middleware/admin_auth.py` (Enforce strict OIDC token validation)
- **Forbidden Actions**: Retention of "legacy" or "test_operator" bypass pathways.
- **Verification Gates**: E2E Auth verification via `tests/e2e/auth_reality.spec.ts`
- **Required Report**: `docs/reports/AE-REMED-R2-AUTH_LOCKDOWN.md`

### Phase R3: Telemetry & Side-Effect Realism
- **Objective**: Ensuring every system action results in a verifiable state change.
- **Allowed Operations**:
  - `MODIFY` `src/telemetry/api.py` (Connect all Hive metrics to real system telemetry)
  - `MODIFY` `src/database.py` (Enforce strict DB-driven state for all agents)
- **Forbidden Actions**: Returning simulated success messages for infra actions like `COLLAPSE_HIVE`.
- **Verification Gates**: Integration tests verifying DB state mutability under load.
- **Required Report**: `docs/reports/AE-REMED-R3-SIDE_EFFECT_REALITY.md`

### Phase R4: UI Truth Enforcement (Hive Layer)
- **Objective**: Decoupling the Hive UI from any client-side state initialization.
- **Allowed Operations**:
  - `MODIFY` `src/admin_ui_frontend/src/components/EmpireHiveUI.tsx`
  - `MODIFY` `src/admin_ui_frontend/src/state/useHiveState.tsx`
- **Forbidden Actions**: UI `useEffect` hooks that populate metrics without API calls.
- **Verification Gates**: Visual regression audit + Network log audit.
- **Required Report**: `docs/reports/AE-REMED-R4-UI_TRUTH.md`

---

## 2. STOP CONDITIONS (ABSOLUTE)
Execution MUST STOP and Windsurf MUST REFUSE to continue if:
1. Any mock removal is implicit rather than explicit.
2. Auth requirements are bypassed or "mocked" for dev convenience.
3. An `.intent.md` file is missing for any change.
4. Any violation of Phase R1-R4 is detected in the audit trail.

---

## 3. AUDITABILITY
The system is auditable by reading ONLY reports and `.intent.md` files. Evidence of truth MUST be embedded in these documents.

