Plan Name: ATLAS END-TO-END REMEDIATION PLAN

Owner: ANTIGRAVITY

Date: 2026-01-18

Status: Approved

Applies To: Atlas Empire

Repo(s): empire-ai

Service(s): main-api, kernel-d, hive-ui

UI: Hive UI (React)

# 1. OBJECTIVE (WHY THIS PLAN EXISTS)

Primary Objective:
Achieve full operational status for Atlas Empire Phases 0–13 by resolving all critical blockers identified in the AMP Verification Report, ensuring the system operates on real state with unified authentication and authoritative control.

Concrete failures resolved:
- Kernel bootstrap failure due to hardcoded paths.
- Frontend dependency absence.
- Conflicting and unintegrated authentication systems.
- Lack of a central API entry point.
- UI/Backend disconnection (404s and connection refused).
- Simulated/fake data in dashboard and metrics.
- Non-functional emergency controls (Kill Switch).
- Lack of policy enforcement at the API boundary.

What “done” means:
AMP PASS — SYSTEM VERIFIED. The system boots, authenticates, renders real data, enforces policy, and responds to authorized control actions.

Explicit Non-Objectives (MANDATORY):
- This plan does NOT add new features.
- This plan does NOT redesign the UI.
- This plan does NOT change visual metaphors.
- This plan does NOT alter auth architecture unless required to unblock execution (Unified JWT flow).
- This plan does NOT introduce new phases.
- This plan does NOT expand scope beyond AMP findings.

# 2. INVARIANTS (MUST NEVER CHANGE)

- Backend is the single source of truth: No logic exists solely in the UI.
- No fake, random, mock, or simulated state: Data shown in UI must be derived from system state.
- Identity precedes all UI rendering: No system views are accessible without valid JWT.
- UI cannot grant authority: Permissions are enforced by the backend Policy Engine (OPA/Governor).
- All execution paths are auditable: Every state-changing action must produce an immutable audit log.
- Kill / collapse authority is real and backend-confirmed: Emergency controls must actually stop system execution.
- AMP findings override all other documents: If a conflict arises between historical plans and AMP, AMP wins.

# 3. AUTHORITY & SCOPE LOCK

- AMP report is binding and non-negotiable.
- This plan is remediation-only: Windsurf must refuse any instruction to add features.
- No feature expansion is permitted.
- No UI redesign is permitted.
- No scope growth is permitted.
- Windsurf must refuse execution on ambiguity that leads to scope creep.

# 4. BLOCKING ISSUE MATRIX (FROM AMP)

| Issue ID | Phase(s) Affected | Observable Symptom | Root Cause | Required Remediation | Verification Signal |
|----------|-------------------|--------------------|------------|----------------------|----------------------|
| B1 | Phase 0 | `FileNotFoundError` on boot | Hardcoded dev machine paths in `kernel_d.py` | Implement relative path discovery using `os.path` | Kernel starts and mounts audit log |
| B2 | Phase 11 | `npm run dev` fails | Frontend dependencies not installed | Execute `npm install` in root | `npm list` shows no unmet dependencies |
| B3 | Phase 3, 12 | 404 on login / login failure | Dual auth systems (`auth_wall.py` / `admin_auth.py`) not integrated into API | Unify to `admin_auth.py`, delete `auth_wall.py`, implement API endpoints | UI can successfully login and receive JWT |
| B4 | Phase 4 | Connection refused to port 8000 | No main FastAPI entry point exists | Create `src/main_api.py` as central hub | `curl http://localhost:8000/api/system/health` returns 200 |
| B5 | Phase 3 | Credentials rejected | Conflicting default passwords in auth systems | Standardize password to `admin123` (or as defined in `admin_auth.py`) | Operator can log in with documented credential |
| B6 | Phase 8 | Dashboard shows 64% CPU (static) | UI using hardcoded/simulated state variables | Connect UI components to `/api/system/metrics` endpoints | UI metrics change in response to actual system load |
| B7 | Phase 11 | Kill Switch does nothing | No backend handler for `kill.system` action | Implement `@app.post("/api/control/kill")` with system halt logic | Pressing Kill Switch halts system and logs "HALTED" to audit |
| B8 | Phase 1 | Permissions appear granted but fail | UI `useControlPolicy` lacks backend endpoint | Implement `/api/control/policy/{controlId}` with real evaluation | UI buttons reflect actual backend permission status |

# 5. REMEDIATION PHASES (STRICT ORDER)

## R1: Kernel & Environment Bootstrap
- Purpose: Ensure the fundamental system can start.
- Scope: `src/kernel_d.py`, `package.json`.
- Inputs: AMP Blocker 1, 2.
- Outputs: Working kernel, installed node_modules.
- Files Affected: `src/kernel_d.py`.
- Acceptance Criteria: `python src/kernel_d.py` starts without path errors; `npm install` completes.
- Stop Condition: FileNotFoundError persists after path fix.

## R2: API Foundation & Unified Auth
- Purpose: Establish the communication hub and secure entry.
- Scope: `src/main_api.py`, `src/middleware/admin_auth.py`, `src/phase12_auth_wall.py` (deletion).
- Inputs: AMP Blocker 3, 4, 5.
- Outputs: FastAPI server with `/auth/*` endpoints and JWT issuance.
- Files Affected: `src/main_api.py` (New), `src/middleware/admin_auth.py` (Modify), `src/phase12_auth_wall.py` (Delete).
- Acceptance Criteria: Successful login via `POST /auth/login` returns HTTP-only cookie + valid JWT.
- Stop Condition: Auth endpoints return 404 or verify fails under correct credentials.

## R3: Core Service Integration
- Purpose: Connect the UI to the system state and control.
- Scope: `src/main_api.py`, `src/admin_ui_frontend/src/services/api.ts`.
- Inputs: AMP Blocker 8.
- Outputs: Implementation of `/api/system/*`, `/api/control/policy/*`.
- Files Affected: `src/main_api.py`, `src/admin_ui_frontend/src/services/api.ts`.
- Acceptance Criteria: UI successfully fetches system status from backend on load.
- Stop Condition: Backend policy evaluation allows unauthorized access.

## R4: Real State & Control Implementation
- Purpose: Replace all fakes with system truth and enable emergency controls.
- Scope: `src/main_api.py`, `src/admin_ui_frontend/src/AtlasUI.tsx`.
- Inputs: AMP Blocker 6, 7.
- Outputs: Functioning metrics endpoints, functioning kill switch endpoint.
- Files Affected: `src/main_api.py`, `src/admin_ui_frontend/src/AtlasUI.tsx`.
- Acceptance Criteria: Dashboard metrics update dynamically; Kill Switch halts the system.
- Stop Condition: Static values still present in UI after R4.

# 6. REALITY REPLACEMENT RULES

- Mock Hive Data: All dashboard cards must fetch from `apiService.get('/api/system/state')`.
- Metrics: CPU/Memory/Latency must be sourced from `psutil` (backend) via `/api/system/metrics`.
- Logs: UI event stream must source from `/api/audit/events`.
- Execution Success/Failure: Must be reported via Decision Contracts (UUID, status, reason) signed by the backend.
- UI State: Derived 100% from backend responses; no local "guess" state allowed for system-level indicators.

# 7. WINDSURF EXECUTION CONTRACT

- Files Modified: `src/**/*`, `package.json`, `requirements.txt`.
- Files Not Touched: `docs/antigravity/ATLAS_PROTECTION_SYSTEM_MASTER_PLAN.md` (locked), `AMP_*.md` reports.
- Required Backend Endpoints: `/auth/login`, `/auth/logout`, `/auth/verify`, `/api/system/state`, `/api/system/metrics`, `/api/control/policy`, `/api/control/kill`.
- Required Tests: Pytest for all new API routes; logic verification for path discovery.
- Required Logging: Every API call must emit structured JSON logs to stdout/file per `AGENTS.md`.
- Refusal Conditions: If asked to add a new dashboard tab or a new AI strategy, Windsurf MUST REFUSE.

# 8. VERIFICATION & RE-AUDIT REQUIREMENT

Mandatory Final Step:
1. Windsurf completes R1–R4.
2. Operator triggers AMP Re-Audit Prompt.
3. Success Criteria: PASS — SYSTEM VERIFIED.
4. If Re-Audit returns PARTIAL or FAIL, execution returns to R1 for corrective action.

# 9. STOP RULES

- No new phases may begin until AMP PASS.
- No new features may be added.
- No UI changes may occur (except for wiring fakes to real data).
- Any invariant violation (e.g., introducing a new simulated metric) forces immediate execution halt.
