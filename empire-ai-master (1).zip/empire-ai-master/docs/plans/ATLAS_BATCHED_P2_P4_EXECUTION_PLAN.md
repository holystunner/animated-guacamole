# ATLAS BATCHED P2-P4 EXECUTION PLAN

**Plan ID:** ATLAS-BATCH-001
**Authority:** ATLAS_ENTERPRISE_PRODUCTION_READINESS_PLAN.md / ATLAS_POST_A4_EXECUTION_PLAN.md
**Status:** APPROVED
**Hash-Lock:** 580cc88dd5d2bd3325bce9e4ac4da463e14465075a2a0a1508bb6eefae68c7d0

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🎯 MISSION OBJECTIVE

Authorize and execute the remaining phases of the Atlas Empire production readiness roadmap in a single, batched operation. This plan enforces absolute "Reality Lock" by rectifying repository hygiene, integrating production-grade database schemas, hardening authentication, and certifying the entire system against enterprise verification gates.

P2, P3, and P4 are authorized to execute sequentially within a single Windsurf run.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE P2: REPOSITORY HYGIENE RECLAMATION

**Phase ID:** AE-REMED-P2
**Objective:** Eliminate root directory clutter and enforce "Reality Lock" file structure.

**Explicit Allowed File Operations:**

- **CREATE** directory [docs/archive/execution/](file:///home/lin/Documents/empire-ai/docs/archive/execution/)
- **CREATE** directory [scripts/archive/](file:///home/lin/Documents/empire-ai/scripts/archive/)
- **MODIFY** [Root Directory](file:///home/lin/Documents/empire-ai/)
  - **MOVE** all `PHASE*_EXECUTION_REPORT.*` and `PHASE*_VALIDATION_RESULTS.*` from root to `docs/archive/execution/`.
  - **MOVE** all `fix_*.py`, `test_*.js`, and `deploy_*.sh` from root to `scripts/archive/`.
  - **DELETE** orphan `.txt` status files after verifying they are indexed in reports.

**Explicit Forbidden Actions:**

- Do NOT use mock handlers or simulated state for hygiene verification.
- Do NOT delete canonical project files (README, AGENTS, requirements.txt, etc.).

**Required Verification Gate:**

- **Command:** `ls -F | grep -v / | wc -l`
- **Expected:** File count (excluding directories) <= 15.
- **Must PASS before the next phase begins.**

**Mandatory Report Artifact:** `docs/reports/AE-REMED-P2-EXECUTION.md`
**Stop Condition:** Failure to reach target file count or accidental deletion of canonical files.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE P3: PRODUCTION BACKEND & AUTH INTEGRITY

**Phase ID:** AE-REMED-P3
**Objective:** Replace stubbed licensing/resource counts and harden authentication across backend and Hive UI.

**Explicit Allowed File Operations:**

- **CREATE** [init_enterprise_schema.sql](file:///home/lin/Documents/empire-ai/scripts/db/init_enterprise_schema.sql)
  - Define production schema: `agents`, `assets`, `registries`, `action_audit_log`.
- **MODIFY** [license_manager.py](file:///home/lin/Documents/empire-ai/src/licensing/license_manager.py)
  - Replace stubbed counts with real PostgreSQL queries via `DatabaseManager`.
- **MODIFY** [control_api.py](file:///home/lin/Documents/empire-ai/src/execution/control_api.py)
  - Ensure all database queries for preconditions are verified against the standard schema.
- **MODIFY** [hive-login.html](file:///home/lin/Documents/empire-ai/hive-login.html)
  - Remove hardcoded "admin/admin123" credentials and demo footer text.
  - Wire login button to real `src/auth/` backend endpoints.
- **MODIFY** [hive_backend.py](file:///home/lin/Documents/empire-ai/src/hive_backend.py)
  - Ensure topology data is served from the live PostgreSQL `registries` table rather than local SQLite seed data.

**Explicit Forbidden Actions:**

- Do NOT allow hardcoded `return 0` or any other constant numeric placeholders in `license_manager.py`.
- Do NOT keep any "admin/admin123" default credentials in the UI.
- Do NOT use simulated state for hive cell visualization.

**Required Verification Gate:**

- **Command:** `python3 -c "import asyncio; from src.database import get_database; asyncio.run(get_database().execute(open('scripts/db/init_enterprise_schema.sql').read()))"`
- **Command:** `pytest tests/execution/test_execution_protection.py`
- **Command:** `grep -r "admin123" hive-login.html`
- **Expected:** Empty result.
- **Must PASS before the next phase begins.**

**Mandatory Report Artifact:** `docs/reports/AE-REMED-P3-EXECUTION.md`
**Stop Condition:** SQL execution failures, test failures, or detection of "admin123" in UI source.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE P4: FINAL REALITY LOCK CERTIFICATION

**Phase ID:** AE-REMED-P4
**Objective:** Execute final end-to-end verification gates to certify production readiness.

**Required Verification Gates:**

- **Command:** `python3 scripts/verify`
- **Command:** `bash scripts/verify_production_readiness.sh`
- **Command:** `python3 scripts/ci/forbidden_markers_scan.py .`

**Mandatory Report Artifact:** `docs/reports/AE-REMED-P4-FINAL_CERTIFICATION.md`
**Stop Condition:** Any gate failure or detection of forbidden markers (TODO/mock/stub).

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**Status:** APPROVED
**Execution Mode:** BATCHED
