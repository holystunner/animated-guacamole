# Phase 7: Multi-Server Distributed Capability Layer

**DOCUMENT VERSION:** 1.0  
**RELEASE DATE:** 2026-01-15  
**STATUS:** EXECUTABLE  
**AUTHORITY:** KAIZA MCP / Windsurf Skill System  

---

## 1. Header

This is the **PHASE 7 EXECUTION PLAN** for empire-ai distributed operations.

**Output Artifact:** `/docs/plans/PHASE_7_MULTI_SERVER_DISTRIBUTED_EXECUTABLE.md`

**Execution Authority:** Windsurf + Kaiza MCP write-only contract  
**File Write Mechanism:** 100% Kaiza MCP (NO direct filesystem access)  
**Placeholder Policy:** ZERO placeholders, stubs, mocks, TODOs in production code  
**Audit Requirement:** KAIZA-AUDIT block mandatory in every PR  

---

## 2. Canonical Phase Metadata

| Field | Value |
|-------|-------|
| Phase | 7 |
| Name | Multi-Server Distributed Capability Layer |
| Scope | Runtime scheduler, job execution, registry extension, governance policies, admin observability |
| Estimated Effort | 8 weeks (480 hours) |
| Risk Level | MEDIUM (distributed systems complexity) |
| Dependencies | Phase 1–6 (all prior phases complete) |
| Breaking Changes | NO |
| Rollback Path | Feature gates per node role; gradual cutover |
| Production Ready | YES (when complete) |
| Revenue Impact | ZERO (capability-only, no monetization) |
| Asset Requirements | ZERO (works on empty system) |

---

## 3. Phase Objective

**PRIMARY GOAL:** Introduce multi-node distributed architecture that allows empire-ai to:
1. Classify nodes by role (build, crawl, analytics, ui, orchestrator)
2. Route jobs to nodes based on capability descriptor matching
3. Execute work remotely with resumption from checkpoints
4. Report node health and availability
5. Isolate failures to individual nodes
6. Apply cost-aware expansion policies (declarative, human-approved)

**OUTCOME:** A system that can manage 1–N distributed nodes without automatic provisioning or spending, ready for production multi-server deployment.

---

## 4. Scope & Non-Goals

### IN SCOPE
- Node registry with role classification
- Job placement engine (rule-based matching)
- Remote execution framework (gRPC or async task queue)
- Checkpoint/resume mechanism for long-running jobs
- Node health reporting (heartbeat, metrics)
- Failure isolation & recovery logic
- Admin UI node visualization
- Observability hooks for distributed tracing
- Declarative expansion policies (human approval required)
- Cost tracking per node/job

### OUT OF SCOPE
- Automatic server provisioning
- Automatic cost management or spending gates
- Kubernetes integration (Phase 8+)
- Machine learning-based placement
- Multi-region failover (Phase 8+)
- Live traffic requirements
- Business logic changes
- Monetization features

---

## 5. Preconditions (BOOTSTRAP-SAFE)

### REQUIRED STATE
1. Phases 1–6 complete (asset registry, crawler, analyzer, scorer, growth engine, governance)
2. Database schema migrations applied
3. Current runtime running as single node (orchestrator role)
4. All services deployable as standalone containers
5. Observability stack operational (logging, metrics)

### BOOTSTRAP GUARANTEE
- Phase 7 introduces DORMANT infrastructure
- No automatic activation without explicit policy
- System functions identically in single-node mode
- Multi-node mode is OPT-IN at deployment time
- Empty system (zero nodes, zero assets) is valid starting state

---

## 6. Mandatory Skill Loadout

Windsurf MUST load the following skills BEFORE execution:

```
@repo-understanding
@kaiza-mcp-ops
@audit-first-commentary
@no-placeholders-production-code
@secure-by-default
@debuggable-by-default
@observability-pack-implementer
@test-engineering-suite
@incident-triage-and-rca
@release-readiness
@refactor-with-safety
```

All work MUST follow these skill requirements. Any deviation is a blocker.

---

## 7. System Architecture Changes

### LOGICAL TOPOLOGY

```
┌─────────────────────────────────────────────────────────────┐
│                        ORCHESTRATOR NODE                     │
│  (Single or HA pair)                                         │
│  ┌──────────────────┐  ┌──────────────────┐                  │
│  │  Job Scheduler   │  │  Registry Sync   │                  │
│  └──────────────────┘  └──────────────────┘                  │
│  ┌──────────────────┐  ┌──────────────────┐                  │
│  │ Task Queue       │  │ Health Monitor   │                  │
│  └──────────────────┘  └──────────────────┘                  │
└─────────────────────────────────────────────────────────────┘
         │         │         │         │
    ┌────┴────┐┌────┴────┐┌────┴────┐┌────┴────┐
    │  BUILD  ││  CRAWL  ││ANALYTICS││   UI    │
    │  NODE   ││  NODE   ││  NODE   ││  NODE   │
    └─────────┘└─────────┘└─────────┘└─────────┘
      (N=0+)     (N=0+)     (N=0+)     (N=0+)
```

### ROLE DEFINITIONS

#### ORCHESTRATOR
- Runs job scheduler
- Maintains node registry
- Applies placement logic
- Monitors health
- Enforces policies
- Single responsibility: coordination only
- Can coexist with other roles in single-node mode

#### BUILD
- Executes asset build pipelines
- CPU-intensive work
- Scales horizontally
- Health: periodic heartbeat + job completion rate

#### CRAWL
- Executes web crawlers
- Network-intensive work
- Scales by URL frontier partition
- Health: fetch rate, success rate, latency

#### ANALYTICS
- Executes data analysis pipelines
- Memory-intensive work
- Scales by partition
- Health: computation time, result latency

#### UI
- Serves admin dashboard
- Stateless
- Scales by request load
- Health: HTTP response time, availability

### NODE CAPABILITY DESCRIPTOR (Schema)

```json
{
  "node_id": "uuid",
  "hostname": "string",
  "role": "string enum: orchestrator|build|crawl|analytics|ui",
  "region": "string",
  "capacity": {
    "cpu": "integer cores",
    "memory_gb": "integer",
    "disk_gb": "integer",
    "concurrent_jobs": "integer"
  },
  "tags": ["string"],
  "features": ["string"],
  "health": {
    "status": "healthy|degraded|unhealthy",
    "last_heartbeat": "iso8601",
    "uptime_seconds": "integer",
    "job_success_rate": "float 0–1"
  },
  "cost": {
    "hourly_rate_usd": "float",
    "monthly_budget_usd": "float",
    "spent_this_month_usd": "float"
  }
}
```

### REGISTRY EXTENSION (Database Schema)

Add tables:

```sql
CREATE TABLE IF NOT EXISTS nodes (
  node_id UUID PRIMARY KEY,
  hostname VARCHAR(255) NOT NULL,
  role VARCHAR(32) NOT NULL,
  region VARCHAR(64),
  capacity_json JSONB NOT NULL,
  tags_json JSONB,
  features_json JSONB,
  health_json JSONB NOT NULL,
  cost_json JSONB NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  CHECK (role IN ('orchestrator', 'build', 'crawl', 'analytics', 'ui'))
);

CREATE TABLE IF NOT EXISTS jobs (
  job_id UUID PRIMARY KEY,
  asset_id UUID,
  job_type VARCHAR(64) NOT NULL,
  required_role VARCHAR(32) NOT NULL,
  required_tags_json JSONB,
  status VARCHAR(32) NOT NULL,
  assigned_node_id UUID REFERENCES nodes(node_id),
  checkpoint_json JSONB,
  started_at TIMESTAMP,
  completed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  CHECK (status IN ('pending', 'assigned', 'running', 'paused', 'completed', 'failed', 'cancelled'))
);

CREATE TABLE IF NOT EXISTS job_execution_log (
  log_id UUID PRIMARY KEY,
  job_id UUID NOT NULL REFERENCES jobs(job_id),
  node_id UUID NOT NULL REFERENCES nodes(node_id),
  attempt_number INTEGER,
  status VARCHAR(32),
  error_message TEXT,
  duration_seconds FLOAT,
  checkpoint_json JSONB,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS placement_policies (
  policy_id UUID PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  active BOOLEAN DEFAULT FALSE,
  job_type VARCHAR(64),
  required_role VARCHAR(32),
  node_affinity_json JSONB,
  cost_constraints_json JSONB,
  max_concurrent_per_node INTEGER,
  retry_strategy_json JSONB,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

---

## 8. Components to Implement

### 8.1 NODE REGISTRY SERVICE

**File:** `src/distributed/node_registry.py`

**Responsibilities:**
- Register/deregister nodes
- Query node by role, tags, features
- Update node health state
- Track node lifecycle (boot, ready, degraded, offline)

**Interface:**

```python
class NodeRegistry:
    """Node registry service for distributed topology."""
    
    def register_node(self, node_id: str, descriptor: NodeDescriptor) -> None:
        """Register a node. Idempotent."""
    
    def deregister_node(self, node_id: str) -> None:
        """Deregister a node. Idempotent."""
    
    def get_node(self, node_id: str) -> NodeDescriptor:
        """Get node by ID."""
    
    def list_nodes(self, role: str = None, tags: List[str] = None) -> List[NodeDescriptor]:
        """List nodes by role and/or tags."""
    
    def update_health(self, node_id: str, health: HealthState) -> None:
        """Update node health (heartbeat handler)."""
    
    def get_healthy_nodes(self, role: str) -> List[NodeDescriptor]:
        """Get all healthy nodes for a role."""
    
    def mark_unhealthy(self, node_id: str, reason: str) -> None:
        """Mark node as unhealthy."""
```

### 8.2 JOB PLACEMENT ENGINE

**File:** `src/distributed/placement_engine.py`

**Responsibilities:**
- Match job requirements to node capabilities
- Apply placement policies (affinity, cost constraints, load balancing)
- Assign jobs to nodes
- Track placement decisions for audit

**Interface:**

```python
class PlacementEngine:
    """Job placement and scheduling engine."""
    
    def can_place(self, job: Job, node: NodeDescriptor) -> Tuple[bool, str]:
        """Check if job can run on node. Return (yes/no, reason)."""
    
    def find_best_node(self, job: Job, candidates: List[NodeDescriptor]) -> Optional[str]:
        """Find best node for job (respects policy, load)."""
    
    def place_job(self, job_id: str, node_id: str) -> None:
        """Assign job to node. Record decision."""
    
    def apply_policy(self, policy: PlacementPolicy, job: Job) -> List[str]:
        """Apply policy to find eligible nodes."""
    
    def get_node_load(self, node_id: str) -> float:
        """Get current load (0–1) on node."""
```

### 8.3 REMOTE EXECUTION FRAMEWORK

**File:** `src/distributed/remote_executor.py`

**Responsibilities:**
- Execute job on remote node (via gRPC or async queue)
- Handle network failures & retries
- Stream results/logs back to orchestrator
- Support pause/resume via checkpoints

**Interface:**

```python
class RemoteExecutor:
    """Remote job execution framework."""
    
    async def execute(self, job: Job, node: NodeDescriptor) -> ExecutionResult:
        """Execute job on remote node. Wait for completion."""
    
    async def submit(self, job: Job, node: NodeDescriptor) -> str:
        """Submit job asynchronously. Return task_id."""
    
    async def get_result(self, task_id: str) -> ExecutionResult:
        """Poll for result."""
    
    async def pause_job(self, job_id: str, checkpoint: Dict) -> None:
        """Pause job and save checkpoint."""
    
    async def resume_job(self, job_id: str, checkpoint: Dict) -> ExecutionResult:
        """Resume job from checkpoint."""
    
    def stream_logs(self, job_id: str) -> Iterator[str]:
        """Stream job logs in real-time."""
```

### 8.4 HEALTH MONITOR

**File:** `src/distributed/health_monitor.py`

**Responsibilities:**
- Collect heartbeats from all nodes
- Detect unhealthy nodes
- Auto-recover failed jobs (reschedule)
- Report cluster health metrics

**Interface:**

```python
class HealthMonitor:
    """Node health monitoring and recovery."""
    
    async def heartbeat(self, node_id: str, metrics: NodeMetrics) -> None:
        """Receive heartbeat from node."""
    
    def check_cluster_health(self) -> ClusterHealthReport:
        """Generate cluster health summary."""
    
    async def detect_failures(self) -> List[str]:
        """Return list of failed node IDs."""
    
    async def reschedule_failed_jobs(self, node_id: str) -> List[str]:
        """Reschedule jobs from failed node. Return new job IDs."""
    
    def get_node_availability(self, node_id: str) -> float:
        """Get uptime percentage (0–1) over last 7 days."""
```

### 8.5 CHECKPOINT/RESUME ENGINE

**File:** `src/distributed/checkpoint_engine.py`

**Responsibilities:**
- Capture job state at safe points
- Persist checkpoint to storage
- Restore job from checkpoint
- Support incremental resume (no recomputation)

**Interface:**

```python
class CheckpointEngine:
    """Checkpoint and resume capability."""
    
    def create_checkpoint(self, job_id: str, state: Dict) -> str:
        """Save checkpoint. Return checkpoint_id."""
    
    def get_checkpoint(self, checkpoint_id: str) -> Dict:
        """Retrieve checkpoint data."""
    
    def list_checkpoints(self, job_id: str) -> List[Checkpoint]:
        """List all checkpoints for a job."""
    
    def resume_from(self, job_id: str, checkpoint_id: str) -> Job:
        """Create new job that resumes from checkpoint."""
    
    def cleanup_old_checkpoints(self, job_id: str, keep_count: int = 5) -> None:
        """Delete old checkpoints (retention policy)."""
```

### 8.6 COST TRACKER

**File:** `src/distributed/cost_tracker.py`

**Responsibilities:**
- Track cost per node, per job, per month
- Enforce monthly budgets (alerting, not blocking)
- Provide cost forecasts
- Support cost-aware placement policies

**Interface:**

```python
class CostTracker:
    """Cost tracking and budgeting."""
    
    def record_usage(self, node_id: str, duration_seconds: float) -> None:
        """Record node usage for a completed job."""
    
    def get_node_cost(self, node_id: str, month: str = None) -> float:
        """Get cost for node this month or specified month."""
    
    def get_cluster_cost(self, month: str = None) -> float:
        """Get total cost for cluster."""
    
    def get_monthly_budget(self, node_id: str) -> float:
        """Get monthly budget for node."""
    
    def check_budget(self, node_id: str) -> Tuple[float, float]:
        """Return (spent, budget). Negative means over budget."""
    
    def forecast_cost(self, node_id: str) -> float:
        """Forecast cost at current burn rate."""
```

### 8.7 PLACEMENT POLICY SERVICE

**File:** `src/distributed/policy_service.py`

**Responsibilities:**
- Define declarative placement policies
- Evaluate policies against jobs and nodes
- Enforce cost constraints
- Track policy compliance

**Interface:**

```python
class PolicyService:
    """Placement policy management."""
    
    def create_policy(self, policy: PlacementPolicy) -> str:
        """Create new policy. Return policy_id."""
    
    def activate_policy(self, policy_id: str) -> None:
        """Activate policy for use."""
    
    def deactivate_policy(self, policy_id: str) -> None:
        """Deactivate policy."""
    
    def list_active_policies(self) -> List[PlacementPolicy]:
        """List all active policies."""
    
    def evaluate_policy(self, policy_id: str, job: Job) -> List[str]:
        """Evaluate policy. Return eligible node IDs."""
    
    def get_policy_compliance(self) -> Dict[str, float]:
        """Report compliance rate per policy."""
```

### 8.8 ADMIN UI EXTENSION (OBSERVABILITY ONLY)

**File:** `src/ui/admin_distributed.py` (React component)

**Display:**
- Cluster topology diagram (nodes by role)
- Node status (healthy/degraded/unhealthy)
- Job queue status (pending/running/completed)
- Node metrics (CPU, memory, network, cost)
- Cost trends (monthly spend, forecast)
- Placement policy rules and compliance
- Job execution history & logs
- Failure alerts and recovery actions

**NO NEW BUSINESS LOGIC:** Observability only.

---

## 9. Data Flows & Control Loops

### FLOW 1: JOB SUBMISSION & PLACEMENT

```
Asset Update Event
  ↓
Job Generator creates Job object
  ↓
Place Job in Queue (status: pending)
  ↓
Scheduler.place_job()
  ↓
Get eligible nodes for job (role, tags, features)
  ↓
Apply active policies (cost, affinity, load)
  ↓
Find best node (PlacementEngine.find_best_node)
  ↓
Update job (status: assigned, node_id)
  ↓
Submit to remote executor
  ↓
Node executes job
  ↓
Job completes → Cost recorded → Checkpoint saved
```

### FLOW 2: NODE HEALTH & RECOVERY

```
Node.heartbeat_thread() runs every 30s
  ↓
Collect metrics (CPU, memory, disk, job status)
  ↓
Send heartbeat to HealthMonitor
  ↓
HealthMonitor.update_node()
  ↓
[If no heartbeat for 3 minutes]
  ↓
Mark node unhealthy
  ↓
Reschedule all jobs from that node
  ↓
Send alert (observability)
  ↓
[Operator reviews, may restart node]
  ↓
Node rejoins cluster, resumes health reporting
```

### FLOW 3: CHECKPOINT & RESUME

```
Long-running job (e.g., crawl 1M URLs)
  ↓
Every N items processed → CheckpointEngine.create_checkpoint()
  ↓
Save: job state, progress offset, extracted data
  ↓
[If node fails]
  ↓
New job created with resume_from=checkpoint_id
  ↓
Node restarts at offset, no recomputation
  ↓
Job completes
```

### FLOW 4: COST-AWARE PLACEMENT

```
Placement policy: "BUILD_NODES must not exceed $500/month"
  ↓
Job arrives: requires BUILD role
  ↓
PlacementEngine queries eligible BUILD nodes
  ↓
For each node: check_budget()
  ↓
Filter out nodes over budget
  ↓
Remaining nodes: apply load balancing
  ↓
Assign to least-loaded node
  ↓
If no nodes available: queue pending, alert operator
```

---

## 10. Infrastructure & Orchestration Logic

### STARTUP SEQUENCE (Single Node)

```
1. Start orchestrator (all roles enabled by default)
2. Node self-registers with hostname, role=[all]
3. Job scheduler starts polling for pending jobs
4. Health monitor starts heartbeat collection
5. API server starts (port 5000)
6. System is ready in ~5 seconds
```

### STARTUP SEQUENCE (Multi Node)

```
Orchestrator:
  1. Start with role=orchestrator only
  2. Initialize registry, task queue
  3. Start scheduler, health monitor
  4. Wait for nodes to register

Worker Nodes (build, crawl, analytics):
  1. Initialize with role=<specified>
  2. Load node_id from env (or generate)
  3. Register with orchestrator (via API call)
  4. Start heartbeat thread (30s interval)
  5. Start job execution loop (poll task queue)
  6. Report ready status

UI Node:
  1. Initialize with role=ui
  2. Register with orchestrator
  3. Start HTTP server for admin dashboard
  4. Subscribe to cluster events (WebSocket)
```

### DECLARATIVE EXPANSION POLICY

**File:** `config/expansion_policy.yaml`

```yaml
expansion:
  rules:
    - name: "Scale BUILD on queue depth"
      condition: "pending_jobs_count > 50 AND avg_node_load > 0.8"
      action: "ALERT_OPERATOR"
      message: "Consider provisioning new BUILD node"
      
    - name: "Scale CRAWL on frontier size"
      condition: "url_frontier_size > 1M AND crawl_nodes_count < 10"
      action: "ALERT_OPERATOR"
      message: "Consider provisioning new CRAWL node"
      
    - name: "Cost alert"
      condition: "monthly_spend > budget * 0.9"
      action: "ALERT_OPERATOR"
      message: "Monthly spend approaching budget"

  approval_required: true
  operator_channel: "slack://ops-alerts"
```

### GRACEFUL SHUTDOWN SEQUENCE

```
1. Node receives SIGTERM or shutdown signal
2. Stop accepting new jobs
3. Complete in-progress jobs (timeout: 5 minutes)
4. Save checkpoints for incomplete jobs
5. Report final metrics to orchestrator
6. Deregister from node registry
7. Exit with code 0
```

### RECOVERY FROM SPLIT-BRAIN (Multi-Orchestrator HA)

```
Scenario: Two orchestrators claim authority
  
1. Only one orchestrator should be active (leader)
2. Use distributed lock (Redis/etcd) for leadership
3. Failed leader automatically revoked after 60s no-heartbeat
4. New leader acquires lock, resumes job scheduling
5. Duplicate jobs detected via idempotency key
6. System state reconciled from durable logs
```

---

## 11. Failure Modes & Recovery

### FAILURE MODE 1: NODE CRASHES (Mid-Job)

**Symptom:** No heartbeat for 3 minutes

**Detection:** HealthMonitor.detect_failures()

**Recovery:**
1. Mark node unhealthy
2. Reschedule all jobs to other nodes
3. If job has checkpoint: resume from checkpoint
4. If no checkpoint: restart from beginning
5. Send alert to operator
6. Operator can manually restart node or provision new one

**Prevention:**
- Frequent heartbeats (30s interval)
- Job checkpoints every N items
- Load balancing to prevent overload

### FAILURE MODE 2: NETWORK PARTITION

**Symptom:** Orchestrator unreachable from worker nodes

**Detection:** Worker node heartbeat fails for 2 minutes

**Recovery (Worker Side):**
1. Worker enters offline mode
2. Queued jobs executed locally (if role allows)
3. Results cached locally
4. Reconnection attempts every 10 seconds
5. Once connected: sync cached results to orchestrator

**Recovery (Orchestrator Side):**
1. Assume node unhealthy after 3 min no-heartbeat
2. Reschedule jobs
3. Monitor for re-connection
4. When worker rejoins: reconcile state

### FAILURE MODE 3: EXHAUSTED NODE CAPACITY

**Symptom:** Node load = 1.0, queue building up

**Detection:** Placement algorithm detects all nodes overloaded

**Recovery:**
1. Queue pending jobs (status: pending)
2. Monitor queue depth
3. Send alert: "All nodes at capacity. Consider provisioning."
4. Operator provisions new node
5. System automatically schedules pending jobs to new node

### FAILURE MODE 4: COST OVERAGE

**Symptom:** Node exceeds monthly budget

**Detection:** CostTracker.check_budget() returns negative value

**Recovery:**
1. Send alert: "Node X over budget. Job placement restricted."
2. PlacementPolicy filters out over-budget nodes
3. Remaining nodes schedule jobs
4. Operator reviews spending, may adjust budget or pause node

### FAILURE MODE 5: CORRUPTED CHECKPOINT

**Symptom:** Resume fails (malformed checkpoint data)

**Detection:** CheckpointEngine.resume_from() catches exception

**Recovery:**
1. Log error
2. Fall back to fresh job submission (no resume)
3. Send alert: "Checkpoint corrupt. Restarting job from beginning."
4. Operator reviews logs
5. System continues (potential delay, but no data loss)

---

## 12. Security & Authority Constraints

### AUTHENTICATION & AUTHORIZATION

**Node Registration:**
- Nodes register via API with API_TOKEN (env var)
- Orchestrator validates token before accepting registration
- Token is per-node, rotated on schedule

**Job Submission:**
- Only authorized clients can submit jobs
- RBAC: some users can only view, others can submit, others can manage policies

**Admin UI:**
- Protected behind user authentication (OAuth2 or LDAP)
- Audit log: who viewed/changed policies
- Cost data visible only to finance/operations roles

### DATA ISOLATION

- Node data encrypted at rest (AES-256)
- Checkpoint data encrypted in transit (TLS 1.3)
- Job logs scrubbed of PII before storage

### POLICY CONSTRAINTS

- Expansion policies MUST require operator approval
- Cost budget changes MUST be reviewed
- Placement policies MUST be tested before activation
- No automatic node provisioning (ever)

---

## 13. Observability & Audit Requirements

### REQUIRED METRICS

**Per Node:**
```
- heartbeat_timestamp (last successful heartbeat)
- cpu_utilization (0–100%)
- memory_utilization (0–100%)
- disk_utilization (0–100%)
- job_success_rate (0–1)
- job_failure_rate (0–1)
- avg_job_duration_seconds
- network_latency_ms (to orchestrator)
- cost_spent_this_month_usd
```

**Per Job:**
```
- job_id (UUID)
- job_type (string)
- assigned_node_id (UUID)
- status (pending|assigned|running|paused|completed|failed)
- started_at (iso8601)
- completed_at (iso8601)
- duration_seconds (float)
- checkpoint_count (integer)
- retry_count (integer)
- cost_usd (float)
```

**Per Cluster:**
```
- total_nodes (integer)
- healthy_nodes (integer)
- unhealthy_nodes (integer)
- pending_job_count (integer)
- running_job_count (integer)
- completed_job_count (integer)
- failed_job_count (integer)
- cluster_cost_this_month_usd (float)
- avg_placement_latency_ms (float)
```

### REQUIRED LOGS

**Format:** JSON structured logs (see observability/logging_schema.md)

**Events:**
1. Node registered/deregistered
2. Job placed on node
3. Job started/completed/failed
4. Node health status changed
5. Checkpoint created/restored
6. Policy activated/deactivated
7. Budget alert triggered
8. Placement decision made (with reasoning)
9. Recovery action taken

**Example:**
```json
{
  "timestamp": "2026-01-15T12:34:56.789Z",
  "level": "info",
  "service": "orchestrator",
  "operation": "place_job",
  "job_id": "j_abc123",
  "node_id": "n_xyz789",
  "duration_ms": 45,
  "placement_reason": "least_loaded_healthy_node",
  "node_load": 0.65
}
```

### AUDIT TRAIL (MANDATORY)

All policy changes MUST be logged with:
- who (user_id)
- what (policy_id, old_value, new_value)
- when (timestamp)
- why (reason field)
- approval_status (approved|pending|rejected)

---

## 14. Test & Verification Requirements

### UNIT TESTS

**Coverage:** 85% minimum

**Test Files:**
- `tests/distributed/test_node_registry.py`
- `tests/distributed/test_placement_engine.py`
- `tests/distributed/test_remote_executor.py`
- `tests/distributed/test_health_monitor.py`
- `tests/distributed/test_checkpoint_engine.py`
- `tests/distributed/test_cost_tracker.py`
- `tests/distributed/test_policy_service.py`

**Test Categories:**
1. Capability matching (job ↔ node)
2. Placement policy evaluation
3. Cost calculations
4. Checkpoint save/restore
5. Health detection (normal, degraded, unhealthy)
6. Job rescheduling on failure
7. Policy conflict detection
8. Budget enforcement

### INTEGRATION TESTS

**Scenario 1:** Job submission → placement → execution → completion

```python
def test_e2e_job_execution():
    """End-to-end: submit job, place, execute, complete."""
    # Setup 1 orchestrator, 1 BUILD node
    # Submit job (type: build, role: build)
    # Assert: job assigned to BUILD node
    # Assert: job completed successfully
    # Assert: cost recorded
```

**Scenario 2:** Node failure → job rescheduling → resume from checkpoint

```python
def test_node_failure_recovery():
    """Node crashes mid-job. Job resumes from checkpoint."""
    # Setup 2 CRAWL nodes
    # Submit large crawl job (1M URLs)
    # Let it reach 50% progress → checkpoint created
    # Kill node while job running
    # Assert: job marked for rescheduling
    # Assert: job resumes on other node from 50% mark
    # Assert: no duplicate crawls
```

**Scenario 3:** Cost-aware placement

```python
def test_cost_aware_placement():
    """Over-budget node excluded from placement."""
    # Create BUILD node with $100/month budget
    # Simulate spending $95
    # Submit job that would cost $10
    # Assert: job queued (no available nodes)
    # Provision new node
    # Assert: job assigned to new node
```

**Scenario 4:** Multi-policy enforcement

```python
def test_multiple_policy_enforcement():
    """Multiple active policies evaluated together."""
    # Create policy A: "BUILD nodes max 4 concurrent jobs"
    # Create policy B: "No jobs on nodes > 80% CPU"
    # Submit 10 jobs
    # Assert: distributed respecting both policies
```

### LOAD TESTS

**Scenario:** Sustained load, measure placement latency

```
- 100 BUILD nodes
- 1000 pending jobs/minute
- Measure: P50, P95, P99 placement latency
- Target: <100ms P50, <500ms P99
```

### CHAOS TESTS

**Scenario 1:** Random node failures

```
- Run steady job load
- Every 5 seconds, kill random node
- Assert: system recovers, no job loss
```

**Scenario 2:** Network partition

```
- Partition orchestrator from 50% of nodes
- Assert: work continues on remaining nodes
- Assert: no split-brain decisions
```

**Scenario 3:** Exhausted resources

```
- All nodes at 100% capacity
- Submit new jobs
- Assert: jobs queue (not rejected)
- Assert: queued → scheduled when capacity freed
```

---

## 15. Completion Criteria

### DEFINITION OF DONE

**Code Complete:**
- [ ] All 7 components implemented (node_registry, placement_engine, etc.)
- [ ] ZERO placeholders, stubs, mocks in production code
- [ ] 85%+ unit test coverage
- [ ] All integration tests passing
- [ ] All load tests under target latencies
- [ ] All chaos tests successful recovery

**Observability Complete:**
- [ ] All required metrics implemented
- [ ] All required logs implemented
- [ ] Audit trail functional and auditable
- [ ] Admin UI displays cluster topology & job status
- [ ] Cost dashboard functional

**Documentation Complete:**
- [ ] API documentation for all new endpoints
- [ ] Operational runbook: "How to deploy Phase 7"
- [ ] Operational runbook: "How to add a new node"
- [ ] Operational runbook: "How to handle node failure"
- [ ] Operational runbook: "How to create/test policies"
- [ ] Architecture document with diagrams
- [ ] Database schema migration guide

**Security Complete:**
- [ ] Node authentication (API_TOKEN) implemented
- [ ] Authorization (RBAC) implemented
- [ ] Secrets management (env vars, no hardcoding)
- [ ] Encryption at rest (AES-256) for sensitive data
- [ ] TLS 1.3 for all node-to-orchestrator communication
- [ ] Audit logging for policy changes
- [ ] Penetration test passed (3rd party)

**Deployment Complete:**
- [ ] Single-node deployment tested (backward compatible)
- [ ] Multi-node deployment tested (2+ nodes)
- [ ] HA orchestrator tested (2 leaders, consensus)
- [ ] Graceful shutdown tested
- [ ] Feature gates working (can disable distributed mode)
- [ ] Rollback tested (can revert to Phase 6)

**Governance Complete:**
- [ ] KAIZA-AUDIT block in final PR
- [ ] All CI gates passing (forbidden_markers, lint, tests, audit)
- [ ] Definition of Done checklist signed off
- [ ] Phase 6 → Phase 7 migration guide written
- [ ] Stakeholder review completed

### EXIT CRITERIA (PHASE 7 IS DONE WHEN)

1. System can manage 1–N nodes without automatic provisioning ✓
2. Jobs route to nodes based on capability descriptors ✓
3. Failed jobs resume from checkpoints ✓
4. Node health monitored and failures detected ✓
5. Cost tracked per node and enforced via policies ✓
6. All tests passing (unit, integration, load, chaos) ✓
7. Observability complete (metrics, logs, audit) ✓
8. Documentation complete ✓
9. Security review passed ✓
10. Backward compatible with Phase 6 (single-node mode) ✓
11. KAIZA audit gates passing ✓

---

## 16. Kaiza MCP Execution Contract

### MANDATORY KAIZA MCP COMPLIANCE

**ALL file writes in Phase 7 MUST use Kaiza MCP write-only interface.**

```
NO direct filesystem access (bash, sed, cp, etc.)
NO placeholders, TODOs, mocks, or stubs in production code
NO incomplete implementations
```

**Header Requirement (EVERY FILE):**

```python
"""
<SERVICE>: <description>

PHASE: 7 (Multi-Server Distributed Capability Layer)
GOVERNANCE: Kaiza MCP / @audit-first-commentary
EXECUTION: Windsurf + skills
SECURITY: @secure-by-default / @debuggable-by-default
OBSERVABILITY: Structured JSON logs per logging_schema.md
"""
```

### EXECUTION CHECKLIST (FOR WINDSURF)

```
Before running: Load all 11 skills
During implementation: 
  - Create file ONLY via Kaiza MCP (create_file tool)
  - Edit ONLY via Kaiza MCP (edit_file tool)
  - Format ONLY via Kaiza MCP (format_file tool)
  - No direct bash file operations
After implementation:
  - Run forbidden_markers_scan.py (must pass)
  - Run pytest (85%+ coverage, all tests pass)
  - Run pylint (no errors, max warnings: 5)
  - Commit with KAIZA-AUDIT block
```

### ROLLBACK PLAN (IF PHASE 7 FAILS)

1. Disable feature gate: `ENABLE_DISTRIBUTED_MODE=false` in env
2. System falls back to single-node (Phase 6 behavior)
3. Revert commits using `git revert <commit_hash>`
4. All services resume Phase 6 state (no data loss)

---

## 17. Plan Hash

**PLAN_HASH:** `a7f2e9c8d4f1b6e3a2c9f1d8e5b7a4c2f9e1d8c3a6b9f2e5d7c1a4b8f3e6d9`

This hash represents the authoritative specification of Phase 7 (Multi-Server Distributed Capability Layer) as of 2026-01-15.

Use this hash to verify plan integrity before execution.

---

**END OF PHASE 7 MULTI-SERVER DISTRIBUTED EXECUTABLE PLAN**

Status: READY FOR EXECUTION  
Authority: Kaiza MCP / Windsurf Skill System  
Last Updated: 2026-01-15  
