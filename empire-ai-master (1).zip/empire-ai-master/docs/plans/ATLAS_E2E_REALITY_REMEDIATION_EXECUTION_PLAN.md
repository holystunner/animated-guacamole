# ATLAS E2E REALITY REMEDIATION EXECUTION PLAN

**STATUS**: APPROVED
**PLAN HASH (Stable Content)**: 1ad28c06090bc582c2af1da03151db677efe532057aa0de2d4f18eebd2cf38a4
**VERIFICATION**: `sed -n '9,$p' docs/plans/ATLAS_E2E_REALITY_REMEDIATION_EXECUTION_PLAN.md | sha256sum`
**AUTHORITY HASH**: 15d31c09f9e9bb71b7446860fbb23a1e6f6ee4e2e66b98da3f5cd125b4bc0ae9 (Inputs Verified)
**SUPERVISOR**: KAIZA MCP
**DATE**: 2026-01-21

---

## 0. GLOBAL GOVERNANCE REQUIREMENTS (LAW)

### 4.1 Zero-Mock Reality Law

Execution MUST NOT introduce or retain any hardcoded UI values, seeded demo data, simulated metrics, or heuristic formulas. Any detection of mock behavior renders the execution INVALID.

### 4.2 Authentication Integrity Law

Authentication MUST use real identity storage and gate UI render BEFORE pixels display. Auth illusion or audit-log-only inference for identity is FORBIDDEN.

### 4.3 Hive UI Truth Law

Every Hive UI element MUST bind to live backend data with proof of freshness (timestamp/source). Synthetic UI or simulated success signals are FORBIDDEN.

### 4.4 Failure Semantics Law

ALL failures MUST hard-stop execution, emit a stable error code, and identify the violated invariant. Silent failure (except: pass) is FORBIDDEN.

### 4.5 Debuggability & Audit Law

For EVERY file created or modified, a `<file>.intent.md` MUST exist. Failure MUST emit structured debug evidence auditable by non-coders.

---

## 1. REMEDIATION PHASES

### Phase R-1: Frontend Build Integrity

- **Objective**: Repair the corruption in the authentication gating logic.
- **Actions**:
  - MODIFY `src/admin_ui_frontend/src/components/policy/ControlRegistry.tsx` to fix syntax error on Line 13.
- **Verification**: `npm run build` MUST succeed.

### Phase R-2: Backend Zero-Mock Enforcement

- **Objective**: Remove hardcoded assets and heuristic metric functions.
- **Actions**:
  - MODIFY `src/db.py`: Remove `_seed_default_data` assets Page A/Tool B.
  - MODIFY `src/db.py`: Replace heuristic formulas in `_get_basic_health_metrics` with hard-fail if real metrics are unavailable.
- **Verification**: `api/assets` returns empty or real records only.

### Phase R-3: Authentication Reality Correction

- **Objective**: Transition from audit-log inference to canonical identity store.
- **Actions**:
  - CREATE `src/models/operator.py`: Define `Operator` schema.
  - MODIFY `src/db.py`: Implement `operators` table and atomic `operator_exists` query.
- **Verification**: Attempt login with non-existent ID MUST fail with 403.

### Phase R-4: Hive UI Real-Data Binding

- **Objective**: Connect the static grid and gauges to real API endpoints.
- **Actions**:
  - MODIFY `src/admin_ui_frontend/src/AtlasUI.tsx`: Re-wire `SystemsGrid` to fetch from `api/system/clusters`.
  - MODIFY `src/admin_ui_frontend/src/AtlasUI.tsx`: Re-wire Gauges to use `metrics.cpu_percent` instead of index `i`.
- **Verification**: Browser verification of DOM against API response.

### Phase R-5: Audit Schema & Causality Repair

- **Objective**: Add mandatory human-readable intent to all system mutations.
- **Actions**:
  - MODIFY `src/db.py`: Update `audit_events` schema to include `audit_msg`.
  - MODIFY `src/main_api.py`: Ensure every `write_audit_event` call includes a descriptive `audit_msg`.
- **Verification**: `sqlite3 empire_ai.db "SELECT audit_msg FROM audit_events"` returns non-empty strings.

### Phase R-6: Playwright E2E Verification

- **Objective**: Verify end-to-end reality via browser automation.
- **Actions**:
  - CREATE `tests/reality/e2e_compliance.spec.ts`: Playwright test asserting 0% mock data in `SystemsGrid`.
- **Verification**: `npx playwright test`.

### Phase R-7: Puppeteer UI Truth Verification

- **Objective**: Deep DOM/Network inspection for illusion detection.
- **Actions**:
  - CREATE `scripts/verify_ui_reality.js`: Puppeteer script to detect hardcoded values in DOM compared to API.
- **Verification**: Script execution returns zero violations.

---

## 2. STOP CONDITIONS

1. Detection of ANY mock behavior (`Math.random`, `TODO`, `FIXME`).
2. Missing `<file>.intent.md` for any change.
3. Silent failure in any critical path.
4. Build failure in Phase R-1.

---

## 3. IMMUTABILITY NOTICE

This blueprint is canonicalized and APPROVED. No further modifications are permitted without a new audit session.
