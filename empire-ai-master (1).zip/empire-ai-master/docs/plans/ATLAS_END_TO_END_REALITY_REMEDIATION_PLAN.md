# ATLAS PRODUCTION EXECUTION BLUEPRINT

**PLAN HASH**: 799a18b2a7eeaa37d397a0e58230589c2d6158fcda05ac78bfdf9a8adc1700d7
**STATUS**: APPROVED
**GOVERNANCE**: KAIZA MCP
**SCOPE**: ATLAS EMPIRE PROJECT (FULL REPO)

---

# ATLAS END-TO-END REALITY REMEDIATION BLUEPRINT

**STATUS**: APPROVED
**GOVERNANCE**: KAIZA MCP
**SCOPE**: ATLAS EMPIRE PROJECT (FULL REPO)

---

## 0. MANDATORY GOVERNANCE LAW (NON-NEGOTIABLE)

### 0.1 Zero-Mock Reality Law

Execution MUST NOT introduce or retain any `mock`, `stub`, `placeholder`, `hardcoded credentials`, or `static return values` in functional code. Presence of any such artifact → EXECUTION INVALID.

### 0.2 Authentication Reality Law

Authentication MUST be enforced server-side via a real OIDC provider. Client-side auth simulation or backend hardcoded admin checks → EXECUTION INVALID.

### 0.3 Data Reality Law

All UI state MUST derive exclusively from real backend APIs. UI-initialized or simulated backend state → EXECUTION INVALID.

### 0.4 Hard-Error Semantics

All failures MUST hard-stop execution, emit a stable error code, identify the violated invariant, and attribute failure to a specific component. Silent failure → EXECUTION INVALID.

### 0.5 Mandatory Intent Artifacts

For EVERY file created or modified, a corresponding `<file>.intent.md` MUST exist explaining purpose, invariants, failure modes, and debug signals. Missing intent artifact → EXECUTION INVALID.

---

## 1. REMEDIATION PHASES

### Phase R1: Zero-Mock Eradication

- **Objective**: Structural removal of all mock/stub logic across the entire source tree.
- **Allowed Operations**:
  - `MODIFY` all files in `src/` to replace mock logic with real implementations or hard-fail pathways.
- **Forbidden Actions**:
  - Retaining any line containing `mock`, `stub`, or `placeholder` in non-comment code.
- **Governance**: LAW 0.1, 0.4, 0.5.
- **Required Evidence**: `grep` audit report showing 0 hits for forbidden patterns in logic.
- **Verification Gates**: `npm run verify` + `scripts/verify_reality.sh`.

### Phase R2: OIDC Identity Lock

- **Objective**: Replacing hardcoded `admin` pathways with real OIDC/JWT logic.
- **Allowed Operations**:
  - `MODIFY` `src/main_api.py`, `src/gateway/gateway_pep.py`.
- **Forbidden Actions**:
  - Simulation of auth state in the frontend `AuthContext`.
- **Governance**: LAW 0.2, 0.4, 0.5.
- **Required Evidence**: JWT validation logs and response headers showing real identity signals.
- **Verification Gates**: API test suite with valid OIDC token injection.

### Phase R3: Backend Action Reality

- **Objective**: Forcing real side effects for all system-critical actions.
- **Allowed Operations**:
  - `MODIFY` `src/telemetry/api.py`, `src/distributed/placement_engine.py`, `src/execution/action_envelope.py`.
- **Forbidden Actions**:
  - Static string returns for `COLLAPSE_HIVE`, `SCALE`, `PURGE`.
- **Governance**: LAW 0.3, 0.4, 0.5.
- **Required Evidence**: Database state change logs or infra side-effect traces.
- **Verification Gates**: Integration tests verifying DB state mutability.

### Phase R4: UI Data Integrity

- **Objective**: Forcing the Hive UI to be a pure reflection of backend telemetry.
- **Allowed Operations**:
  - `MODIFY` `src/admin_ui_frontend/src/components/EmpireHiveUI.tsx`, `src/admin_ui_frontend/src/components/state/useHiveState.tsx`.
- **Forbidden Actions**:
  - UI-side `useEffect` loops that initialize or modify state independently of API responses.
- **Governance**: LAW 0.3, 0.4, 0.5.
- **Required Evidence**: Network trace showing UI dependency on Telemetry API.
- **Verification Gates**: Visual regression test + Network log audit.

---

## 2. STOP CONDITIONS (ABSOLUTE)

Execution MUST STOP and Windsurf MUST REFUSE to continue if:

1. Any mock removal is implicit rather than explicit.
2. Auth requirements are bypassed for "developer convenience".
3. An `.intent.md` file is missing for an edit.
4. Any failure is silently swallowed.

---

## 3. AUDITABILITY

This system is auditable by reading ONLY the generated reports and `.intent.md` files. Evidence of truth MUST be embedded in these documents.
