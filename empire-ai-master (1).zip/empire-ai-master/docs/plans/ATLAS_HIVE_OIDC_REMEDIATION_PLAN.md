# ATLAS EMPIRE: HIVE OIDC GATEWAY REMEDIATION PLAN (OPTION A)

## HASH: 2d907543451073e19e02bb55fec3604c665a8da5f5af83321559519a131dc0dc

## STATUS: APPROVED

## SUPERVISOR: KAIZA MCP

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🎯 MISSION OBJECTIVE

Transition the Atlas Empire Hive from a hybrid/ambiguous authentication model to a strict **OIDC Gateway Auth (Option A)** architecture. This plan mandates Keycloak as the sole Identity Authority, enforces OIDC/JWT validation as the only gateway to system pixels, and eliminates all native "Security Theater" auth logic.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE P1: GATEWAY REALITY LOCK (OIDC ALIGNMENT)

**Phase ID:** AE-OIDC-P1
**Objective:** Standardize token validation strictly on Keycloak-issued OIDC/JWT claims and remove native database dependencies for initial validation.

**Explicit File Operations:**

- **MODIFY** [token_validator.py](file:///home/lin/Documents/empire-ai/src/gateway/token_validator.py)
  - Remove direct database calls to `operators` table for `_get_operator` if the JWT is from a trusted issuer and contains sufficient metadata.
  - Enforce `RS256` signature verification using Keycloak's JWKS endpoint as the ONLY trusted source.
  - Ensure `capabilities` and `policy_epoch` claims are extracted strictly from the JWT.
  - Fail-closed on any OIDC/JWKS connectivity issues.

**Explicit Forbidden Actions:**

- Do NOT allow "Bypass" tokens or hardcoded secrets.
- Do NOT use internal database states to override OIDC authority results during the validation phase.

**Required Verification Gates:**

- **Command:** `pytest tests/test_phase4_gateway_pep.py`
- **Expected:** 100% PASS on JWT validation tests.
- **Mandatory Report Artifact:** `docs/reports/AE-OIDC-P1-EXECUTION.md`

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE P2: AUTH API CONVERGENCE (DE-STUBBING)

**Phase ID:** AE-OIDC-P2
**Objective:** Remove all native WebAuthn/TOTP implementation logic from the backend API to resolve Keycloak/Native ambiguity.

**Explicit File Operations:**

- **MODIFY** [auth_endpoints.py](file:///home/lin/Documents/empire-ai/src/api/auth_endpoints.py)
  - **DELETE** all endpoints related to native WebAuthn registration/verification (`/webauthn/register`, `/webauthn/authenticate`).
  - **DELETE** native TOTP verification logic.
  - **CREATE** `/api/v1/auth/session/me` (Session Bootstrap) endpoint that mirrors the current JWT claims to the UI.
  - Refactor `/callback` to be a pure OIDC code-exchange proxy.

**Explicit Forbidden Actions:**

- Do NOT maintain dual-auth paths (Keycloak AND Native).
- Do NOT keep "Stubbed" WebAuthn validation logic in the codebase.

**Required Verification Gates:**

- **Command:** `grep -r "webauthn" src/api/auth_endpoints.py`
- **Expected:** Result limited only to OIDC-related proxying/hints, no registration/verification code.
- **Mandatory Report Artifact:** `docs/reports/AE-OIDC-P2-EXECUTION.md`

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE P3: HIVE UI IDENTITY GATING (NO IDENTITY → NO PIXELS)

**Phase ID:** AE-OIDC-P3
**Objective:** Enforce identity-before-UI-render in the Hive UI (React), ensuring the dashboard is unreachable without a valid OIDC session.

**Explicit File Operations:**

- **MODIFY** [index.tsx](file:///home/lin/Documents/empire-ai/src/admin_ui_frontend/src/index.tsx)
  - Wrap the main application render in an `AuthenticationProvider` or `Gatekeeper` component.
- **MODIFY** [AtlasUI.tsx](file:///home/lin/Documents/empire-ai/src/admin_ui_frontend/src/AtlasUI.tsx)
  - Ensure all data fetching is blocked until the authentication state is confirmed via `/session/me`.
  - Implement immediate redirect to OIDC Provider (Keycloak) on 401/403.

**Explicit Forbidden Actions:**

- Do NOT allow the UI to render "Demo" or "Placeholder" data while waiting for auth.
- Do NOT store JWTs in local storage (session storage or HTTP-only cookies only).

**Required Verification Gates:**

- **Manual Verification:** Verify browser loop redirects to Keycloak when visiting the root path without an active session.
- **Mandatory Report Artifact:** `docs/reports/AE-OIDC-P3-EXECUTION.md`

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE P4: FINAL REALITY LOCK CERTIFICATION

**Phase ID:** AE-OIDC-P4
**Objective:** Terminal verification of the Atlas Empire auth posture.

**Explicit Allowed Operations:**

- **NONE** (Verification and Documentation only)

**Verification Gates:**

- **Command:** `bash scripts/verify`
- **Expected:** 0 violations for "mock", "stub", "placeholder", or "pass" in all auth/gateway modules.
- **Criteria:** `PHASE_P1_IDENTITY` must achieve "AUTH PASS - OIDC ENFORCED" status.

**Mandatory Report Artifact:** `docs/reports/AE-OIDC-FINAL-CERTIFICATION.md`

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🚦 STOP CONDITIONS

- **HALT** if Keycloak (OIDC Provider) cannot be contacted for JWKS retrieval.
- **HALT** if any phase fails its verification gate.
- **HALT** if "Security Theater" (bypass logic) is detected during A4 regression.
- **HALT** if a JWT without `device_verified=true` is accepted for high-value actions.
