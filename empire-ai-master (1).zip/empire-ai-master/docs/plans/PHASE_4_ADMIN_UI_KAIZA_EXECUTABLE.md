---
status: APPROVED
plan_id: PHASE_4_ADMIN_UI_KAIZA_EXECUTABLE
title: Phase 4 Admin UI (KAIZA Executable)
created_by: Antigravity (Planner)
created_date: 2026-01-12
source_inputs:
  - docs/plans/PHASE_4_ADMIN_UI_KAIZA.md
  - docs/plans/PHASE_3_ASSET_RUNTIME_KAIZA_EXECUTABLE.md
authority:
  - /docs/governance/EMPIRE_AI_CANONICAL_SPECIFICATION.md (Layer 5)
  - KAIZA_COMPLETE_GUIDE.md
---

# PHASE 4: ADMIN UI (KAIZA-EXECUTABLE)

## 1. Header Block
**Phase ID:** PHASE_4_ADMIN_UI  
**Status:** APPROVED  
**Date:** 2026-01-12  
**Authority:** EMPIRE_AI_CANONICAL_SPECIFICATION.md v1.0, KAIZA_COMPLETE_GUIDE.md  
**Source Inputs:** docs/plans/PHASE_4_ADMIN_UI_KAIZA.md, PHASE_3 (Dependency)

## 2. Objective
Build the "Single Pane of Glass" for the Owner. This is a Full-Stack Web Application (FastAPI + React) that allows God-Mode observation and control of the entire Empire. The UI interacts with the system *only* via the Registry and Ledger (read) and Governor (write/approve). It provides no backdoor access; every action from the UI is an authenticated job submission.

## 3. Scope Lock
**Allowed Paths:**
- `src/web/*` (React Frontend)
- `src/api/*` (FastAPI Validation Layer)
- `src/admin_ui_server.py`
- `src/admin_ui/*`
- `tests/test_ui.py`
- `docs/plans/` (self-update)

**Forbidden Paths:**
- `src/job_executor.py` (Phase 1)
- `src/agents/*.py` (Phase 2)
- `src/asset_runtime.py` (Phase 3)

*Touching forbidden paths = HARD FAIL.*

## 4. Hard Bans / Reality Lock
- **NO** direct DB writes from UI (must use Job/Governor).
- **NO** "Read-Only by default" logic (User must be able to ACT).
- **NO** missing screens (all 8 required).
- **NO** unauthenticated routes.

## 5. Write Tool Law
- ALL file writes MUST be performed using `kaiza_mcp.write_file`.
- Writing code directly in chat is **FORBIDDEN**.
- Partial writes are **FORBIDDEN**.

## 6. Deliverables
1.  **Backend API (`src/admin_ui_server.py`)**: FastAPI wrapper exposing System State.
2.  **Frontend App (`src/web/`)**: React + TypeScript + Tailwind (if approved) Dashboard.
3.  **Screens**:
    - **Empire Tab**: High-level health/metrics.
    - **Assets Tab**: Grid of deployed assets with status.
    - **Agents Tab**: Agent list + activity log.
    - **Jobs Tab**: Live job feed + approval queue.
    - **Capital Tab**: Financials (ROI/Burn).
    - **Infrastructure Tab**: Server/Resource status.
    - **Audit Tab**: Full Ledger viewer.
    - **Strategy Tab**: (Placeholder for Phase 5).
4.  **Integration Tests**: API tests and UI rendering tests.

## 7. File-Level Write Set

| Path | Action | Purpose | Required Behaviors | Failure Modes | Tests |
|------|--------|---------|-------------------|---------------|-------|
| `src/admin_ui_server.py` | CREATE | API Backend | - `GET /state`<br>- `POST /approve_job`<br>- `POST /kill_switch` | - Port bind fail<br>- Auth fail | `test_api.py` |
| `src/api/routes.py` | CREATE | Route Logic | - Map UI actions to Governor calls | - Validation fail | `test_routes.py` |
| `src/web/App.tsx` | CREATE | UI Root | - Main Layout<br>- Navigation | - Render fail | `test_ui_render` |
| `src/web/components/JobFeed.tsx`| CREATE | Job Component | - Live poll Ledger<br>- Approve button | - API sync fail | `test_job_feed` |
| `src/web/screens/Assets.tsx` | CREATE | Asset Grid | - Display all assets | - N/A | `test_assets_screen` |
| `tests/test_ui.py` | CREATE | UI Verification | - Test API endpoints | - N/A | `pytest` |

## 8. Data Flows & Control Loops

1.  **Read Loop**:
    `UI (Poll)` -> `API.get_state` -> `Registry.read` -> `JSON Response` -> `UI Render`
2.  **Action Loop**:
    `Owner Click` -> `API.post_action` -> `Governor.submit_job` -> `Ledger (Log)` -> `UI Update (Optimistic)`

## 9. Determinism & Audit Guarantees
- **Audit**: UI actions are logged as `actor="owner"` in Ledger.
- **Safety**: UI cannot corrupt DB directly; relies on Governor.

## 10. Acceptance Criteria (BINARY)

- [ ] **Command**: `npm run test` passes 100%.
- [ ] **Requirement**: All 8 tabs/screens present and navigable.
- [ ] **Invariant**: UI reads match `sqlite3` data exactly.
- [ ] **Invariant**: Action from UI appears in Ledger.

## 11. Stop Conditions
- If UI exposes secrets to client, system MUST HALT.
- If API allows unconstrained writes, system MUST HALT.

## 12. Non-Scope
- **No Public Access**: Admin UI is local/VPN only.
