---
kaiza:
  plan_name: PHASE_1_CORE_OS
  phase: 1
  authority: EMPIRE_AI_CANONICAL
  hash_algo: sha256
  plan_hash: 106297b1938f8e3ec977a538412908df0f5b4cacce9a4b81d55905dff6120e0d
  scope_lock: true
  write_tool_required: true
---
# PHASE 1: EMPIRE CORE OS (THE BRAIN)

## 1. Phase Objective
Establish the deterministic operating system kernel capable of executing rule-based logic, managing state in a central registry, running a single-threaded job loop, and maintaining an immutable audit log, providing the necessary boundaries for future autonomous operations without generating revenue.

## 2. System Boundaries
### Included
- **Governor**: Policy enforcement, permission management, and emergency stops.
- **Registry**: Centralized state management for agents, assets, and configurations.
- **Runtime**: Deterministic execution loop for jobs and steps.
- **Audit Engine**: Append-only tracing of all decisions and actions.
- **Admin Visibility**: Read-only interfaces for system state inspection.

### Excluded
- **Autonomous Agents**: Builders, writers, scouts, or any autonomous labor.
- **Asset Generation**: No creation of business assets or websites.
- **Revenue Operations**: No payment processing or profit seeking.
- **External Scraping**: No web crawling or external data ingestion.
- **Multi-Server**: Single-node execution only.

## 3. File Manifest

### src/core/governor/policy.ts
- **Purpose**: Defines system-wide invariants and permission logic.
- **Responsibilities**: Validating actions against the rulebook; authorizing requests.
- **Invariants**: Default deny; rules are immutable during execution.
- **Forbidden**: Runtime rule modification without audit.

### src/core/registry/store.ts
- **Purpose**: In-memory database of all system entities.
- **Responsibilities**: Storage and retrieval of Agents, Assets, and Configs.
- **Invariants**: Entity IDs must be globally unique.
- **Forbidden**: Direct database access bypassing the registry API.

### src/core/runtime/loop.ts
- **Purpose**: Main event loop for job execution.
- **Responsibilities**: Fetch next job, execute step, handle result, retry logic.
- **Invariants**: Serial execution (one step at a time).
- **Forbidden**: Parallel execution threads.

### src/core/audit/log.ts
- **Purpose**: Immutable append-only event ledger.
- **Responsibilities**: Writing events to persistent storage with cryptographic chains.
- **Invariants**: Chronological ordering; tamper-evident hashing.
- **Forbidden**: Modifying or deleting past entries.

### src/core/types.ts
- **Purpose**: Shared type definitions for the Core OS.
- **Responsibilities**: Defining interfaces for Entity, Job, Event, Policy.
- **Invariants**: Strict typing with no implicit `any`.
- **Forbidden**: Runtime type coercion without validation.

## 4. Subsystem Specifications

### Governor
- **Inputs**: (Subject, Action, Resource) tuple.
- **Outputs**: Boolean (Allow/Deny).
- **State Transitions**: Updates internal circuit-breaker state (Open/Closed).
- **Authority Checks**: Verifies request against static policy and current system state.
- **Failure Modes**: Fail-closed (Deny all) upon internal error.

### Registry
- **Inputs**: Entity ID, Data payload.
- **Outputs**: Stored Entity or Error.
- **State Transitions**: Null -> Active -> Disabled.
- **Authority Checks**: Requires 'System' or 'Governor' level capability to write.
- **Failure Modes**: Reject write on ID collision; Return null on missing read.

### Runtime
- **Inputs**: Pending Job Queue.
- **Outputs**: Job execution results (Success/Failure).
- **State Transitions**: Idle -> Executing -> Completed.
- **Authority Checks**: Validates job origin before execution.
- **Failure Modes**: Catch step exceptions, log stack trace, increment retry count, continue.

### Audit Engine
- **Inputs**: Event data.
- **Outputs**: Written Log Entry with Hash.
- **State Transitions**: Appended to ledger file.
- **Authority Checks**: None (Low-level system function).
- **Failure Modes**: Panic/Halt system if write fails (cannot operate without audit).

## 5. Data Models & Schemas

### Entity
- **id**: string (UUIDv4)
- **kind**: 'agent' | 'asset' | 'system'
- **status**: 'active' | 'paused' | 'disabled'
- **metadata**: Record<string, unknown>
- **createdAt**: string (ISO8601)

### Job
- **id**: string (UUIDv4)
- **type**: string (JobType)
- **payload**: unknown
- **status**: 'pending' | 'running' | 'completed' | 'failed'
- **retries**: number

### AuditEvent
- **id**: string (UUIDv4)
- **timestamp**: string (ISO8601)
- **type**: string
- **actor**: string (EntityID)
- **details**: unknown
- **prevHash**: string (SHA256)
- **hash**: string (SHA256)

## 6. Execution & Control Flow
- **Loop**: `while(true) { check_halt(); job = next(); if(job) { execute(job); } else { sleep(); } }`
- **Ordering**: Strict FIFO for job queue (unless priority override defined).
- **Idempotency**: Jobs tracking 'completed' state prevents double-execution.
- **Retry Rules**: Exponential backoff up to 3 times before moving to Dead Letter handling.

## 7. Authority & Governance Rules
- **Root Authority**: Only the 'System' user can bootstrap the Registry.
- **Read Access**: Admin UI has read-only access to Registry and Audit Log.
- **Write Access**: Agents cannot write to Registry directly; must submit requests.
- **Kill Conditions**: Any detected tamper of Audit Log triggers immediate Shutdown.

## 8. Audit & Determinism Guarantees
- **Logged**: Every state change, job start, job end, and error.
- **When**: Audit entry committed *before* acknowledging action completion.
- **Replay**: State reconstruction possible by replaying event log from genesis.
- **Tamper**: Each log entry contains hash of previous entry; verification walks the chain.

## 9. Failure Handling & Recovery
- **Process Crash**: Restart process; Audit Log integrity checked on boot.
- **Job Failure**: Job marked 'failed', error logged, system proceeds to next job.
- **State Corruption**: If Registry in-memory state disagrees with Log, Log wins (rebuild state).
- **No Human**: Automatic restart scripts; no interactive debugger required for recovery.

## 10. Acceptance Criteria (BINARY)
- [ ] System initializes and passes self-check.
- [ ] Registry accepts valid entities and rejects duplicates.
- [ ] Governor correctly enforces a "Deny" policy on unauthorized attempts.
- [ ] Runtime picks up a job, executes it, and marks it complete.
- [ ] Audit log file exists and contains valid linked hashes.
- [ ] Application strictly adheres to defined types in `src/core/types.ts`.

## 11. Explicit Non-Goals
- implementing functional AI Agents.
- generating any user-facing web pages.
- processing real money.
- distributed consensus.
- high-availability clustering.