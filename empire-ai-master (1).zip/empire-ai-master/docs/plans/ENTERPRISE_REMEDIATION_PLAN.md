# ENTERPRISE REMEDIATION PLAN: ATLAS PROTECTION SYSTEM

**Authority:** Enterprise Readiness Audit (2026-01-17)
**Protocol:** MCP-ENFORCED / Execution-Locked
**Status:** APPROVED
**Hash-Lock:** 69e7b0edeeb5eee2dffe2d0384a9833c794d03b5b3b5e8ac6bb832545efe32c4

## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🛡️ MISSION OBJECTIVE

## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Directly address and remediate all CRITICAL and HIGH findings from the Enterprise Readiness Audit to achieve "Reality Lock" parity. This plan enforces a fail-secure posture across permission logic, cryptographic verification, and execution preconditions.

## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE A1: AUTHORITY LOCK (DENY-BY-DEFAULT)

## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**Phase ID:** AE-REMED-A1
**Objective:** Eliminate fail-open logic in permission checking and core execution handlers.

**Explicit File Operations:**

- **MODIFY** [permission_checker.py](file:///home/lin/Documents/empire-ai/src/governor/permission_checker.py)
  - Change `_perform_check` to return `allowed=False` by default.
  - Implement explicit grant requirements for all operations.
- **MODIFY** [execution_engine.py](file:///home/lin/Documents/empire-ai/src/execution/execution_engine.py)
  - Remove "signatures are logged but not enforced" logic.
  - Implement mandatory RSA signature verification for all action envelopes.

**Explicit Forbidden Actions:**

- Do NOT use internal mocks or simulation flags to bypass signature checks.
- Do NOT allow any unmapped operation to succeed in `PermissionChecker`.

**Required Verification Gates:**

- **Command:** `python3 scripts/verify`
  - **Expected:** Pass with zero findings on "fail-open" or "stubbed verification".
- **Command:** `pytest tests/security/test_permission_checker.py`
  - **Expected:** 100% pass including negative tests (unauthorized access blocked).

**Mandatory Report Artifact:** `docs/reports/AE-REMED-A1-EXECUTION.md`
**Stop Conditions:** Any regression that allows an unauthenticated or unsigned action to execute.

## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE A2: CRYPTOGRAPHIC IDENTITY RECLAMATION

## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**Phase ID:** AE-REMED-A2
**Objective:** Replace stubbed identity verification with real cryptographic attestation.

**Explicit File Operations:**

- **MODIFY** [auth_endpoints.py](file:///home/lin/Documents/empire-ai/src/api/auth_endpoints.py)
  - Implement full WebAuthn attestation verification.
  - Enforce challenge/response integrity.
- **MODIFY** [license_verify.py](file:///home/lin/Documents/empire-ai/src/licensing/license_verify.py)
  - Replace `token.startswith` verification with JWT/RS256 signature validation using the instance public key.

**Explicit Forbidden Actions:**

- Do NOT use string-based prefix matching for security tokens.
- Do NOT skip WebAuthn attestation verification in production routes.

**Required Verification Gates:**

- **Command:** `pytest tests/auth/test_webauthn_logic.py`
- **Command:** `pytest tests/licensing/test_instance_auth.py`

**Mandatory Report Artifact:** `docs/reports/AE-REMED-A2-EXECUTION.md`
**Stop Conditions:** Invalid tokens are accepted or signatures are ignored.

## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE A3: OPERATIONAL INTEGRITY & PRECONDITIONS

## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**Phase ID:** AE-REMED-A3
**Objective:** Replace debug stubs with real system/resource verification logic.

**Explicit File Operations:**

- **MODIFY** [control_api.py](file:///home/lin/Documents/empire-ai/src/execution/control_api.py)
  - Implement real logic for `system`, `resource`, and `rate_limit` preconditions in `_check_single_precondition`.
  - Ensure actual verification of resource availability.
- **MODIFY** [license_manager.py](file:///home/lin/Documents/empire-ai/src/licensing/license_manager.py)
  - Implement exhaustive feature gate mapping.
- **MODIFY** [permission_checker.py](file:///home/lin/Documents/empire-ai/src/governor/permission_checker.py)
  - Implement dynamic rule loading from master ledger as specified in Master Plan Axioms.

**Required Verification Gates:**

- **Command:** `pytest tests/execution/test_preconditions.py`
- **Command:** `python3 scripts/verify_production_readiness.sh`

**Mandatory Report Artifact:** `docs/reports/AE-REMED-A3-EXECUTION.md`
**Stop Conditions:** Preconditions log "Check passed" without actually performing verification.

## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 🧬 PHASE A4: REPOSITORY HYGIENE & LOCKDOWN

## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**Phase ID:** AE-REMED-A4
**Objective:** Resolve the clutter of unmanaged reports and perform final compliance scan.

**Explicit File Operations:**

- **DELETE** Move all non-canonical AMP execution reports from root to `docs/archive/reports/`.
- **MODIFY** Root `.gitignore` to prevent future report spill into the root directory.

**Required Verification Gates:**

- **Command:** `ls -F | grep -v / | wc -l`
  - **Expected:** Significant reduction in root directory file count (only canonical project files).
- **Command:** `python3 scripts/ci/forbidden_markers_scan.py --root .`

**Mandatory Report Artifact:** `docs/reports/AE-REMED-A4-FINAL_LOCKDOWN.md`
