# PHASE 2: AGENT ECONOMY — KAIZA EXECUTABLE PLAN

**Document Version:** 1.0  
**Plan Status:** EXECUTABLE  
**Authority:** KAIZA MCP Governance  
**Authoring Agent:** ANTIGRAVITY  
**Generated:** 2026-01-15T00:00:00Z  
**Target Execution:** Windsurf + KAIZA MCP Write Tool

---

## 1. PLAN METADATA

### Identification
- **Plan Name:** `PHASE_2_AGENT_ECONOMY_KAIZA_EXECUTABLE`
- **Plan ID:** `PHASE-2-ECONOMY`
- **Version:** 1.0
- **Semantic Versioning:** Phase 2, Iteration 0, Release Candidate 1

### Governance
- **Governing Framework:** KAIZA MCP (Multi-Agent Coordinated Execution)
- **Compliance Level:** MANDATORY
- **Execution Authority:** Windsurf Agent + KAIZA MCP Write Tool
- **Fallback Authority:** Human operator manual execution via Bash

### Content Hash
- **SHA256(full_document):** `a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6a7b8c9d0e1`
- **Document Encoding:** UTF-8, Markdown (GitHub-flavored)
- **Tamper Detection:** Hash includes all sections 1–12; modifications invalidate hash

### Required Windsurf Skills (Load Before Execution)
1. `@no-placeholders-production-code` — All agent code must be complete, no stubs
2. `@test-engineering-suite` — All agent functionality tested, ≥90% coverage
3. `@audit-first-commentary` — Every agent function documented with decision rationale
4. `@secure-by-default` — Agent input validation, permission boundary enforcement
5. `@debuggable-by-default` — Agent execution logged with correlation IDs
6. `@repo-understanding` — Registry entries cross-checked against Phase 1 schemas

---

## 2. PHASE OBJECTIVE (DETERMINISTIC)

### What Phase 2 Accomplishes

**Phase 2 delivers a specialized agent labor force with explicit permission boundaries, governed by Phase 1 subsystems.**

Specifically:

1. **Registers 7 agent classes** in the Phase 1 Registry with immutable permission sets
2. **Implements agent runtime wrapper** for all agents to enforce Governor approval before execution
3. **Defines budget enforcement** per agent, per action, per day (Governor enforces)
4. **Implements agent lifecycle API**: register → assign job → execute → log → audit
5. **Validates all agent outputs** against compliance matrix before Registry update
6. **Establishes failure taxonomy** for agent-specific error types and retry rules
7. **Logs every agent decision** with context (input, rules applied, output)

### No Longer Theoretical; Now Operational

By end of Phase 2:
- The system has **internal labor** (7 agents) with proven constraints
- Each agent **cannot exceed its permission boundary** (enforced by Governor)
- The **Governor is testable with real workloads** (agent job approval flow)
- The **Registry is source-of-truth** for agent configurations
- The **Audit ledger proves agent accountability** with full decision trails

### Success Criteria (Testable)

Phase 2 is complete when:
1. ✅ All 7 agents registered in Registry with permission boundaries
2. ✅ Governor approval logic invoked for every agent action (dry-run validated)
3. ✅ 6+ integration tests pass (agent job submission → execution → audit logging)
4. ✅ Zero forbidden markers (TODO, FIXME, XXX, HACK) in agent code
5. ✅ All agent output types defined in Registry schema
6. ✅ Failure taxonomy documented with retry/kill rules
7. ✅ KAIZA-AUDIT block completed with full verification results

---

## 3. AUTHORITY & SCOPE LOCK

### What Phase 2 is Allowed to Modify

**CREATE:**
- `src/agents/` directory with 7 agent implementations
- `src/agents/base_agent.py` — Agent interface, lifecycle methods
- `src/agents/scout_agent.py` — Market discovery agent
- `src/agents/builder_agent.py` — Code generation agent
- `src/agents/writer_agent.py` — Content generation agent
- `src/agents/verifier_agent.py` — Validation/compliance agent
- `src/agents/growth_agent.py` — Optimization/testing agent
- `src/agents/finance_agent.py` — Portfolio analysis agent
- `src/agents/compliance_agent.py` — Legal/regulatory agent
- `src/agents/__init__.py` — Agent registration
- `src/agent_runtime.py` — Agent job lifecycle executor
- `src/agent_permissions.py` — Permission boundary enforcement
- `config/agent_permissions.json` — Agent permission matrix (immutable after Phase 2)
- `tests/test_agents_phase2.py` — Comprehensive agent testing (unit + integration)
- `docs/PHASE_2_AGENT_ECONOMY.md` — Agent documentation and API reference

**EXTEND (Phase 1 Components):**
- `src/registry.py` — Add `register_agent()`, `get_agent_permissions()`, `update_agent_state()` methods
- `src/governor/main_governor.py` — Add `approve_agent_action()` method with budget validation
- `src/core/audit.py` — Ensure agent-specific event logging (already supports)

### What Phase 2 is FORBIDDEN to Modify

- ❌ Phase 1 core APIs (Governor, Runtime, Registry, Audit) — may only call, not rewrite
- ❌ `src/universal_ledger.py` — immutable, read-only for Phase 2
- ❌ Kill switch logic or emergency controls
- ❌ Agent permission boundaries after registration (Registry immutable post-Phase 2)
- ❌ Any hardcoded business logic for specific assets
- ❌ Any external API calls without offline fallback
- ❌ Any agent-to-agent direct communication (must route through Governor)

### Scope Boundary Definition

**In Scope:**
- Agent state machine (registered → ready → executing → idle)
- Agent job submission, execution, failure handling
- Permission boundary enforcement at Governor
- Audit logging of agent decisions
- Agent-specific retry and failure rules

**Out of Scope:**
- Asset creation, deployment, or scaling (Phase 3+)
- Billing, revenue attribution, or capital allocation (Phase 5)
- Marketing content generation beyond agent interface (Phase 6)
- User onboarding or support (Phase 7)
- Telemetry or observability UI (Phase 8)

### Scope Violation Triggers (Hard Stop)

If ANY of these occur, **PHASE 2 HALTS AND REVERTS**:

1. **Any agent bypasses Governor approval** (detected: agent submits action without `approve_agent_action()` call)
2. **Any agent modifies its own permissions** (detected: Registry permission field altered after registration)
3. **Any agent exceeds its budget ceiling** (detected: Governor blocks action with budget error)
4. **Forbidden markers found in committed code** (TODO, FIXME, XXX, HACK, STUB)
5. **Any test fails or coverage < 90%** (detected: `pytest --cov` fails)
6. **Registry schema validation fails** (detected: agent config missing required fields)
7. **Phase 1 component modified** (detected: git diff on Phase 1 files)
8. **External API call without local fallback** (detected: hardcoded URL to external service)

---

## 4. PRECONDITIONS (HARD GATES)

### Phase 1 Artifacts MUST Exist

Phase 2 execution requires ALL of the following Phase 1 deliverables to be present and functional:

#### ✅ Governor System (Required)
- **File:** `src/governor/main_governor.py`
- **API Method Required:** `approve_request(actor, action, resource, budget)` → `ApprovalResult`
- **Behavior Required:** Returns `ApprovalResult.APPROVED` or `ApprovalResult.DENIED`
- **Budget Enforcement:** Governor must enforce budget ceilings, return `BUDGET_EXCEEDED` error if overspent
- **Audit Integration:** Governor must call `audit.log_event()` for every approval decision

#### ✅ Runtime System (Required)
- **File:** `src/runtime/__init__.py`
- **API Methods Required:**
  - `submit_job(job_definition: JobDefinition)` → `job_id: str`
  - `execute_job(job_id: str)` → `JobResult`
  - `get_job_status(job_id: str)` → `JobStatus`
- **Behavior Required:** FIFO queue, step-by-step execution, checkpoint support
- **Idempotency:** Must support re-executing failed jobs without side effects

#### ✅ Registry System (Required)
- **File:** `src/registry.py`
- **API Methods Required:**
  - `set_agent(agent_definition: dict)` → agent registered
  - `get_agent(agent_id: str)` → agent definition
  - `get_state()` → full registry state dict
  - `validate_schema(data: dict, schema_name: str)` → bool
- **Behavior Required:** Single source of truth, versioned, atomic writes
- **Consistency:** All reads return consistent state across concurrent threads

#### ✅ Audit Engine (Required)
- **File:** `src/core/audit.py`
- **API Methods Required:**
  - `log_event(event_dict: dict)` → event_id
  - `query_events(filter_dict: dict)` → list[EventRecord]
  - `verify_integrity()` → bool
- **Behavior Required:** Immutable, append-only, tamper-evident (hash-chained)
- **Event Fields:** Must support `event_type`, `actor_id`, `action`, `resource`, `result`, `timestamp`, `context`

#### ✅ Kill Switch (Required)
- **File:** `src/core/kill_switch.py`
- **API Methods Required:**
  - `check_before_action(agent_id: str, action: str)` → bool
  - `is_engaged()` → bool
- **Behavior Required:** Can freeze all jobs instantly
- **Owner Control:** Only owner can engage/disengage

#### ✅ Configuration File (Required)
- **File:** `config/phase_1_defaults.json`
- **Content:** Default policies, governance settings, agent skeleton
- **Writability:** Read-only for Phase 2 (Phase 2 extends, does not overwrite)

#### ✅ Tests Passing (Required)
- All Phase 1 tests must pass: `pytest tests/test_*_phase1.py -v`
- No forbidden markers in Phase 1 code
- Phase 1 coverage ≥ 80%

### Governor Availability Test

```python
# Phase 2 startup must verify Governor is ready:
from src.governor.main_governor import Governor
from src.core.audit import AuditEngine

governor = Governor()
audit = AuditEngine()

# Test approval flow
result = governor.approve_request(
    actor="phase2_init",
    action="test_gate",
    resource="registry_write",
    budget={"registry_writes": 1}
)
assert result.status == "APPROVED", "Governor not functional"
audit.log_event({"event_type": "phase2_precondition_check", "status": "PASS"})
```

### If ANY Precondition Fails

**PHASE 2 MUST NOT PROCEED.** Instead:

1. Emit error: `"Phase 1 precondition FAILED: [component] [reason]"`
2. Log event to audit: `{"event_type": "phase2_blocked", "reason": "...", "timestamp": now}`
3. Return control to operator with recovery instructions
4. Do NOT auto-retry or skip precondition

---

## 5. AGENT MODEL (CANONICAL)

### Agent Base Class (`src/agents/base_agent.py`)

All agents inherit from `BaseAgent` with standardized lifecycle:

```python
class BaseAgent:
    """Base class for all Empire AI agents."""
    
    def __init__(self, agent_id: str, permissions: dict, governor, registry, audit):
        """Initialize agent with immutable permissions."""
        self.agent_id = agent_id
        self.permissions = permissions  # Frozen after init
        self.governor = governor
        self.registry = registry
        self.audit = audit
        self.state = "idle"
        
    def register(self) -> dict:
        """Register agent in Registry with permission boundary."""
        agent_def = {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "permissions": self.permissions,
            "state": "registered",
            "created_at": timestamp(),
            "output_schema": self.output_schema,
        }
        self.registry.set_agent(agent_def)
        self.audit.log_event({
            "event_type": "agent_registered",
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "permissions": self.permissions,
        })
        return agent_def
        
    def request_action(self, action: str, resource: str, input_data: dict) -> dict:
        """Request Governor approval before executing action."""
        # Check permission boundary
        if action not in self.permissions.get("allowed_actions", []):
            raise PermissionDenied(f"Action {action} not in agent permissions")
        
        # Request Governor approval
        approval = self.governor.approve_request(
            actor=self.agent_id,
            action=action,
            resource=resource,
            budget=self.permissions.get("budget", {})
        )
        
        if approval.status != "APPROVED":
            self.audit.log_event({
                "event_type": "agent_action_denied",
                "agent_id": self.agent_id,
                "action": action,
                "reason": approval.reason,
            })
            raise ActionDenied(f"Governor denied action: {approval.reason}")
        
        # Execute action
        result = self.execute(action, input_data)
        
        # Log result
        self.audit.log_event({
            "event_type": "agent_action_executed",
            "agent_id": self.agent_id,
            "action": action,
            "result_status": "SUCCESS" if result.get("success") else "FAILED",
            "context": {
                "input_summary": str(input_data)[:200],
                "output_summary": str(result)[:200],
            }
        })
        
        return result
    
    def execute(self, action: str, input_data: dict) -> dict:
        """Execute agent action. Subclasses override."""
        raise NotImplementedError
```

### Agent Registry Entries (Immutable After Registration)

Each agent entry in Registry contains:

```json
{
  "agent_id": "scout_001",
  "agent_type": "Scout",
  "state": "registered",
  "permissions": {
    "allowed_actions": ["search_market", "analyze_trends"],
    "forbidden_actions": ["publish", "spend_budget"],
    "read_domains": ["market_data", "analytics"],
    "write_domains": [],
    "budget": {
      "api_calls_per_day": 100,
      "compute_minutes_per_day": 60,
      "storage_gb_per_month": 0.5
    }
  },
  "output_schema": {
    "type": "object",
    "properties": {
      "opportunities": {"type": "array"},
      "confidence": {"type": "number", "minimum": 0, "maximum": 1}
    },
    "required": ["opportunities", "confidence"]
  },
  "created_at": "2026-01-15T00:00:00Z",
  "last_updated": "2026-01-15T00:00:00Z"
}
```

---

### Agent 1: SCOUT AGENT (`src/agents/scout_agent.py`)

**Purpose:** Discover market opportunities, identify niches, analyze trends  
**Owner:** Phase 2 Agent Economy

#### Permissions (Immutable)
```json
{
  "allowed_actions": [
    "search_keywords",
    "analyze_seo_difficulty",
    "identify_niches",
    "analyze_trends",
    "estimate_market_size"
  ],
  "forbidden_actions": [
    "spend_budget",
    "create_asset",
    "publish",
    "modify_agent_permissions"
  ],
  "read_domains": [
    "public_market_data",
    "keyword_databases",
    "trend_data"
  ],
  "write_domains": [],
  "budget": {
    "api_calls_per_day": 500,
    "compute_minutes_per_day": 120,
    "storage_gb_per_month": 2.0
  }
}
```

#### Input Contract
```python
{
    "action": "search_keywords",
    "keywords": ["list of strings"],
    "region": "US|EU|Global",  # optional
    "language": "en",
    "limit": 10,  # max results
}
```

#### Output Contract
```python
{
    "success": bool,
    "opportunities": [
        {
            "keyword": "string",
            "search_volume": int,
            "difficulty": float,  # 0-100
            "trend": "rising|stable|declining",
            "market_size_estimate": int,
            "niche_score": float,  # 0-1
        }
    ],
    "analysis_timestamp": "ISO8601",
    "confidence": float,  # 0-1
}
```

#### Audit Events Emitted
- `"scout_search_initiated"` — When search starts
- `"scout_search_completed"` — When search completes
- `"scout_api_call_made"` — Before each external API call (cached)
- `"scout_budget_check"` — Budget validation before action

#### Failure Modes
| Error | Retry Rule | Kill Rule |
|-------|-----------|-----------|
| API rate limit | Retry after 60s, max 3x | Kill if 5 consecutive failures |
| Invalid keyword | Log + skip, continue | (no kill) |
| Database read error | Retry exponential, max 5x | Kill if unrecoverable after 1 hour |
| Output validation fail | Reject output, return error | (no kill) |

---

### Agent 2: BUILDER AGENT (`src/agents/builder_agent.py`)

**Purpose:** Generate code, integrate templates, package artifacts  
**Owner:** Phase 2 Agent Economy

#### Permissions (Immutable)
```json
{
  "allowed_actions": [
    "generate_code",
    "run_tests",
    "package_artifact",
    "commit_to_staging",
    "validate_build"
  ],
  "forbidden_actions": [
    "deploy_to_production",
    "modify_production_assets",
    "delete_assets",
    "modify_agent_permissions"
  ],
  "read_domains": [
    "asset_spec",
    "template_library",
    "build_config"
  ],
  "write_domains": [
    "artifact_store",
    "staging_deployment"
  ],
  "budget": {
    "api_calls_per_day": 200,
    "compute_minutes_per_day": 480,
    "storage_gb_per_month": 50.0
  }
}
```

#### Input Contract
```python
{
    "action": "generate_code",
    "spec": {
        "product_name": "string",
        "description": "string",
        "features": ["list of strings"],
        "tech_stack": ["node", "python", "rust"],
        "complexity": "mvp|simple|moderate",
    },
    "template_id": "string",
    "output_format": "packaged_artifact",
}
```

#### Output Contract
```python
{
    "success": bool,
    "artifact_id": "string",
    "artifact_path": "/artifacts/...",
    "build_log": "string (last 5000 chars)",
    "test_results": {
        "tests_run": int,
        "tests_passed": int,
        "coverage": float,
        "passed": bool,
    },
    "warnings": ["list of strings"],
    "generation_time_seconds": float,
    "confidence": float,  # 0-1
}
```

#### Audit Events Emitted
- `"build_code_generation_started"`
- `"build_code_generation_completed"`
- `"build_tests_executed"`
- `"build_artifact_packaged"`
- `"build_artifact_stored"`

#### Failure Modes
| Error | Retry Rule | Kill Rule |
|-------|-----------|-----------|
| Code generation timeout | Retry with smaller spec, max 2x | Kill if 3 consecutive timeouts |
| Test failure | Log failure, do NOT auto-fix | Kill if tests fail (code must be valid) |
| Template not found | Return error, suggest alternatives | (no kill) |
| Storage full | Return error, request cleanup | Kill if storage cannot be freed |

---

### Agent 3: WRITER AGENT (`src/agents/writer_agent.py`)

**Purpose:** Generate marketing content, variants, metadata  
**Owner:** Phase 2 Agent Economy

#### Permissions (Immutable)
```json
{
  "allowed_actions": [
    "generate_content",
    "generate_variants",
    "optimize_seo",
    "generate_metadata",
    "create_draft"
  ],
  "forbidden_actions": [
    "publish_content",
    "publish_to_web",
    "delete_content",
    "modify_agent_permissions"
  ],
  "read_domains": [
    "asset_metadata",
    "audience_profiles",
    "brand_guidelines"
  ],
  "write_domains": [
    "content_draft_store"
  ],
  "budget": {
    "api_calls_per_day": 300,
    "compute_minutes_per_day": 60,
    "storage_gb_per_month": 10.0
  }
}
```

#### Input Contract
```python
{
    "action": "generate_content",
    "asset_id": "string",
    "content_type": "blog|email|ad|landing_page",
    "target_audience": "string",
    "tone": "professional|casual|urgent",
    "seo_keywords": ["list of strings"],
    "word_count": int,  # target
}
```

#### Output Contract
```python
{
    "success": bool,
    "content_id": "string",
    "content": "string",
    "variants": [
        {"variant_id": "string", "content": "string", "tone": "string"}
    ],
    "metadata": {
        "word_count": int,
        "reading_time_minutes": float,
        "sentiment": float,  # -1 to 1
        "seo_optimized": bool,
    },
    "warnings": ["list of strings"],
    "generation_time_seconds": float,
    "confidence": float,
}
```

#### Audit Events Emitted
- `"writer_content_generation_started"`
- `"writer_content_generated"`
- `"writer_variants_created"`
- `"writer_draft_stored"`

#### Failure Modes
| Error | Retry Rule | Kill Rule |
|-------|-----------|-----------|
| Content generation timeout | Retry with shorter length, max 2x | Kill if 3 consecutive timeouts |
| Guideline violation | Log warning, return content with flag | (no kill) |
| Variant generation fail | Return base content only | (no kill) |
| Storage error | Retry, max 3x | Kill if unrecoverable |

---

### Agent 4: VERIFIER AGENT (`src/agents/verifier_agent.py`)

**Purpose:** Validate claims, test compliance, ensure quality  
**Owner:** Phase 2 Agent Economy

#### Permissions (Immutable)
```json
{
  "allowed_actions": [
    "validate_content",
    "check_compliance",
    "run_security_checks",
    "verify_claims",
    "audit_asset"
  ],
  "forbidden_actions": [
    "auto_remediate",
    "delete_content",
    "modify_agent_permissions"
  ],
  "read_domains": [
    "all_asset_data",
    "compliance_rules",
    "security_policies"
  ],
  "write_domains": [
    "verification_results"
  ],
  "budget": {
    "api_calls_per_day": 400,
    "compute_minutes_per_day": 240,
    "storage_gb_per_month": 5.0
  }
}
```

#### Input Contract
```python
{
    "action": "validate_content",
    "asset_id": "string",
    "content": "string",
    "validation_rules": ["list of rule names"],
    "compliance_framework": "GDPR|CCPA|CAN-SPAM",
}
```

#### Output Contract
```python
{
    "success": bool,
    "verification_id": "string",
    "passed": bool,
    "violations": [
        {
            "rule": "string",
            "severity": "critical|warning|info",
            "description": "string",
            "suggestion": "string",
        }
    ],
    "compliance_score": float,  # 0-1
    "verification_timestamp": "ISO8601",
    "confidence": float,
}
```

#### Audit Events Emitted
- `"verification_started"`
- `"verification_completed"`
- `"compliance_check_performed"`
- `"violation_detected"`

#### Failure Modes
| Error | Retry Rule | Kill Rule |
|-------|-----------|-----------|
| Rule parsing error | Return error with rule info | (no kill) |
| External compliance check fail | Retry, max 2x | Kill if external service unreachable |
| Content read error | Retry, max 3x | (no kill) |
| Output validation fail | Return error | (no kill) |

---

### Agent 5: GROWTH AGENT (`src/agents/growth_agent.py`)

**Purpose:** Optimize performance, run A/B tests, create variants  
**Owner:** Phase 2 Agent Economy

#### Permissions (Immutable)
```json
{
  "allowed_actions": [
    "create_experiment",
    "analyze_metrics",
    "recommend_optimization",
    "generate_variant",
    "track_cohort"
  ],
  "forbidden_actions": [
    "modify_production_asset",
    "spend_budget",
    "publish_experiment",
    "modify_agent_permissions"
  ],
  "read_domains": [
    "analytics_data",
    "user_behavior",
    "asset_performance"
  ],
  "write_domains": [
    "experiment_tracking",
    "variant_store"
  ],
  "budget": {
    "api_calls_per_day": 250,
    "compute_minutes_per_day": 180,
    "storage_gb_per_month": 20.0
  }
}
```

#### Input Contract
```python
{
    "action": "create_experiment",
    "asset_id": "string",
    "hypothesis": "string",
    "control_variant": "string",
    "test_variant": "string",
    "sample_size": int,
    "duration_days": int,
    "metric": "conversion_rate|engagement|bounce_rate",
}
```

#### Output Contract
```python
{
    "success": bool,
    "experiment_id": "string",
    "hypothesis": "string",
    "status": "pending|running|completed",
    "control_metric": float,
    "variant_metric": float,
    "p_value": float,
    "is_significant": bool,
    "confidence": float,  # 0-1
    "recommendation": "adopt|reject|inconclusive",
    "analysis_timestamp": "ISO8601",
}
```

#### Audit Events Emitted
- `"experiment_created"`
- `"experiment_analysis_completed"`
- `"optimization_recommended"`

#### Failure Modes
| Error | Retry Rule | Kill Rule |
|-------|-----------|-----------|
| Insufficient data | Return error with min samples needed | (no kill) |
| Metric calculation error | Retry, max 2x | Kill if data source unavailable |
| Duration exceeded | Mark complete, analyze partial | (no kill) |

---

### Agent 6: FINANCE AGENT (`src/agents/finance_agent.py`)

**Purpose:** Analyze ROI, forecast performance, recommend kill/scale  
**Owner:** Phase 2 Agent Economy

#### Permissions (Immutable)
```json
{
  "allowed_actions": [
    "analyze_roi",
    "forecast_revenue",
    "recommend_kill",
    "recommend_scale",
    "calculate_margin"
  ],
  "forbidden_actions": [
    "spend_budget",
    "modify_pricing",
    "execute_kill",
    "modify_agent_permissions"
  ],
  "read_domains": [
    "all_portfolio_metrics",
    "financial_data",
    "cost_attribution"
  ],
  "write_domains": [
    "financial_reports"
  ],
  "budget": {
    "api_calls_per_day": 150,
    "compute_minutes_per_day": 120,
    "storage_gb_per_month": 3.0
  }
}
```

#### Input Contract
```python
{
    "action": "recommend_kill",
    "asset_id": "string",
    "lookback_days": 90,
    "include_projections": bool,
}
```

#### Output Contract
```python
{
    "success": bool,
    "recommendation": "kill|scale|hold|investigate",
    "roi": float,
    "monthly_revenue": float,
    "monthly_cost": float,
    "margin": float,
    "trend_90d": "improving|stable|declining",
    "confidence": float,
    "rationale": "string",
    "projected_30d_revenue": float,
    "analysis_timestamp": "ISO8601",
}
```

#### Audit Events Emitted
- `"financial_analysis_completed"`
- `"roi_recommendation_made"`
- `"kill_recommendation_issued"`

#### Failure Modes
| Error | Retry Rule | Kill Rule |
|-------|-----------|-----------|
| Missing cost data | Return error with data requirements | (no kill) |
| Calculation error | Retry, max 2x | (no kill) |
| Data staleness | Return warning, use best available | (no kill) |

---

### Agent 7: COMPLIANCE AGENT (`src/agents/compliance_agent.py`)

**Purpose:** Ensure regulatory compliance, flag violations  
**Owner:** Phase 2 Agent Economy

#### Permissions (Immutable)
```json
{
  "allowed_actions": [
    "scan_compliance",
    "check_disclosure",
    "flag_violation",
    "audit_policy"
  ],
  "forbidden_actions": [
    "auto_remediate",
    "delete_content",
    "disable_asset",
    "modify_agent_permissions"
  ],
  "read_domains": [
    "all_asset_data",
    "marketing_content",
    "user_data"
  ],
  "write_domains": [
    "compliance_reports"
  ],
  "budget": {
    "api_calls_per_day": 300,
    "compute_minutes_per_day": 180,
    "storage_gb_per_month": 5.0
  }
}
```

#### Input Contract
```python
{
    "action": "scan_compliance",
    "asset_id": "string",
    "frameworks": ["GDPR", "CCPA", "CAN-SPAM"],
    "scan_type": "full|incremental",
}
```

#### Output Contract
```python
{
    "success": bool,
    "scan_id": "string",
    "compliant": bool,
    "violations": [
        {
            "framework": "string",
            "rule": "string",
            "severity": "critical|warning|info",
            "finding": "string",
            "remediation": "string",
        }
    ],
    "compliance_score": float,  # 0-1
    "scan_timestamp": "ISO8601",
    "confidence": float,
}
```

#### Audit Events Emitted
- `"compliance_scan_initiated"`
- `"compliance_scan_completed"`
- `"violation_flagged"`

#### Failure Modes
| Error | Retry Rule | Kill Rule |
|-------|-----------|-----------|
| Rule database error | Retry, max 2x | Kill if unrecoverable |
| Asset read error | Retry, max 3x | (no kill) |
| Output validation fail | Return error | (no kill) |

---

## 6. PERMISSION & BUDGET MODEL

### Governor Approval Logic (Enforced by Phase 1)

Every agent action follows this deterministic flow:

```python
def approve_agent_action(governor, agent_id, action, resource, budget_required):
    """
    Deterministic approval logic enforced by Governor.
    Returns APPROVED or DENIED (no maybe states).
    """
    # Step 1: Check if agent exists in Registry
    agent_def = registry.get_agent(agent_id)
    if not agent_def:
        return ApprovalResult(status="DENIED", reason="agent_not_registered")
    
    # Step 2: Check if action is in agent's allowed_actions
    if action not in agent_def["permissions"]["allowed_actions"]:
        return ApprovalResult(status="DENIED", reason="action_not_permitted")
    
    # Step 3: Check if kill switch is engaged
    if kill_switch.is_engaged():
        return ApprovalResult(status="DENIED", reason="kill_switch_engaged")
    
    # Step 4: Check budget ceiling
    budget_limit = agent_def["permissions"]["budget"]
    current_usage = registry.get_agent_budget_usage(agent_id)
    
    if current_usage >= budget_limit:
        return ApprovalResult(status="DENIED", reason="budget_exceeded")
    
    # Step 5: Log decision
    audit.log_event({
        "event_type": "agent_action_approved",
        "agent_id": agent_id,
        "action": action,
        "decision_rules_applied": [
            "agent_exists",
            "action_permitted",
            "kill_switch_not_engaged",
            "budget_available"
        ]
    })
    
    return ApprovalResult(status="APPROVED")
```

### Budget Enforcement Rules

**Budget Ceilings (Hard Limits):**

| Budget Type | Scout | Builder | Writer | Verifier | Growth | Finance | Compliance |
|-------------|-------|---------|--------|----------|--------|---------|------------|
| API calls/day | 500 | 200 | 300 | 400 | 250 | 150 | 300 |
| Compute min/day | 120 | 480 | 60 | 240 | 180 | 120 | 180 |
| Storage GB/mo | 2 | 50 | 10 | 5 | 20 | 3 | 5 |

**Enforcement:**
- Budget counters reset daily at 00:00 UTC (deterministic)
- Governor checks budget BEFORE approving action
- If budget would be exceeded, action is DENIED
- No agent may request Governor to waive budget (hard constraint)
- Budget usage logged with every approval

**Budget Usage Tracking:**

```python
# Registry stores usage:
{
    "agent_id": "scout_001",
    "budget_usage": {
        "api_calls_today": 450,  # 500 limit
        "compute_minutes_today": 95,  # 120 limit
        "storage_gb_this_month": 1.8,  # 2 limit
    },
    "last_reset": "2026-01-15T00:00:00Z"
}
```

### Permission Escalation Rules

**No agent may self-expand authority.** Escalation is blocked:

```python
# FORBIDDEN: Agent cannot modify its own permissions
agent.request_action(
    action="modify_agent_permissions",
    resource=f"agent_{agent_id}",
    input_data={"permissions": {...}}
)
# Governor denies: action not in allowed_actions
```

**Only Governor can modify permissions.** Mechanism:

```python
# ONLY Governor can do this (requires owner override):
registry.update_agent_permissions(
    agent_id="scout_001",
    new_permissions={...},
    approved_by="owner",
    audit_reason="Phase 3 expansion"
)
```

### Agent-to-Agent Communication

**Forbidden direct communication.** Agents route through Governor:

```python
# FORBIDDEN:
scout.send_message_to(builder, "opportunities")

# REQUIRED:
# Scout stores result in Registry
registry.set_agent_output("scout_001", "opportunities_batch_1")

# Builder checks Registry, gets data, submits own Governor request
builder.request_action("generate_code", "opportunities_batch_1")
```

---

## 7. EXECUTION FLOW

### Agent Lifecycle State Machine

```
[UNREGISTERED]
    ↓
    register()
[REGISTERED]
    ↓
    request_job()
[WAITING_FOR_APPROVAL]
    ↓
    (Governor approves/denies)
    ├→ APPROVED
    │   ↓
    │   execute_job()
    │   ├→ SUCCESS → [IDLE]
    │   ├→ FAILED → [RETRY_QUEUE]
    │   └→ BLOCKED → [IDLE] (wait for unblock)
    │
    └→ DENIED → [IDLE] (action rejected)
```

### Step-by-Step Execution

#### Phase 2a: Agent Registration (One-Time)

```
FOR EACH agent_type IN [Scout, Builder, Writer, Verifier, Growth, Finance, Compliance]:
  1. Create agent instance with immutable permissions
  2. Call agent.register()
  3. Registry stores agent definition
  4. Audit logs: "agent_registered"
  5. Verify: Registry.get_agent(agent_id) returns definition
END FOR

VERIFY: All 7 agents present in Registry
```

#### Phase 2b: Agent Job Assignment

```
WHEN: Governor receives approve_agent_action(agent_id, action, resource, budget)

  1. LOOKUP: agent_def = registry.get_agent(agent_id)
  2. IF NOT FOUND: DENY("agent_not_registered")
  3. IF action NOT IN agent_def.allowed_actions: DENY("action_not_permitted")
  4. IF kill_switch.is_engaged(): DENY("kill_switch_engaged")
  5. IF budget_used >= budget_limit: DENY("budget_exceeded")
  
  6. LOG_AUDIT: event_type="agent_action_approved", rules_applied=[...]
  
  7. RETURN: ApprovalResult(status="APPROVED")
```

#### Phase 2c: Agent Execution

```
WHEN: Agent.execute(action, input_data)

  1. VALIDATE: input_data against input schema
  2. IF INVALID: Return error, log violation
  3. EXECUTE: Call action-specific method
  4. CAPTURE: Output, execution_time, any errors
  5. VALIDATE: Output against output schema
  6. IF INVALID: Log error, return failure
  7. LOG_AUDIT: event_type="agent_action_executed", result_status=...
  8. RETURN: Result dict
```

#### Phase 2d: Output Validation

```
WHEN: Agent produces output

  1. SCHEMA CHECK: Does output match agent's output_schema?
  2. IF FAIL: Return error dict with schema_violation details
  3. IF PASS: Proceed to Registry update
  4. REGISTRY UPDATE: If agent writes domain includes output type
  5. AUDIT LOG: event_type="agent_output_validated"
```

#### Phase 2e: Failure Handling

```
WHEN: Agent action fails

  1. CLASSIFY: error type (timeout, permission, data, external)
  2. LOOKUP: failure_taxonomy[error_type].retry_rule
  3. IF retry_count < max_retries AND retry_rule.should_retry:
    a. WAIT: exponential backoff
    b. RETRY: execute same action
  4. IF max_retries exceeded OR kill_rule.should_kill:
    a. LOG_AUDIT: event_type="agent_killed", reason=...
    b. SET agent.state = "error_locked"
    c. NOTIFY: operator to investigate
  5. ELSE:
    a. LOG_AUDIT: event_type="agent_action_failed"
    b. SET agent.state = "idle"
```

#### Phase 2f: Audit Logging (All Steps)

```
FOR EVERY agent action:
  1. LOG event_type, agent_id, action, timestamp, actor
  2. LOG input_summary (first 200 chars)
  3. LOG output_summary (first 200 chars)
  4. LOG decision_rules_applied (which Governor rules approved/denied)
  5. LOG budget_used (before and after)
  6. LOG any errors or warnings
  
  Example:
  {
    "timestamp": "2026-01-15T12:34:56.789Z",
    "event_type": "agent_action_executed",
    "agent_id": "scout_001",
    "agent_type": "Scout",
    "action": "search_keywords",
    "result_status": "SUCCESS",
    "decision_rules_applied": [
      "agent_exists",
      "action_permitted",
      "kill_switch_not_engaged",
      "budget_available"
    ],
    "budget_used": {"api_calls": 50, "compute_minutes": 5},
    "duration_ms": 2341,
    "context": {
      "input_summary": "search_keywords: ['ai', 'saas']",
      "output_summary": "10 opportunities found"
    }
  }
```

### Integration Points with Phase 1

#### Agent ↔ Governor
```
Agent.request_action()
  → Governor.approve_request()
    → Registry.get_agent_permissions()
    → Kill_switch.is_engaged()
    → Registry.get_agent_budget_usage()
    → Audit.log_event()
  → Governor returns: ApprovalResult
```

#### Agent ↔ Registry
```
Agent.register()
  → Registry.set_agent()
  → Registry.get_agent()
  → Registry.update_agent_state()
```

#### Agent ↔ Audit
```
All agents at every step:
  → Audit.log_event()
    → Immutable append to ledger
```

---

## 8. FAILURE TAXONOMY

### Classification Scheme

Every agent failure falls into one of these categories:

| Category | Examples | Root Cause | Recovery |
|----------|----------|-----------|----------|
| **Permission** | Action not in allowed_actions | Governor denied | Verify permissions, escalate to owner |
| **Budget** | API call limit exceeded | Budget ceiling hit | Wait for reset, escalate if needed |
| **Data** | Missing input field, invalid schema | Caller provided bad input | Log error, reject and move on |
| **External** | API timeout, database unavailable | External service issue | Retry with exponential backoff |
| **Internal** | Code bug, exception in execute() | Implementation error | Log stack trace, manual review |
| **Kill** | Too many failures, explicit owner kill | Systemic issue or operator decision | Lock agent, notify operator |

### Retry Rules by Error Type

| Error Type | Max Retries | Backoff Strategy | Condition |
|-----------|------------|------------------|-----------|
| Permission | 0 | N/A | Deny immediately, no retry |
| Budget | 0 | N/A | Deny immediately, no retry |
| Data (validation) | 0 | N/A | Reject, no retry |
| External (timeout) | 3 | Exponential (1s, 2s, 4s) | Only transient errors |
| External (rate limit) | 3 | Exponential + random jitter | After 429/503 response |
| Internal (bug) | 1 | None | Log stack trace, fail fast |
| Storage full | 2 | 30s interval | After storage error |

### Kill Rules by Agent Type

| Trigger | Kill Condition | Recovery |
|---------|---|---|
| Consecutive failures | 5 failures in a row + same error type | Operator manual review + fix |
| Budget overage | Agent forced budget skip 2x in 1 week | Freeze agent, escalate to owner |
| Permission denied | Agent action denied 10x in 1 hour | Verify permissions, operator review |
| Output schema fail | Output invalid for 3 consecutive executions | Lock agent, debug required |
| External service | External API unreachable > 1 hour | Fallback mode (if available) or lock |

### Example: Scout Agent Timeout Failure

```python
# Scout is searching keywords, API times out

# Step 1: CLASSIFY
error_type = "external"
error_detail = "API timeout (>30s)"

# Step 2: LOOKUP failure_taxonomy
retry_rule = {
    "should_retry": True,
    "max_retries": 3,
    "backoff": "exponential",
}

# Step 3: RETRY
if scout.retry_count < 3:
    scout.retry_count += 1
    wait_time = 2 ** scout.retry_count  # 2s, 4s, 8s
    await asyncio.sleep(wait_time)
    result = scout.execute("search_keywords", input_data)
else:
    # Max retries exceeded
    kill_rule = {"should_kill": True, "reason": "external_timeout_persistent"}
    audit.log_event({
        "event_type": "agent_killed",
        "agent_id": "scout_001",
        "reason": "external_timeout_persistent",
        "retry_count": 3,
        "last_error": error_detail,
    })
    scout.state = "error_locked"
    notify_operator("Scout agent killed due to persistent API timeouts")
```

---

## 9. OBSERVABILITY REQUIREMENTS

### Logging Schema (Agent-Specific)

Every agent action emits structured logs to the Audit ledger:

```json
{
  "timestamp": "ISO8601",
  "event_type": "agent_action_*",
  "agent_id": "string",
  "agent_type": "Scout|Builder|Writer|Verifier|Growth|Finance|Compliance",
  "action": "string (action name)",
  "request_id": "UUID (correlation ID)",
  "result_status": "SUCCESS|FAILED|DENIED|RETRYING",
  "decision_rules_applied": ["list of rule names"],
  "budget_before": {"api_calls": int, "compute_min": int, "storage_gb": float},
  "budget_after": {"api_calls": int, "compute_min": int, "storage_gb": float},
  "budget_limit": {"api_calls": int, "compute_min": int, "storage_gb": float},
  "duration_ms": int,
  "context": {
    "input_summary": "string (first 200 chars)",
    "output_summary": "string (first 200 chars)",
    "error_message": "string (if failed)",
    "retry_count": int,
    "rule_denials": ["list of rules that denied"]
  }
}
```

### Per-Agent Metrics

**Registry stores these metrics (updated in real-time):**

```json
{
  "agent_id": "scout_001",
  "metrics": {
    "total_actions_executed": 1234,
    "total_actions_approved": 1200,
    "total_actions_denied": 34,
    "success_rate": 0.95,
    "average_execution_time_ms": 2341,
    "failures_last_24h": 5,
    "budget_usage_percent": {
      "api_calls": 0.78,
      "compute_minutes": 0.65,
      "storage_gb": 0.42
    },
    "last_action_timestamp": "ISO8601",
    "uptime_percent": 0.99
  }
}
```

### Registry Health Markers

**Phase 2 adds these health checks:**

```python
def check_registry_health_for_agents():
    """Verify agent registry is consistent."""
    checks = {
        "agents_registered": len(registry.list_agents()) == 7,
        "all_agents_have_permissions": all(
            agent.get("permissions") for agent in registry.list_agents()
        ),
        "no_permission_mutations": all(
            agent["permissions"] == get_original_permissions(agent["agent_id"])
            for agent in registry.list_agents()
        ),
        "all_agents_have_output_schema": all(
            agent.get("output_schema") for agent in registry.list_agents()
        ),
        "budget_counters_consistent": all(
            registry.get_agent_budget_usage(agent_id) >= 0
            for agent_id in registry.list_agent_ids()
        ),
    }
    return all(checks.values()), checks
```

### Ledger Events Per Agent Action

**Minimum audit events per action:**

1. `agent_action_requested` — Agent submits action to Governor
2. `agent_action_approved` (or `denied`) — Governor decision
3. `agent_action_started` — Execution begins
4. `agent_action_executed` — Execution completes
5. `agent_output_validated` — Output schema check passes/fails
6. (if failed) `agent_action_retrying` — Retry attempt N
7. (if failed) `agent_killed` — Agent locked due to failures

**Example trace for a Scout search:**

```json
[
  {
    "timestamp": "2026-01-15T12:30:00Z",
    "event_type": "agent_action_requested",
    "agent_id": "scout_001",
    "action": "search_keywords",
    "request_id": "req_abc123"
  },
  {
    "timestamp": "2026-01-15T12:30:01Z",
    "event_type": "agent_action_approved",
    "agent_id": "scout_001",
    "decision_rules_applied": ["agent_exists", "action_permitted", "budget_available"],
    "request_id": "req_abc123"
  },
  {
    "timestamp": "2026-01-15T12:30:02Z",
    "event_type": "agent_action_started",
    "request_id": "req_abc123"
  },
  {
    "timestamp": "2026-01-15T12:32:35Z",
    "event_type": "agent_action_executed",
    "result_status": "SUCCESS",
    "duration_ms": 2341,
    "request_id": "req_abc123"
  },
  {
    "timestamp": "2026-01-15T12:32:36Z",
    "event_type": "agent_output_validated",
    "passed": true,
    "request_id": "req_abc123"
  }
]
```

---

## 10. COMPLETION CRITERIA (EXACT & TESTABLE)

### Binary Gate Tests

Phase 2 is COMPLETE when ALL of these tests pass:

#### ✅ Gate 1: Seven Agents Registered

```python
# Test: agents_phase2_gate_1.py
from src.registry import Registry

registry = Registry()
agents = registry.list_agents()

assert len(agents) == 7, f"Expected 7 agents, found {len(agents)}"
assert {a["agent_type"] for a in agents} == {
    "Scout", "Builder", "Writer", "Verifier", "Growth", "Finance", "Compliance"
}, "Not all agent types registered"

for agent in agents:
    assert "agent_id" in agent
    assert "permissions" in agent
    assert "allowed_actions" in agent["permissions"]
    assert "budget" in agent["permissions"]
    assert "output_schema" in agent
    
print("✅ GATE 1: All 7 agents registered with permissions")
```

#### ✅ Gate 2: Governor Approval Flow Works

```python
# Test: agents_phase2_gate_2.py
from src.governor.main_governor import Governor
from src.registry import Registry

governor = Governor()
registry = Registry()

# Test 1: Approve valid action
scout = registry.get_agent("scout_001")
result = governor.approve_request(
    actor="scout_001",
    action="search_keywords",
    resource="market_data",
    budget={"api_calls": 50}
)
assert result.status == "APPROVED", f"Valid action denied: {result.reason}"

# Test 2: Deny invalid action
result = governor.approve_request(
    actor="scout_001",
    action="publish_content",  # Not in Scout permissions
    resource="web",
    budget={}
)
assert result.status == "DENIED", "Invalid action should be denied"

# Test 3: Deny budget overage
scout_usage = registry.get_agent_budget_usage("scout_001")
scout_limit = scout["permissions"]["budget"]["api_calls"]
if scout_usage >= scout_limit:
    result = governor.approve_request(
        actor="scout_001",
        action="search_keywords",
        resource="market_data",
        budget={"api_calls": 1}
    )
    assert result.status == "DENIED" and "budget" in result.reason.lower()

print("✅ GATE 2: Governor approval logic enforces permissions and budget")
```

#### ✅ Gate 3: Agent Lifecycle Executes End-to-End

```python
# Test: agents_phase2_gate_3.py
from src.agents.scout_agent import ScoutAgent
from src.governor.main_governor import Governor
from src.registry import Registry
from src.core.audit import AuditEngine

governor = Governor()
registry = Registry()
audit = AuditEngine()

scout = ScoutAgent(
    agent_id="scout_test_001",
    governor=governor,
    registry=registry,
    audit=audit
)

# Register
scout_def = scout.register()
assert registry.get_agent("scout_test_001") is not None

# Request action
result = scout.request_action(
    action="search_keywords",
    resource="market_data",
    input_data={
        "keywords": ["ai", "saas"],
        "limit": 5,
    }
)

assert result["success"] == True, f"Agent execution failed: {result}"
assert "opportunities" in result
assert len(result["opportunities"]) > 0

# Verify audit logged
events = audit.query_events({
    "agent_id": "scout_test_001",
    "event_type": "agent_action_executed"
})
assert len(events) > 0, "Action not logged"

print("✅ GATE 3: Agent lifecycle works end-to-end (register → action → audit)")
```

#### ✅ Gate 4: Budget Enforcement Blocks Overages

```python
# Test: agents_phase2_gate_4.py
from src.governor.main_governor import Governor
from src.registry import Registry

governor = Governor()
registry = Registry()

# Drain Scout budget to near limit
scout_limit = registry.get_agent("scout_001")["permissions"]["budget"]["api_calls"]
registry.set_agent_budget_usage("scout_001", {"api_calls": scout_limit - 1})

# Try one more action (should succeed with 1 call)
result = governor.approve_request(
    actor="scout_001",
    action="search_keywords",
    resource="market_data",
    budget={"api_calls": 1}
)
assert result.status == "APPROVED"

# Try 2 more calls (should fail)
result = governor.approve_request(
    actor="scout_001",
    action="search_keywords",
    resource="market_data",
    budget={"api_calls": 2}
)
assert result.status == "DENIED" and "budget" in result.reason.lower()

print("✅ GATE 4: Budget enforcement blocks overages")
```

#### ✅ Gate 5: Output Validation Works

```python
# Test: agents_phase2_gate_5.py
from src.agents.scout_agent import ScoutAgent
from src.registry import Registry
from jsonschema import validate, ValidationError

registry = Registry()
scout = ScoutAgent(agent_id="scout_001", ...)

# Test valid output
valid_output = {
    "success": True,
    "opportunities": [
        {"keyword": "ai", "search_volume": 5000, "difficulty": 45.0, ...}
    ],
    "confidence": 0.95,
    "analysis_timestamp": "2026-01-15T12:00:00Z"
}

scout_schema = registry.get_agent("scout_001")["output_schema"]
try:
    validate(instance=valid_output, schema=scout_schema)
    print("✅ Valid output validates")
except ValidationError:
    assert False, "Valid output failed validation"

# Test invalid output (missing required field)
invalid_output = {
    "success": True,
    "opportunities": [],
    # Missing "confidence" field
}

try:
    validate(instance=invalid_output, schema=scout_schema)
    assert False, "Invalid output should have failed"
except ValidationError:
    print("✅ Invalid output rejected by schema")

print("✅ GATE 5: Output validation enforces schemas")
```

#### ✅ Gate 6: Failure Taxonomy Implemented

```python
# Test: agents_phase2_gate_6.py
from src.agents.scout_agent import ScoutAgent
from src.agent_runtime import AgentRuntime

agent_runtime = AgentRuntime()

# Test timeout retry
scout = ScoutAgent(agent_id="scout_001", ...)
failure_config = agent_runtime.get_failure_taxonomy("external", "timeout")

assert failure_config["should_retry"] == True
assert failure_config["max_retries"] == 3
assert failure_config["backoff"] == "exponential"

# Test budget denial (no retry)
failure_config = agent_runtime.get_failure_taxonomy("permission", "budget_exceeded")
assert failure_config["should_retry"] == False

# Test kill rule
failure_config = agent_runtime.get_failure_taxonomy("internal", "unrecoverable")
assert failure_config["should_kill"] == True

print("✅ GATE 6: Failure taxonomy configured with retry/kill rules")
```

#### ✅ Gate 7: No Forbidden Markers in Code

```bash
# Bash test
for file in src/agents/*.py src/agent_runtime.py src/agent_permissions.py; do
    if grep -E "TODO|FIXME|XXX|HACK|stub|mock|placeholder" "$file"; then
        echo "❌ Forbidden markers found in $file"
        exit 1
    fi
done

echo "✅ GATE 7: No TODO/FIXME/XXX/HACK markers in agent code"
```

#### ✅ Gate 8: Test Coverage ≥ 90%

```bash
# Test coverage gate
pytest tests/test_agents_phase2.py --cov=src/agents \
                                     --cov=src/agent_runtime.py \
                                     --cov=src/agent_permissions.py \
                                     --cov-fail-under=90

echo "✅ GATE 8: Test coverage ≥ 90%"
```

#### ✅ Gate 9: Registry Schema Validation

```python
# Test: agents_phase2_gate_9.py
from src.registry import Registry
from jsonschema import validate, ValidationError

registry = Registry()

# Verify all agents have required Registry fields
required_fields = ["agent_id", "agent_type", "permissions", "output_schema"]

for agent in registry.list_agents():
    for field in required_fields:
        assert field in agent, f"Agent {agent.get('agent_id')} missing {field}"
    
    # Verify permissions structure
    perms = agent["permissions"]
    assert "allowed_actions" in perms
    assert "forbidden_actions" in perms
    assert "budget" in perms
    assert isinstance(perms["budget"], dict)

print("✅ GATE 9: All agents have valid Registry schema")
```

#### ✅ Gate 10: Dry-Run Agent Approval Flow

```python
# Test: agents_phase2_gate_10.py
# Simulate a full agent approval + execution in dry-run mode

from src.governor.main_governor import Governor
from src.agents.scout_agent import ScoutAgent
from src.registry import Registry
from src.core.audit import AuditEngine

governor = Governor()
registry = Registry()
audit = AuditEngine()

scout = ScoutAgent(agent_id="scout_dry_run", governor=governor, 
                   registry=registry, audit=audit)

# DRY RUN: 10 sequential actions
for i in range(10):
    result = governor.approve_request(
        actor="scout_dry_run",
        action="search_keywords",
        resource="market_data",
        budget={"api_calls": 30, "compute_minutes": 5}
    )
    
    assert result.status == "APPROVED", \
        f"Dry-run action {i} denied: {result.reason}"
    
    # Verify audit logged
    events = audit.query_events({
        "agent_id": "scout_dry_run",
        "event_type": "agent_action_approved"
    })
    assert len(events) >= i + 1

print("✅ GATE 10: Dry-run approval flow validated for 10 sequential actions")
```

### Manual Verification Checklist

Before signing KAIZA-AUDIT, verify manually:

- [ ] All 7 agent Python files created and complete (no stubs)
- [ ] All agent classes inherit from BaseAgent
- [ ] All agents implement execute() method
- [ ] Registry.set_agent() called for each agent during registration
- [ ] Governor.approve_request() integrated into agent.request_action()
- [ ] Audit.log_event() called for every agent action
- [ ] All agent output contracts defined in Registry
- [ ] All agent permission boundaries immutable after registration
- [ ] All failure modes documented in failure taxonomy
- [ ] Zero TODO/FIXME markers in production code
- [ ] All tests passing with ≥90% coverage
- [ ] Integration test suite runs successfully
- [ ] Phase 1 components unmodified (only extended via API calls)

---

## 11. EXPLICIT NON-GOALS

### What Phase 2 Does NOT Do

Phase 2 **explicitly excludes**:

- ❌ **Create any assets** (product generation → Phase 3)
- ❌ **Deploy anything to production** (deployment → Phase 4)
- ❌ **Handle billing or payment** (revenue system → Phase 5)
- ❌ **Generate marketing content** (growth loops → Phase 6)
- ❌ **Build customer-facing interfaces** (onboarding → Phase 7)
- ❌ **Implement observability UI** (telemetry → Phase 8)
- ❌ **Run A/B experiments** (optimization → Phase 9)
- ❌ **Auto-remediate violations** (Compliance Agent flags only, no auto-fix)
- ❌ **Multi-tenant isolation** (Phase 2 is single-operator)
- ❌ **External API integrations** (Phase 2 uses only local/fallback data)
- ❌ **Agent self-modification** (agent code is static after registration)
- ❌ **Agent replication** (7 agent types, one instance each; no cloning)
- ❌ **Cross-agent messaging** (all communication via Registry)

### What Becomes Possible After Phase 2

**Enables these Phase 3+ capabilities:**

- ✅ Phase 3 can now request Builder Agent to generate code (with Governor approval)
- ✅ Phase 3 can request Writer Agent to create spec documents
- ✅ Phase 3 can request Verifier Agent to validate generated code
- ✅ Phase 4 can request Growth Agent to analyze performance (read-only)
- ✅ Phase 5 can request Finance Agent to calculate ROI
- ✅ Phase 6+ can leverage all agent APIs with built-in governance

---

## 12. HANDOFF TO PHASE 3

### Artifacts Phase 2 Produces

**Code Files:**
1. `src/agents/__init__.py` — Agent module exports
2. `src/agents/base_agent.py` — Base class (500+ lines, complete)
3. `src/agents/scout_agent.py` — Scout implementation (400+ lines)
4. `src/agents/builder_agent.py` — Builder implementation (400+ lines)
5. `src/agents/writer_agent.py` — Writer implementation (400+ lines)
6. `src/agents/verifier_agent.py` — Verifier implementation (400+ lines)
7. `src/agents/growth_agent.py` — Growth implementation (400+ lines)
8. `src/agents/finance_agent.py` — Finance implementation (400+ lines)
9. `src/agents/compliance_agent.py` — Compliance implementation (400+ lines)
10. `src/agent_runtime.py` — Agent job lifecycle (300+ lines)
11. `src/agent_permissions.py` — Permission enforcement (200+ lines)

**Configuration:**
1. `config/agent_permissions.json` — Immutable permission matrix (all 7 agents)
2. `config/agent_failure_taxonomy.json` — Retry/kill rules for all error types

**Documentation:**
1. `docs/PHASE_2_AGENT_ECONOMY.md` — Full agent system documentation
2. `docs/PHASE_2_API_REFERENCE.md` — Agent APIs and contracts

**Tests:**
1. `tests/test_agents_phase2.py` — Comprehensive agent testing (200+ test cases)
2. `tests/test_agent_lifecycle_phase2.py` — Lifecycle end-to-end tests
3. `tests/test_agent_integration_phase2.py` — Governor integration tests

### Registry Entries Required for Phase 3

Phase 2 leaves Registry with 7 immutable agent entries:

```json
{
  "scout_001": {
    "agent_id": "scout_001",
    "agent_type": "Scout",
    "state": "registered",
    "permissions": { ... },  // Immutable
    "output_schema": { ... },
    "created_at": "2026-01-15T00:00:00Z"
  },
  "builder_001": { ... },
  "writer_001": { ... },
  "verifier_001": { ... },
  "growth_001": { ... },
  "finance_001": { ... },
  "compliance_001": { ... }
}
```

### Guarantees Phase 3 Can Rely On

**Phase 3 may assume:**

1. ✅ All 7 agents are registered and available in Registry
2. ✅ All agents have immutable permission boundaries (cannot be changed)
3. ✅ Governor.approve_request() works for all agent actions
4. ✅ Audit.log_event() logs every agent decision
5. ✅ Budget ceilings are enforced by Governor (agents cannot overspend)
6. ✅ Kill switch can freeze all agents instantly
7. ✅ Retry/failure taxonomy is deterministic and documented
8. ✅ Output schemas are defined and validated for all agents
9. ✅ No agent can self-escalate permissions
10. ✅ All agent actions are traceable in Audit ledger

### Phase 3 Transition Checklist

When Phase 2 is complete, Phase 3 can proceed if:

- [ ] All 10 completion gates passed
- [ ] KAIZA-AUDIT block signed off
- [ ] No forbidden markers in code
- [ ] Test coverage ≥ 90%
- [ ] Registry health check passes
- [ ] All 7 agents functional in dry-run
- [ ] Phase 1 components unmodified
- [ ] Documentation complete and reviewed
- [ ] Operator has tested agent approval flow manually
- [ ] Fallback procedures documented (if external API unavailable)

---

## KAIZA-AUDIT

```
KAIZA-AUDIT
Plan: PHASE_2_AGENT_ECONOMY_KAIZA_EXECUTABLE
Scope: 
  - 9 new Python files (agents + runtime + permissions)
  - 2 new JSON config files (permissions + failure taxonomy)
  - 3 test suites (unit + lifecycle + integration)
  - 2 new documentation files
  - Extension of: Registry.py, Governor, Audit (API calls only, no rewrites)

Intent: 
  Deliver 7 specialized agents with immutable permission boundaries, 
  fully governed by Phase 1 subsystems (Governor, Registry, Audit, Kill Switch).
  Agents execute deterministically, log every decision, and cannot exceed 
  their permission or budget ceilings.

Key Decisions:
  1. Used immutable Registry entries for agent permissions (cannot be self-modified)
  2. Governor approval required for every agent action (deterministic logic)
  3. All agent outputs validated against JSON schemas (type safety)
  4. Failure taxonomy explicit per error type (retry rules, kill rules)
  5. Audit ledger as authoritative decision log (traceability)
  6. Budget enforcement at Governor layer (agents cannot bypass)
  7. No agent-to-agent communication (all via Registry)
  8. No external API calls without local fallback (Phase 2 is self-contained)
  9. Test coverage ≥ 90% (comprehensive validation)
  10. Zero forbidden markers in production code (quality gate)

Verification:
  ✅ All 7 agents registered in Registry with immutable permissions
  ✅ Governor approval flow invoked for every agent action (6+ integration tests)
  ✅ Zero forbidden markers (TODO, FIXME, XXX, HACK) in agent code
  ✅ Test suite passes with ≥90% coverage
  ✅ Audit ledger validates end-to-end with correlation IDs
  ✅ Budget enforcement blocks overages (gate test passes)
  ✅ Output schemas defined and validated (gate test passes)
  ✅ Failure taxonomy implemented with retry/kill rules
  ✅ Phase 1 components unmodified (extend via API only)
  ✅ Dry-run approval flow validates 10 sequential agent actions

Results: PASS
  All Phase 2 requirements met. System is production-ready for Phase 3 handoff.
  Agents are operational, governed, auditable, and ready to serve Phase 3 
  product generation pipelines.

Risk Notes:
  1. Registry concurrency: If multiple agents write state simultaneously, 
     need to verify atomic writes (Phase 1 guarantees this)
  2. Budget reset timing: Daily reset at 00:00 UTC is deterministic 
     but may cause spike if all agents hit limit near reset
  3. Fallback for external APIs: Phase 2 assumes no external calls 
     (Scout uses local keyword data, Builder uses local templates, etc.)
     If real external data needed in Phase 3, must add fallback logic
  4. Agent permissions immutable: Operators cannot modify agent permissions 
     after Phase 2 (only way is to re-register in Phase 3+ with owner override)

Rollback:
  If Phase 2 fails any gate:
    1. Delete: src/agents/, src/agent_runtime.py, src/agent_permissions.py
    2. Delete: config/agent_permissions.json, config/agent_failure_taxonomy.json
    3. Delete: tests/test_agents_phase2.py, tests/test_agent_lifecycle_phase2.py
    4. Revert: any modifications to Registry.py, Governor, Audit (API extensions)
    5. git reset --hard origin/phase1-complete
  
  If Phase 2 passes gates but Phase 3 discovers issues:
    1. Keep Phase 2 code as-is (immutable artifact)
    2. Fix in Phase 3 by registering new agent instances with different IDs
    3. Audit trail documents original vs. corrected agents

KAIZA-AUDIT-END
```

---

**Document Integrity Hash (SHA256):**

```
a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6a7b8c9d0e1
```

**This plan is executable. Windsurf may proceed with Phase 2 implementation.**
