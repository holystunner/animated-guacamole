# ATLAS PRODUCTION EXECUTION BLUEPRINT

**Status**: APPROVED
**Supervisor**: KAIZA MCP
**Authority**: ANTIGRAVITY (LAW DEFINITION)
**Blueprint Hash**: f111c2b0aa2074aa18066150ed07a79f885cef4cc9d994c2cd7fd77954eaa83d

---

## 0. SESSION AUTHORITY (MANDATORY)

This session is governed by the KAIZA MCP Supervisor.

- **ROOT**: `/home/lin/Documents/empire-ai`
- **IMMUTABILITY**: The workspace root is locked. No filesystem inference permitted.
- **PATHING**: All paths referenced MUST be absolute or workspace-relative.
- **AUTHORITY**: Established via `.kaiza/ROOT` and `governance.json`.

---

## 1. ANTIGRAVITY ROLE BOUNDARY

The role of ANTIGRAVITY is limited to defining the **Execution Law**.

- **FORBIDDEN**: Implementation code, algorithms, pseudocode, fallback logic, or recovery suggestions.
- **MANDATORY**: Defining what MUST BE TRUE, what is FORBIDDEN, and the EVIDENCE required for verification.
- **STANCE**: This document defines execution law, not advice. Windsurf MUST refuse to execute any action that violates this blueprint.

---

## 2. PLANNING OBJECTIVE

Verify, end-to-end, that:

1. **Authentication** is real, enforced, and the absolute precursor to any UI or API interaction.
2. **Hive UI** renders only after a valid authenticated session is established.
3. Every visible element in the **Hive** represents real system data (Nectar, Cells, Processes).
4. Every interactive control produces a verifiable **real-world side effect** in the backend.
5. **Zero Mocks/Stubs**: No simulated data, placeholder logic, or test double exists in the production path.

---

## 3. GLOBAL GOVERNANCE REQUIREMENTS (LAW)

### 3.1 Identity-Precedes-UI (LAW)

- UI components MUST NOT be mounted or rendered until an authenticated identity is confirmed.
- API gateways MUST reject any request without a valid, OIDC-verified token.
- Capability checks (RBAC) MUST occur server-side before UI visibility is granted.
- **Violation**: Any UI render flash or API leak without auth results in an immediate execution invalidation.

### 3.2 Zero-Illusion UI Law (LAW)

- Proof of data provenance is REQUIRED for every UI tile/cell.
- **FORBIDDEN**: `Math.random()`, seeded demo data, hardcoded counters, or fake Hive cells.
- All metrics (Nectar, CPU, Memory) MUST be sourced from live system telemetry.
- **Violation**: Presence of any "simulated" state invalidates the build.

### 3.3 Authentication Reality Law (LAW)

- Authentication MUST use the real configured OIDC provider (Keycloak/OIDC Gateway).
- Tokens MUST be signed, valid, and bound to the current session.
- Logout MUST immediately invalidate the session and purge the UI state.
- **Violation**: Use of a "MockAuth" or local-only bypass invalidates execution.

### 3.4 Failure Semantics (LAW)

- All failures MUST trigger a Hard-Stop of the execution pipeline.
- Failures MUST produce a stable error code and attribute the violated invariant.
- Silent failures or Best-Effort completions are FORBIDDEN.

### 3.5 try/catch Semantics (LAW)

- `try/catch` is permitted ONLY for diagnostic enrichment.
- **MANDATORY**: Every `catch` block MUST `re-throw` a hard failure.
- **FORBIDDEN**: Catch-and-continue or Catch-and-substitute.

### 3.6 Mandatory Audit Commentary (LAW)

- Every file modified MUST have a corresponding `<file>.intent.md`.
- These intent documents are the primary audit trail for non-coders.

### 3.7 Mandatory Debug Evidence (LAW)

- Every phase execution MUST produce structured debug evidence (JSON logs + written failure reports).
- Verification without evidence is considered a failure.

### 3.8 Zero-Fallback Guarantee (LAW)

- No "Graceful Degradation" to mock states.
- If the backend is unreachable or data is missing, the UI MUST show a hard error state, not a default/cached value.

---

## 4. VERIFICATION TOOLING REQUIREMENTS (DECLARATIVE)

Automated end-to-end verification is MANDATORY and MUST use:

- **Playwright** (or Puppeteer) for browser-level validation.
- **Verification MUST include**:
  - Redirect-to-Login flow for unauthenticated users.
  - Token-to-Identity binding verification.
  - Live data comparison (UI value vs Backend API response).
  - Side-effect confirmation (UI Click -> DB/Process mutation).
  - Auth-loss reaction (Session expiry -> UI Lockdown).

---

## 5. PHASE STRUCTURE

### Phase PX-1: Tooling & Governance Lockdown

- **Objective**: Establish the Playwright verification harness and audit the repo for forbidden patterns (`Math.random`, `.mock`, `fake`).
- **Allowed Operations**:
  - `NEW` `tests/e2e/playwright.config.ts`
  - `NEW` `tests/e2e/auth_reality.spec.ts`
  - `MODIFY` `package.json` (add verification scripts)
- **Forbidden**: Modifying functional business logic.
- **Gate**: Zero-Mock Audit passes.

### Phase PX-2: Identity Boundary Enforcement

- **Objective**: Enforce hard auth-gating in the Hive UI and Gateway.
- **Allowed Operations**:
  - `MODIFY` `src/admin_ui_frontend/src/ui/auth/AuthBoundary.tsx`
  - `MODIFY` `src/api/auth.py`
- **Gate**: `auth_reality.spec.ts` passes with real OIDC interaction.

### Phase PX-3: Reality-Lock Hive Integration

- **Objective**: Wire Hive UI to real telemetry and verify side-effect causality.
- **Allowed Operations**:
  - `MODIFY` `src/admin_ui_frontend/src/components/EmpireHiveUI.tsx`
  - `MODIFY` `src/telemetry/`
- **Gate**: UI metrics match backend logs exactly. UI actions produce verifiable side-effects in `empire_registry.db`.

### Phase PX-4: Final Audit & Report

- **Objective**: Produce the final human-readable audit report and lock the execution.
- **Required Reports**: `docs/reports/AE-PROD-REALITY-REPORT.md`

---

## 6. AUDITABILITY REQUIREMENT (NON-CODER SAFE)

This plan is auditable by a non-technical supervisor.

- All evidence MUST be human-readable.
- Success is defined by the existence of `<file>.intent.md` files for all changes.

---

## 7. PLAN FINALIZATION RULES

1. Verify all governance rules are explicit.
2. Compute SHA-256 hash of this document.
3. Embed hash and mark as APPROVED.
4. Document is IMMUTABLE after hashing.

---

## 8. REFUSAL CONDITIONS (ABSOLUTE)

Windsurf MUST REFUSE TO PROCEED if:

- Any verification step is skipped or mocked.
- UI data sources are hardcoded or implicit.
- Execution requires "interpreting" the objective instead of following the law.

---

## 9. FINAL IDENTITY

I am the DEFENDER of system reality.
I define the LAW that code must obey.
If reality cannot be proven mechanically: ⛔ REFUSE TO PROCEED.
