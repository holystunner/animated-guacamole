# ADR-XXX: [Title]

**Status**: [Proposed/Accepted/Deprecated/Superseded/Amended/Rejected]  
**Date**: [YYYY-MM-DD]  
**Authors**: [Author names]  
**Reviewers**: [Reviewer names]  

## Context

[Provide the context for the decision. What problem are we trying to solve? What are the constraints? What is the background information that led to this decision?]

## Decision

[Clearly state the decision that was made. This should be a concise statement of what was decided.]

## Rationale

[Explain why this decision was made. What were the key factors that influenced this decision? What are the benefits of this approach? Why is this the best choice among the alternatives?]

## Consequences

### Positive Consequences

[List the positive impacts of this decision. What benefits will this bring to the system, team, or organization?]

### Negative Consequences

[List the negative impacts or trade-offs of this decision. What are the costs, risks, or downsides?]

### Risks and Mitigations

[Identify any risks associated with this decision and how they will be mitigated.]

## Alternatives Considered

[Describe the alternatives that were considered and why they were not chosen. For each alternative, explain the pros and cons and why it was rejected.]

### Alternative 1: [Name]
- **Description**: [Brief description of the alternative]
- **Pros**: [List of advantages]
- **Cons**: [List of disadvantages]
- **Reason for Rejection**: [Why this alternative was not chosen]

### Alternative 2: [Name]
- **Description**: [Brief description of the alternative]
- **Pros**: [List of advantages]
- **Cons**: [List of disadvantages]
- **Reason for Rejection**: [Why this alternative was not chosen]

## Implementation

[Describe how this decision will be implemented. What are the specific steps, timelines, and resources required?]

### Implementation Plan

1. **Phase 1**: [Description of first phase]
   - **Timeline**: [Estimated duration]
   - **Resources**: [Required resources]
   - **Deliverables**: [Expected outcomes]

2. **Phase 2**: [Description of second phase]
   - **Timeline**: [Estimated duration]
   - **Resources**: [Required resources]
   - **Deliverables**: [Expected outcomes]

### Success Criteria

[How will we know if this implementation is successful? What metrics or indicators will we use?]

## Related ADRs

[List any related ADRs that this decision builds upon, conflicts with, or is related to in any way.]

- [ADR-XXX: Title](xxx-title.md) - [Relationship to this ADR]
- [ADR-YYY: Title](yyy-title.md) - [Relationship to this ADR]

## Documentation References

[Reference any relevant documentation, specifications, or external resources.]

- [Document Title](link-to-document) - [Relevance]
- [Specification](link-to-spec) - [Relevance]

## Code References

[Reference any code implementations, configurations, or examples that demonstrate this decision.]

- `src/component/file.py` - [Relevance]
- `config/setting.yaml` - [Relevance]

## Testing Strategy

[How will this decision be tested? What testing approach will be used to validate the implementation?]

### Unit Tests
- [Description of unit test approach]
- [Coverage requirements]

### Integration Tests
- [Description of integration test approach]
- [Test scenarios]

### Performance Tests
- [Description of performance test approach]
- [Performance criteria]

## Monitoring and Observability

[How will we monitor this implementation? What metrics or observability signals are needed?]

### Key Metrics
- [Metric 1]: [Description and target]
- [Metric 2]: [Description and target]

### Alerting
- [Alert condition]: [Description and response procedure]

### Dashboards
- [Dashboard name]: [Purpose and key indicators]

## Rollback Plan

[If this decision needs to be rolled back, what is the procedure? What are the triggers for rollback?]

### Rollback Triggers
- [Trigger 1]: [Description and threshold]
- [Trigger 2]: [Description and threshold]

### Rollback Procedure
1. [Step 1 of rollback procedure]
2. [Step 2 of rollback procedure]
3. [Step 3 of rollback procedure]

### Rollback Risks
- [Risk 1]: [Description and mitigation]
- [Risk 2]: [Description and mitigation]

## Future Considerations

[What future work or considerations might be needed related to this decision? Are there any follow-up decisions that might be needed?]

### Potential Enhancements
- [Enhancement 1]: [Description and timeline]
- [Enhancement 2]: [Description and timeline]

### Long-term Implications
- [Implication 1]: [Description and impact]
- [Implication 2]: [Description and impact]

## Review History

| Date | Reviewer | Comments | Status |
|------|----------|----------|--------|
| [YYYY-MM-DD] | [Reviewer name] | [Review comments] | [Status] |
| [YYYY-MM-DD] | [Reviewer name] | [Review comments] | [Status] |

## Approval

**Approved by**: [Approver name and title]  
**Approval Date**: [YYYY-MM-DD]  
**Implementation Start**: [YYYY-MM-DD]  
**Target Completion**: [YYYY-MM-DD]

---

**ADR Metadata**:
- **Category**: [Architecture/Data/Communication/Infrastructure/Security]
- **Impact**: [High/Medium/Low]
- **Scope**: [System-wide/Component/Team]
- **Effort**: [High/Medium/Low]
