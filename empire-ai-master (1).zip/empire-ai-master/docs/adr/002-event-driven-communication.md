# ADR-002: Event-Driven Communication

**Status**: Accepted  
**Date**: 2025-01-20  
**Authors**: Principal Engineer (Backend), Integration Architect  
**Reviewers**: Architecture Committee  

## Context

With the microservices architecture established in [ADR-001](001-microservices-architecture.md), Empire AI needs a communication pattern that supports:

1. **Autonomous Operations**: Services must operate independently without tight coupling
2. **Scalability**: Communication patterns must support variable load patterns
3. **Reliability**: System must remain operational even if individual services are unavailable
4. **Audit Trail**: All communication must be logged for compliance and debugging
5. **Real-time Updates**: UI requires real-time updates from backend services
6. **Agent Coordination**: Multiple agents need to coordinate without direct dependencies

Traditional synchronous request/response patterns create tight coupling and single points of failure. The autonomous nature of Empire AI requires services to make decisions and act independently while maintaining system coherence.

## Decision

We will adopt an **event-driven communication pattern** using a combination of:

1. **Event Bus**: Central event bus for asynchronous service communication
2. **WebSocket Connections**: Real-time bidirectional communication for UI updates
3. **REST APIs**: Synchronous communication for query operations and external integrations
4. **Message Queues**: Durable message queues for critical operations
5. **Event Sourcing**: Immutable event log for audit and replay capabilities

## Rationale

### Benefits of Event-Driven Architecture

1. **Loose Coupling**: Services communicate through events without direct dependencies
2. **Scalability**: Event consumers can scale independently of producers
3. **Resilience**: Services can continue operating even if consumers are temporarily unavailable
4. **Audit Trail**: All events are logged, providing complete audit history
5. **Real-time Updates**: WebSocket connections provide immediate UI updates
6. **Autonomy Support**: Services can make autonomous decisions and broadcast results

### Alignment with Empire AI Requirements

1. **Agent Independence**: Agents can publish events without knowing who consumes them
2. **Governance**: Policy decisions can be broadcast to all relevant services
3. **Audit Compliance**: All events are logged for compliance and debugging
4. **Real-time Monitoring**: UI receives real-time updates from all services
5. **Fault Tolerance**: System continues operating even if some services are down

## Consequences

### Positive Consequences

1. **Improved Resilience**: Services can operate independently of each other
2. **Better Scalability**: Event consumers can scale based on their own load
3. **Complete Audit Trail**: All communication is logged and auditable
4. **Real-time Responsiveness**: UI updates immediately when events occur
5. **Flexibility**: New services can easily subscribe to existing events
6. **Debugging Support**: Event replay helps with debugging and testing

### Negative Consequences

1. **Increased Complexity**: More complex than simple REST APIs
2. **Event Ordering**: Ensuring event order across distributed services
3. **Event Schema Evolution**: Managing changes to event schemas over time
4. **Debugging Complexity**: Harder to trace request flow across events
5. **Testing Complexity**: Need to test event flows and timing
6. **Operational Overhead**: Need to manage event infrastructure

### Risks and Mitigations

| Risk | Impact | Mitigation |
|------|--------|------------|
| Event Storming | High | Implement event throttling and circuit breakers |
| Message Loss | High | Durable message queues with acknowledgments |
| Schema Conflicts | Medium | Strict event schema validation and versioning |
| Debugging Complexity | Medium | Distributed tracing with correlation IDs |
| Performance Bottlenecks | Medium | Event bus clustering and load balancing |

## Alternatives Considered

### Alternative 1: Pure REST APIs
- **Description**: All communication through synchronous REST APIs
- **Pros**: Simple, well-understood, easy to debug
- **Cons**: Tight coupling, poor resilience, no real-time updates
- **Reason for Rejection**: Cannot support autonomous operations and real-time requirements

### Alternative 2: gRPC Communication
- **Description**: Use gRPC for all service-to-service communication
- **Pros**: High performance, strongly typed interfaces
- **Cons**: Still synchronous, limited real-time capabilities
- **Reason for Rejection**: Doesn't provide the loose coupling needed for autonomy

### Alternative 3: Message Queues Only
- **Description**: Use message queues for all communication
- **Pros**: Reliable, asynchronous, good for batch processing
- **Cons**: Poor for real-time updates, complex for simple queries
- **Reason for Rejection**: Too heavyweight for simple query operations

## Implementation

### Phase 1: Event Bus Infrastructure (Weeks 1-3)
- **Redis Pub/Sub**: Basic event bus implementation
- **Event Schema Definition**: Standardized event format and validation
- **Basic Event Publishers**: Core services publish key events
- **Timeline**: 3 weeks
- **Resources**: 2 backend engineers, 1 DevOps engineer
- **Deliverables**: Working event bus with basic events

### Phase 2: WebSocket Real-time Updates (Weeks 4-5)
- **WebSocket Server**: Real-time bidirectional communication
- **Event-to-WebSocket Bridge**: Bridge events to WebSocket clients
- **UI Integration**: Frontend consumes WebSocket events
- **Timeline**: 2 weeks
- **Resources**: 1 frontend engineer, 1 backend engineer
- **Deliverables**: Real-time UI updates

### Phase 3: Message Queues and Durability (Weeks 6-7)
- **RabbitMQ Integration**: Durable message queues for critical events
- **Event Replay**: Event history and replay capabilities
- **Dead Letter Queues**: Handle failed event processing
- **Timeline**: 2 weeks
- **Resources**: 1 backend engineer, 1 DevOps engineer
- **Deliverables**: Durable event processing

### Success Criteria

- **Event Latency**: <50ms for 95th percentile event delivery
- **Message Durability**: 99.999% message delivery guarantee
- **Real-time Updates**: <100ms from event to UI update
- **Event Throughput**: Support 10,000 events/second
- **Reliability**: No message loss even with service failures

## Related ADRs

- [ADR-001: Microservices Architecture](001-microservices-architecture.md) - Provides the service context
- [ADR-003: Immutable Audit Log](003-immutable-audit-log.md) - Defines audit logging requirements
- [ADR-004: Agent-Based Architecture](004-agent-based-architecture.md) - Defines agent communication patterns

## Documentation References

- [Event-Driven Architecture Patterns](https://microservices.io/patterns/data/event-driven-architecture.html)
- [WebSocket API Reference](../v1/api/websocket-api.md)
- [Event Schema Specification](../v1/development/event-schemas.md)

## Code References

- `src/events/event_bus.py` - Event bus implementation
- `src/events/websocket_handler.py` - WebSocket event handler
- `src/events/message_queue.py` - Message queue integration
- `config/event_schemas.json` - Event schema definitions

## Testing Strategy

### Unit Tests
- Test event publishing and subscription
- Test event schema validation
- Test WebSocket connection handling
- Test message queue operations

### Integration Tests
- Test end-to-end event flows
- Test event delivery across service boundaries
- Test WebSocket event broadcasting
- Test message queue durability

### Performance Tests
- Load test event bus with high event volume
- Test WebSocket connection limits
- Test message queue throughput
- Validate latency targets

## Monitoring and Observability

### Key Metrics
- **Event Throughput**: Events processed per second
- **Event Latency**: Time from event publish to consume
- **WebSocket Connections**: Active WebSocket connections
- **Message Queue Depth**: Queue size and processing rate
- **Error Rate**: Event processing error rate

### Alerting
- **Event Bus Down**: Alert if event bus is unavailable
- **High Latency**: Alert if event latency >100ms
- **Queue Backlog**: Alert if queue depth >1000 messages
- **WebSocket Errors**: Alert if WebSocket error rate >1%

### Dashboards
- **Event Flow Dashboard**: Real-time event flow visualization
- **WebSocket Dashboard**: WebSocket connection status
- **Message Queue Dashboard**: Queue health and performance

## Rollback Plan

### Rollback Triggers
- **Event Loss**: Detected message loss in event processing
- **Performance Degradation**: Event latency >500ms
- **WebSocket Failures**: >10% WebSocket connection failures
- **Queue Overflow**: Message queue depth >10,000

### Rollback Procedure
1. **Isolate Event Bus**: Stop new event publishing
2. **Switch to REST**: Temporarily use REST APIs for critical operations
3. **Clear Queues**: Clear backed-up message queues
4. **Restart Services**: Restart services with previous configuration
5. **Verify Operations**: Confirm system is operating normally

### Rollback Risks
- **State Inconsistency**: Services may have inconsistent state during rollback
- **Event Loss**: In-flight events may be lost during rollback
- **UI Disconnection**: WebSocket connections may be disrupted

## Future Considerations

### Potential Enhancements
- **Event Sourcing**: Full event sourcing for critical services
- **CQRS**: Command Query Responsibility Segregation for read/write separation
- **Event Mesh**: Advanced event routing and filtering
- **Stream Processing**: Real-time event stream processing

### Long-term Implications
- **Event Schema Evolution**: Need strategy for evolving event schemas
- **Event Governance**: Need governance for event design and ownership
- **Performance Scaling**: May need more sophisticated event infrastructure

## Review History

| Date | Reviewer | Comments | Status |
|------|----------|----------|--------|
| 2025-01-18 | Architecture Committee | Good fit for autonomous operations | Approved |
| 2025-01-19 | Frontend Lead | Ensure WebSocket reliability | Addressed |
| 2025-01-19 | DevOps Engineer | Add monitoring requirements | Added |

## Approval

**Approved by**: Chief Architect  
**Approval Date**: 2025-01-20  
**Implementation Start**: 2025-01-21  
**Target Completion**: 2025-03-15

---

**ADR Metadata**:
- **Category**: Communication
- **Impact**: High
- **Scope**: System-wide
- **Effort**: Medium
