# ADR-005: SQLite for Registry

## Status

**Status**: Accepted  
**Date**: 2026-01-26  
**Authors**: Architecture Committee  
**Reviewers**: Principal Engineers, DevOps Team  

## Context

Empire AI requires a registry system to store metadata, performance data, and state information for digital assets and agents. The registry must support high-frequency reads, moderate write volumes, and maintain data integrity while being simple to deploy and manage.

### Problem Statement

The system needs a registry that can:

1. **High-Frequency Access**: Support thousands of reads per second for agent decision-making
2. **Data Integrity**: Maintain consistent and reliable data across operations
3. **Simple Deployment**: Minimal setup and maintenance requirements
4. **Performance**: Sub-millisecond response times for critical operations
5. **Scalability**: Handle growth from 10 to 10,000+ assets without performance degradation
6. **Backup/Recovery**: Reliable backup and disaster recovery capabilities

### Requirements and Constraints

- **Read Performance**: >10,000 reads/second with <1ms latency
- **Write Performance**: >1,000 writes/second with <10ms latency
- **Data Size**: Support up to 10GB of registry data
- **Availability**: 99.9% uptime with automatic recovery
- **Consistency**: Strong consistency for all operations
- **Deployment**: Single-command deployment with minimal configuration

## Decision

We will use **SQLite** as the primary registry database for Empire AI, implementing a distributed architecture with local SQLite instances for each service and a central aggregation layer for cross-service data consistency.

### Architecture Overview

```
Registry Architecture
├── Local SQLite Instances (per service)
│   ├── Agent Registry (agent state and performance)
│   ├── Asset Registry (asset metadata and metrics)
│   ├── Decision Log (audit trail and decisions)
│   └── Configuration Store (system settings)
├── Central Aggregation Service
│   ├── Data Synchronization (cross-instance consistency)
│   ├── Backup Management (automated backups)
│   ├── Query Optimization (cross-service queries)
│   └── Analytics Engine (performance metrics)
└── Disaster Recovery
    ├── Point-in-Time Recovery (hourly snapshots)
    ├── Geographic Redundancy (multi-region backup)
    └── Automated Failover (service continuity)
```

### Implementation Details

#### 1. Local SQLite Instances
Each service maintains its own SQLite database for:

- **Agent Registry**: Agent state, performance metrics, decision history
- **Asset Registry**: Asset metadata, performance data, lifecycle status
- **Decision Log**: Complete audit trail of all autonomous decisions
- **Configuration Store**: System settings, policy configurations, user preferences

#### 2. Data Schema Design
```sql
-- Asset Registry Schema
CREATE TABLE assets (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    metadata JSON,
    performance_metrics JSON,
    budget_limit REAL,
    current_spend REAL
);

-- Agent Registry Schema
CREATE TABLE agents (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    configuration JSON,
    performance_metrics JSON,
    last_decision TIMESTAMP
);

-- Decision Log Schema
CREATE TABLE decisions (
    id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL,
    asset_id TEXT,
    decision_type TEXT NOT NULL,
    decision_data JSON NOT NULL,
    rationale TEXT,
    confidence_score REAL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (agent_id) REFERENCES agents(id),
    FOREIGN KEY (asset_id) REFERENCES assets(id)
);
```

#### 3. Synchronization Strategy
- **Event-Driven Sync**: Use change events to trigger synchronization
- **Conflict Resolution**: Last-write-wins with timestamp validation
- **Consistency Checks**: Hourly consistency verification across instances
- **Incremental Updates**: Only sync changed data to minimize bandwidth

#### 4. Backup and Recovery
- **Hourly Snapshots**: Automated hourly database snapshots
- **WAL Mode**: Write-Ahead Logging for crash recovery
- **Checkpointing**: Regular checkpoint operations for performance
- **Verification**: Daily backup integrity verification

## Rationale

### Why SQLite?

1. **Performance**: Sub-millisecond read performance for local queries
2. **Simplicity**: Zero-configuration deployment with single-file database
3. **Reliability**: ACID compliance with proven stability and data integrity
4. **Portability**: Single file format for easy backup and migration
5. **Resource Efficiency**: Low memory and CPU footprint
6. **Integration**: Excellent Python and Node.js support

### Alternative Approaches Considered

#### PostgreSQL
- **Pros**: Powerful features, excellent scalability, strong consistency
- **Cons**: Complex deployment, higher resource requirements, operational overhead
- **Rejected**: Overkill for registry requirements, adds unnecessary complexity

#### MongoDB
- **Pros**: Flexible schema, good for unstructured data
- **Cons**: Eventual consistency, higher resource usage, complex backup
- **Rejected**: Not suitable for transactional registry operations

#### Redis
- **Pros**: Excellent performance, simple deployment
- **Cons**: Limited data persistence, memory constraints, limited query capabilities
- **Rejected**: Insufficient for complex registry queries and persistence requirements

#### Distributed SQL (CockroachDB, TiDB)
- **Pros**: Global scalability, strong consistency
- **Cons**: High complexity, significant operational overhead
- **Rejected**: Complexity outweighs benefits for current scale requirements

### Technical Benefits

1. **Local Performance**: Each service has local database access eliminating network latency
2. **Isolation**: Service failures don't affect other services' data access
3. **Simplicity**: No database server administration required
4. **Development Speed**: Fast setup and iteration for development teams
5. **Testing**: Easy to create test databases and reset state

## Consequences

### Positive Consequences

1. **High Performance**: Sub-millisecond local query performance
2. **Simple Operations**: No database server management required
3. **Fast Development**: Quick setup and minimal configuration
4. **Reliable Backup**: Simple file-based backup and recovery
5. **Low Resource Usage**: Minimal memory and CPU requirements

### Negative Consequences

1. **Scaling Limitations**: Single-node performance limits
2. **Cross-Service Queries**: Requires additional synchronization layer
3. **Concurrent Access**: Limited concurrent write capabilities
4. **Data Size Limits**: Maximum database size limitations
5. **Advanced Features**: Limited advanced database features

### Mitigation Strategies

1. **Performance Optimization**: Use connection pooling and query optimization
2. **Data Partitioning**: Distribute data across multiple SQLite instances
3. **Caching Layer**: Implement Redis caching for frequently accessed data
4. **Monitoring**: Comprehensive monitoring of database performance
5. **Migration Path**: Clear upgrade path to PostgreSQL if needed

## Implementation

### Phase 1: Core Registry Implementation (Weeks 1-2)
- Set up SQLite databases for each service
- Implement basic CRUD operations
- Create data schema and migrations
- Add connection pooling and optimization

### Phase 2: Synchronization Layer (Weeks 3-4)
- Implement event-driven synchronization
- Add conflict resolution mechanisms
- Create consistency verification system
- Develop backup and recovery procedures

### Phase 3: Performance Optimization (Weeks 5-6)
- Optimize queries and indexes
- Implement caching layer
- Add monitoring and alerting
- Performance testing and tuning

### Phase 4: Advanced Features (Weeks 7-8)
- Implement analytics and reporting
- Add data archiving capabilities
- Create migration tools
- Documentation and deployment guides

### Technology Stack

- **Database**: SQLite 3.40+ with WAL mode
- **ORM**: SQLAlchemy (Python) and Sequelize (Node.js)
- **Synchronization**: Custom event-driven system
- **Caching**: Redis for frequently accessed data
- **Monitoring**: Custom metrics and alerting
- **Backup**: Automated file-based backup system

## Performance Targets

### Read Performance
- **Local Queries**: <1ms latency for 95% of queries
- **Complex Queries**: <10ms latency for analytical queries
- **Concurrent Reads**: Support 1000+ concurrent readers
- **Cache Hit Rate**: >90% for frequently accessed data

### Write Performance
- **Simple Inserts**: <5ms latency for single record inserts
- **Batch Operations**: <100ms for 100-record batches
- **Concurrent Writes**: Support 100+ concurrent writers
- **Transaction Throughput**: >1000 transactions/second

### Data Management
- **Database Size**: Support up to 10GB per database
- **Record Count**: Support up to 1M records per table
- **Backup Speed**: <30 seconds for 1GB database backup
- **Recovery Time**: <60 seconds for database recovery

## Monitoring and Observability

### Database Metrics
- Query latency and throughput
- Database size and growth rate
- Connection pool utilization
- Error rates and types

### Synchronization Metrics
- Sync latency and success rate
- Conflict detection and resolution
- Data consistency verification results
- Cross-service query performance

### System Metrics
- Resource utilization (CPU, memory, disk)
- Backup success and verification
- Performance degradation alerts
- Capacity planning indicators

## Security Considerations

### Data Protection
- File-level encryption for database files
- Access control for database operations
- Audit logging for data access
- Secure backup storage and transmission

### Operational Security
- Database file integrity verification
- Secure synchronization channels
- Role-based access control
- Regular security updates

## Future Considerations

### Scalability Planning

1. **Database Sharding**: Partition data across multiple SQLite instances
2. **Read Replicas**: Create read-only copies for query scaling
3. **Migration to PostgreSQL**: Clear upgrade path for larger scale
4. **Distributed Architecture**: Move to distributed database if needed
5. **Performance Optimization**: Ongoing query and index optimization

### Feature Enhancements

1. **Advanced Analytics**: Built-in analytics and reporting capabilities
2. **Real-time Sync**: Real-time data synchronization across services
3. **Automated Archiving**: Automatic data archiving and cleanup
4. **Multi-Region Support**: Geographic distribution for disaster recovery
5. **API Layer**: RESTful API for registry operations

## Migration Strategy

### From Current System
1. **Data Export**: Export existing data in compatible format
2. **Schema Mapping**: Map current schema to SQLite schema
3. **Data Import**: Import data with validation and verification
4. **Testing**: Comprehensive testing of migrated system
5. **Cutover**: Planned cutover with rollback capability

### To Future Systems
1. **Export Tools**: Standardized data export tools
2. **Schema Migration**: Automated schema migration capabilities
3. **Data Validation**: Comprehensive data validation procedures
4. **Performance Testing**: Performance comparison testing
5. **Rollback Planning**: Detailed rollback procedures

---

**Next Steps**: Begin Phase 1 implementation with core registry setup

**Related Documents**: [ADR-001](001-microservices-architecture.md) | [ADR-003](003-immutable-audit-log.md) | [ADR-004](004-agent-based-architecture.md)
