# ATLAS PROTECTION SYSTEM MASTER PLAN

**Authority:** Antigravity / KAIZA-MCP Security Architecture  
**Status:** LOCKED FOR EXECUTION  
**Version:** 1.0  
**Date:** 2026-01-15  
**Hash-Lock:** Binding for all Windsurf execution  

---

## 1. AUTHORITY & AXIOMS

### 1.1 Non-Negotiable Invariants

The following are hard constraints that override all other requirements:

| Axiom | Statement | Violation Cost |
|-------|-----------|-----------------|
| **Identity First** | No UI renders, no API responds, no action executes without verified identity | Build failure + deployment block |
| **Explicit Authority** | All permissions are grant-only; default deny on all ambiguity | CI rejection |
| **Operator Binding** | Every action is attributed to exactly one human operator (immutable) | Audit rejection + rollback |
| **Token Verification** | Every request (UI or API) must present current, valid, verifiable token | 403 Forbidden (non-negotiable) |
| **Kill Path Parity** | Authority to kill/abort/rollback requires no more privilege than authority to execute | Architecture redesign if violated |
| **Audit Immutability** | Once written, audit records cannot be deleted, modified, or hidden | Data loss mitigation + emergency recovery |
| **Policy Epoch Bound** | Decisions evaluated under specific policy version; policy changes force revocation | Session invalidation on policy bump |

### 1.2 Violation = Build Failure Rule

Any code that violates the above axioms **MUST** be:

1. Rejected by CI linter before merge
2. Flagged by forbiden_markers_scan.py (markers: `# NO-AUDIT`, `# UNATTRIBUTED`, `# IMPLICIT-DENY-BYPASS`)
3. Blocked by pre-commit hook

Code violating axioms **CANNOT** be deployed.

---

## 2. THREAT MODEL & FAILURE ASSUMPTIONS

### 2.1 Operator Threat Scenarios

| Threat | Assumption | System Response |
|--------|-----------|-----------------|
| **Credential Compromise** | Operator's password/WebAuthn key stolen | Session revoked; all tokens invalidated; quorum approval required to restore access |
| **Lateral Movement** | Compromised operator tries to escalate beyond assigned roles | Authorization check fails; action blocked; audit escalation triggered |
| **Action Repudiation** | Operator claims they did not authorize action | Audit trail provides irrefutable proof (signed decision envelope) |
| **Rogue Admin** | Privileged operator executes unauthorized kill/rollback | Quorum requirement prevents unilateral action; approval evidence locked in audit |
| **Session Hijacking** | Attacker obtains valid session token | Token includes immutable operator ID; request attribution fails on identity mismatch |

### 2.2 Credential Compromise Assumptions

- Passwords compromised: TOTP + WebAuthn bypass is theoretically possible
- API keys disclosed: Short-lived access tokens (15 min) + refresh rotation limit risk

**System Response:**
- Operator cannot change own identity; emergency role-out required
- All sessions terminated; new login requires physical device (WebAuthn)
- Audit reveals compromise window; actions within window flagged for review
- Revocation is immediate (no grace period)

### 2.3 Network & Dependency Failures

| Failure | Assumption | Degradation |
|---------|-----------|-------------|
| **Policy Engine Unavailable** | OPA service down for > 30 sec | Deny all new requests; existing sessions degrade to read-only; quorum ops blocked |
| **Audit Store Unavailable** | Database unreachable | Write-through buffer (500 events); deny mutation ops; alert immediately |
| **Identity Provider Down** | Keycloak unreachable | Allow cached identity; TTL 5 min max; no new token issuance |
| **Network Partition** | Service mesh split | Sticky routing; local policy cache enforced; kill path always available |

### 2.4 Insider Misuse Scenarios

| Scenario | Assumption | Prevention |
|----------|-----------|-----------|
| **Privilege Escalation** | Operator attempts to grant self higher role | Immutable role binding; only Governor can change; change requires quorum approval |
| **Policy Tampering** | Insider modifies policy to allow forbidden action | Policies are versioned; policy changes require Governor approval + audit logging; rollback always available |
| **Audit Deletion** | Insider tries to cover up action | Append-only ledger; no delete operation exists; integrity checks detect tampering |
| **Token Forgery** | Insider creates fake JWT | Token includes non-forgeable claims (issuer signature + policy epoch hash); verification fails |

### 2.5 UI Tampering Scenarios

| Attack | Assumption | Frontend Defense |
|--------|-----------|------------------|
| **JavaScript Injection** | Attacker modifies DOM to remove authorization checks | Authorization enforced by backend; UI is display-only; all mutations require valid token |
| **Capability Hiding** | UI hides "deny" button to force user action | Permission inspector shows true authorization state; UI always reflects backend truth |
| **Off-Screen Execution** | Iframe or hidden request executes action | All requests must present token; token bound to session; session tied to visible browser tab |
| **Local Storage Poisoning** | Attacker modifies token in browser storage | Token is signed; forgery detected on first use; session invalidated |

---

## 3. PROTECTION PIPELINE (CANONICAL)

### 3.1 Full Request Path

```
Operator (Human) 
  ↓ [Identity Assertion]
Identity Service (Keycloak)
  ↓ [Token Issuance]
Token (JWT + Claims)
  ↓ [HTTP Request]
Gateway (PEP: Policy Enforcement Point)
  ↓ [Token Validation + Capability Check]
Policy Engine (PDP: Policy Decision Point, OPA)
  ↓ [Policy Evaluation]
Decision: Allow / Deny / Degrade
  ↓ [For Allow]
Control API (Execution Layer)
  ↓ [Action Execution + Audit Write]
Audit Store (Append-Only Ledger)
  ↓ [Async Verification]
Audit Hash Chain (Integrity Verification)
  ↓ [UI Display]
Permission Inspector (Operator Accountability)
```

### 3.2 Trust Boundaries

| Boundary | Protected By | Direction |
|----------|-------------|-----------|
| **Operator → Identity** | WebAuthn + TOTP; out-of-band MFA | One-way; identity service trusts operator device only |
| **Identity → Token** | Signed JWT; issuer certificate pinned | One-way; gateway trusts issuer certificate only |
| **Token → Gateway** | TLS 1.3 + mTLS; token signature verification | Bidirectional; gateway verifies token; operator verifies server cert |
| **Gateway → Policy Engine** | Sealed request envelope; policy version binding | One-way; policy engine trusts gateway PEP implementation |
| **Policy Decision → Audit** | Digital signature + hash chain | One-way; audit append-only; no backfill |
| **Audit → UI** | Read-only interface; no mutation from UI | One-way; UI is presentation layer only |

### 3.3 Verification Points (Non-Negotiable)

Each request must pass these checks in sequence. **Failure at any step = 403 Forbidden.**

1. **Token Present**: Request must include `Authorization: Bearer <JWT>`
2. **Token Valid**: JWT signature verified against issuer public key
3. **Token Not Expired**: `exp` claim validated; <= 15 minutes old
4. **Token Not Revoked**: Token ID checked against revocation list (in-memory cache, async refresh)
5. **Operator Exists**: Operator ID in `sub` claim must exist in registry
6. **Operator Active**: Operator record must not be suspended/disabled
7. **Operator Realm**: Operator must be in human realm (not service realm)
8. **Policy Epoch Match**: `policy_epoch` claim must match current governance epoch
9. **Capability Present**: Requested action must match declared capability claim
10. **Risk Posture**: Risk flags (new device, geo change, etc.) evaluated; may trigger step-up auth
11. **Rate Limit**: Action rate limit not exceeded (per operator, per action, per minute)
12. **Quorum Check** (if required): Decision must have required approvals; approvers must be distinct operators with distinct sessions

**Failure response:** 403 Forbidden; audit logged with denial reason; operator notified via secure channel.

### 3.4 Deny Points (Hard Stops)

These conditions cause immediate denial with no fallback:

- Token cryptographic validation fails
- Operator ID not found in registry
- Operator status is suspended/revoked
- Policy epoch mismatch
- Risk posture triggers TOTP step-up and step-up not completed
- Quorum approvals incomplete or from same operator/session
- Rate limit exceeded
- Audit store write fails (degraded mode: deny new mutations)

### 3.5 Degradation Behavior

| Condition | Mode | Allowed Actions | Blocked Actions |
|-----------|------|-----------------|-----------------|
| **Policy Engine Timeout (>30s)** | CAUTIOUS | Read-only on cached policies; kill switch available | New approvals; mutation ops; quorum decisions |
| **Audit Store Unavailable** | BUFFERING | Reads; cached audit data; kill switch | Mutations; new decisions; audit-dependent ops |
| **Identity Provider Delay (>10s)** | CACHED | Token refresh from cache; existing sessions persist | New logins; identity changes |
| **Network Partition** | STICKY | Sticky routing; local cache enforced | Cross-partition operations; policy sync |
| **Critical Alert Triggered** | LOCKDOWN | Kill switch only; read-only audit inspect | All other operations |

---

## 4. IDENTITY ARCHITECTURE

### 4.1 Human vs. Service Identity Separation

**Human Realm: Keycloak Default Realm (`empire-humans`)**

- Identity source: OIDC (WebAuthn-backed)
- Token lifetime: 15 minutes (access), 7 days (refresh, single-use)
- MFA: WebAuthn (primary); TOTP (fallback only, requires password + WebAuthn recovery code)
- Device binding: Public key pinning (device certificate chain)
- Attributes: `operator_id` (immutable UUID), `roles` (array), `org` (immutable), `policy_epoch` (current governance version)

**Service Realm: SPIFFE/SPIRE (`empire-services`)**

- Identity source: SPIFFE Workload API
- Token lifetime: 1 hour (not refreshable; must re-bind)
- MFA: None (service-to-service mTLS enforces identity)
- Device binding: Workload SVIDs (ephemeral certificates, max 1 hour)
- Attributes: `service_id` (SPIFFE URI), `namespace` (Kubernetes namespace), `policy_epoch`
- **Constraint:** Services cannot initiate quorum decisions; services cannot make kill/abort decisions
- **Constraint:** Service tokens cannot represent human operators

### 4.2 Keycloak Configuration

**Realm: empire-humans**

```
Realm Settings:
  ├─ Tokens Tab
  │  ├─ Access Token Lifespan: 900 seconds (15 min)
  │  ├─ Refresh Token Lifespan: 604800 seconds (7 days)
  │  ├─ Refresh Token Max Reuse: 1 (single-use enforcement)
  │  ├─ Action Token Lifespan: 300 seconds (5 min, for MFA step-up)
  │  └─ Revoke Refresh Tokens on Login: ON
  │
  ├─ Authentication Tab
  │  ├─ First Broker Login: Require existing account (no auto-signup)
  │  ├─ Post Login Flow: identity-risk-assessment (ORCA-style)
  │  └─ Post Login Flow: conditional-totp-enrollment
  │
  ├─ Security Defenses
  │  ├─ Brute Force Detection: ON (5 failed attempts → 15 min lockout)
  │  ├─ Headers: X-Frame-Options: DENY, X-Content-Type-Options: nosniff
  │  └─ SSL Mode: REQUIRED (no exception)
  │
  └─ Required Actions
     ├─ Webauthn Passwordless Register (required for all humans)
     ├─ TOTP Config (optional; for backup MFA only)
     └─ Update Profile (required on first login)

User Attributes (on every operator record):
  ├─ operator_id: UUID-v4 (immutable; generated on account creation)
  ├─ org: organization code (immutable; cannot change)
  ├─ role: string from [admin, operator, auditor, viewer] (mutable only via Governor)
  ├─ device_binding: JWK Set (public keys of user's registered devices)
  ├─ emergency_access: boolean (true = recovery codes valid; false = codes exhausted)
  ├─ last_password_change: ISO 8601 timestamp (for forcing rotation at 90 days)
  └─ policy_epoch: integer (current governance version; bumped on policy changes)

Client: empire-admin-ui
  ├─ Standard Flow: Enabled
  ├─ Direct Access Grants: Disabled (use refresh token flow only)
  ├─ Implicit Flow: Disabled
  ├─ Service Accounts: Disabled
  └─ Valid Redirect URIs: https://<admin-ui-domain>/auth/callback (no wildcards)

Client: empire-api
  ├─ Standard Flow: Disabled
  ├─ Direct Access Grants: Disabled
  ├─ Service Accounts: Enabled
  ├─ Service Account Roles: None (services use SPIFFE, not Keycloak)
  └─ Audience: empire-api
```

### 4.3 SPIFFE/SPIRE Service Identity Model

**Workload Registration (SPIRE Agent on each service pod):**

```
Workload ID: spiffe://empire-ai.local/<service-name>/<pod-namespace>/<pod-name>
  ├─ SVIDs: 2 active (rotated hourly, overlap 5 min)
  ├─ TTL: 3600 seconds (1 hour, no extension)
  ├─ Revocation: Immediate if pod deleted or namespace revoked
  └─ Attributes: workload_type=<executor|governor|gateway>, namespace=<ns>, pod=<name>

Attestation:
  ├─ Kubernetes Node Attestor (PSAT: Projected Service Account Token)
  ├─ Workload Attestor (SPIFFE oidc-discovery-provider checks issuer)
  └─ No human-directed attestation (fully automated)

mTLS Enforcement:
  ├─ All service-to-service calls require mutual TLS
  ├─ Client certificate must match SPIFFE identity
  ├─ Server certificate pinned (SPIFFE URI validation)
  └─ Handshake failure → immediate connection drop
```

### 4.4 Immutable Operator ID

Each human operator has a unique, immutable UUID assigned at account creation.

**Immutability Guarantees:**

- UUID never changes for lifetime of account
- Cannot be reassigned or recycled
- UUID used as correlation ID in all audit events
- UUID embedded in all tokens (claim: `sub`)
- Change of email/username does not change UUID

**Token Claim:**
```json
{
  "sub": "550e8400-e29b-41d4-a716-446655440000",
  "operator_id": "550e8400-e29b-41d4-a716-446655440000",
  "email": "alice@empire.local",
  "role": "admin",
  "org": "empire"
}
```

### 4.5 Device Binding Rules

All human operators must register at least one WebAuthn device.

**Device Registration:**

1. Operator initiates WebAuthn enrollment (passwordless)
2. Browser/device prompts for biometric or PIN
3. Device generates attestation (certificate of hardware security module)
4. Public key stored in Keycloak `device_binding` attribute (JWK format)
5. Device ID (credential ID) stored; if lost, user registers new device

**Device Verification:**

- Every WebAuthn assertion includes device ID + signature
- Gateway verifies signature against stored public key
- If device stolen: Operator revokes device; must use recovery code + TOTP to register new device
- Biometric/PIN protected: Local to device, never sent to server

**Rules:**

- Minimum 1 registered device (WebAuthn)
- Maximum 10 devices per operator
- Device timeout: 90 days without use → auto-revoked (user must re-enroll)
- Cross-device login allowed (on same user account; user controls which devices)

### 4.6 Forbidden Auth Patterns (Hard Blocklist)

These patterns are **explicitly prohibited** and cause build failure if detected:

| Pattern | Why Forbidden | Detection |
|---------|---------------|-----------|
| **Password-only auth** | No MFA; easily compromised | Keycloak must enforce WebAuthn |
| **Implicit grant flow** | Token exposed in URL history | OAuth config: Disabled |
| **Client credentials from human UI** | Service credentials in browser memory | UI must use Authorization Code + PKCE |
| **Long-lived tokens (>1 hr)** | Increases compromise window | Token TTL enforced in Keycloak; rejected by gateway if TTL > 15 min |
| **Shared operator accounts** | Breaks attribution; cannot audit | Account provisioning requires unique email; Keycloak enforces 1:1 user:account |
| **Hardcoded credentials** | Cannot rotate; always compromised | Secrets scanning: Pre-commit hook rejects |
| **Unencrypted device keys in local storage** | Browser storage is not secure | Local storage must be empty; tokens in secure HTTP-only cookies only |
| **Token stored in sessionStorage** | Exposed to XSS; cannot auto-refresh | Tokens must be HTTP-only; refresh via secure cookie |
| **No token validation on backend** | Trust-nothing violated | Gateway must verify every token; CI rejects code that skips validation |
| **Service using human realm for auth** | Services cannot have identity; breaks audit | Service detection: If `realm: empire-humans` and `sub` is SPIFFE URI → reject |

---

## 5. AUTHENTICATION & SESSION MODEL

### 5.1 WebAuthn-First Enforcement

**Requirement:** All human operators must authenticate using WebAuthn (CTAP2/U2F) as primary method.

**Flow:**

1. Operator navigates to `/auth/login`
2. User enters username (or email)
3. Server initiates WebAuthn challenge (random 32-byte nonce)
4. Browser/device prompts operator for biometric/PIN
5. Device returns signed assertion (includes challenge, origin, device credential ID)
6. Server verifies:
   - Challenge matches (prevents replay)
   - Origin matches (prevents phishing)
   - Signature verifies against stored device public key
   - Device counter incremented (prevents cloning)
7. On success: Issue access token + refresh token
8. On failure: Increment failed attempts; after 5 failures → lockout (15 min)

**Passwordless:** Operators do NOT enter a password on primary WebAuthn flow.

### 5.2 TOTP Fallback Constraints

TOTP is **fallback only**; used only when WebAuthn unavailable (lost device, device malfunction).

**Conditions for TOTP activation:**

- Operator has registered WebAuthn device AND
- Device is unavailable (locked/lost) AND
- Operator has TOTP secret enrolled AND
- Operator is attempting to access via different device/browser

**TOTP Challenge Flow:**

1. WebAuthn fails (no matching credential)
2. Server checks: Operator has TOTP enrolled?
3. If yes: Prompt for TOTP code
4. Operator enters 6-digit code from authenticator app
5. Server validates: Code must match within ±1 window; code must not be replay of previous code
6. If valid: Issue temporary token; operator **must** re-enroll WebAuthn on successful login
7. If invalid: Increment failed attempts; after 3 failures → prompt for emergency recovery code

**Constraints:**

- TOTP cannot be primary auth (must have WebAuthn first)
- TOTP secret is ephemeral; re-generated every 90 days
- TOTP secret **never** sent via email; shown once on enrollment, operator must save offline
- TOTP secret is NOT backed up (if lost, operator uses recovery code)

### 5.3 Session Lifecycle

**Session Creation:**

1. WebAuthn success → Keycloak issues tokens
2. Access token (15 min TTL) + Refresh token (7 days TTL, single-use)
3. Tokens sent to UI; UI stores access token in secure HTTP-only cookie
4. Session record created in gateway (maps operator → token ID → device fingerprint)

**Session Active:**

- Operator uses access token for all API calls
- Access token includes all required claims (operator ID, role, policy epoch, etc.)
- Gateway validates token on every request
- Session activity tracked (last request timestamp)

**Token Refresh:**

- Access token expiring in < 5 min → UI initiates refresh
- UI presents refresh token (sent via secure cookie)
- Keycloak validates refresh token (signature + not revoked + single-use)
- If valid: Issue new access token + new refresh token (one-time use)
- Old refresh token invalidated immediately
- On failure: Session terminated; operator must re-login

**Session Termination:**

1. Operator clicks logout
2. UI deletes tokens from cookies + local state
3. UI calls `/api/logout` to invalidate refresh token
4. Gateway removes session record
5. Token revocation list updated (async)
6. Keycloak invalidates refresh token

**Forced Termination (Revocation):**

- Operator disabled in Keycloak → All tokens immediately revoked
- Policy epoch bumped → Existing tokens rejected (epoch mismatch)
- Risk posture change (e.g., geographic anomaly) → Step-up auth required
- Compliance breach detected → All sessions terminated; quorum approval required to restore

### 5.4 Revocation Guarantees

Revocation is **immediate** and **irrevocable**.

**Revocation List (In-Memory + Persistent):**

- In-memory cache on gateway (100,000 max entries)
- Persistent store in PostgreSQL (audit trail)
- Async refresh from DB every 30 seconds
- On revocation: Entry added to list with revocation timestamp

**Revocation Checks:**

- Gateway checks token ID against revocation list on every request
- If token ID in list: Reject (403); do not allow bypass
- Revocation persists across reboots (stored in DB)

**Revocation Audit:**

- Revocation event logged: operator revoked, reason, timestamp, initiated-by, decision ID
- Cannot be deleted; hash-chained to previous entry

---

## 6. TOKEN & CLAIMS CONTRACT

### 6.1 Access Token (JWT) Specification

**Issuer:** Keycloak `empire-humans` realm  
**Algorithm:** RS256 (RSA 2048-bit minimum)  
**TTL:** 900 seconds (15 minutes)  
**Audience:** `empire-api`

**Mandatory Claims:**

| Claim | Type | Format | Validation |
|-------|------|--------|-----------|
| `iss` | string | `https://keycloak.empire.local/realms/empire-humans` | Must match issuer URL (pinned certificate) |
| `sub` | string | UUID-v4 | Operator ID; must exist in registry |
| `operator_id` | string | UUID-v4 | Duplicate of `sub` for clarity |
| `aud` | array | `["empire-api"]` | Must include empire-api |
| `exp` | number | Unix timestamp | Token must not be expired; < 15 min old |
| `iat` | number | Unix timestamp | Token issuance time; must be recent (< 5 sec old) |
| `jti` | string | UUID-v4 | Token ID; used for revocation tracking |
| `email` | string | RFC 5322 | Operator email; informational only |
| `email_verified` | boolean | true/false | Must be true; unverified users cannot access |
| `name` | string | full name | Operator display name; informational |
| `role` | string | `admin` \| `operator` \| `auditor` \| `viewer` | Determines default capability set |
| `capabilities` | array | `["action:execute", "policy:read", "audit:read"]` | Explicit action permissions (see §7) |
| `org` | string | org code | Organization; immutable; used for multi-tenancy isolation |
| `policy_epoch` | number | integer | Current governance epoch version (bumped on policy changes) |
| `device_id` | string | UUID-v4 | Device public key ID (for device binding verification) |
| `device_verified` | boolean | true/false | Device cryptographic verification passed |
| `authn_method` | string | `webauthn` \| `totp` \| `mfa-recovery` | Authentication method used |
| `risk_flags` | array | `["geo_anomaly", "new_device", "admin_login_early_morning"]` | Risk signals; may trigger step-up auth |
| `session_id` | string | UUID-v4 | Session identifier; used for session invalidation |
| `nbf` | number | Unix timestamp | Not-before time (for future tokens; usually same as iat) |

**Optional Claims (Keycloak standard):**

- `preferred_username`: Username
- `given_name`: First name
- `family_name`: Last name

### 6.2 Refresh Token Specification

**Issuer:** Keycloak `empire-humans` realm  
**Algorithm:** Not applicable (opaque token)  
**TTL:** 604800 seconds (7 days)  
**Reuse:** Single-use only (must not be reused)

**Refresh Token Contract:**

- Sent via secure HTTP-only cookie (cannot be read by JavaScript)
- Contains no claims (server-side lookup)
- Each refresh generates new refresh token + new access token
- Old refresh token invalidated immediately
- If refresh token reused (replay attack): Session terminated; operator forced to re-login

### 6.3 Claims Validation Rules

Every access token must be validated against these rules before granting access:

| Rule | Check | Failure Action |
|------|-------|-----------------|
| **Signature** | RS256 signature valid against issuer public key | Reject (403); log as potential forgery |
| **Issuer** | `iss` matches pinned issuer URL | Reject (403); log as forgery attempt |
| **Audience** | `aud` includes `empire-api` | Reject (403) |
| **Expiration** | `exp` > current time AND `exp` - `iat` <= 15 min | Reject (403) |
| **Freshness** | `iat` within 5 seconds of current time | Reject (403); token too old or future-dated |
| **Operator Exists** | `sub` (operator_id) exists in operator registry | Reject (403); operator account deleted |
| **Operator Active** | Operator status is `active` (not `suspended` or `disabled`) | Reject (403); log operator status check |
| **Email Verified** | `email_verified` must be true | Reject (403) |
| **Policy Epoch** | `policy_epoch` matches current governance epoch | If mismatch: Revoke; operator must re-login (governance change) |
| **No Revocation** | `jti` (token ID) not in revocation list | Reject (403); check async-updated revocation cache |
| **Device Verified** | `device_verified` must be true | Reject (403); require device re-verification |
| **Risk Flags** | If risk flags present and severity high: Prompt for step-up auth | Pause request; initiate TOTP/WebAuthn re-challenge |

### 6.4 Policy Epoch Handling

Policy epoch is a governance version number bumped whenever system-wide policies change.

**Use Cases for Epoch Bump:**

- Role definitions change (e.g., "admin" gains new capability)
- Authorization rules updated (e.g., quorum requirements change)
- Compliance rules enforced (e.g., MFA requirement added)
- Operator set changes (new operator onboarded; existing operator off-boarded)

**Epoch Bump Mechanism:**

1. Governor approves policy change (recorded in audit trail with decision ID)
2. Policy version incremented (e.g., epoch 1 → epoch 2)
3. New policy bundle deployed to policy engine
4. All existing tokens still valid (claim carries old epoch)
5. On next request: Gateway detects epoch mismatch
6. Token is revoked; operator re-authenticates with new epoch
7. New token issued with new epoch

**Justification:** Forces re-authentication to ensure operator understands changed rules.

### 6.5 Example JWT Payload

```json
{
  "iss": "https://keycloak.empire.local/realms/empire-humans",
  "sub": "550e8400-e29b-41d4-a716-446655440000",
  "operator_id": "550e8400-e29b-41d4-a716-446655440000",
  "aud": [
    "empire-api",
    "account"
  ],
  "exp": 1736976299,
  "iat": 1736975399,
  "jti": "a0b1c2d3-e4f5-41d4-a716-446655440001",
  "email": "alice@empire.local",
  "email_verified": true,
  "name": "Alice Chen",
  "preferred_username": "alice.chen",
  "given_name": "Alice",
  "family_name": "Chen",
  "role": "admin",
  "capabilities": [
    "action:execute",
    "action:kill",
    "action:approve",
    "policy:read",
    "policy:propose",
    "audit:read",
    "audit:export",
    "operator:manage"
  ],
  "org": "empire",
  "policy_epoch": 5,
  "device_id": "d7e8f9g0-h1i2-43d4-a716-446655440002",
  "device_verified": true,
  "authn_method": "webauthn",
  "risk_flags": [],
  "session_id": "s-12345678-90ab-cdef-1234-567890abcdef",
  "nbf": 1736975399
}
```

---

## 7. AUTHORIZATION MODEL

### 7.1 Canonical Roles and Limits

All operators are assigned exactly one role from this canonical set. **Role cannot be assumed; must be granted by Governor.**

| Role | Capabilities | Kill Authority | Quorum Eligible | Audit Access | Max Actions/Min |
|------|--------------|-----------------|-----------------|---------------|----|
| **admin** | execute, kill, approve, manage, read all | Can kill any action; must have quorum for production kills | Yes | Full audit + sensitive fields | 100 |
| **operator** | execute, read own actions | Can kill own actions only | No | Own audit + common fields | 50 |
| **auditor** | audit:read, audit:export | None | No | Full audit; read-only; no execute | Unlimited read |
| **viewer** | read all (read-only) | None | No | Limited audit (summary only) | Unlimited read |

### 7.2 Capability Taxonomy

Capabilities are explicit, granular permissions. **Role membership does NOT imply all capabilities; capabilities are declared in token.**

**Capability Format:** `<resource>:<action>` or `<resource>:<action>:<scope>`

**Resource Categories:**

- `action`: Execution operations (execute, kill, abort, approve, list, inspect)
- `policy`: Policy management (read, propose, test, deploy)
- `audit`: Audit log access (read, export, search, delete-retention-old)
- `operator`: Operator management (list, create, suspend, restore, revoke)
- `governance`: Governance (list-decisions, test-policy, set-epoch)
- `system`: System operations (healthcheck, metrics, reset, emergency)

**Capability Examples:**

```
action:execute                 # Can execute any action
action:execute:own-only        # Can execute only own actions
action:kill                    # Can initiate kill (may require quorum)
action:kill:own-only           # Can kill own actions only
action:approve                 # Can approve pending decisions
policy:read                    # Can read policies
policy:propose                 # Can propose new policies
policy:test                    # Can test policies in sandbox
audit:read                     # Can read audit logs
audit:read:30d                 # Can read audit logs <= 30 days old
audit:export                   # Can export audit logs
operator:manage                # Can create/suspend operators
system:emergency               # Can trigger emergency shutdown
```

### 7.3 Role ≠ Permission Rule

**Critical distinction:**

- **Role** is a human-readable category (admin, operator, etc.)
- **Capability** is a specific permission required for an action
- Possession of a role does NOT automatically grant all capabilities
- Capabilities are explicitly listed in token claims

**Example:**

```
Alice has role: admin
Alice capabilities claim: [action:execute, policy:read, audit:read]

Alice tries to create new operator (requires operator:manage)
Capability check fails → 403 Forbidden
(Even though admin role conceptually "should" have this, explicit capability claim required)
```

**Reason for this rule:** Allows fine-grained permission tuning without requiring new role definitions. Enables temporary capability grants (e.g., "grant this operator action:approve for 1 hour only").

### 7.4 Capability Naming Standard

All capabilities follow this strict format. Non-conformant capability names are rejected at token validation.

**Grammar:**

```
capability := resource : action [ : scope ]

resource := [a-z_]{1,32}
action := [a-z_]{1,32}
scope := [a-z0-9_:]{1,64}
```

**Valid examples:**

- `action:execute`
- `policy:read`
- `audit:read:90d`
- `operator:manage:empire-org-only`
- `system:emergency:lockdown`

**Invalid (rejected):**

- `action:EXECUTE` (uppercase)
- `action_execute` (underscores only, no colons)
- `action:execute:kill` (three parts must be explicit in token, not compound)

### 7.5 Context Inputs to Authorization Decision

When evaluating whether an action is permitted, policy engine considers:

| Context | Source | Example |
|---------|--------|---------|
| **Operator ID** | Token `sub` claim | 550e8400-e29b-41d4-a716-446655440000 |
| **Operator Role** | Token `role` claim | admin |
| **Requested Capability** | Decoded from action endpoint | action:execute |
| **Action Type** | Parsed from request body | growth_action.metadata_update |
| **Action Target** | Resource ID in request | asset_id=123 |
| **Target Owner** | Registry lookup | owner_operator_id=xyz |
| **Time of Day** | System clock | 14:30 UTC |
| **Operator Org** | Token `org` claim | empire |
| **Risk Flags** | Token `risk_flags` claim | ["geo_anomaly"] |
| **Quorum State** | Audit ledger query | approvals=[{id, sig, timestamp}] |
| **Policy Epoch** | Token `policy_epoch` claim | 5 |
| **Current Policy Version** | Policy engine internal state | 5 |

---

## 8. POLICY ENGINE (OPA)

### 8.1 Policy Decision Contract

The Policy Engine (OPA Rego) is the authoritative arbiter of allow/deny decisions.

**Decision Request (from Gateway PEP to OPA):**

```json
{
  "input": {
    "request_id": "req-12345678-90ab-cdef-1234-567890abcdef",
    "operator": {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "role": "admin",
      "capabilities": ["action:execute", "action:kill", "audit:read"],
      "org": "empire"
    },
    "action": {
      "type": "action_execute",
      "target": {
        "asset_id": "asset-uuid",
        "operation": "metadata_update"
      }
    },
    "context": {
      "time": "2026-01-15T14:30:00Z",
      "request_path": "/api/v1/actions/execute",
      "method": "POST",
      "remote_ip": "192.0.2.1",
      "user_agent": "Mozilla/5.0 ...",
      "policy_epoch": 5
    }
  }
}
```

**Decision Response (from OPA to Gateway):**

```json
{
  "result": {
    "allow": true,
    "decision_id": "dec-87654321-abcd-ef01-2345-67890abcdef0",
    "reason": "operator has action:execute capability",
    "deny_reasons": [],
    "quorum_required": false,
    "step_up_required": false,
    "risk_flags": [],
    "policy_version": 5,
    "decision_timestamp": "2026-01-15T14:30:00.000Z",
    "signature": "MCwCFQDWNhYf5z...[truncated RSA-256 signature]"
  }
}
```

### 8.2 Required Inputs

Every decision request must provide:

| Input | Mandatory | Validation |
|-------|-----------|-----------|
| `request_id` | YES | UUID-v4; unique per request |
| `operator.id` | YES | Operator UUID; must exist in registry |
| `operator.role` | YES | One of [admin, operator, auditor, viewer] |
| `operator.capabilities` | YES | Non-empty array; each capability validated against grammar |
| `operator.org` | YES | Organization code; non-empty string |
| `action.type` | YES | Registered action type; checked against action registry |
| `action.target` | YES | Object with relevant fields (asset_id, etc.) |
| `context.time` | YES | ISO 8601 timestamp |
| `context.request_path` | YES | HTTP request path |
| `context.method` | YES | HTTP method (GET, POST, etc.) |
| `context.policy_epoch` | YES | Current governance epoch |

### 8.3 Required Outputs

Every decision response must include:

| Output | Type | Constraint |
|--------|------|-----------|
| `result.allow` | boolean | Primary decision |
| `result.decision_id` | string | Unique per decision; UUID-v4 |
| `result.reason` | string | Human-readable decision rationale (max 256 chars) |
| `result.deny_reasons` | array | List of failure reasons (if allow=false) |
| `result.quorum_required` | boolean | Whether quorum approval is needed |
| `result.step_up_required` | boolean | Whether operator must redo MFA |
| `result.risk_flags` | array | List of risk signals detected |
| `result.policy_version` | integer | Version of policy applied |
| `result.decision_timestamp` | string | ISO 8601 timestamp of decision |
| `result.signature` | string | RSA-256 signature of decision (see §8.4) |

### 8.4 Decision ID Propagation

**Decision ID** is the unique identifier for each policy decision. It is:

1. Generated by OPA (UUID-v4)
2. Included in response
3. Stored in audit log (linked to action execution)
4. Used for audit trail tracing
5. Never reused (if decision requested twice, new ID generated)

**Propagation Path:**

```
OPA → Decision ID (dec-xxx)
  ↓
Gateway (store in context)
  ↓
Control API (include in action request)
  ↓
Audit Store (record alongside action)
  ↓
UI (display in permission inspector)
```

### 8.5 Bundle & Version Strategy

OPA policies are distributed as bundles (versioned, cryptographically signed).

**Bundle Structure:**

```
bundle-v5.tar.gz
├── manifest.json
│   ├─ version: 5
│   ├─ timestamp: 2026-01-15T14:30:00Z
│   ├─ parent_version: 4
│   ├─ policies: ["authorization.rego", "quorum.rego", "audit.rego"]
│   └─ signature: "MCwCFQDWNhYf5z...[RSA-256]"
│
├── authorization.rego
├── quorum.rego
├── audit.rego
└── data.json (static data: roles, capabilities, etc.)
```

**Bundle Deployment:**

1. Governor approves policy change (decision recorded in audit)
2. New bundle versioned (v5 parent v4)
3. Bundle signed with private key (stored in HSM)
4. Bundle pushed to OPA via artifact repository (signed)
5. OPA fetches bundle; verifies signature; loads into memory
6. Old bundle stays active until new bundle fully loaded
7. Switchover: Policy epoch bumped; all existing tokens invalidated

**Verification:**

- Bundle signature verified on every download (no auto-trust)
- Manifest parent pointer enforces version continuity (no gaps)
- Bundle contents frozen (no in-place modification)

### 8.6 Example Rego Snippets (Policy Level Only)

**Example 1: Basic Capability Check**

```rego
package authorization

# Decision function
decision = {
  "allow": allow,
  "decision_id": decision_id,
  "reason": reason,
  "deny_reasons": deny_reasons
} if {
  input.request_id
  input.operator.id
  not_revoked(input.operator.id)
  [allow, reason, deny_reasons] := check_capability(
    input.operator.capabilities,
    input.action.type
  )
  decision_id := uuid.v4
}

# Capability check
check_capability(caps, action_type) = [true, reason, []] if {
  required_cap := action_required_capability[action_type]
  required_cap in caps
  reason := sprintf("operator has %s capability", [required_cap])
}

check_capability(caps, action_type) = [false, "", reasons] if {
  required_cap := action_required_capability[action_type]
  not (required_cap in caps)
  reasons := [sprintf("missing capability: %s", [required_cap])]
}

# Action type → required capability mapping
action_required_capability = {
  "action_execute": "action:execute",
  "action_kill": "action:kill",
  "policy_read": "policy:read",
  "operator_create": "operator:manage"
}

# Revocation check
not_revoked(operator_id) if {
  not operator_id in data.revoked_operators
}
```

**Example 2: Quorum Policy**

```rego
package quorum

# Quorum requirement for production kills
kill_action_quorum_required = true if {
  input.action.type == "action_kill"
  input.context.environment == "production"
}

kill_action_quorum_required = false

# Quorum approval check
quorum_satisfied = true if {
  not kill_action_quorum_required
}

quorum_satisfied = true if {
  kill_action_quorum_required
  approvals := input.action.approvals
  count(approvals) >= 2
  all_distinct_operators(approvals)
  all_recent(approvals)  # approvals < 5 min old
}

quorum_satisfied = false

all_distinct_operators(approvals) if {
  operator_ids := [a.operator_id | a := approvals[_]]
  count(operator_ids) == count(array.unique(operator_ids))
}

all_recent(approvals) if {
  max_age_seconds := 300
  now := time.now_ns / 1000000000
  all a := approvals[_]; (now - a.timestamp) < max_age_seconds
}
```

**Example 3: Risk-Based Step-Up**

```rego
package risk

step_up_required = true if {
  risk_flags := input.context.risk_flags
  risk_flags != []
  high_risk_present(risk_flags)
}

step_up_required = true if {
  input.action.type == "action_kill"
  input.operator.role != "admin"
}

step_up_required = false

high_risk_present(flags) if {
  risk_levels := data.risk_levels
  [_ | f := flags[_]; risk_levels[f] == "high"] | length > 0
}

# Data: risk classification
risk_levels = {
  "geo_anomaly": "high",
  "new_device": "low",
  "unusual_time": "low",
  "failed_previous": "high"
}
```

---

## 9. DUAL CONTROL & QUORUM SYSTEM

### 9.1 Which Actions Require Quorum

Quorum approval (multiple distinct operators) is required for:

| Action | Quorum Size | Eligible Approvers | Timeout |
|--------|------------|-------------------|---------|
| **Production action kill** | 2 | admin only | 5 min |
| **Production action rollback** | 2 | admin only | 5 min |
| **Policy change deployment** | 2 | admin + Governor | 10 min |
| **Operator suspension** | 2 | admin + Governor | 10 min |
| **Emergency lockdown trigger** | 1 (admin only) | admin | N/A (immediate) |
| **Audit log export (>30 days)** | 2 | admin + auditor | 10 min |
| **Governance epoch bump** | 2 | Governor + admin | 10 min |

**No Quorum Required:**

- Operator's own action kill (operator can kill own actions)
- Read-only operations (audit inspect, status check)
- Non-production actions (test environment)

### 9.2 Distinct-Operator Rules

All quorum approvers must be distinct human operators.

**Rules:**

- Operator A cannot provide 2 approvals (one decision, one approval)
- One operator cannot approve own action
- All approvers must have required capability (e.g., action:kill for kill quorum)
- All approvers must be active (not suspended)
- All approvers must belong to same organization

### 9.3 Distinct-Session Rules

All quorum approvers must use distinct sessions.

**Rules:**

- Same person cannot approve from two tabs/browsers (one session per browser)
- Session-hijacking mitigated: Two sessions → two different session IDs
- If operator logs out and logs in again → different session ID; can approve

### 9.4 Approval Lifecycle

**State Transitions:**

```
PENDING
  ↓ [Approver 1 signs]
SINGLE_APPROVAL
  ↓ [Approver 2 signs with distinct session/operator]
QUORUM_MET
  ↓ [Execute action]
EXECUTED
  ↓ [Audit logged]
COMPLETED

Alternative paths:
PENDING → CANCELLED (if timeout or explicit cancel)
PENDING → DENIED (if approver explicitly denies)
```

**Approval Record:**

```json
{
  "decision_id": "dec-87654321-abcd-ef01-2345-67890abcdef0",
  "action_id": "act-12345678-90ab-cdef-1234-567890abcdef",
  "approver_id": "550e8400-e29b-41d4-a716-446655440000",
  "approval_timestamp": "2026-01-15T14:30:15.000Z",
  "session_id": "s-12345678-90ab-cdef-1234-567890abcdef",
  "signature": "MCwCFQDWNhYf5z...[RSA-256 signature of approval decision]",
  "signature_device_id": "d7e8f9g0-h1i2-43d4-a716-446655440002",
  "signature_timestamp": "2026-01-15T14:30:15.125Z",
  "approval_reason": "Audited and verified safe" (optional)
}
```

**Approval signatures:**

- Signed by approver device (WebAuthn assertion or private key)
- Signature proves approver explicitly authorized (not just token-based)
- Signature verified before acceptance

### 9.5 Expiry & Cancellation Rules

**Expiry:**

- Pending quorum approval expires after timeout (5-10 min depending on action type)
- After expiry: Approval request invalidated; approvers cannot approve
- Expired approvals are logged (for audit trail)
- On expiry: Operator notified; can re-request approval

**Cancellation:**

- Initiator can cancel pending approval before any approver signs
- After first approval signed: Cancellation blocked (approval is binding)
- On cancel: All gathered approvals discarded
- Cancellation logged (audit trail shows who cancelled and when)

### 9.6 Quorum State Machine

```
STATE: PENDING
├─ Timeout expires? → EXPIRED (logged)
├─ Initiator cancels? → CANCELLED (logged)
├─ First approver signs? → SINGLE_APPROVAL
│  └─ Approval expires? → EXPIRED (first approval lost)
│  └─ Approver retracts? → RETRACTED (audit logged)
│  └─ Second approver signs (distinct)? → QUORUM_MET
│     └─ Execute? → EXECUTING
│        ├─ Success? → EXECUTED → COMPLETED
│        └─ Failure? → EXECUTION_FAILED (audit logged, retry available)
└─ Approver rejects? → REJECTED (audit logged)
```

---

## 10. UI ENFORCEMENT CONTRACT

### 10.1 Identity-First UI Bootstrap

**No pixels render without verified identity.**

**Bootstrap Sequence:**

1. Browser loads `/index.html`
2. JavaScript initialization: Check `Authorization` header (from secure cookie)
3. If no auth token: Redirect to `/auth/login`
4. `/auth/login` page: No identity → show only login form (no system data)
5. On WebAuthn success: Token issued; stored in HTTP-only secure cookie
6. Redirect to `/dashboard`
7. Dashboard loads; on first render, fetch `/api/v1/identity/me` (requires token)
8. Verify token signature in browser (optional but recommended)
9. Render UI components based on response

**No Fallback:**

- If token missing or invalid: Show login page (not error; just redirect)
- If token expired: Show login page on next API call
- No cached identity across browser refresh (identity re-verified from token)

### 10.2 Capability-Declared Controls

Every UI control (button, menu item, action) declares its required capability.

**Declaration Schema (Example React component):**

```typescript
interface ControlDeclaration {
  id: string;                    // "kill-action-button"
  label: string;                 // "Kill Action"
  requiredCapability: string;    // "action:kill"
  requiredQuorum?: {
    size: number;               // 2
    eligible: string[];         // ["admin"]
  };
  enabled: boolean;              // true if user has capability
  hidden: boolean;               // true if user should not see button
  reason?: string;               // "admin:kill" if denied
}

// Example:
const killButton: ControlDeclaration = {
  id: "kill-action-btn",
  label: "Kill Action",
  requiredCapability: "action:kill",
  requiredQuorum: { size: 2, eligible: ["admin"] },
  enabled: capabilities.includes("action:kill"),
  hidden: !capabilities.includes("action:kill"),
  reason: "action:kill capability required"
};
```

**UI Enforcement:**

- Button is `disabled` if `enabled=false`
- Button is `hidden` if `hidden=true`
- Tooltip shows `reason` on hover
- Button is always rendered in DOM (inspect with DevTools to see declaration)

### 10.3 Permission Inspector Requirements

The Permission Inspector is a UI feature that shows the operator's current authorization state.

**Feature Requirements:**

- Accessible from all pages (sidebar widget or modal dialog)
- Shows operator ID, role, organization, current token expiry
- Lists all capabilities from current token (with descriptions)
- Shows risk flags (if any)
- Shows session ID and device binding status
- Includes "Request new token" button (for re-authentication)
- Audit log link: "View my recent actions" (read-only)

**Example Inspector UI:**

```
┌─ Permission Inspector ─────────────────────┐
│                                             │
│ Identity                                    │
│  Operator ID: 550e8400-e29b-41d4-a716-... │
│  Name: Alice Chen (alice@empire.local)     │
│  Role: admin                                │
│  Organization: empire                       │
│  Policy Epoch: 5                            │
│                                             │
│ Session                                     │
│  Session ID: s-12345678-90ab-cdef-...      │
│  Device: WebAuthn (MacBook Pro)             │
│  Token Expires: 14:45 UTC (15 min)          │
│  [Request New Token]                        │
│                                             │
│ Capabilities                                │
│  ✓ action:execute    (execute any action)  │
│  ✓ action:kill       (kill any action)     │
│  ✓ action:approve    (approve decisions)   │
│  ✓ policy:read       (read policies)       │
│  ✓ audit:read        (read audit logs)     │
│                                             │
│ Risk Assessment                             │
│  None (normal login)                        │
│                                             │
│ [View Recent Actions] [Inspect Token] [OK] │
│                                             │
└─────────────────────────────────────────────┘
```

### 10.4 Denied-State UX Requirements

When an operator attempts an action they do not have capability for:

| Scenario | UX Response |
|----------|-------------|
| **Denied on frontend (button disabled)** | Button shows as disabled; tooltip explains reason; no API call made |
| **Denied on backend (API rejects)** | Toast notification: "Access denied: missing action:kill capability"; redirect to permission inspector |
| **Requires quorum (pending)** | Show approval pending dialog; list approvers; show countdown timer (5 min) |
| **Quorum expired** | Toast: "Approval request expired; please re-request approval" |
| **Step-up required** | Modal dialog: "Security check required"; re-authenticate with WebAuthn or TOTP |
| **Session expired** | Redirect to login page; preserve return-to URL |

### 10.5 Logging of Denied Attempts

Every denied attempt is logged to audit trail.

**Denied Attempt Record:**

```json
{
  "event_type": "access_denied",
  "timestamp": "2026-01-15T14:30:00.000Z",
  "operator_id": "550e8400-e29b-41d4-a716-446655440000",
  "action": "action_kill",
  "target": "action-uuid",
  "reason": "missing capability: action:kill",
  "request_id": "req-12345678-90ab-cdef-1234-567890abcdef",
  "source": "frontend" | "backend",
  "device_id": "d7e8f9g0-h1i2-43d4-a716-446655440002"
}
```

**Audit Query:**

- Operators can query denial attempts (own only)
- Admins can query all denial attempts
- Auditors can query all denial attempts (read-only)

---

## 11. EXECUTION PROTECTION

### 11.1 Execution Envelopes

Every action execution is wrapped in a sealed envelope that contains preconditions, authorization, and proof.

**Envelope Schema:**

```json
{
  "action_id": "act-12345678-90ab-cdef-1234-567890abcdef",
  "request_id": "req-12345678-90ab-cdef-1234-567890abcdef",
  "decision_id": "dec-87654321-abcd-ef01-2345-67890abcdef0",
  "policy_epoch": 5,
  "operator_id": "550e8400-e29b-41d4-a716-446655440000",
  "operator_role": "admin",
  "session_id": "s-12345678-90ab-cdef-1234-567890abcdef",
  "device_id": "d7e8f9g0-h1i2-43d4-a716-446655440002",
  "action_type": "action_execute",
  "action_payload": {
    "asset_id": "asset-123",
    "operation": "metadata_update",
    "parameters": { ... }
  },
  "preconditions": {
    "operator_capability": "action:execute",
    "quorum_required": false,
    "risk_step_up_required": false
  },
  "authorization": {
    "policy_decision": { "allow": true, ... },
    "approvals": []
  },
  "envelope_timestamp": "2026-01-15T14:30:00.000Z",
  "envelope_signature": "MCwCFQDWNhYf5z...[RSA-256 signature]",
  "envelope_nonce": "nonce-random-value"
}
```

**Envelope is immutable:** Signature covers entire envelope; any change invalidates signature.

### 11.2 Preconditions

Before executing an action, system verifies preconditions. **Failure of any precondition = abort (no partial execution).**

**Required Preconditions:**

- Operator exists and is active
- Token valid (not expired, not revoked)
- Policy epoch matches
- Capability claim matches required capability
- Quorum approvals satisfied (if required)
- Step-up auth completed (if required)
- Asset/target exists and is in valid state
- No concurrent execution of same asset (lock or fail-fast)
- Audit store is writable (or buffer available)
- Rate limit not exceeded

**Precondition Verification:**

```python
# Example pseudocode
def verify_preconditions(envelope: ActionEnvelope) -> bool:
    checks = [
        check_operator_exists(envelope.operator_id),
        check_token_valid(envelope.token),
        check_policy_epoch_match(envelope.policy_epoch),
        check_capability_match(envelope.operator_id, envelope.action_type),
        check_quorum_if_required(envelope.approvals),
        check_step_up_if_required(envelope.device_id),
        check_asset_exists(envelope.action_payload.asset_id),
        check_not_locked(envelope.action_payload.asset_id),
        check_audit_writable(),
        check_rate_limit(envelope.operator_id, envelope.action_type)
    ]
    
    results = [c() for c in checks]
    if not all(results):
        for i, result in enumerate(results):
            if not result:
                audit_log.log("precondition_failed", {
                    "action_id": envelope.action_id,
                    "check": checks[i].__name__,
                    "operator_id": envelope.operator_id
                })
        return False
    
    return True
```

### 11.3 Idempotency

All actions are idempotent: executing the same action twice produces the same result as executing once.

**Idempotency Key:** `request_id` (from envelope) is the idempotency key.

**Mechanism:**

1. On first execution: Generate request_id; execute action; record result
2. On retry with same request_id: Lookup previous result; return cached result (no re-execution)
3. Cached result expires after 24 hours

**Example:**

```python
def execute_action(envelope: ActionEnvelope) -> ActionResult:
    # Check cache for idempotency
    cached = idempotency_cache.get(envelope.request_id)
    if cached:
        audit_log.log("action_retried", {
            "action_id": envelope.action_id,
            "request_id": envelope.request_id,
            "original_timestamp": cached["timestamp"]
        })
        return cached["result"]
    
    # Execute action
    result = _execute_action_internal(envelope)
    
    # Cache result
    idempotency_cache.set(
        envelope.request_id,
        {
            "result": result,
            "timestamp": now(),
            "operator_id": envelope.operator_id
        },
        ttl=86400  # 24 hours
    )
    
    return result
```

### 11.4 Replay Protection

Prevents attacker from capturing a legitimate action request and replaying it.

**Replay Protection Mechanisms:**

1. **Nonce in Envelope:** Every envelope contains `envelope_nonce` (random 32-byte value)
2. **Nonce Used Once:** Nonce tracked in database; if reused, reject with "nonce already consumed"
3. **Request Timestamp:** Envelope timestamp must be within ±5 seconds of server time (prevents old captured requests)
4. **Token Fresh:** Token must be < 15 minutes old (prevents replay from old sessions)
5. **Operator Session Active:** Session must be active (not revoked or expired)

**Replay Check Flow:**

```python
def check_replay_protection(envelope: ActionEnvelope) -> bool:
    # Check nonce freshness
    if nonce_cache.exists(envelope.envelope_nonce):
        audit_log.log("replay_attack_detected", {...})
        return False
    
    # Check timestamp freshness (±5 sec)
    now = time.time()
    envelope_time = parse_timestamp(envelope.envelope_timestamp)
    if abs(now - envelope_time) > 5:
        audit_log.log("stale_envelope", {...})
        return False
    
    # Mark nonce as used (TTL: 24 hours)
    nonce_cache.set(envelope.envelope_nonce, True, ttl=86400)
    
    return True
```

### 11.5 Kill / Abort / Rollback Parity Rules

Authority to kill/abort/rollback an action requires **no more privilege** than authority to execute the action.

**Parity Rules:**

| Action Type | Who Can Execute | Who Can Kill/Abort |
|-------------|-----------------|-------------------|
| **Operator's own action** | operator (action:execute) | operator (can kill own) |
| **Admin action** | admin (action:execute) | admin (action:kill) or quorum |
| **Service action** | service (via SPIFFE) | admin (action:kill) |

**Justification:**

- Ensures operator can always undo their own decisions
- Prevents privilege escalation through kill requirement
- Allows emergency abort by lower privilege (same privilege as execution)

**Implementation:**

```python
def can_kill_action(operator_id, action_id, action_owner_id) -> bool:
    # Get action details
    action = action_registry.get(action_id)
    
    # Rule 1: Operator can kill own actions
    if operator_id == action_owner_id:
        return True
    
    # Rule 2: Admin can kill any action (with quorum if production)
    if has_capability(operator_id, "action:kill"):
        return True
    
    # Rule 3: Operator with action:execute can kill actions they execute
    if has_capability(operator_id, "action:execute") and operator_id == action_owner_id:
        return True
    
    return False
```

---

## 12. AUDIT & PROVENANCE SYSTEM

### 12.1 Append-Only Requirements

The audit trail is an immutable append-only ledger. **No delete, no update, no backfill.**

**Append-Only Guarantees:**

- Every event added to ledger is assigned monotonically increasing sequence number
- Sequence numbers are never reused
- No event can be deleted (even after retention period)
- No event can be modified (immutable once written)
- No backfill (events must be written in time order)

**Database Schema:**

```sql
CREATE TABLE audit_events (
  sequence_number BIGINT PRIMARY KEY AUTO_INCREMENT,
  event_id UUID UNIQUE NOT NULL,
  timestamp TIMESTAMP NOT NULL,
  event_type VARCHAR(64) NOT NULL,
  operator_id UUID NOT NULL,
  action_id UUID,
  request_id UUID,
  decision_id UUID,
  details JSONB NOT NULL,
  hash VARCHAR(64) NOT NULL,  -- SHA-256 hash of this record + prev hash
  previous_hash VARCHAR(64) NOT NULL,
  signature VARCHAR(512) NOT NULL,  -- RSA-256 signature by audit server
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_operator_id ON audit_events(operator_id);
CREATE INDEX idx_timestamp ON audit_events(timestamp);
CREATE INDEX idx_event_type ON audit_events(event_type);
```

### 12.2 Immutability Strategy

**Storage Immutability:**

- PostgreSQL with table constraints (no UPDATE on audit_events table)
- Separate read-only replica for querying
- Write-once to primary; async replicate to read replicas
- No SQL grants for UPDATE/DELETE on audit table (role-based access control)

**Cryptographic Immutability:**

- Every event includes hash of previous event (hash chain)
- Hash mismatch detected on read → integrity violation
- Signature covers event + hash chain (ties together)
- Public key pinned in code (signature verification cannnot be bypassed)

**Observational Immutability:**

- Audit log is append-only by definition (new events only, never delete)
- If immutability violated: Operator detects (hash chain breaks)
- Violation triggers security alert (potential tampering)

### 12.3 Required Audit Fields

Every audit event must include:

| Field | Type | Required | Example |
|-------|------|----------|---------|
| `event_id` | UUID | YES | e-12345678-90ab-cdef-1234-567890abcdef |
| `timestamp` | ISO 8601 | YES | 2026-01-15T14:30:00.000Z |
| `event_type` | string | YES | action_executed, policy_deployed, operator_suspended |
| `operator_id` | UUID | YES | 550e8400-e29b-41d4-a716-446655440000 |
| `action_id` | UUID | IF APPLICABLE | act-12345678-90ab-cdef-1234-567890abcdef |
| `request_id` | UUID | IF APPLICABLE | req-12345678-90ab-cdef-1234-567890abcdef |
| `decision_id` | UUID | IF APPLICABLE | dec-87654321-abcd-ef01-2345-67890abcdef0 |
| `session_id` | UUID | IF APPLICABLE | s-12345678-90ab-cdef-1234-567890abcdef |
| `details` | JSON | YES | {...detailed context...} |
| `severity` | string | YES | info, warning, critical |
| `source` | string | YES | gateway, control-api, policy-engine, ui |

**Audit Event Details (example):**

```json
{
  "event_id": "e-12345678-90ab-cdef-1234-567890abcdef",
  "timestamp": "2026-01-15T14:30:00.000Z",
  "event_type": "action_executed",
  "operator_id": "550e8400-e29b-41d4-a716-446655440000",
  "action_id": "act-12345678-90ab-cdef-1234-567890abcdef",
  "request_id": "req-12345678-90ab-cdef-1234-567890abcdef",
  "decision_id": "dec-87654321-abcd-ef01-2345-67890abcdef0",
  "session_id": "s-12345678-90ab-cdef-1234-567890abcdef",
  "severity": "info",
  "source": "control-api",
  "details": {
    "action_type": "action_execute",
    "asset_id": "asset-123",
    "operation": "metadata_update",
    "result": "success",
    "duration_ms": 250,
    "audit_tag": "growth_engine:phase_4_evolution"
  }
}
```

### 12.4 Hash Chaining

Every audit event is cryptographically chained to the previous event.

**Chain Formula:**

```
hash(event[n]) = SHA256(
  event[n].timestamp +
  event[n].event_type +
  event[n].details_json +
  hash(event[n-1])
)
```

**Verification:**

- On write: Compute expected hash using previous hash; verify it matches
- On read: Recompute hash from event data; compare to stored hash
- Mismatch → Integrity violation; alert security team

**Chain Integrity Checker:**

```python
def verify_hash_chain(events: List[AuditEvent]) -> bool:
    """
    Verify entire hash chain is intact.
    Returns False if any mismatch detected.
    """
    for i, event in enumerate(events):
        if i == 0:
            # First event: previous_hash should be a known constant
            if event.previous_hash != GENESIS_HASH:
                return False
        else:
            # Subsequent events: previous_hash should match hash of prev event
            if event.previous_hash != events[i-1].hash:
                return False
        
        # Verify current event's hash
        computed_hash = compute_hash(event)
        if computed_hash != event.hash:
            return False
    
    return True
```

### 12.5 Anchoring Strategy

Audit trail is anchored to external immutable storage (blockchain or trusted timestamp service).

**Anchoring Mechanism:**

- Every 1000 events (or every 24 hours): Take hash of latest event
- Hash posted to blockchain (Ethereum testnet or similar public ledger)
- Blockchain transaction ID recorded in audit trail
- Anchoring timestamp provides external proof of time
- If audit trail modified: Anchor hash mismatch detected (provable tampering)

**Example Anchor Record:**

```json
{
  "anchor_event_id": "a-87654321-abcd-ef01-2345-67890abcdef0",
  "timestamp": "2026-01-15T15:00:00.000Z",
  "event_type": "audit_anchored",
  "anchor_point": 1000,
  "latest_hash": "d7e8f9g0h1i2j3k4l5m6n7o8p9q0r1s2t3u4v5w6x7y8z9a0b1c2d3e4f5g6h7",
  "blockchain": "ethereum-sepolia",
  "transaction_id": "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
  "block_number": 12345678,
  "block_timestamp": "2026-01-15T15:05:30.000Z"
}
```

### 12.6 UI Audit Visibility

Operators can inspect audit logs via the UI (read-only).

**Audit Inspector Feature:**

- Filter by event type, operator, action, date range
- Search by request_id, decision_id, action_id
- Export audit logs as CSV or JSON (requires audit:export capability)
- Permission inspector shows recent audit events for operator
- Anomaly detection: Flag suspicious patterns (e.g., 100 denials in 1 min)

**Example Audit Inspector Query:**

```sql
SELECT 
  timestamp,
  event_type,
  operator_id,
  action_id,
  details->>'result' as result,
  severity
FROM audit_events
WHERE 
  operator_id = '550e8400-e29b-41d4-a716-446655440000'
  AND timestamp >= NOW() - INTERVAL '7 days'
ORDER BY timestamp DESC
LIMIT 100;
```

---

## 13. DEGRADED & CRITICAL MODES

### 13.1 Mode Triggers

System automatically enters degraded or critical mode when:

| Condition | Trigger | Mode | Duration | Recovery |
|-----------|---------|------|----------|----------|
| **Policy Engine Timeout** | OPA latency > 30 sec | CAUTIOUS | Until OPA responds | Auto-recover when OPA responds |
| **Audit Store Errors** | Write failures > 3 in 1 min | BUFFERING | Until writes succeed | Auto-recover when DB responds |
| **Identity Service Down** | Keycloak unreachable > 5 min | CACHED | 5-30 min | Manual intervention to restore identity service |
| **Critical Security Alert** | Breach detected, compromise flagged | LOCKDOWN | Until manual reset | Admin must acknowledge alert; manually reset mode |
| **High Error Rate** | API errors > 20% for 5 min | DEGRADED | Until error rate < 5% | Auto-recover when errors drop |

### 13.2 Automatic Gating

When in degraded/critical mode, system automatically restricts what actions are allowed.

**Mode Restrictions:**

| Mode | Read Actions | Mutations | Quorum Decisions | Kill Switch | Audit Access |
|------|-------------|-----------|-------------------|------------|-----------------|
| **NORMAL** | YES | YES | YES | YES | YES |
| **CAUTIOUS** | YES | YES (cached policy) | NO (deny new) | YES | YES |
| **BUFFERING** | YES | NO (queue to buffer) | NO (deny new) | YES | YES (cached) |
| **DEGRADED** | YES | NO (deny all) | NO | YES | YES (read-only) |
| **LOCKDOWN** | YES (read-only) | NO | NO | YES (only) | YES (read-only) |

### 13.3 Allowed Actions per Mode

**NORMAL Mode:**
- All operations allowed
- Policy engine must be responsive

**CAUTIOUS Mode (Policy Engine slow):**
- Read-only operations allowed
- Cached policy decisions allowed (up to 30 sec old)
- New quorum decisions denied (require fresh policy)
- Kill switch available
- Recommendation: Alert operator; investigate policy engine latency

**BUFFERING Mode (Audit Store unreachable):**
- Write operations queued to in-memory buffer (500 event capacity)
- Once buffer full: New mutations denied (graceful degradation)
- Kill switch available (not buffered)
- Recommendation: Alert operator; restore audit store connectivity

**DEGRADED Mode (High error rate):**
- All mutations denied
- Read-only access to system state
- Kill switch available
- Recommendation: Alert operator; investigate error cause

**LOCKDOWN Mode (Critical security alert):**
- Only kill switch available (immediate shutdown)
- All other operations denied
- Audit trail still accessible (read-only)
- Recommendation: Security team investigates; manual reset required

### 13.4 Always-Available Containment Paths

The kill switch and emergency abort are **always** available, regardless of system mode.

**Kill Switch:**
- Accessible even in LOCKDOWN mode
- Single click (no confirmation required, but logged)
- Stops all running actions immediately
- Reverses uncommitted state (rollback to last stable point)
- Does not require policy engine response
- Immutable kill decision (cannot be undone; only audit trail tracks original action)

**Emergency Abort:**
- Available to any operator with action:kill capability
- Can abort any pending action (quorum or non-quorum)
- Abort decision logged with rationale
- Does not require approvals

---

## 14. EXPLICIT PROHIBITIONS

The following patterns are **hard-blocked** and cause immediate CI/deployment failure:

| Pattern | Detection | Consequence |
|---------|-----------|-------------|
| **Implicit deny bypass** (no explicit allow check) | Grep: `if not denied` patterns | CI rejects; code not merged |
| **TODO/FIXME in auth code** | `forbidden_markers_scan.py` | Build fails before deployment |
| **Hardcoded credentials** | Secrets scanner + grep | Build fails; credentials rotated |
| **Long-lived tokens (>1 hr)** | Token TTL validation in code | Linter rejects; deployment blocked |
| **Unauthenticated API endpoint** | Endpoint audit scan | Linter rejects; deployment blocked |
| **Unencrypted password storage** | Code audit: plaintext in config | CI fails; credentials rotated |
| **No audit logging for action** | Audit trail checker | Linter rejects; requires audit_log call |
| **Token in URL or logs** | Secret scanner + grep pattern | Pre-commit rejects; token rotated |
| **Cross-origin token acceptance** | CORS policy + origin validation check | Linter rejects; deployment blocked |
| **Operator masquerading** (using another operator's ID) | Audit trail: `operator_id` mismatch | Deployment blocked; audit alert |
| **Modification of audit record** | Database constraints (no UPDATE) | Data layer rejects |
| **Shared service credentials** | Code review + SPIFFE validation | Deployment blocked; credentials rotated |

---

## 15. BUILD ORDER (PROTECTION-FIRST)

Implementation must follow this phased order. **No phase begins until prior phase complete and audited.**

### Phase 1: Identity & Keycloak Foundation (Week 1)

1. Deploy Keycloak `empire-humans` realm
2. Configure WebAuthn as primary auth (CTAP2/U2F)
3. Configure TOTP as fallback (optional, for recovery)
4. Implement operator account model (immutable UUID)
5. Set token TTL: 900 sec (access), 604800 sec (refresh)
6. Configure mTLS for admin UI clients
7. Test: No authentication bypass possible

**Audit Gate:** Keycloak security audit; OWASP compliance check

### Phase 2: Token & Claims Contract (Week 1)

1. Define and implement JWT claims schema (§6.1)
2. Implement access token generation in Keycloak realm
3. Implement refresh token single-use enforcement
4. Implement token revocation list (in-memory cache + DB)
5. Implement claims validation in gateway (§6.3)
6. Test: Malformed token rejected; expired token rejected; revoked token rejected

**Audit Gate:** Token validation test suite; claims audit

### Phase 3: Policy Engine (OPA) Foundation (Week 2)

1. Deploy OPA cluster (3 nodes, HA)
2. Implement core policy bundle (authorization.rego, quorum.rego)
3. Implement policy decision contract (§8.1-8.3)
4. Implement decision ID generation and propagation
5. Implement policy versioning and bundle signing
6. Test: All decisions include decision ID; all decisions signed

**Audit Gate:** Policy engine security review; bundle integrity check

### Phase 4: Gateway (PEP) & Authorization (Week 2)

1. Implement gateway PEP (Policy Enforcement Point)
2. Implement token validation checks (§3.3)
3. Implement gateway → OPA request/response handling
4. Implement capability matching logic
5. Implement risk-based step-up auth logic
6. Test: No request executes without policy decision; denied requests return 403

**Audit Gate:** Authorization test suite; gateway security scan

### Phase 5: Audit & Immutability (Week 3)

1. Implement audit table (PostgreSQL, append-only)
2. Implement hash chaining logic (§12.4)
3. Implement audit event schema and validation
4. Implement audit write path (gateway → audit store)
5. Implement audit integrity checker
6. Implement blockchain anchoring (if available; optional for MVP)
7. Test: Audit events immutable; hash chain unbroken

**Audit Gate:** Audit integrity audit; data loss prevention test

### Phase 6: Dual Control & Quorum (Week 3)

1. Implement quorum requirement evaluation (§9.1-9.6)
2. Implement approval workflow (PENDING → QUORUM_MET → EXECUTED)
3. Implement distinct-operator validation
4. Implement distinct-session validation
5. Implement approval expiry and cancellation
6. Test: Quorum enforced; one operator cannot approve own action; approvals expire

**Audit Gate:** Quorum compliance test; approval audit

### Phase 7: Execution Protection (Week 4)

1. Implement action envelope schema (§11.1)
2. Implement precondition verification (§11.2)
3. Implement idempotency mechanism (§11.3)
4. Implement replay protection (§11.4)
5. Implement kill/abort/rollback parity (§11.5)
6. Test: Duplicate requests return cached result; replayed envelope rejected

**Audit Gate:** Execution security test; replay attack test

### Phase 8: UI & Frontend (Week 4-5)

1. Implement identity-first bootstrap (§10.1)
2. Implement capability-declared controls (§10.2)
3. Implement permission inspector (§10.3)
4. Implement denied-state UX (§10.4)
5. Implement audit inspector UI
6. Test: No UI without auth; denied actions clearly shown

**Audit Gate:** UI security test; accessibility audit

### Phase 9: Degradation & Emergency (Week 5)

1. Implement mode detection logic (§13.1-13.4)
2. Implement automatic gating per mode (§13.2)
3. Implement kill switch (always available)
4. Implement emergency abort
5. Implement circuit breakers (policy engine, audit store, identity)
6. Test: Kill switch works in all modes; system degrades gracefully

**Audit Gate:** Resilience test; emergency response test

### Phase 10: Integration & Testing (Week 5-6)

1. End-to-end integration tests (entire pipeline)
2. Penetration testing (authorization bypass attempts)
3. Load testing (under normal + degraded conditions)
4. Audit trail verification (correctness + completeness)
5. Documentation completeness check
6. CI/CD gates verified (all linters active)

**Audit Gate:** Security audit; compliance audit; deployment readiness

---

## 16. ACCEPTANCE CRITERIA & PROOFS

Every requirement must have a verifiable proof. **Proof = automated test or audit result.**

### 16.1 Identity & Authentication

**Proof 1: No Identity → No Pixels**

```
Test: Request /api/dashboard without Authorization header
Expected: 302 redirect to /auth/login OR 401 Unauthorized
Automated: UI integration test; API contract test
```

**Proof 2: Invalid Token Rejected**

```
Test: Request /api/actions with malformed JWT (bad signature)
Expected: 403 Forbidden; audit log includes "signature_validation_failed"
Automated: Test with forge JWT library; verify audit entry
```

**Proof 3: Expired Token Rejected**

```
Test: Request /api/actions with token exp < now
Expected: 403 Forbidden; audit log includes "token_expired"
Automated: Create token with exp = now - 1000; verify rejection
```

**Proof 4: Revoked Token Rejected**

```
Test: Revoke operator; try using existing token
Expected: 403 Forbidden; audit log includes "token_revoked"
Automated: Operator logout test; token in revocation cache
```

**Proof 5: Device Binding Enforced**

```
Test: WebAuthn assertion from unregistered device
Expected: Assertion rejected; device re-registration required
Automated: Test with random credential ID; verify failure
```

### 16.2 Authorization & Policy

**Proof 6: Missing Capability → Denial**

```
Test: Operator without action:execute tries to execute action
Expected: 403 Forbidden; decision_id in response; audit log includes decision
Automated: Policy test with missing capability; verify OPA decision
```

**Proof 7: API Denial with Forged UI**

```
Test: Manually forge AJAX request (JavaScript disabled); 
send to API with valid token but missing capability
Expected: 403 Forbidden (backend rejects, ignores frontend UI state)
Automated: Test with curl/Postman; verify backend enforcement
```

**Proof 8: Decision ID Propagation**

```
Test: Execute action; verify decision_id in audit log
Expected: decision_id matches policy decision; traceable end-to-end
Automated: Request action; verify audit entry includes decision_id
```

**Proof 9: Policy Engine Outage Behavior**

```
Test: Simulate OPA timeout (> 30 sec); try to execute action
Expected: CAUTIOUS mode; cached policy used (if available); new quorum decisions denied
Automated: Mock OPA timeout; verify request behavior
```

### 16.3 Quorum & Approval

**Proof 10: Quorum Enforced**

```
Test: Production action kill requires 2 approvals; try with 1
Expected: Action not executed; approval still pending; audit shows state
Automated: Action execution test; verify quorum requirement
```

**Proof 11: Distinct Operators Enforced**

```
Test: Operator A initiates action; Operator A tries to approve
Expected: Approval rejected; "same operator" rule violation logged
Automated: Approval test; verify distinct operator check
```

**Proof 12: Approval Expiry**

```
Test: Request quorum approval; wait 5 min; try to approve
Expected: Approval expired; cannot approve; must re-request
Automated: Time-based test; verify expiry enforcement
```

### 16.4 Audit & Immutability

**Proof 13: Audit Append-Only**

```
Test: Try to DELETE from audit_events table
Expected: SQL error (DELETE not allowed); no rows deleted
Automated: SQL test; database constraint verification
```

**Proof 14: Hash Chain Integrity**

```
Test: Corrupt audit event (modify details); recompute hash
Expected: Hash mismatch detected on read; integrity violation reported
Automated: Corruption test; verify hash validation
```

**Proof 15: Audit Complete**

```
Test: Execute action; verify all required fields in audit entry
Expected: event_id, timestamp, operator_id, action_id, decision_id, details all present
Automated: Audit schema test; verify no null required fields
```

### 16.5 Execution Protection

**Proof 16: Replay Attack Rejected**

```
Test: Capture action envelope; replay identical request twice
Expected: First succeeds; second fails (nonce already consumed)
Automated: Replay test; verify nonce tracking
```

**Proof 17: Preconditions Verified**

```
Test: Try to execute action on non-existent asset
Expected: Precondition fails; action not executed; audit shows reason
Automated: Precondition test; verify all checks run
```

**Proof 18: Kill/Abort Parity**

```
Test: Operator with action:execute tries to kill own action
Expected: Kill succeeds (no additional capability required)
Automated: Kill authorization test; verify parity rule
```

### 16.6 Degradation & Emergency

**Proof 19: Kill Switch Always Available**

```
Test: Trigger LOCKDOWN mode; try kill switch
Expected: Kill switch works; action stops immediately
Automated: LOCKDOWN mode test; verify kill switch function
```

**Proof 20: Graceful Degradation**

```
Test: Simulate audit store outage; try to execute action
Expected: Mutation denied (BUFFERING mode); read operations still work
Automated: Audit store outage simulation; verify mode behavior
```

---

## 17. WINDSURF HANDOFF CONTRACT

This plan is law for Windsurf execution. Windsurf may only modify what is authorized below.

### 17.1 What Windsurf May Modify

✓ **Allowed:**

- Keycloak configuration files (realm.json, clients.json) following §4.2 exactly
- Policy engine Rego files following §8.6 patterns (no business logic in policy code)
- Gateway middleware (token validation, PEP logic) following §3.2-3.4 exactly
- Audit event logging following §12.3 schema exactly
- API endpoint implementations (following execution envelope §11.1 exactly)
- UI React components (following capability declarations §10.2 exactly)
- Test files (all test code must follow proofs §16)
- Documentation (keeping audit trail updated)
- CI/CD linter rules (enforcing this plan)

### 17.2 What Is Read-Only

✗ **Forbidden to modify:**

- Identity axioms (§1.1) - hard constraints
- Token claims contract (§6.1) - JWT structure
- Authorization model (§7.1-7.5) - roles and capabilities
- Audit schema (§12.3) - immutable fields
- Quorum requirements (§9.1) - which actions require approval
- Threat model (§2) - failure assumptions
- Phase sequence (§15) - build order
- Acceptance proofs (§16) - test requirements

### 17.3 Plan Hash Enforcement

This plan document is hashed and embedded in deployment manifests.

**Hash Computation:**

```bash
sha256sum ATLAS_PROTECTION_SYSTEM_MASTER_PLAN.md
# Output: abc123def456... (256-bit hex)
```

**Enforcement:**

1. Git commit includes plan hash in commit message: `PLAN-HASH: abc123def456...`
2. CI verifies plan hash matches deployed version
3. If plan modified after deployment: Hash mismatch → deployment blocked
4. If Windsurf deviates from plan: Code review catches deviation; plan must be updated first

**Updating Plan:**

If Windsurf needs to deviate from this plan:

1. Propose plan change (new Antigravity review required)
2. New plan versioned (ATLAS_PROTECTION_SYSTEM_MASTER_PLAN_v1.1.md)
3. Old plan archived (docs/antigravity/archive/)
4. New plan hash updated in deployment
5. CI enforces new plan hash

### 17.4 Stop Conditions

Windsurf must stop and escalate if:

| Condition | Action | Escalate To |
|-----------|--------|------------|
| **Plan ambiguity detected** | Stop implementation; flag ambiguity | Antigravity (request clarification) |
| **Deviation necessary** | Stop; propose plan amendment | Antigravity (security review) |
| **Axiom conflict** | Stop immediately | Antigravity + Security team |
| **Test failure (proof §16)** | Fix code, not test | Code quality gates; retest |
| **Audit schema violation** | Stop; reject commit | CI lint (non-negotiable) |
| **Authorization bypass found** | Stop; incident response | Security + Antigravity |

### 17.5 Required Reporting Format

Windsurf must report execution status in this format:

**Daily Report (template):**

```
WINDSURF EXECUTION REPORT
Date: 2026-01-15
Plan: ATLAS_PROTECTION_SYSTEM_MASTER_PLAN (v1.0)
Plan Hash: abc123def456...

PHASE: [phase number and name]
Status: [IN_PROGRESS | COMPLETE | BLOCKED]

Completed:
- [ ] Subtask 1
- [ ] Subtask 2

Blocked By:
- [description of blocker]

Plan Deviations:
- None | [list deviations with rationale]

Audit Trail:
- [commits made today]
- [tests run and results]

Next Steps:
- [planned for tomorrow]

KAIZA-AUDIT
Plan: ATLAS_PROTECTION_SYSTEM_MASTER_PLAN
Scope: [files changed]
Intent: [what was implemented]
Key Decisions: [why these choices]
Verification: [tests pass, proofs satisfied]
Results: [PASS | FAIL with details]
Risk Notes: [remaining concerns]
Rollback: [how to revert if needed]
KAIZA-AUDIT-END
```

---

## EXECUTION LOCK

This plan is **LOCKED FOR EXECUTION** as of 2026-01-15.

**All Windsurf execution is bound by this plan.**

**Violations of axioms (§1.1) result in:**
1. CI build failure
2. Deployment block
3. Audit rejection
4. Security incident investigation

**No exceptions. No shortcuts. No "later" implementation.**

**Plan Authority:** Antigravity / KAIZA-MCP  
**Hash:** (computed on finalization)  
**Effective Date:** 2026-01-15  
**Revision Authority:** Antigravity only

---

**END OF MASTER PLAN**
