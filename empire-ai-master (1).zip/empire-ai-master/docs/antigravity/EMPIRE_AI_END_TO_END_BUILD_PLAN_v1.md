# EMPIRE_AI_END_TO_END_BUILD_PLAN_v1

> **ARTIFACT STATUS**: FROZEN
> **GOVERNANCE**: KAIZA MCP
> **AUTHORITY**: ANTIGRAVITY

---

## 0. KAIZA MCP INVARIANTS (HARD LOCK)

1.  **Single Source of Truth**: This document is the absolute reference. No deviations.
2.  **Cost Invariant**: Hetzner VPS/Dedicated servers ONLY. No AWS, No GCP, No Paid APIs, No SaaS.
3.  **No Scope Drift**: Implement exactly what is specified. No new features.
4.  **Determinism**: All logic must be rule-based, not heuristic.
5.  **Execution Supremacy**: If it cannot be automated, it is excluded.

---

## 1. SYSTEM DECOMPOSITION

### 1.1. Command Plane (Human Interface)
*   **Purpose**: The single point of entry for human control (Governance only).
*   **Inputs**: Autonomy Horizon (3/6/12mo), Risk Threshold (Low/Med/High), Kill Signal.
*   **Outputs**: System State Dashboard, ROI Reports, Emergency Stop Confirmation.
*   **Responsibilities**: Setting high-level constraints, emergency shutdown.
*   **Non-Responsibilities**: Business strategy, niche selection, content approval.

### 1.2. Governor (Strategic Authority)
*   **Purpose**: Orchestrate resource allocation and business lifecycle decisions.
*   **Inputs**: Global Performance Data, Resource State, Command Plane Constraints.
*   **Outputs**: Spawn/Kill Orders, Budget Allocations, Mode Switches.
*   **Responsibilities**: Deciding *what* runs. Enforcing ROI thresholds.
*   **Non-Responsibilities**: Execution details, content generation.

### 1.3. Niche / Demand Discovery Engine
*   **Purpose**: Identify monetizable gaps in the market.
*   **Inputs**: Crawled Search Data, SERP Volatility, Keyword Volumes (inferred or scraped).
*   **Outputs**: `TargetNiche` objects (Keyword, Intent, CompetitionScore, EstValue).
*   **Responsibilities**: Finding demand.
*   **Non-Responsibilities**: Monetizing demand.

### 1.4. Business Registry & Executors
*   **Purpose**: The catalog of available profit engines and their runtime logic.
*   **Inputs**: `TargetNiche`, Resource Quota.
*   **Outputs**: Deployed Assets (Sites, Videos, Ads, Leads).
*   **Responsibilities**: Instantiating specific business logic (e.g., "Build an Affiliate Site").
*   **Non-Responsibilities**: Cross-business optimization.

### 1.5. Distribution Engine
*   **Purpose**: Pushing assets to the public web.
*   **Inputs**: Generated Assets (HTML, Video, Text).
*   **Outputs**: Live URLs, Indexed Content.
*   **Responsibilities**: Deploying to servers, submitting sitemaps, managing DNS.
*   **Non-Responsibilities**: Content creation.

### 1.6. Monetization Engine
*   **Purpose**: Converting traffic/views to value.
*   **Inputs**: Live Traffic via Distribution Engine.
*   **Outputs**: Revenue Signals (Clicks, Conversions), Affiliate Links, Ad Tags.
*   **Responsibilities**: Injecting money-making elements, tracking revenue.
*   **Non-Responsibilities**: Generating traffic.

### 1.7. Resource Governor (Infrastructure)
*   **Purpose**: Enforce the "Hetzner-Only" and "Cost-Invariant" rules.
*   **Inputs**: Resource Usage Stats (CPU/RAM/Disk), Budget Config.
*   **Outputs**: Throttle Signals, Server Provisions/Destructions.
*   **Responsibilities**: Managing Docker swarms, provisioning Hetzner instances, rigorous cost capping.
*   **Non-Responsibilities**: Business logic.

---

## 2. BUSINESS REGISTRY IMPLEMENTATION

### 2.1. Internal Representation
All businesses are classes implementing `IBusinessUnit`.
Attributes:
*   `ID`: Unique Hash
*   `Type`: Enum (AFFILIATE_NETWORK, MEDIA_FARM, LEAD_GEN, etc.)
*   `State`: INITIALIZING, SCALING, SUSTAINING, DYING
*   `Metrics`: { Cost, Revenue, ROI, Confidence }

### 2.2. Selection Logic
The **Governor** runs a selection loop every 6 hours:
1.  Query **Demand Discovery** for `TopNiches` sorted by `EstValue`.
2.  Filter `TopNiches` against `Blacklist` (previous failures).
3.  Match Niche Intent to `BusinessType`.
    *   *Example*: "Best blender" -> AFFILIATE_NETWORK. "Plumber near me" -> LEAD_GEN.
4.  Spawn `IBusinessUnit` instance if Resource Governor allows.

### 2.3. Lifecycle Management (Throttle, Scale, Kill)
*   **Throttle**: If `ROICalculated < 0` for > 7 days BUT `Traffic > Threshold`, reduce CPU priority.
*   **Scale**: If `ROICalculated > 1.5` AND `ResourceUtil < 80%`, duplicate instance or expand keyword scope.
*   **Kill**: If `ROICalculated < -0.5` after 30 days OR `LegalRisk > 0`, strict delete.

### 2.4. Spawning
*   Automatic Docker container deployment.
*   Configuration injected via env vars derived from `TargetNiche`.
*   No human approval required.

---

## 3. DATA & DEMAND PIPELINE

### 3.1. Data Sources (Zero Cost)
*   **Common Crank**: High-churn common crawl subsets.
*   **SERP Scrapers**: Custom-built, residential proxy rotation (if needed, self-hosted/scanned) or low-tier SERP data scraping (locally run headless browsers).
*   **Social Listeners**: API-less scraping of Reddit/Twitter/Trends for rising keywords.

### 3.2. Normalization
*   All inputs converted to `DemandSignal` schema: `{ topic, volume_proxy, competition_index, timestamp }`.
*   Text cleaning: Strip PII, strip irrelevant boilerplate.

### 3.3. Demand Graph
*   Directed Graph stored in graph DB (e.g., Neo4j or lightweight alternative like SQLite with recursive CTEs).
*   Nodes: Keywords/Topics.
*   Edges: Semantic relatedness.
*   Weights: Monetization potential.

### 3.4. Signal Propagation
*   Revenue events (Clicks/Sales) propagate BACKWARDS to Demand Graph.
*   Success increases weight of parent Niche and related Topics.

### 3.5. Noise Handling
*   **Stale Data**: Signals older than 30 days decay by 50% per week.
*   **Blacklisting**: Domains/topics with 0 revenue after significant traffic are marked `POISON`.

---

## 4. RESOURCE & COST GOVERNANCE

### 4.1. The Hetzner Constraint
*   **Infrastructure**: Hetzner Cloud and Dedicated Servers only.
*   **Orchestration**: Kubernetes (K3s) or Docker Swarm.
*   **Provisioning**: Terraform scripts triggered by Resource Governor.
*   **Constraint**: Total Monthly Bill <= `GlobalBudget` (Hard limit).

### 4.2. Throttles & Limits
*   **CPU**: 90% utilization cap. Processes > 90% for 10min are killed.
*   **Crawl**: Rate limits per target domain (respect robots.txt to avoid IP bans).
*   **Gen**: Local LLM inference (e.g., LLaMA 3/Mistral on GPU instances) or free-tier API rotation if strictly necessary and compliant with "No SaaS" (prefer Local).
    *   *Decision*: **LOCAL INFERENCE ONLY** to satisfy "No SaaS" cost invariant strictly.

### 4.3. ROI-Based Scaling
*   `Score = (Revenue - ServerCost) / ServerCost`.
*   If `Score > 0.5`, authorize new dedicated server provision.
*   If `Score < 0` for portfolio, de-provision oldest/lowest-performing nodes until budget fits.

### 4.4. Runaway Prevention
*   **Hard Circuit Breaker**: If projected bill > `GlobalBudget`, ALL non-essential containers pause.
*   **Kill Switch**: API endpoint that immediately halts all network traffic outbound.

---

## 5. ASSET LIFECYCLE (UNIVERSAL)

### 5.1. Phases
1.  **Genesis**: Niche identified, content generated locally, static site/asset compiled.
2.  **Deployment**: Pushed to Nginx serving layer. DNS records updated.
3.  **Probing**: Low-volume traffic acquisition (long-tail keywords).
4.  **Graduation**: If `Visits > 100` and `CTR > 1%`, move to High-Availability cluster.
5.  **Templating**: Success pattern saved as `WinningArchetype`.
6.  **Death**: Criteria met (Revenue=0 for 90 days). `rm -rf`. DNS released.

### 5.2. Granularity
*   **Page**: Smallest unit. Deleted individually if bouncing.
*   **Site**: Collection of pages. Deleted if domain reputation tanks.
*   **Business**: Specific strategy (e.g., "AI Image Directories"). Deleted if strategy fails globally.

---

## 6. PORTFOLIO-LEVEL OPTIMIZATION

### 6.1. Winner Compression
*   Successful sites are analyzed for Structure, Keyword Density, DOM Layout.
*   "DNA" of winners is stored as JSON templates.
*   `ArchetypeReplicator` spawns 10 variants of the winner in adjacent niches.

### 6.2. Loser Blacklisting
*   Keywords/Niches that fail 3x across different strategies are added to `GlobalBlacklist`.
*   No resources wasted on them for 12 months.

### 6.3. Effort Reallocation
*   **Dynamic Weighting**:
    *   Affiliate: `Weight * (RecentRevenue / Cost)`
    *   Ad Network: `Weight * (RPM / Cost)`
*   Resources shifted dynamically every 24h cycle to the highest weighted business type.

---

## 7. AUTONOMY MODE BEHAVIOR

### 7.1. 3-Month Mode (Short Horizon)
*   **Strategy**: Aggressive Exploitation.
*   **Explore/Exploit Ratio**: 10% / 90%.
*   **Risk**: Medium-High.
*   **Pruning**: Fast (Kill if no profit in 14 days).
*   **Growth**: Maximize immediate cash flow.

### 7.2. 6-Month Mode (Balanced)
*   **Strategy**: Asset Building.
*   **Explore/Exploit Ratio**: 30% / 70%.
*   **Risk**: Medium.
*   **Pruning**: Moderate (Kill if no profit in 30 days).
*   **Growth**: Reinvest 50% of profit into new server capacity.

### 7.3. 12-Month Mode (Empire)
*   **Strategy**: Deep Moats & Data Dominance.
*   **Explore/Exploit Ratio**: 50% / 50%.
*   **Risk**: Low (Focus on sustainability).
*   **Pruning**: Slow (Allow 90 days for SEO maturation).
*   **Growth**: Uncapped scaling. Reinvest 80%.

---

## 8. RISK, ABUSE & KILL CONTROLS

### 8.1. Platform Risk
*   **Detection**: Sudden drop in referrer traffic (Google Update).
*   **Reaction**: Halt content updates on affected sites. Launch "Lifeboat" sites on fresh domains/IPs.

### 8.2. Legal Risk
*   **Triggers**: DMCA notices, C&D keyword matches in inbox (if monitored).
*   **Reaction**: Immediate 410 Gone on affected assets. Domain abandonment.

### 8.3. Emergency Shutdown
*   **Physical**: `kill_switch.sh` script execution.
*   **Result**: Stop all Docker containers, wipe sensitive logs, release IP bindings.

### 8.4. Safe Degradation
*   **Failure**: If Database fails: Executors switch to "Cached Mode" (read-only).
*   **Failure**: If specific crawler blocked: Switch to backup method (e.g., related keywords) or pause niche.

---

## 9. PHASED BUILD ROADMAP

### Phase 0: The Core (Minimum Runnable)
*   **Goal**: Infrastructure Setup & Hello World.
*   **Outputs**:
    *   Hetzner Account Configured & Terraform State established.
    *   Kubernetes/Docker Swarm active.
    *   Local LLM (inference) running.
    *   Simple "Hello World" site generator pipeline functional.

### Phase 1: The Loop (First Revenue)
*   **Goal**: End-to-end automation of ONE business type (e.g., Programmatic SEO Directories).
*   **Outputs**:
    *   Demand Discovery active (identifying low-comp keywords).
    *   Generation Pipeline producing 100+ pages/day.
    *   Deployment to live domains.
    *   Monetization (Adsense/Affiliate filler) inserted.
    *   **Metric**: $1 Revenue generated autonomously.

### Phase 2: Expansion (Multi-Business)
*   **Goal**: Activate the Registry.
*   **Outputs**:
    *   Enable 3+ Business Types (e.g., Content Farm + Lead Gen + Asset Gen).
    *   Resource Governor actively balancing load.
    *   Feedback loop optimizing based on winners.

### Phase 3: Unattended (The Empire)
*   **Goal**: Full Autonomy.
*   **Outputs**:
    *   Switch to 6/12 Month Mode.
    *   Dashboard Green.
    *   Human intervention = 0.

---

**END OF SPECIFICATION**
