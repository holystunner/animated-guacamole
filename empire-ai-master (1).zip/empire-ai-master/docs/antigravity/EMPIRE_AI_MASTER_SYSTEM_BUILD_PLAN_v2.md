# EMPIRE AI MASTER SYSTEM BUILD PLAN v2
**Authority:** KAIZA MCP  
**Status:** DRAFT -> FROZEN  
**Date:** 2026-01-02  
**Executor:** Antigravity

---

## 1. SYSTEM DECOMPOSITION

The system is a closed-loop cybernetic organism designed for autonomous profit generation. It is composed of 9 distinct subsystems.

### 1.1 Command Plane (Level 0)
*   **Purpose:** The single interface for Human-to-Machine control.
*   **Inputs:** Human intent (Autonomy Mode, Risk Threshold, Kill Signal).
*   **Outputs:** System State, Aggregated Financials, Emergency Alerts.
*   **Responsibilities:**
    *   Authentication (Hardware key + Password).
    *   Displaying high-level dashboards (Revenue, Cost, Profit, Active Assets).
    *   Broadcasting "Kill" signals to the Governor.
*   **Non-Responsibilities:** Granular asset management, debugging, creative direction.

### 1.2 Governor (Level 1)
*   **Purpose:** The strategic brain. Allocates resources to the highest ROI opportunities.
*   **Inputs:** Demand Signals, Financial Performance, Resource Status.
*   **Outputs:** Orders to Executor (Spawn, Scale, Kill).
*   **Responsibilities:**
    *   Selecting which Business types to run.
    *   Enforcing global risk/cost constraints.
    *   Prioritizing threads based on calculated Expected Value (EV).
*   **Non-Responsibilities:** Execution details, content generation.

### 1.3 Business Registry (Level 1)
*   **Purpose:** The ledger of all active and historical business instances.
*   **Inputs:** Registration events from Executor.
*   **Outputs:** State of the portfolio.
*   **Responsibilities:**
    *   Tracking lifecycle state (`SPAWN`, `SCALE`, `SUSTAIN`, `KILL`).
    *   Storing configuration for each running business instance.
    *   Maintaining P&L per instance.

### 1.4 Niche & Demand Discovery Engine (Level 2)
*   **Purpose:** Identifies monetizable voids in the market.
*   **Inputs:** Crawled web data, search trends, social signals.
*   **Outputs:** `Opportunity` objects (Keyword + Intent + Volume + Competition).
*   **Responsibilities:**
    *   Continuous crawling of seed lists.
    *   Keyword extraction and volume estimation (using local statistical models).
    *   Competitor weakness analysis.

### 1.5 Executor Factories (Level 2)
*   **Purpose:** The hands that build assets.
*   **Inputs:** `Order` from Governor, `Opportunity` data.
*   **Outputs:** Deployed Digital Assets (Sites, Videos, Ad Campaigns).
*   **Responsibilities:**
    *   **Content Factory:** Generates text/images via local LLMs/Diffusion.
    *   **Code Factory:** Deploys HTML/JS containers.
    *   **Setup:** Domain configuration (via registrar API - *exception permissible only for domain purchase interaction via simplified interface, strictly limited*), Server provisioning.

### 1.6 Distribution Engine (Level 2)
*   **Purpose:** Pushes assets to eyeballs.
*   **Inputs:** Deployed Assets.
*   **Outputs:** Traffic.
*   **Responsibilities:**
    *   Indexing submission.
    *   Social posting automation.
    *   Ad campaign bidding (algorithmic).

### 1.7 Monetization Engine (Level 2)
*   **Purpose:** Converts traffic to capital.
*   **Inputs:** Traffic.
*   **Outputs:** Revenue data, Affiliate links, Ad tags.
*   **Responsibilities:**
    *   Rotating offer links based on conversion rate (CVR).
    *   Injecting ad units.
    *   Collecting revenue data from scraping affiliate dashboards (no APIs if paid, scrape dashboard HTML).

### 1.8 Resource Governor (Level 0 - Sidecar)
*   **Purpose:** Enforces physical and financial constraints.
*   **Inputs:** CPU/RAM usage, Bandwidth, API credits (if any free tier), Server costs.
*   **Outputs:** Throttling signals, Kill signals.
*   **Responsibilities:**
    *   Monitoring Hetzner bill estimation.
    *   Hard stopping processes exceeding quotas.

### 1.9 Feedback Loop (Level 3)
*   **Purpose:** Learning from success and failure.
*   **Inputs:** Performance Data (Traffic, Revenue).
*   **Outputs:** Weight updates for Governor logic.
*   **Responsibilities:**
    *   Updating `Opportunity` scores.
    *   Adjusting prompt templates for higher CTR.

---

## 2. BUSINESS REGISTRY DESIGN

The Registry is a relational database (PostgreSQL) enforcing strict schemas.

### 2.1 Internal Representation
Table: `businesses`
*   `id`: UUID
*   `type`: ENUM ('AFFILIATE_SEO', 'MEDIA_BUY', 'SOCIAL_FARM', 'LEAD_GEN', 'LOCAL_ARB', 'JOB_BOARD', 'DIRECTORY', 'DATA_LICENSING', 'ASSET_MFG', 'MICRO_TOOL', 'TRAFFIC_ARB')
*   `status`: ENUM ('SPAWN', 'VALIDATION', 'SCALE', 'SUSTAIN', 'KILL')
*   `metrics`: JSONB (Revenue, Cost, Profit, ROI, Age)
*   `config`: JSONB (Target Niche, Template ID, ResourceLimit)

### 2.2 Lifecycle States
1.  **SPAWN:** Resources allocated. Skeleton deployed. No traffic yet.
2.  **VALIDATION:** initial traffic test (30-90 days). Strict Kill threshold if ROI < -50%.
3.  **SCALE:** Profit proven. Reinvest 80% of revenue into growth. Unlimited scaling speed.
4.  **SUSTAIN:** Mature. Reinvest 20%. Harvest 80%.
5.  **KILL:** Failed metrics or risk trigger. Immediate deletion.

### 2.3 Creation Logic
*   Triggered when `Demand Engine` finds `Opportunity` with Score > `Governor.Threshold` AND `Resource Governor` allows.

---

## 3. DEMAND & DATA PIPELINE

### 3.1 Data Acquisition (No Paid APIs)
*   **Technique:** Headless Browser Cluster (Puppeteer/Playwright) with rotation.
*   **Sources:**
    *   Search Engine Result Pages (SERPs) for Keyword difficulty.
    *   Social Platforms (Trends, Hashtags).
    *   Competitor Sitemaps.
    *   Public Data Sets (Gov/Academic).

### 3.2 Normalization
*   Raw HTML -> Extracted Text -> Vector Embeddings (Local Embedding Model, e.g., `all-MiniLM-L6-v2`).
*   Metrics (Volume, CPC) estimated via proxy signals (e.g., result count, advertiser count) if exact data not available.

### 3.3 Demand Graph structure
*   Nodes: `Keyword` / `Topic`.
*   Edges: `Related_To` (weighted by semantic similarity).
*   Properties: `Est_Volume`, `Difficulty_Score`, `Monetization_Potential`.

---

## 4. RESOURCE & COST GOVERNANCE (HETZNER ONLY)

### 4.1 Infrastructure Constraints
*   **Provider:** Hetzner Robot / Cloud.
*   **Server Types:**
    *   **Brain:** AX-Line (AMD EPYC) for Orchestration & DB.
    *   **Worker:** SX-Line (Storage) or CX-Cloud (Ephemeral).
    *   **GPU:** Rented dedicated GPU servers (or external cheap GPU cloud if Hetzner unavailable, e.g., RunPod/Vast.ai, BUT PREFER CPU Inference (Quantized models) on powerful Hetzner CPUs for cost invariance).
    *   **Decision:** Use Quantized Llama 3 (8B/70B) on CPU for bulk text. Low latency not required.

### 4.2 Throttling & Scaling
*   **Global Cap:** $X/month hard limit set by Human.
*   **Unit Cap:** Each business instance starts with $Y budget.
*   **Circuit Breaker:** If System Cost > Revenue for 7 days (after initial grace period), HALT all creation.

### 4.3 Runaway Prevention
*   Monitor: Disk Usage (Logs/Assets).
*   Action: Delete oldest `KILL` state data immediately. Rotate logs daily.

---

## 5. UNIVERSAL ASSET LIFECYCLE

All assets (Article, Video, Ad, Site) follow:

1.  **Draft:** Generated by AI.
2.  **Review:** Automated Quality Check (Grammar, Safety, Formatting via Rule-Engine).
3.  **Live:** Published.
4.  **Audition:** First 1000 impressions.
    *   If CTR < Benchmark: **Delete/Rewrite**.
    *   If CTR >= Benchmark: **Promote**.
5.  **Evergreen:** Periodic updates (every 6 months).
6.  **Retire:** If traffic drops below threshold for 3 months -> 404/Delete.

---

## 6. PORTFOLIO-LEVEL OPTIMIZATION

### 6.1 Winner Compression
*   Identify top 5% performing assets.
*   Extract "Archetype" (Structure, Tone, Topic Cluster).
*   Update `Generator Templates` with this Archetype.

### 6.2 Redeployment
*   If `Affiliate` fails but gets traffic, pivot to `Display Ads`.
*   If `Display Ads` fails but gets high CTR, pivot to `Lead Gen`.

### 6.3 Blacklisting
*   Patterns (Phrases, Layouts, Niches) associated with `KILL` (Banned/Deindexed) assets are hashed and added to `Global_Blacklist`.

---

## 7. AUTONOMY MODE BEHAVIOR

### Three Horizons

| Parameter | 3-Month Mode | 6-Month Mode | 12-Month Mode |
| :--- | :--- | :--- | :--- |
| **Exploration Ratio** | 40% New / 60% Proven | 20% New / 80% Proven | 5% New / 95% Proven |
| **Pruning** | Aggressive (Weekly) | Moderate (Monthly) | Conservative (Quarterly) |
| **Risk Tolerance** | High (Move fast) | Medium | Low (Protect Core) |
| **Scaling Velocity** | Exponential | Linear | Logarithmic |
| **Check-in Req** | None | None | None |

---

## 8. RISK, ABUSE & KILL CONTROLS

### 8.1 Detectors
*   **Platform Risk:** IP Blocking rate > 5%. (Solution: Rotate IP/Pause).
*   **Legal Risk:** Scanned content for extensive copyright matches (Local Fuzzy Hash).
*   **Financial Leak:** Server cost spike detection (>20% variance).

### 8.2 Safe Degradation
*   If Database fails: Executors enter "Cached Read-Only" mode.
*   If Generator fails: Traffic redirection to existing assets.

### 8.3 Emergency Kill
*   **Level 1 (Soft):** Stop new spawns.
*   **Level 2 (Hard):** Stop all traffic sources (Ads).
*   **Level 3 (Nuclear):** Delete all Cloud instances. Wipe Data. (Requires 2-step verification).

---

## 9. PHASED BUILD ROADMAP

### Phase 0: Minimum Runnable Core (Weeks 1-4)
*   **Goal:** Infrastructure & Command Plane.
*   **Deliverables:**
    *   Hetzner Server Provisioned.
    *   Postgres DB + Redis configured.
    *   Governor Logic (Rules Engine) implemented.
    *   Simple "Hello World" site generator.

### Phase 1: First Revenue Loop (Weeks 5-12)
*   **Goal:** End-to-end automation of ONE business type (e.g., SEO Affiliate).
*   **Deliverables:**
    *   Crawler finding keywords.
    *   Content Factory producing articles.
    *   Deployment to WordPress/Static HTML.
    *   First $1 revenue verified.

### Phase 2: Multi-Business Expansion (Weeks 13-24)
*   **Goal:** Activate 3+ Business Types.
*   **Deliverables:**
    *   Add Video Generation (FFmpeg automation).
    *   Add Paid Traffic Arbitration (API wrappers for Ad Networks).
    *   Feedback loop actively optimizing.

### Phase 3: Long-Term Autonomy (Week 25+)
*   **Goal:** Human steps away.
*   **Deliverables:**
    *   Enable 3/6/12 Month modes.
    *   Full delegation of resource scaling.
    *   Strict Kill-switch testing.

---

**END OF PLAN**
