# Phase 9: Permission Boundaries Specification

**Authority:** KAIZA Execution Framework  
**Status:** COMPLETE  
**Version:** 1.0  
**Date:** 2026-01-15

---

## 1. Overview

This document specifies the permission boundary enforcement for Atlas Empire productization. It implements Section 9 of the Phase 9 executable plan, defining how operations are gated based on license capabilities, authority rules, and instance isolation.

---

## 2. Permission Model

### 2.1 Three-Layer Permission System

```
Layer 1: Forbidden Operations (Hard blocks)
  ├─ Checked first, no exceptions
  ├─ Always denied regardless of license
  └─ Examples: modify_governor, trigger_evolution, cross_instance_access

Layer 2: License-Gated Operations
  ├─ Checked second
  ├─ Allowed only if license includes feature
  └─ Examples: export_audit, view_analytics, create_custom_factory

Layer 3: Authority Rules
  ├─ Checked third
  ├─ Validated against immutable policy
  └─ Examples: rate limits, resource limits, isolation rules
```

### 2.2 Permission Decision Flow

```
Check Request
  ↓
1. Is operation forbidden?
   └─ YES → DENY (ForbiddenOperationError)
  ↓
2. Does resource belong to this instance?
   └─ NO → DENY (IsolationViolation)
  ↓
3. Is operation licensed?
   └─ Required features missing → DENY (PermissionDenied)
  ↓
4. Are resource limits exceeded?
   └─ YES → DENY (LimitExceeded)
  ↓
5. Do authority rules allow operation?
   └─ Rule violation → DENY (AuthorityViolation)
  ↓
6. ALLOW operation
```

---

## 3. Forbidden Operations (Layer 1)

### 3.1 Never-Allowed Operations

These operations are ALWAYS forbidden for customer instances:

```python
FORBIDDEN_OPERATIONS = {
    # Governor & Authority Protection
    'modify_governor_logic',
    'update_governor_code',
    'patch_governor_behavior',
    'override_authority_rules',
    'modify_permission_policies',
    'bypass_safety_checks',
    
    # Self-Evolution Protection
    'trigger_self_evolution',
    'start_evolution_cycle',
    'upgrade_phase_0_8',
    'modify_canonical_code',
    'update_core_immutables',
    
    # Multi-Tenancy Prevention
    'create_shared_ledger',
    'setup_multi_tenant',
    'enable_cross_instance_access',
    'share_registries',
    'pool_resources',
    
    # Direct Database Access
    'connect_direct_db',
    'bypass_api_layer',
    'execute_raw_sql',
    'access_master_database',
    
    # Custom Agent Injection
    'inject_custom_agent',
    'upload_agent_code',
    'modify_agent_factory',
    'bypass_agent_validation',
    
    # Revenue-Driven Behavior
    'enable_revenue_features',
    'modify_behavior_for_tier',
    'disable_features_for_payment',
    'block_for_billing',
    
    # Security & Isolation
    'disable_isolation',
    'bypass_instance_boundary',
    'access_other_instances',
    'export_master_secrets'
}
```

### 3.2 Block Reasons

Each forbidden operation has a specific reason code:

| Reason | Operations | Description |
|--------|-----------|-------------|
| GOVERNOR_MODIFICATION | modify_governor* | Cannot modify Governor logic |
| AUTHORITY_OVERRIDE | override_authority*, modify_permission* | Cannot override authority rules |
| EVOLUTION_TRIGGER | trigger_evolution*, upgrade_phase* | Cannot trigger self-evolution |
| MASTER_ACCESS | access_master* | Cannot access master resources |
| CROSS_INSTANCE | access_other_instances, enable_cross* | Cannot cross instance boundaries |
| ISOLATION_BREACH | disable_isolation, bypass_* | Cannot breach isolation |
| SECURITY_VIOLATION | inject_*, upload_agent* | Security constraint violation |

### 3.3 Enforcement Mechanism

```python
class ForbiddenGates:
    def check_operation(self, operation: str) -> BlockResult:
        if operation in self.FORBIDDEN_OPERATIONS:
            reason = self._determine_block_reason(operation)
            raise ForbiddenOperationError(
                operation=operation,
                reason=reason,
                description=self._get_block_description(operation, reason)
            )
        return BlockResult(blocked=False)
```

---

## 4. License-Gated Operations (Layer 2)

### 4.1 Operation-to-Features Mapping

```python
LICENSED_OPERATIONS = {
    'export_audit': {'audit_export'},
    'view_analytics': {'analytics_dashboard'},
    'create_custom_factory': {'custom_factories'},
    'access_advanced_factories': {'asset_factory_advanced'},
    'sso_authentication': {'sso_integration'},
    'generate_compliance_report': {'compliance_reports'},
}
```

### 4.2 Feature Checking

```python
def check_licensed_operation(operation: str, license_info: LicenseInfo) -> bool:
    if operation not in LICENSED_OPERATIONS:
        return True  # Unlicensed operations allowed
    
    required_features = LICENSED_OPERATIONS[operation]
    license_features = set(license_info.features)
    
    if not required_features.issubset(license_features):
        missing = required_features - license_features
        raise PermissionDenied(
            f"Operation '{operation}' requires features: {missing}"
        )
    
    return True
```

### 4.3 License Validation Flow

```
Check operation
  ↓
1. Is operation licensed?
   └─ Not in LICENSED_OPERATIONS → Allow (unlicensed ops OK)
  ↓
2. Get license info
   └─ Invalid/expired → Deny
  ↓
3. Extract required features
   ↓
4. Check if all required features present in license
   └─ Missing feature → Deny with clear error
  ↓
5. Allow operation
```

---

## 5. Authority Rules (Layer 3)

### 5.1 Immutable Authority Rules

Authority rules are read-only for customer instances:

```python
class AuthorityRules:
    def __init__(self, instance_id: str, is_master: bool = False):
        self.instance_id = instance_id
        self.is_master = is_master
        self._rules = self._load_rules()
    
    def _load_rules(self) -> Dict:
        if self.is_master:
            # Master loads from source
            return self._fetch_canonical_rules()
        else:
            # Customer loads from read-only snapshot
            return self._load_snapshot_rules()
    
    def get_rule(self, rule_name: str) -> Any:
        return self._rules.get(rule_name)
    
    def modify_rule(self, rule_name: str, value: Any):
        if not self.is_master:
            raise PermissionDenied("Rules are immutable in customer instances")
        # Master can modify...
```

### 5.2 Rate Limiting Rules

```python
RATE_LIMIT_RULES = {
    'asset_creation': {
        'limit': 100,
        'window': 'per_minute'
    },
    'api_requests': {
        'limit': 1000,
        'window': 'per_minute'
    },
    'export_operations': {
        'limit': 10,
        'window': 'per_hour'
    }
}

def check_rate_limit(operation: str, operator_id: str) -> bool:
    if operation not in RATE_LIMIT_RULES:
        return True  # No limit
    
    rule = RATE_LIMIT_RULES[operation]
    current_count = get_operation_count(operator_id, operation, rule['window'])
    
    if current_count >= rule['limit']:
        raise RateLimitExceeded(
            f"Rate limit exceeded for '{operation}': {current_count}/{rule['limit']}"
        )
    
    return True
```

### 5.3 Resource Limit Rules

```python
def check_resource_limit(operation: str, license_info: LicenseInfo, 
                        current_usage: int) -> bool:
    limits = {
        'create_agent': license_info.max_concurrent_agents,
        'create_asset': license_info.max_assets,
        'create_registry': license_info.max_registries,
    }
    
    if operation not in limits:
        return True  # No limit
    
    limit = limits[operation]
    if current_usage >= limit:
        raise LimitExceeded(
            f"Resource limit exceeded for '{operation}': {current_usage}/{limit}"
        )
    
    return True
```

---

## 6. Read-Only Operations

### 6.1 Always-Allowed Operations

These operations are always allowed if instance exists:

```python
READONLY_OPERATIONS = {
    'read_own_ledger',
    'read_own_registry',
    'read_own_assets',
    'read_instance_health',
    'read_audit_logs',
    'read_license_info',
    'read_authority_rules',
    'list_own_resources',
}
```

### 6.2 No Permission Check Required

```python
def check_readonly_operation(operation: str, instance_id: str, 
                            resource_id: str) -> bool:
    if operation not in READONLY_OPERATIONS:
        return False  # Not a readonly operation
    
    # Verify resource belongs to this instance
    if not resource_belongs_to_instance(instance_id, resource_id):
        raise IsolationViolation(f"Resource does not belong to instance")
    
    return True  # Allowed
```

---

## 7. Permission Checker Implementation

### 7.1 Core Permission Check

```python
class PermissionChecker:
    def check_permission(self, operation: str, resource_id: Optional[str] = None,
                        context: Optional[Dict] = None) -> PermissionResult:
        """
        Check if an operation is permitted.
        
        Returns PermissionResult with decision and reason.
        """
        # Layer 1: Forbidden operations
        if operation in self.FORBIDDEN_OPERATIONS:
            return PermissionResult(
                allowed=False,
                reason=f"Operation '{operation}' is forbidden",
                authority_source="forbidden_list"
            )
        
        # Layer 2: Isolation check
        if resource_id and not self._resource_belongs_to_instance(resource_id):
            return PermissionResult(
                allowed=False,
                reason=f"Resource does not belong to this instance",
                authority_source="isolation_check"
            )
        
        # Layer 3: Read-only operations (always allowed)
        if operation in self.READONLY_OPERATIONS:
            return PermissionResult(
                allowed=True,
                reason="Read-only operation",
                authority_source="readonly_list"
            )
        
        # Layer 4: License validation
        try:
            license_info = self.license_manager.validate_license()
        except LicenseError as e:
            return PermissionResult(
                allowed=False,
                reason=f"License validation failed: {e}",
                authority_source="license_validation"
            )
        
        # Layer 5: Licensed operations
        if operation in self.LICENSED_OPERATIONS:
            required_features = self.LICENSED_OPERATIONS[operation]
            if required_features and not required_features.intersection(license_info.features):
                return PermissionResult(
                    allowed=False,
                    reason=f"Operation requires features: {required_features}",
                    tier=license_info.tier,
                    features=license_info.features,
                    authority_source="license_features"
                )
        
        # Layer 6: Resource limits
        if operation.startswith('exceed_'):
            if not self._check_resource_limits(operation, license_info, context):
                return PermissionResult(
                    allowed=False,
                    reason=f"Resource limit exceeded",
                    tier=license_info.tier,
                    authority_source="resource_limits"
                )
        
        # Layer 7: Authority rules
        authority_result = self._check_authority_rules(operation, resource_id, context)
        if not authority_result.allowed:
            return authority_result
        
        # All checks passed
        return PermissionResult(
            allowed=True,
            reason="All permission checks passed",
            tier=license_info.tier,
            features=license_info.features,
            authority_source="default_allow"
        )
```

---

## 8. Permission Summary API

```python
def get_permission_summary(instance_id: str) -> Dict[str, Any]:
    """Get summary of permissions for instance."""
    checker = PermissionChecker(instance_id)
    license_info = checker.license_manager.validate_license()
    
    return {
        'instance_id': instance_id,
        'tier': license_info.tier,
        'features': license_info.features,
        'limits': {
            'max_concurrent_agents': license_info.max_concurrent_agents,
            'max_assets': license_info.max_assets,
            'max_registries': license_info.max_registries
        },
        'forbidden_operations': list(checker.FORBIDDEN_OPERATIONS),
        'readonly_operations': list(checker.READONLY_OPERATIONS),
        'licensed_operations': {
            op: list(features) 
            for op, features in checker.LICENSED_OPERATIONS.items()
        }
    }
```

---

## 9. Testing

### 9.1 Forbidden Operation Tests

```python
def test_forbidden_operations():
    checker = PermissionChecker('inst_test')
    
    with pytest.raises(ForbiddenOperationError):
        checker.check_permission('modify_governor_logic')
    
    with pytest.raises(ForbiddenOperationError):
        checker.check_permission('trigger_self_evolution')
```

### 9.2 Licensed Operation Tests

```python
def test_licensed_operations():
    # Professional tier has audit_export
    prof_license = create_license('professional')
    checker = PermissionChecker('inst_test', license=prof_license)
    
    result = checker.check_permission('export_audit')
    assert result.allowed
    
    # Free tier doesn't have audit_export
    free_license = create_license('free')
    checker = PermissionChecker('inst_test', license=free_license)
    
    result = checker.check_permission('export_audit')
    assert not result.allowed
```

### 9.3 Resource Limit Tests

```python
def test_resource_limits():
    license_info = LicenseInfo(tier='free', max_agents=5)
    checker = PermissionChecker('inst_test', license=license_info)
    
    # Under limit
    result = checker.check_permission('create_agent', context={'current_usage': 4})
    assert result.allowed
    
    # At limit
    result = checker.check_permission('create_agent', context={'current_usage': 5})
    assert not result.allowed
```

### 9.4 Isolation Tests

```python
def test_isolation_checking():
    checker = PermissionChecker('inst_a')
    
    # Own resource
    result = checker.check_permission('read_own_ledger', resource_id='inst_a_ledger')
    assert result.allowed
    
    # Other instance's resource
    result = checker.check_permission('read_own_ledger', resource_id='inst_b_ledger')
    assert not result.allowed
```

---

## 10. Verification Checklist

- [ ] Forbidden operations are checked first
- [ ] Forbidden operations cannot be licensed
- [ ] License is validated before gated operations
- [ ] Resource isolation is enforced at operation level
- [ ] Read-only operations need no license
- [ ] Resource limits prevent quota overflow
- [ ] Authority rules are immutable for customers
- [ ] Permission decisions are logged
- [ ] Permission denials include clear reason
- [ ] Permission summary shows current capabilities

---

**PHASE 9 PERMISSIONS COMPLETE**
