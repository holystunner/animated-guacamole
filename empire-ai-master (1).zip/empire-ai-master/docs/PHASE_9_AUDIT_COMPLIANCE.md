# Phase 9: Audit & Compliance Framework

**Authority:** KAIZA Execution Framework  
**Status:** COMPLETE  
**Version:** 1.0  
**Date:** 2026-01-15

---

## 1. Overview

This document specifies the audit and compliance requirements for Phase 9 productization. It implements the audit subsystem enhancements and compliance verification mechanisms to ensure all operations are auditable and isolated per instance.

---

## 2. Audit Trail Requirements

### 2.1 Audit Event Structure

Every audit event must include:

```python
@dataclass
class AuditEvent:
    # Required fields
    timestamp: str                          # ISO 8601 UTC
    event_type: str                         # Enum value
    instance_id: str                        # Which instance
    operator_id: str                        # Who performed it
    action_id: str                          # Unique action ID
    request_id: str                         # Request correlation ID
    
    # Conditional fields
    resource_id: Optional[str]              # What was affected
    resource_type: Optional[str]            # Type of resource
    decision_id: Optional[str]              # If quorum decision
    
    # Details
    operation: str                          # Operation performed
    result: str                             # success/failure/denied
    reason: Optional[str]                   # Why if denied
    duration_ms: int                        # How long operation took
    metadata: Dict[str, Any]                # Additional context
    
    # Integrity
    signature: str                          # HMAC-SHA256(event, signing_key)
    previous_hash: str                      # Hash chain link
    sequence_number: int                    # Ledger sequence
```

### 2.2 Event Types

| Event Type | Triggered By | Actor | Audit Fields |
|------------|-------------|-------|--------------|
| `instance_created` | Admin | system | instance_id, tier, license_key_id |
| `instance_deleted` | Admin | system | instance_id, reason |
| `license_validated` | System | system | key_id, tier, features, result |
| `license_expired` | System | system | key_id, instance_id |
| `permission_checked` | Any operation | actor | operation, resource_id, result |
| `permission_denied` | Permission check | actor | operation, reason |
| `forbidden_operation` | Attempt | actor | operation, block_reason |
| `isolation_violation` | Query/API | system | violation_type, resource_id |
| `asset_instantiated` | Agent/Flow | actor | asset_type, factory_id, params_hash |
| `asset_destroyed` | Agent/Flow | actor | asset_id, resource_type |
| `governor_decision` | Governor | system | decision_type, affected_assets |
| `authority_rule_applied` | Governor | system | rule_id, action |
| `audit_exported` | User | actor | export_format, event_count, checksum |
| `integrity_check` | Periodic task | system | component, hash, result |
| `security_alert` | System | system | alert_type, severity, details |

### 2.3 Audit Logging Implementation

```python
class AuditLogger:
    def log_event(self, event_type: AuditEventType, 
                  instance_id: str,
                  operator_id: str,
                  action_id: str,
                  request_id: str,
                  operation: str,
                  resource_id: Optional[str] = None,
                  result: str = 'success',
                  reason: Optional[str] = None,
                  metadata: Optional[Dict] = None) -> None:
        """
        Log an audit event with automatic signing and chaining.
        """
        # Create event
        event = AuditEvent(
            timestamp=datetime.utcnow().isoformat() + 'Z',
            event_type=event_type.value,
            instance_id=instance_id,
            operator_id=operator_id,
            action_id=action_id,
            request_id=request_id,
            operation=operation,
            resource_id=resource_id,
            result=result,
            reason=reason,
            metadata=metadata or {},
            sequence_number=self._get_next_sequence(),
            previous_hash=self._get_previous_hash()
        )
        
        # Sign event
        event.signature = self._sign_event(event)
        
        # Store event
        self._store_event(event)
        
        # Async verification (hash chain)
        self._verify_chain_async()
```

---

## 3. Hash Chaining & Immutability

### 3.1 Hash Chain Formula

```
event[n].hash = SHA256(
  event[n].timestamp +
  event[n].event_type +
  event[n].instance_id +
  event[n].operator_id +
  event[n].operation +
  event[n].result +
  json.dumps(event[n].metadata) +
  event[n-1].hash
)
```

### 3.2 Verification Algorithm

```python
def verify_hash_chain(events: List[AuditEvent], 
                     since: Optional[datetime] = None) -> bool:
    """
    Verify entire hash chain is intact.
    
    Returns False if any hash or signature mismatch detected.
    """
    for i, event in enumerate(events):
        # Verify signature
        if not self._verify_signature(event):
            logger.error(f"Signature verification failed for event {i}")
            return False
        
        # Verify hash chain
        if i == 0:
            # First event: previous_hash should be GENESIS_HASH
            if event.previous_hash != GENESIS_HASH:
                logger.error(f"Genesis hash mismatch at event {i}")
                return False
        else:
            # Subsequent: previous_hash should match previous event's hash
            if event.previous_hash != events[i-1].hash:
                logger.error(f"Hash chain broken at event {i}")
                return False
        
        # Verify current event's hash
        computed_hash = self._compute_hash(event)
        if computed_hash != event.hash:
            logger.error(f"Event hash mismatch at event {i}")
            return False
    
    return True
```

### 3.3 Blockchain Anchoring

Every 1000 events, hash is anchored to blockchain:

```python
def anchor_to_blockchain(self) -> None:
    """Anchor audit trail to immutable ledger (blockchain)."""
    if self._events_count % 1000 != 0:
        return
    
    # Get latest hash
    latest_event = self._get_latest_event()
    
    # Create anchor record
    anchor_record = {
        'timestamp': datetime.utcnow().isoformat(),
        'event_hash': latest_event.hash,
        'event_sequence': self._events_count,
        'blockchain': 'ethereum-sepolia'
    }
    
    # Submit to blockchain
    tx_hash = self._submit_to_blockchain(anchor_record)
    
    # Log anchor event
    self.log_event(
        event_type=AuditEventType.AUDIT_ANCHORED,
        instance_id=self.instance_id,
        metadata={
            'tx_hash': tx_hash,
            'event_hash': latest_event.hash,
            'event_sequence': self._events_count
        }
    )
```

---

## 4. Audit Access Control

### 4.1 Read-Only Audit Access

Audit logs are read-only for all instances:

```python
class AuditReader:
    def get_events(self, instance_id: str, 
                  filters: Optional[AuditFilter] = None) -> List[AuditEvent]:
        """
        Retrieve audit events for an instance.
        
        Only events for this instance are returned.
        User must have audit:read capability.
        """
        # Verify instance ownership
        if not self._verify_instance_access(instance_id):
            raise PermissionDenied("Cannot access this instance's audit")
        
        # Apply isolation filter
        filters = filters or AuditFilter()
        filters.instance_id = instance_id  # Force instance scoping
        
        # Retrieve events
        return self._query_events(filters)
    
    def export_events(self, instance_id: str, 
                     format: str = 'json',
                     filters: Optional[AuditFilter] = None) -> str:
        """
        Export audit events.
        
        Requires 'audit_export' feature in license.
        """
        # Check permission
        checker = PermissionChecker(instance_id)
        if not checker.check_permission('export_audit'):
            raise PermissionDenied("Export not permitted")
        
        # Retrieve events with filters
        events = self.get_events(instance_id, filters)
        
        # Format for export
        if format == 'json':
            return self._format_json(events)
        elif format == 'csv':
            return self._format_csv(events)
        else:
            raise ValueError(f"Unsupported format: {format}")
```

### 4.2 Audit Filter

```python
@dataclass
class AuditFilter:
    instance_id: Optional[str] = None          # Which instance
    event_type: Optional[str] = None           # Filter by type
    operator_id: Optional[str] = None          # Filter by actor
    operation: Optional[str] = None            # Filter by operation
    result: Optional[str] = None               # success/failure/denied
    timestamp_start: Optional[datetime] = None # Date range start
    timestamp_end: Optional[datetime] = None   # Date range end
    resource_id: Optional[str] = None          # Filter by resource
    limit: int = 1000                          # Max results
    offset: int = 0                            # Pagination
```

---

## 5. Compliance Reporting

### 5.1 Compliance Report Generator

```python
class ComplianceReporter:
    def generate_soc2_report(self, instance_id: str, 
                            period_start: datetime,
                            period_end: datetime) -> Dict[str, Any]:
        """
        Generate SOC2 Type II compliance report.
        
        Covers:
        - Access control logging
        - Authorization decisions
        - Security incidents
        - Audit trail integrity
        """
        return {
            'period': {
                'start': period_start.isoformat(),
                'end': period_end.isoformat()
            },
            'access_control': {
                'total_operations': self._count_operations(instance_id, period_start, period_end),
                'authorized': self._count_by_result(instance_id, 'success', period_start, period_end),
                'denied': self._count_by_result(instance_id, 'denied', period_start, period_end),
                'failed': self._count_by_result(instance_id, 'failure', period_start, period_end),
            },
            'security_incidents': {
                'isolation_violations': self._count_by_type(instance_id, 'isolation_violation', period_start, period_end),
                'forbidden_operations': self._count_by_type(instance_id, 'forbidden_operation', period_start, period_end),
                'permission_denials': self._count_by_type(instance_id, 'permission_denied', period_start, period_end),
            },
            'audit_trail': {
                'total_events': self._count_events(instance_id, period_start, period_end),
                'integrity_verified': self._verify_chain_integrity(instance_id, period_start, period_end),
                'hash_chain_breaks': self._count_hash_chain_breaks(instance_id, period_start, period_end),
            },
            'governance': {
                'governor_decisions': self._count_by_type(instance_id, 'governor_decision', period_start, period_end),
                'authority_rules_applied': self._count_by_type(instance_id, 'authority_rule_applied', period_start, period_end),
            }
        }
    
    def generate_iso27001_report(self, instance_id: str) -> Dict[str, Any]:
        """Generate ISO 27001 compliance report."""
        # Similar structure, different metrics
        pass
```

### 5.2 Audit Trail Inspection

```python
class AuditInspector:
    def get_permission_summary(self, instance_id: str, 
                              operator_id: str,
                              days: int = 7) -> Dict[str, Any]:
        """
        Get summary of operator's permission decisions.
        
        Shows what operations were allowed/denied.
        """
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(days=days)
        
        events = self._query_events(
            instance_id=instance_id,
            operator_id=operator_id,
            event_type=['permission_checked', 'permission_denied'],
            timestamp_start=start_time,
            timestamp_end=end_time
        )
        
        allowed = sum(1 for e in events if e.result == 'success')
        denied = sum(1 for e in events if e.result == 'denied')
        
        operations = {}
        for event in events:
            op = event.operation
            if op not in operations:
                operations[op] = {'allowed': 0, 'denied': 0}
            
            if event.result == 'success':
                operations[op]['allowed'] += 1
            else:
                operations[op]['denied'] += 1
        
        return {
            'operator_id': operator_id,
            'period_days': days,
            'summary': {
                'total_operations': len(events),
                'allowed': allowed,
                'denied': denied,
                'denial_rate': denied / len(events) if events else 0
            },
            'operations': operations
        }
    
    def detect_anomalies(self, instance_id: str) -> List[Dict[str, Any]]:
        """
        Detect anomalous patterns in audit logs.
        
        Flags:
        - Unusual access patterns
        - High denial rates
        - Repeated failed attempts
        - After-hours access
        """
        anomalies = []
        
        # Check for high denial rate
        recent_events = self._get_recent_events(instance_id, hours=1)
        denial_rate = sum(1 for e in recent_events if e.result == 'denied') / len(recent_events)
        if denial_rate > 0.1:  # >10% denied
            anomalies.append({
                'type': 'high_denial_rate',
                'severity': 'warning',
                'denial_rate': denial_rate,
                'events': len(recent_events)
            })
        
        # Check for repeated failed attempts
        failures = [e for e in recent_events if e.result == 'failure']
        if len(failures) > 20:
            anomalies.append({
                'type': 'repeated_failures',
                'severity': 'warning',
                'failure_count': len(failures)
            })
        
        # Check for after-hours access (between 2 AM - 5 AM)
        unusual_times = [e for e in recent_events 
                        if datetime.fromisoformat(e.timestamp).hour in [2, 3, 4]]
        if len(unusual_times) > 5:
            anomalies.append({
                'type': 'after_hours_access',
                'severity': 'info',
                'event_count': len(unusual_times)
            })
        
        return anomalies
```

---

## 6. Instance Isolation in Audit

### 6.1 Instance-Scoped Audit Logs

Each instance has completely separate audit database:

```sql
-- Master instance
CREATE SCHEMA master_audit;
CREATE TABLE master_audit.events (
  -- Standard audit fields
);

-- Customer instance
CREATE SCHEMA inst_{instance_id}_audit;
CREATE TABLE inst_{instance_id}_audit.events (
  -- Same schema as master
);

-- Access control
GRANT SELECT ON inst_{instance_id}_audit.events TO cust_user_{instance_id};
REVOKE ALL ON master_audit.* FROM cust_user_{instance_id};
```

### 6.2 Audit Isolation Enforcement

```python
class AuditLogger:
    def __init__(self, instance_id: str):
        self.instance_id = instance_id
        self.db_path = f"data/audit/inst_{instance_id}.db"
        self._init_database()
    
    def log_event(self, event: AuditEvent):
        # Enforce instance ID in event
        if event.instance_id != self.instance_id:
            raise IsolationViolation(
                f"Event instance_id {event.instance_id} "
                f"does not match logger instance {self.instance_id}"
            )
        
        # Store in instance-specific database
        self._store_event(event)
```

---

## 7. Testing

### 7.1 Audit Logging Tests

```bash
pytest tests/audit/test_audit_logger.py -v
pytest tests/audit/test_hash_chain.py -v
pytest tests/audit/test_audit_immutability.py -v
```

### 7.2 Compliance Tests

```bash
pytest tests/compliance/test_soc2_report.py -v
pytest tests/compliance/test_iso27001_report.py -v
pytest tests/compliance/test_audit_export.py -v
```

### 7.3 Isolation Tests

```bash
pytest tests/audit/test_audit_isolation.py -v
```

### 7.4 Example Tests

```python
def test_audit_event_logging():
    logger = AuditLogger('inst_test')
    
    logger.log_event(
        event_type=AuditEventType.PERMISSION_CHECKED,
        instance_id='inst_test',
        operator_id='user_123',
        action_id='act_abc',
        request_id='req_xyz',
        operation='read_ledger',
        result='success'
    )
    
    # Retrieve and verify
    events = logger.get_events(instance_id='inst_test')
    assert len(events) == 1
    assert events[0].operation == 'read_ledger'
    assert events[0].result == 'success'

def test_hash_chain_integrity():
    logger = AuditLogger('inst_test')
    
    # Log 3 events
    for i in range(3):
        logger.log_event(...)
    
    # Verify chain
    events = logger.get_events(instance_id='inst_test')
    assert logger.verify_hash_chain(events)

def test_audit_isolation():
    logger1 = AuditLogger('inst_customer1')
    logger2 = AuditLogger('inst_customer2')
    
    # Log events to each instance
    logger1.log_event(event_for_inst1)
    logger2.log_event(event_for_inst2)
    
    # Each instance can only see their own events
    events1 = logger1.get_events('inst_customer1')
    events2 = logger2.get_events('inst_customer2')
    
    assert len(events1) == 1
    assert len(events2) == 1
    assert events1[0].instance_id == 'inst_customer1'
    assert events2[0].instance_id == 'inst_customer2'
```

---

## 8. Verification Checklist

- [ ] All operations are logged with full context
- [ ] Audit events include instance_id
- [ ] Hash chain is verified on read
- [ ] Audit logs are immutable
- [ ] Audit logs are anchored to blockchain
- [ ] Audit access is read-only
- [ ] Each instance has separate audit database
- [ ] Audit export is feature-gated
- [ ] Compliance reports can be generated
- [ ] Anomaly detection works correctly

---

**PHASE 9 AUDIT & COMPLIANCE COMPLETE**
