# Phase 5 Operator Guide

## Overview

Phase 5 Capital Engine enables Atlas Empire to autonomously manage financial operations without human intervention. This guide helps operators monitor, manage, and troubleshoot the system.

## Components Overview

### Core Components

1. **Revenue Attribution Engine** (`revenue_attribution_engine.py`)
   - Records all revenue events with asset attribution
   - Ensures every dollar is tracked to its source

2. **Cost Attribution Engine** (`cost_attribution_engine.py`)
   - Allocates costs to assets deterministically
   - Applies revenue-weighted overhead distribution

3. **Profit & Margin Calculator** (`profit_margin_calculator.py`)
   - Calculates P&L per asset and portfolio
   - Provides ROI and rolling metrics

4. **Capital Allocation Policy Engine** (`capital_allocation_policy_engine.py`)
   - Enforces allocation rules (60/30/10 split)
   - Identifies winners and underperformers

5. **Budget Enforcement Engine** (`budget_enforcement_engine.py`)
   - Enforces hard spending ceilings
   - Auto-freezes underperforming assets

6. **Financial Audit Trail** (`financial_audit_trail.py`)
   - Immutable transaction log with hash chaining
   - Enables dollar tracing and reconciliation

7. **Financial Safety Monitor** (`financial_safety_monitor.py`)
   - Runs hourly health checks
   - Triggers emergency stops on critical issues

8. **Capital Engine Daemon** (`capital_engine_daemon.py`)
   - Orchestrates all components
   - Runs daily allocation cycles

## Daily Operations

### Monitoring Dashboard

Check system status daily:

```bash
# Check daemon status
python3 -c "
from src.capital_engine_daemon import CapitalEngineDaemon
daemon = CapitalEngineDaemon()
status = daemon.get_daemon_status()
print('Daemon Status:', status['running'])
print('Last Daily Cycle:', status['last_daily_cycle'])
print('Last Health Check:', status['last_health_check'])
"

# Check budget status
python3 -c "
from src.budget_enforcement_engine import BudgetEnforcement
be = BudgetEnforcement()
status = be.get_budget_status()
print('Daily Budget Used:', status['daily']['percent_used'], '%')
print('Monthly Budget Used:', status['monthly']['percent_used'], '%')
print('Frozen Assets:', len([a for a in status['by_asset'].values() if a['status'] == 'frozen']))
"

# Run health check
python3 -c "
from src.financial_safety_monitor import FinancialSafetyMonitor
monitor = FinancialSafetyMonitor()
health = monitor.run_health_check()
print('System Healthy:', health['healthy'])
print('Alerts:', len(health['alerts']))
for alert in health['alerts']:
    print('  -', alert['severity'], ':', alert['message'])
"
```

### Key Metrics to Monitor

1. **Budget Utilization**
   - Daily spend should stay < 80% of limit
   - Monthly spend should stay < 85% of limit
   - Investigate if > 90% on any metric

2. **Asset Performance**
   - Monitor assets with negative ROI
   - Watch for assets frozen due to poor performance
   - Track winner/underperformer ratios

3. **System Health**
   - All health checks should pass
   - No critical alerts should be present
   - Ledger integrity must be verified

## Common Operations

### Viewing Budget Status

```bash
python3 -c "
from src.budget_enforcement_engine import BudgetEnforcement
import json

be = BudgetEnforcement()
status = be.get_budget_status()

print('=== BUDGET STATUS ===')
print('Daily:', status['daily']['spent_cents'], '/', status['daily']['limit_cents'], 'cents (', status['daily']['percent_used'], '%)')
print('Monthly:', status['monthly']['spent_cents'], '/', status['monthly']['limit_cents'], 'cents (', status['monthly']['percent_used'], '%)')

print('\n=== ASSET STATUS ===')
for asset_id, asset_status in status['by_asset'].items():
    print(asset_id, ':', asset_status['status'], '- Spent:', asset_status['spent_cents'], '/', asset_status['limit_cents'])
    if asset_status['status'] == 'frozen':
        print('  FROZEN until:', asset_status['freeze_until'])
"
```

### Checking Asset Profitability

```bash
python3 -c "
from src.profit_margin_calculator import ProfitMarginCalculator
from datetime import datetime, timedelta

calc = ProfitMarginCalculator()
end_date = datetime.now()
start_date = end_date - timedelta(days=30)

# Check specific asset
profit = calc.calculate_asset_profit('your_asset_id', start_date, end_date)
print('=== ASSET PROFIT ===')
print('Revenue:', profit['revenue_cents'], 'cents')
print('Cost:', profit['cost_cents'], 'cents')
print('Profit:', profit['profit_cents'], 'cents')
print('Margin:', profit['margin_percent'], '%')
print('Status:', profit['status'])

# Check portfolio
portfolio = calc.calculate_portfolio_profit(start_date, end_date)
print('\n=== PORTFOLIO ===')
print('Total Revenue:', portfolio['total_revenue_cents'], 'cents')
print('Total Cost:', portfolio['total_cost_cents'], 'cents')
print('Total Profit:', portfolio['total_profit_cents'], 'cents')
print('Portfolio Margin:', portfolio['portfolio_margin_percent'], '%')
print('Profitable Assets:', portfolio['profitable_assets'])
print('Loss Assets:', portfolio['loss_assets'])
"
```

### Manual Allocation Trigger

For testing or emergency situations:

```bash
python3 -c "
import asyncio
from src.capital_engine_daemon import CapitalEngineDaemon

async def manual_allocation():
    daemon = CapitalEngineDaemon()
    await daemon.start()
    
    # Trigger manual allocation with $10,000
    allocation = await daemon.manual_allocation(1000000)  # $10,000 in cents
    
    print('=== ALLOCATION RESULT ===')
    print('Allocation ID:', allocation['allocation_id'])
    print('Reinvest Pool:', allocation['allocation']['reinvest']['amount_cents'], 'cents')
    print('Exploratory Pool:', allocation['allocation']['exploratory']['amount_cents'], 'cents')
    print('Reserve Pool:', allocation['allocation']['reserve']['amount_cents'], 'cents')
    
    await daemon.stop()

asyncio.run(manual_allocation())
"
```

## Emergency Procedures

### Emergency Freeze

If system integrity is compromised:

```bash
python3 -c "
from src.budget_enforcement_engine import BudgetEnforcement

be = BudgetEnforcement()
be.trigger_emergency_freeze('manual_operator_intervention')

print('EMERGENCY FREEZE TRIGGERED')
print('All spending blocked')
print('Manual intervention required to resume')
"
```

### Unfreeze Asset

When an asset freeze duration expires:

```bash
python3 -c "
from src.budget_enforcement_engine import BudgetEnforcement

be = BudgetEnforcement()
success = be.unblock_spend('asset_id_to_unfreeze')

if success:
    print('Asset unfrozen successfully')
else:
    print('Asset still frozen - freeze duration not expired')
"
```

### Recovery from Ledger Corruption

If ledger integrity fails:

```bash
# 1. Stop the daemon
python3 -c "
import asyncio
from src.capital_engine_daemon import CapitalEngineDaemon

async def stop_daemon():
    daemon = CapitalEngineDaemon()
    await daemon.stop()
    print('Daemon stopped')

asyncio.run(stop_daemon())
"

# 2. Verify ledger integrity
python3 -c "
from src.universal_ledger import UniversalLedger

ledger = UniversalLedger()
integrity = ledger.verify_integrity()
print('Ledger Integrity:', integrity)

if not integrity:
    print('LEDGER CORRUPTION DETECTED')
    print('Check logs for details')
    print('Consider restoring from backup')
"
```

## Monthly Reports

### Generate Monthly P&L Report

```bash
python3 -c "
from src.financial_audit_trail import FinancialAuditTrail
from datetime import datetime

audit = FinancialAuditTrail()
now = datetime.now()
report_path = audit.export_monthly_report(now.year, now.month)

print('Monthly report generated:', report_path)

# Display summary
with open(report_path, 'r') as f:
    import json
    report = json.load(f)
    
    recon = report['reconciliation']
    print('=== MONTHLY P&L ===')
    print('Period:', report['month'])
    print('Total Revenue:', recon['total_in_cents'], 'cents')
    print('Total Cost:', recon['total_out_cents'], 'cents')
    print('Net Profit:', recon['net_cents'], 'cents')
    print('Transactions:', recon['transaction_count'])
    print('Integrity Verified:', recon['integrity_verified'])
    
    if recon['mismatches']:
        print('MISMATCHES FOUND:')
        for mismatch in recon['mismatches']:
            print('  Asset:', mismatch['asset_id'], 'Discrepancy:', mismatch['discrepancy_cents'], 'cents')
"
```

### Reconciliation Check

```bash
python3 -c "
from src.financial_audit_trail import FinancialAuditTrail
from datetime import datetime, timedelta

audit = FinancialAuditTrail()
end_date = datetime.now()
start_date = end_date - timedelta(days=30)

recon = audit.reconcile(start_date, end_date)

print('=== RECONCILIATION ===')
print('Period:', start_date.strftime('%Y-%m-%d'), 'to', end_date.strftime('%Y-%m-%d'))
print('Total In:', recon['total_in_cents'], 'cents')
print('Total Out:', recon['total_out_cents'], 'cents')
print('Net:', recon['net_cents'], 'cents')
print('Integrity:', recon['integrity_verified'])

if recon['mismatches']:
    print('MISMATCHES:')
    for mismatch in recon['mismatches']:
        print('  ', mismatch['asset_id'], ':', mismatch['discrepancy_cents'], 'cents')
else:
    print('All accounts balanced')
"
```

## Troubleshooting

### Common Issues

1. **High Budget Utilization**
   - Check for unusual spending patterns
   - Verify cost model accuracy
   - Consider adjusting allocation policy

2. **Assets Not Generating Revenue**
   - Check asset health and configuration
   - Verify revenue events are being recorded
   - Review asset performance metrics

3. **Health Check Failures**
   - Check component logs for errors
   - Verify database connectivity
   - Review recent changes or deployments

4. **Allocation Not Running**
   - Check daemon status
   - Verify configuration files
   - Review system logs

### Log Locations

- **Daemon Logs**: Check daemon output for cycle status
- **Component Logs**: Each component logs to stdout with structured JSON
- **Ledger**: All actions recorded in `data/universal_ledger.db`
- **Audit Trail**: Financial transactions in `data/financial_audit_trail.db`

### Performance Monitoring

Monitor these metrics:

```bash
# Check system performance
python3 -c "
from src.financial_safety_monitor import FinancialSafetyMonitor

monitor = FinancialSafetyMonitor()
status = monitor.get_system_status()

print('=== SYSTEM STATUS ===')
print('Uptime:', status['metrics']['system_uptime_hours'], 'hours')
print('Alerts (24h):', status['metrics']['alerts_24h'])
print('Emergency Stops (24h):', status['metrics']['emergency_stops_24h'])

print('\n=== COMPONENT STATUS ===')
for component, comp_status in status['components'].items():
    print(component, ':', comp_status['status'])
    if comp_status['status'] != 'healthy':
        print('  Details:', comp_status['details'])
"
```

## Configuration

### Key Configuration Files

1. **`config/phase5_defaults.json`** - Main Phase 5 configuration
2. **`config/cost_model.json`** - Cost rates and model
3. **`config/allocation_policy_v1.json`** - Allocation rules and thresholds

### Updating Configuration

```bash
# Example: Update daily budget limit
python3 -c "
import json

# Load current config
with open('config/phase5_defaults.json', 'r') as f:
    config = json.load(f)

# Modify values
config['daemon']['daily_cycle_hour'] = 3  # Run at 3 AM UTC

# Save updated config
with open('config/phase5_defaults.json', 'w') as f:
    json.dump(config, f, indent=2)

print('Configuration updated')
print('Restart daemon for changes to take effect')
"
```

## Best Practices

### Daily Checks
1. Review budget utilization
2. Check asset performance
3. Verify health check results
4. Review any alerts

### Weekly Reviews
1. Analyze portfolio trends
2. Review allocation effectiveness
3. Check for underperforming assets
4. Verify ledger integrity

### Monthly Tasks
1. Generate and review P&L reports
2. Run full reconciliation
3. Archive monthly data
4. Plan for next month's allocation

### Security Considerations
1. Monitor for unusual spending patterns
2. Verify all revenue is properly attributed
3. Check for duplicate transactions
4. Ensure emergency freeze procedures work

## Contact and Escalation

### When to Escalate
- Ledger integrity failures
- Emergency freeze triggers
- Unexplained budget overruns
- System unavailable > 1 hour

### Information to Collect
1. System status output
2. Health check results
3. Recent error logs
4. Steps to reproduce (if applicable)

### Recovery Procedures
1. Always verify ledger integrity before recovery
2. Use conservative defaults when in doubt
3. Document all recovery actions
4. Test system thoroughly after recovery
