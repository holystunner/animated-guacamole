# Phase 8: Controlled Self-Evolution - Documentation

## Overview

Phase 8 implements a controlled, deterministic, and reversible self-improvement mechanism for the ATLAS EMPIRE system. This enables the system to propose, evaluate, approve, and apply improvements to its decision-making, asset generation, and capital allocation logic while maintaining strict guardrails and audit trails.

## Architecture

### Core Components

1. **Evolution Proposal Framework** (`src/growth_engine.py`)
   - Generates evolution proposals based on system performance
   - Validates proposals against permitted domains
   - Detects and rejects forbidden domain mutations

2. **Evaluation Engine** (`src/evaluation_engine.py`)
   - Executes proposals in isolated sandbox environment
   - Evaluates against 6 deterministic criteria
   - Computes approval scores (0.0 - 1.0)

3. **Approval Engine** (`src/approval_engine.py`)
   - Makes approval decisions based on evaluation scores
   - Routes medium-confidence proposals to Governor review
   - Supports emergency override with proper authority

4. **Evolution Engine** (`src/evolution_engine.py`)
   - Applies approved evolutions atomically
   - Maintains semantic versioning (MAJOR.MINOR.PATCH)
   - Supports rollback to any prior version

5. **Audit Ledger** (`src/evolution_models.py`)
   - Immutable append-only ledger for all evolution events
   - Hash chain integrity verification
   - Complete lifecycle tracking

6. **Observability** (`src/evolution_observability.py`)
   - Structured logging for all evolution events
   - Metrics collection and dashboard configuration
   - Sensitive data redaction

## Evolution Domains

### Permitted Domains
- **prompt**: Prompt Templates & Instructions
- **scoring**: Scoring Heuristics & Weights
- **assets**: Asset Generation Strategies
- **tactics**: Growth Tactics & Scheduling
- **capital**: Capital Allocation Weights
- **scheduling**: Priority Scheduling & Queue Management

### Forbidden Domains (ABSOLUTE)
- **authority**: Authority Expansion
- **permissions**: Permission & Privilege Systems
- **mission**: Mission & Goals
- **ledger**: Ledger & Financial Records
- **audit**: Audit & Observability
- **agents**: Agent Self-Spawning
- **infrastructure**: Infrastructure Self-Provisioning
- **security**: Security Boundaries

## Evaluation Criteria

1. **Safety (0.30 weight)**
   - No forbidden domain mutations
   - Hard stop on any violations

2. **Determinism (0.20 weight)**
   - 5 runs with identical results
   - Variance detection

3. **Audit (0.15 weight)**
   - Complete audit trail
   - Full provenance tracking

4. **Performance (0.15 weight)**
   - < 10% latency increase
   - < 5% throughput decrease

5. **Quality (0.20 weight)**
   - Maintain or improve output quality
   - No increase in hallucinations

6. **Consistency (0.10 weight)**
   - No breaking changes
   - API compatibility

## Approval Workflow

### Automatic Approval
- Score ≥ 0.80 AND all critical criteria pass
- Applied immediately after 1-hour cooling period

### Manual Review
- Score 0.60 - 0.79 OR minor issues
- Routed to Governor for review
- 24-hour review window

### Automatic Rejection
- Score < 0.60 OR safety violations
- Immediate rejection with reason

### Emergency Override
- Requires Governor emergency authority
- Bypasses normal evaluation
- Triggers quarterly review

## Application Mechanics

1. **Pre-Application**
   - Snapshot current state
   - Verify approval validity
   - Acquire state lock

2. **Application**
   - Apply changes atomically
   - Increment version
   - Update configuration

3. **Post-Application**
   - Release state lock
   - Start monitoring window
   - Log completion

4. **Monitoring**
   - 1-hour minimum monitoring
   - Anomaly detection
   - Auto-rollback on issues

## Rollback Strategy

### Automatic Rollback
- Triggered by monitoring anomalies
- Error rate > 5%
- Latency increase > 20%
- Quality degradation

### Manual Rollback
- Governor initiated via Admin UI
- Requires rollback authority
- Immediate effect

### Rollback Process
1. Snapshot current state
2. Restore target version
3. Verify rollback success
4. Update audit ledger

## Admin UI Controls

### Dashboard Features
- Pending approvals list
- Recent proposals history
- Version history with rollback
- Real-time metrics
- Monitoring alerts

### Governor Actions
- Approve/Reject proposals
- View detailed evaluations
- Trigger manual rollback
- Emergency override
- Audit trail review

## Security Controls

### Authentication
- Governor token required
- Token validation and expiration
- IP whitelisting option

### Authorization
- Role-based permissions
- Emergency authority tracking
- Action logging

### Data Protection
- Sensitive data redaction
- Encrypted audit storage
- Secure API endpoints

## Monitoring & Alerting

### Metrics
- Proposal generation rate
- Evaluation success rate
- Approval distribution
- Application success rate
- Rollback frequency

### Alerts
- Safety violations
- Evaluation failures
- Application errors
- Rollback triggers
- Audit integrity issues

### Dashboards
- Evolution pipeline health
- Approval workflow status
- System version history
- Anomaly detection

## Testing Strategy

### Unit Tests
- Component isolation
- Deterministic behavior
- Edge case coverage

### Integration Tests
- Full pipeline flow
- API integration
- Database operations

### Failure Mode Tests
- Timeouts and errors
- Network failures
- Corruption detection
- Concurrent operations

### Security Tests
- Forbidden domain attempts
- Authorization bypass
- Data injection
- Audit manipulation

## Troubleshooting

### Common Issues

1. **Stuck Evaluation**
   - Check sandbox logs
   - Verify timeout settings
   - Review resource limits

2. **Approval Delays**
   - Check Governor availability
   - Verify notification system
   - Review queue status

3. **Application Failures**
   - Check state lock status
   - Verify approval validity
   - Review error logs

4. **Rollback Issues**
   - Verify target version exists
   - Check system state
   - Review rollback logs

### Debug Commands

```bash
# Check evolution status
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:8080/api/evolution/dashboard

# View proposal details
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:8080/api/evolution/proposals/$PROPOSAL_ID

# Trigger rollback
curl -X POST -H "Authorization: Bearer $TOKEN" \
  -d '{"target_version":"7.0.0"}' \
  http://localhost:8080/api/evolution/applications/$APP_ID/rollback

# Verify audit integrity
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:8080/api/evolution/audit/verify
```

## Best Practices

### Proposal Generation
- Start with small, incremental changes
- Provide clear rationale and expected impact
- Test in development environment first

### Evaluation
- Monitor evaluation metrics closely
- Review failed evaluations for patterns
- Adjust criteria weights as needed

### Approval
- Review medium-confidence proposals carefully
- Document manual approval decisions
- Use emergency override sparingly

### Application
- Schedule evolutions during low-traffic periods
- Monitor system health post-application
- Keep rollback plans ready

## Compliance & Governance

### Audit Requirements
- All actions logged with full provenance
- Immutable audit trail
- Regular integrity verification
- Quarterly compliance reports

### Governance Controls
- Governor approval for manual actions
- Emergency override tracking
- Forbidden domain enforcement
- Change management procedures

### Reporting
- Monthly evolution summaries
- Quarterly compliance reports
- Annual governance review
- Incident reports for failures

## Future Enhancements

### Planned Features
- Multi-environment support
- A/B testing framework
- Automated proposal generation
- ML-based evaluation

### Considerations
- Distributed evolution coordination
- Cross-system evolution
- Evolution composition
- Performance optimization

## References

- [Phase 8 Executable Plan](/docs/plans/PHASE_8_SELF_EVOLUTION_EXECUTABLE.md)
- [Admin UI Guide](/docs/ADMIN_UI_GUIDE.md)
- [Governance Guide](/docs/GOVERNANCE_GUIDE.md)
- [Observability Schema](/observability/logging_schema.md)
