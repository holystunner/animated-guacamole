#!/bin/bash

# Empire AI Diagram Generation Script
# This script generates rendered diagrams from source files
# Supports Mermaid, PlantUML, and Draw.io diagrams

set -e

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="$(dirname "$SCRIPT_DIR")/source"
RENDERED_DIR="$(dirname "$SCRIPT_DIR")/rendered"
LOG_FILE="$SCRIPT_DIR/diagram-generation.log"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging function
log() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1" | tee -a "$LOG_FILE"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1" | tee -a "$LOG_FILE"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1" | tee -a "$LOG_FILE"
}

# Check if required tools are installed
check_dependencies() {
    log "Checking dependencies..."
    
    # Check for Mermaid CLI
    if command -v mmdc &> /dev/null; then
        log_success "Mermaid CLI found"
    else
        log_error "Mermaid CLI not found. Install with: npm install -g @mermaid-js/mermaid-cli"
        exit 1
    fi
    
    # Check for PlantUML (requires Java)
    if command -v java &> /dev/null; then
        if [ -f "$SCRIPT_DIR/plantuml.jar" ]; then
            log_success "PlantUML found"
        else
            log_warning "PlantUML JAR not found. Downloading..."
            curl -L "https://github.com/plantuml/plantuml/releases/download/v1.2024.3/plantuml.jar" -o "$SCRIPT_DIR/plantuml.jar"
        fi
    else
        log_warning "Java not found. PlantUML diagrams will be skipped."
    fi
    
    # Check for Python (for validation)
    if command -v python3 &> /dev/null; then
        log_success "Python found"
    else
        log_warning "Python not found. Validation will be skipped."
    fi
}

# Create rendered directory structure
create_directories() {
    log "Creating directory structure..."
    mkdir -p "$RENDERED_DIR"/{architecture,processes,security,user-interface}
}

# Generate Mermaid diagrams
generate_mermaid() {
    log "Generating Mermaid diagrams..."
    
    find "$SOURCE_DIR" -name "*.mmd" -type f | while read -r file; do
        relative_path="${file#$SOURCE_DIR/}"
        output_file="$RENDERED_DIR/${relative_path%.mmd}.png"
        output_dir="$(dirname "$output_file")"
        
        # Create output directory if it doesn't exist
        mkdir -p "$output_dir"
        
        log "Processing: $relative_path"
        
        # Generate PNG from Mermaid
        if mmdc -i "$file" -o "$output_file" -w 1200 -H 800 -t neutral -b transparent 2>> "$LOG_FILE"; then
            log_success "Generated: $output_file"
            
            # Also generate SVG for vector graphics
            svg_file="${output_file%.png}.svg"
            if mmdc -i "$file" -o "$svg_file" -t neutral -b transparent 2>> "$LOG_FILE"; then
                log_success "Generated SVG: $svg_file"
            else
                log_warning "Failed to generate SVG: $svg_file"
            fi
        else
            log_error "Failed to generate: $output_file"
        fi
    done
}

# Generate PlantUML diagrams
generate_plantuml() {
    if ! command -v java &> /dev/null; then
        log_warning "Java not available, skipping PlantUML diagrams"
        return
    fi
    
    log "Generating PlantUML diagrams..."
    
    find "$SOURCE_DIR" -name "*.puml" -type f | while read -r file; do
        relative_path="${file#$SOURCE_DIR/}"
        output_file="$RENDERED_DIR/${relative_path%.puml}.png"
        output_dir="$(dirname "$output_file")"
        
        # Create output directory if it doesn't exist
        mkdir -p "$output_dir"
        
        log "Processing: $relative_path"
        
        # Generate PNG from PlantUML
        if java -jar "$SCRIPT_DIR/plantuml.jar" -tpng -o "$output_file" "$file" 2>> "$LOG_FILE"; then
            log_success "Generated: $output_file"
            
            # Also generate SVG
            svg_file="${output_file%.png}.svg"
            if java -jar "$SCRIPT_DIR/plantuml.jar" -tsvg -o "$svg_file" "$file" 2>> "$LOG_FILE"; then
                log_success "Generated SVG: $svg_file"
            else
                log_warning "Failed to generate SVG: $svg_file"
            fi
        else
            log_error "Failed to generate: $output_file"
        fi
    done
}

# Process Draw.io diagrams (manual process)
process_drawio() {
    log "Draw.io diagrams found - manual processing required"
    
    find "$SOURCE_DIR" -name "*.drawio" -type f | while read -r file; do
        relative_path="${file#$SOURCE_DIR/}"
        log_warning "Manual processing required for: $relative_path"
        log_warning "Open in Draw.io and export to: $RENDERED_DIR/${relative_path%.drawio}.png"
    done
}

# Validate generated diagrams
validate_diagrams() {
    if command -v python3 &> /dev/null && [ -f "$SCRIPT_DIR/validate-diagrams.py" ]; then
        log "Validating generated diagrams..."
        python3 "$SCRIPT_DIR/validate-diagrams.py" --check-rendered 2>> "$LOG_FILE"
    else
        log_warning "Validation script not available, skipping validation"
    fi
}

# Generate statistics
generate_stats() {
    log "Generating generation statistics..."
    
    total_source=$(find "$SOURCE_DIR" -name "*.mmd" -o -name "*.puml" -o -name "*.drawio" | wc -l)
    mermaid_count=$(find "$SOURCE_DIR" -name "*.mmd" | wc -l)
    plantuml_count=$(find "$SOURCE_DIR" -name "*.puml" | wc -l)
    drawio_count=$(find "$SOURCE_DIR" -name "*.drawio" | wc -l)
    
    total_rendered=$(find "$RENDERED_DIR" -name "*.png" -o -name "*.svg" | wc -l)
    png_count=$(find "$RENDERED_DIR" -name "*.png" | wc -l)
    svg_count=$(find "$RENDERED_DIR" -name "*.svg" | wc -l)
    
    echo "=== Diagram Generation Statistics ===" | tee -a "$LOG_FILE"
    echo "Source Diagrams: $total_source" | tee -a "$LOG_FILE"
    echo "  Mermaid: $mermaid_count" | tee -a "$LOG_FILE"
    echo "  PlantUML: $plantuml_count" | tee -a "$LOG_FILE"
    echo "  Draw.io: $drawio_count" | tee -a "$LOG_FILE"
    echo "" | tee -a "$LOG_FILE"
    echo "Rendered Diagrams: $total_rendered" | tee -a "$LOG_FILE"
    echo "  PNG files: $png_count" | tee -a "$LOG_FILE"
    echo "  SVG files: $svg_count" | tee -a "$LOG_FILE"
    echo "" | tee -a "$LOG_FILE"
    echo "Success rate: $(( total_rendered * 100 / total_source ))%" | tee -a "$LOG_FILE"
}

# Help function
show_help() {
    echo "Empire AI Diagram Generation Script"
    echo ""
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  --type TYPE     Generate only specific type (mermaid, plantuml, drawio)"
    echo "  --file FILE     Generate only specific file"
    echo "  --validate-only Run validation only"
    echo "  --stats-only    Show statistics only"
    echo "  --help          Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0                          # Generate all diagrams"
    echo "  $0 --type mermaid           # Generate only Mermaid diagrams"
    echo "  $0 --file system-overview.mmd # Generate specific file"
    echo "  $0 --validate-only           # Run validation only"
}

# Main execution
main() {
    local diagram_type=""
    local specific_file=""
    local validate_only=false
    local stats_only=false
    
    # Parse arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            --type)
                diagram_type="$2"
                shift 2
                ;;
            --file)
                specific_file="$2"
                shift 2
                ;;
            --validate-only)
                validate_only=true
                shift
                ;;
            --stats-only)
                stats_only=true
                shift
                ;;
            --help)
                show_help
                exit 0
                ;;
            *)
                log_error "Unknown option: $1"
                show_help
                exit 1
                ;;
        esac
    done
    
    # Initialize log
    echo "=== Empire AI Diagram Generation ===" > "$LOG_FILE"
    echo "Started: $(date)" >> "$LOG_FILE"
    
    if [ "$stats_only" = true ]; then
        generate_stats
        exit 0
    fi
    
    if [ "$validate_only" = true ]; then
        validate_diagrams
        exit 0
    fi
    
    log "Starting diagram generation..."
    
    # Check dependencies
    check_dependencies
    
    # Create directories
    create_directories
    
    # Generate diagrams based on type
    if [ -n "$diagram_type" ]; then
        case "$diagram_type" in
            mermaid)
                generate_mermaid
                ;;
            plantuml)
                generate_plantuml
                ;;
            drawio)
                process_drawio
                ;;
            *)
                log_error "Unknown diagram type: $diagram_type"
                exit 1
                ;;
        esac
    elif [ -n "$specific_file" ]; then
        log "Processing specific file: $specific_file"
        # Handle specific file generation
        if [[ "$specific_file" == *.mmd ]]; then
            mmdc -i "$SOURCE_DIR/$specific_file" -o "$RENDERED_DIR/${specific_file%.mmd}.png"
        elif [[ "$specific_file" == *.puml ]]; then
            java -jar "$SCRIPT_DIR/plantuml.jar" -tpng "$SOURCE_DIR/$specific_file"
        else
            log_error "Unsupported file type: $specific_file"
            exit 1
        fi
    else
        # Generate all diagrams
        generate_mermaid
        generate_plantuml
        process_drawio
    fi
    
    # Validate diagrams
    validate_diagrams
    
    # Generate statistics
    generate_stats
    
    log_success "Diagram generation completed!"
    log "Log file: $LOG_FILE"
}

# Run main function
main "$@"
