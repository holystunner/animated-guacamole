#!/usr/bin/env python3

"""
Empire AI Diagram Validation Script
Version: 1.0
Author: Documentation Team
Description: Validate diagram sources and rendered outputs
"""

import os
import sys
import json
import subprocess
import argparse
from pathlib import Path
from typing import List, Dict, Tuple
import re

class DiagramValidator:
    def __init__(self, diagrams_dir: Path):
        self.diagrams_dir = diagrams_dir
        self.source_dir = diagrams_dir / "source"
        self.rendered_dir = diagrams_dir / "rendered"
        self.errors = []
        self.warnings = []
        
    def log_error(self, message: str):
        self.errors.append(message)
        print(f"❌ ERROR: {message}")
        
    def log_warning(self, message: str):
        self.warnings.append(message)
        print(f"⚠️  WARNING: {message}")
        
    def log_info(self, message: str):
        print(f"ℹ️  INFO: {message}")
        
    def log_success(self, message: str):
        print(f"✅ SUCCESS: {message}")

    def validate_mermaid_syntax(self, file_path: Path) -> bool:
        """Validate Mermaid diagram syntax"""
        try:
            # Try to render with Mermaid CLI
            result = subprocess.run(
                ["mmdc", "-i", str(file_path), "-o", "/tmp/test.png"],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode == 0:
                self.log_success(f"Valid Mermaid syntax: {file_path.name}")
                return True
            else:
                self.log_error(f"Invalid Mermaid syntax in {file_path.name}: {result.stderr}")
                return False
                
        except subprocess.TimeoutExpired:
            self.log_error(f"Mermaid validation timeout for {file_path.name}")
            return False
        except FileNotFoundError:
            self.log_warning("Mermaid CLI not found, skipping syntax validation")
            return True  # Not a failure, just can't validate

    def validate_plantuml_syntax(self, file_path: Path) -> bool:
        """Validate PlantUML diagram syntax"""
        plantuml_jar = self.diagrams_dir / "tools" / "plantuml.jar"
        
        if not plantuml_jar.exists():
            self.log_warning("PlantUML JAR not found, skipping PlantUML validation")
            return True
            
        try:
            result = subprocess.run(
                ["java", "-jar", str(plantuml_jar), "-checksyntax", str(file_path)],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode == 0:
                self.log_success(f"Valid PlantUML syntax: {file_path.name}")
                return True
            else:
                self.log_error(f"Invalid PlantUML syntax in {file_path.name}: {result.stderr}")
                return False
                
        except subprocess.TimeoutExpired:
            self.log_error(f"PlantUML validation timeout for {file_path.name}")
            return False
        except FileNotFoundError:
            self.log_warning("Java not found, skipping PlantUML validation")
            return True

    def validate_metadata(self, file_path: Path) -> bool:
        """Validate diagram metadata"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Check for required metadata fields
            required_fields = ["%% Title:", "%% Description:", "%% Author:", "%% Created:", "%% Version:"]
            missing_fields = []
            
            for field in required_fields:
                if field not in content:
                    missing_fields.append(field)
            
            if missing_fields:
                self.log_error(f"Missing metadata in {file_path.name}: {', '.join(missing_fields)}")
                return False
            
            self.log_success(f"Metadata validation passed: {file_path.name}")
            return True
            
        except Exception as e:
            self.log_error(f"Error reading {file_path.name}: {str(e)}")
            return False

    def validate_naming_conventions(self, file_path: Path) -> bool:
        """Validate file naming conventions"""
        name = file_path.stem
        
        # Check kebab-case naming
        if not re.match(r'^[a-z0-9]+(-[a-z0-9]+)*$', name):
            self.log_error(f"Invalid naming convention: {file_path.name} (should be kebab-case)")
            return False
        
        self.log_success(f"Naming convention valid: {file_path.name}")
        return True

    def validate_rendered_files(self) -> bool:
        """Validate that rendered files exist and are not empty"""
        if not self.rendered_dir.exists():
            self.log_error("Rendered directory does not exist")
            return False
        
        success = True
        source_files = list(self.source_dir.rglob("*.mmd")) + list(self.source_dir.rglob("*.puml"))
        
        for source_file in source_files:
            rendered_file = self.rendered_dir / source_file.relative_to(self.source_dir).with_suffix(".png")
            
            if not rendered_file.exists():
                self.log_warning(f"Rendered file missing: {rendered_file.relative_to(self.rendered_dir)}")
                success = False
            elif rendered_file.stat().st_size == 0:
                self.log_error(f"Rendered file is empty: {rendered_file.relative_to(self.rendered_dir)}")
                success = False
            else:
                self.log_success(f"Rendered file valid: {rendered_file.relative_to(self.rendered_dir)}")
        
        return success

    def check_references(self) -> bool:
        """Check for broken references in documentation"""
        docs_dir = self.diagrams_dir.parent
        broken_refs = []
        
        for markdown_file in docs_dir.rglob("*.md"):
            try:
                with open(markdown_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Find diagram references
                diagram_refs = re.findall(r'\!\[.*?\]\([^)]*diagrams/[^)]+\)', content)
                
                for ref in diagram_refs:
                    # Extract path from reference
                    match = re.search(r'\(([^)]+diagrams/[^)]+)\)', ref)
                    if match:
                        ref_path = match.group(1)
                        # Remove .md or .html extension if present
                        ref_path = re.sub(r'\.(md|html)$', '', ref_path)
                        
                        full_path = docs_dir / ref_path
                        
                        if not full_path.exists():
                            broken_refs.append(f"{markdown_file.relative_to(docs_dir)} -> {ref_path}")
                
            except Exception as e:
                self.log_warning(f"Error checking references in {markdown_file.name}: {str(e)}")
        
        if broken_refs:
            for ref in broken_refs:
                self.log_error(f"Broken reference: {ref}")
            return False
        else:
            self.log_success("No broken diagram references found")
            return True

    def check_standards_compliance(self) -> bool:
        """Check compliance with diagram standards"""
        success = True
        
        # Check for required directories
        required_dirs = ["source", "rendered", "tools"]
        for dir_name in required_dirs:
            dir_path = self.diagrams_dir / dir_name
            if not dir_path.exists():
                self.log_error(f"Required directory missing: {dir_name}")
                success = False
            else:
                self.log_success(f"Required directory exists: {dir_name}")
        
        # Check for required tools
        required_tools = ["generate-diagrams.sh", "validate-diagrams.py"]
        for tool_name in required_tools:
            tool_path = self.diagrams_dir / "tools" / tool_name
            if not tool_path.exists():
                self.log_error(f"Required tool missing: {tool_name}")
                success = False
            else:
                self.log_success(f"Required tool exists: {tool_name}")
        
        return success

    def validate_all(self, check_rendered: bool = False, check_references: bool = False, check_standards: bool = False) -> bool:
        """Run all validation checks"""
        self.log_info("Starting diagram validation...")
        
        success = True
        
        # Validate source files
        if self.source_dir.exists():
            for file_path in self.source_dir.rglob("*.mmd"):
                success &= self.validate_metadata(file_path)
                success &= self.validate_naming_conventions(file_path)
                success &= self.validate_mermaid_syntax(file_path)
            
            for file_path in self.source_dir.rglob("*.puml"):
                success &= self.validate_metadata(file_path)
                success &= self.validate_naming_conventions(file_path)
                success &= self.validate_plantuml_syntax(file_path)
        else:
            self.log_error("Source directory does not exist")
            success = False
        
        # Additional checks
        if check_rendered:
            success &= self.validate_rendered_files()
        
        if check_references:
            success &= self.check_references()
        
        if check_standards:
            success &= self.check_standards_compliance()
        
        return success

    def print_summary(self):
        """Print validation summary"""
        print("\n" + "="*50)
        print("VALIDATION SUMMARY")
        print("="*50)
        
        if self.errors:
            print(f"\n❌ ERRORS ({len(self.errors)}):")
            for error in self.errors:
                print(f"  • {error}")
        
        if self.warnings:
            print(f"\n⚠️  WARNINGS ({len(self.warnings)}):")
            for warning in self.warnings:
                print(f"  • {warning}")
        
        if not self.errors and not self.warnings:
            print("\n✅ All validations passed!")
        elif not self.errors:
            print(f"\n⚠️  All validations passed with {len(self.warnings)} warnings")
        else:
            print(f"\n❌ Validation failed with {len(self.errors)} errors and {len(self.warnings)} warnings")
        
        print("="*50)

def main():
    parser = argparse.ArgumentParser(description="Validate Empire AI diagrams")
    parser.add_argument("--file", help="Validate specific file")
    parser.add_argument("--check-rendered", action="store_true", help="Check rendered files")
    parser.add_argument("--check-references", action="store_true", help="Check diagram references")
    parser.add_argument("--check-standards", action="store_true", help="Check standards compliance")
    parser.add_argument("--full", action="store_true", help="Run all validation checks")
    
    args = parser.parse_args()
    
    # Determine diagrams directory
    script_dir = Path(__file__).parent
    diagrams_dir = script_dir.parent
    
    validator = DiagramValidator(diagrams_dir)
    
    success = True
    
    if args.file:
        # Validate specific file
        file_path = diagrams_dir / "source" / args.file
        if file_path.exists():
            if file_path.suffix == ".mmd":
                success &= validator.validate_metadata(file_path)
                success &= validator.validate_naming_conventions(file_path)
                success &= validator.validate_mermaid_syntax(file_path)
            elif file_path.suffix == ".puml":
                success &= validator.validate_metadata(file_path)
                success &= validator.validate_naming_conventions(file_path)
                success &= validator.validate_plantuml_syntax(file_path)
            else:
                validator.log_error(f"Unsupported file type: {file_path.suffix}")
                success = False
        else:
            validator.log_error(f"File not found: {args.file}")
            success = False
    else:
        # Run validation based on arguments
        success = validator.validate_all(
            check_rendered=args.check_rendered,
            check_references=args.check_references,
            check_standards=args.check_standards
        )
        
        if args.full:
            success = validator.validate_all(
                check_rendered=True,
                check_references=True,
                check_standards=True
            )
    
    # Print summary
    validator.print_summary()
    
    # Exit with appropriate code
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()
