# Diagram System

**Version**: 1.0  
**Last Updated**: 2026-01-21  
**Owner**: Documentation Team  

## Overview

This directory contains all system diagrams for Empire AI documentation, organized with both source files and rendered artifacts. Each diagram includes editable source code and a rendered output for immediate use in documentation.

## Directory Structure

```
docs/diagrams/
├── README.md                    # This file - diagram system overview
├── source/                      # Editable diagram source files
│   ├── architecture/            # System architecture diagrams
│   │   ├── system-overview.mmd  # Mermaid source for system overview
│   │   ├── microservices.mmd    # Microservices architecture
│   │   └── data-flow.mmd        # Data flow diagrams
│   ├── processes/               # Process and workflow diagrams
│   │   ├── agent-workflow.mmd    # Agent decision workflows
│   │   ├── governance-flow.mmd  # Governance processes
│   │   └── deployment-flow.mmd  # Deployment procedures
│   ├── security/                # Security and compliance diagrams
│   │   ├── threat-model.mmd      # Security threat model
│   │   ├── audit-flow.mmd        # Audit logging flow
│   │   └── compliance.mmd        # Compliance framework
│   └── user-interface/           # UI and interaction diagrams
│       ├── dashboard-layout.mmd  # Dashboard layout
│       ├── user-journey.mmd      # User interaction flows
│       └── emergency-controls.mmd # Emergency procedures
├── rendered/                    # Rendered diagram outputs
│   ├── architecture/            # PNG/SVG rendered architecture diagrams
│   ├── processes/               # Rendered process diagrams
│   ├── security/                # Rendered security diagrams
│   └── user-interface/           # Rendered UI diagrams
├── tools/                       # Diagram generation tools and scripts
│   ├── generate-diagrams.sh     # Script to regenerate all diagrams
│   ├── validate-diagrams.py     # Validation script for diagram sources
│   └── requirements.txt         # Python dependencies for diagram tools
└── conventions.md               # Diagram creation conventions and standards
```

## Supported Diagram Types

### Mermaid Diagrams
- **Flowcharts**: Process flows and decision trees
- **Sequence Diagrams**: Interactions between components
- **Class Diagrams**: System architecture and relationships
- **State Diagrams**: Component state transitions
- **Entity Relationship Diagrams**: Data models and relationships

### PlantUML Diagrams
- **Component Diagrams**: System component breakdown
- **Deployment Diagrams**: Infrastructure and deployment
- **Use Case Diagrams**: User interactions and requirements
- **Activity Diagrams**: Business process flows

### Draw.io Diagrams
- **Complex Architecture**: Detailed system architecture
- **Network Diagrams**: Infrastructure and network topology
- **Custom Diagrams**: Specialized diagram types

## Diagram Creation Workflow

### 1. Create Source Diagram
1. Choose appropriate diagram type (Mermaid, PlantUML, Draw.io)
2. Create source file in appropriate `source/` subdirectory
3. Follow naming convention: `diagram-name.extension`
4. Include proper metadata and documentation

### 2. Generate Rendered Output
```bash
# Generate all diagrams
./tools/generate-diagrams.sh

# Generate specific diagram type
./tools/generate-diagrams.sh --type mermaid
./tools/generate-diagrams.sh --type plantuml
./tools/generate-diagrams.sh --type drawio

# Generate specific diagram
./tools/generate-diagrams.sh --file system-overview.mmd
```

### 3. Validate Diagrams
```bash
# Validate all diagram sources
python tools/validate-diagrams.py

# Validate specific diagram
python tools/validate-diagrams.py --file source/architecture/system-overview.mmd
```

### 4. Update Documentation
Reference rendered diagrams in documentation:
```markdown
![System Architecture](../diagrams/rendered/architecture/system-overview.png)
```

## Diagram Standards and Conventions

### File Naming
- **Format**: `kebab-case.extension`
- **Descriptive**: Names should clearly indicate diagram content
- **Consistent**: Use consistent naming across related diagrams
- **Versioned**: Include version number for major changes

### Content Standards
- **Clear Labels**: All components and connections clearly labeled
- **Consistent Colors**: Use consistent color scheme across diagrams
- **Readable Text**: Ensure text is readable at intended size
- **Logical Flow**: Information flows logically from left to right or top to bottom

### Metadata Requirements
Each diagram source must include:
```mermaid
%% Title: System Overview Architecture
%% Description: High-level architecture of Empire AI system
%% Author: Architecture Team
%% Created: 2026-01-21
%% Version: 1.0
%% Tags: architecture, overview, system
```

### Color Scheme
- **Blue (#007bff)**: Core system components
- **Green (#28a745)**: Data stores and databases
- **Orange (#fd7e14)**: External services and APIs
- **Red (#dc3545)**: Security and compliance components
- **Purple (#6f42c1)**: User interface and client components
- **Gray (#6c757d)**: Infrastructure and networking

## Tooling and Dependencies

### Required Tools
- **Mermaid CLI**: `npm install -g @mermaid-js/mermaid-cli`
- **PlantUML**: Java-based PlantUML installation
- **Draw.io**: Draw.io desktop application or web interface
- **Python 3.8+**: For validation and automation scripts

### Installation
```bash
# Install Mermaid CLI
npm install -g @mermaid-js/mermaid-cli

# Install PlantUML (requires Java)
curl -L https://github.com/plantuml/plantuml/releases/download/v1.2024.3/plantuml.jar -o plantuml.jar

# Install Python dependencies
pip install -r tools/requirements.txt
```

### Automation Scripts
- **generate-diagrams.sh**: Batch diagram generation
- **validate-diagrams.py**: Diagram source validation
- **update-references.py**: Update diagram references in documentation

## Quality Assurance

### Validation Checks
- **Syntax Validation**: Ensure diagram syntax is correct
- **Rendering Success**: Verify diagrams render without errors
- **File Size**: Check rendered images are appropriately sized
- **Link Validation**: Verify internal links and references work

### Review Process
1. **Technical Review**: Verify technical accuracy
2. **Visual Review**: Ensure clarity and readability
3. **Consistency Review**: Check adherence to standards
4. **Documentation Review**: Verify proper metadata and references

### Automated Checks
```bash
# Run full validation suite
python tools/validate-diagrams.py --full

# Check for broken references
python tools/validate-diagrams.py --check-references

# Verify diagram standards compliance
python tools/validate-diagrams.py --check-standards
```

## Maintenance and Updates

### Regular Maintenance
- **Monthly Review**: Review all diagrams for accuracy
- **Version Updates**: Update diagrams when system changes
- **Standards Updates**: Keep conventions current with system evolution
- **Tool Updates**: Maintain up-to-date diagram generation tools

### Update Process
1. **Identify Changes**: Determine which diagrams need updates
2. **Update Sources**: Modify source files with changes
3. **Regenerate**: Re-render affected diagrams
4. **Validate**: Run validation checks
5. **Update Documentation**: Update references in documentation
6. **Commit Changes**: Commit both source and rendered files

### Version Control
- **Source Files**: Tracked in version control
- **Rendered Files**: Generated files can be tracked or excluded based on workflow
- **Change History**: Maintain change history in diagram metadata
- **Backup**: Keep backup of previous diagram versions

## Integration with Documentation

### Markdown Integration
```markdown
### System Architecture

![System Architecture](../diagrams/rendered/architecture/system-overview.png)

*Figure 1: High-level system architecture showing core components and data flow*

For detailed component information, see [Architecture Documentation](../v1/development/architecture.md).
```

### HTML Integration
```html
<figure>
  <img src="../diagrams/rendered/architecture/system-overview.png" 
       alt="System Architecture Diagram" 
       width="800">
  <figcaption>Figure 1: High-level system architecture</figcaption>
</figure>
```

### PDF Integration
Diagrams are automatically included in PDF generation through standard markdown-to-PDF conversion tools.

## Troubleshooting

### Common Issues

#### Rendering Failures
```bash
# Check Mermaid syntax
mmdc -i source/architecture/system-overview.mmd

# Check PlantUML syntax
java -jar plantuml.jar source/architecture/system-overview.puml
```

#### Image Quality Issues
- Increase resolution: `mmdc -i input.mmd -o output.png -w 1200 -H 800`
- Check font rendering: Ensure system fonts are available
- Verify color scheme: Use defined color palette

#### File Size Issues
- Optimize PNG files: Use `optipng` or `pngcrush`
- Consider SVG format for vector graphics
- Compress images: Use appropriate compression settings

### Getting Help
- **Documentation**: Check tool-specific documentation
- **Community**: Join diagram tool communities for support
- **Internal**: Contact documentation team for Empire AI specific guidance

---

**Next Steps**: [Diagram Conventions](conventions.md) | [Generate All Diagrams](../tools/generate-diagrams.sh)
