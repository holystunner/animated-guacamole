# EMPIRE AI — MASTER ROADMAP

## Vision

Empire AI is an autonomous portfolio engine: a self-operating system that builds digital assets (sites, tools, content networks, data products), measures their performance, allocates capital dynamically, scales winners, and kills losers—all with complete auditability.

**Human role:** Strategic steering and exception approvals only. Operations are fully automated.

---

## Phase 0: Foundation & Reality Lock (Auditability)

**Goal:** Make the system incapable of hiding failures. Every action is logged, deterministic, and reversible.

### Core Deliverables

**1. Repository & Build Discipline**
- Monorepo structure (services + libs + infra)
- Strict lint → build → test gates
- Deterministic configs (no env surprises)
- "Reality Lock" policy: zero stubs, mocks, TODOs, or placeholder returns

**2. Event Ledger (Immutable Audit Trail)**
- Single canonical append-only log capturing:
  - Every agent decision
  - Every tool call and its result
  - Every external action (deploy, payment, API call)
  - Every asset change
- Immutable storage with hash chain for tamper evidence

**3. Core Data Model (Schemas)**
- **Asset:** A thing that earns or learns (site, tool, content stream)
- **Agent:** A worker with specific permissions and constraints
- **Job:** A unit of work (scout, build, publish, measure, scale)
- **Run:** One execution of a job (with inputs, outputs, metrics)
- **Metric:** Measured outcome (views, revenue, error rate)
- **Decision:** Why something happened (linked to approvals, policies, rules)

**4. Identity & Access Control**
- Admin-only auth (Phase 0 assumption)
- Secrets vault strategy (local first, then hardened)
- Per-agent permission model (defined in Phase 2)

### Success Criteria (Gates)

- ✓ You can deterministically replay any run from logs and get identical results
- ✓ No silent failures. Every tool call result is recorded.
- ✓ Every action has: actor + reason + input + output + timestamp
- ✓ Zero unattributable events

---

## Phase 1: Empire OS Core (Governor + Runtime + Registry)

**Goal:** Build the operating system. The system can safely schedule, execute, and track jobs at scale.

### 1. Governor (Decision Engine + Policy Enforcement)

**Responsibilities:**
- Prioritize what jobs run and when
- Enforce budget limits (money, compute, API calls)
- Apply policy rules (compliance, safety, rate limits)
- Score risk and gate approvals
- Provide emergency freeze/kill-switch

**Deliverables:**
- Policy rules engine (if X, then block/warn/approve)
- Approval queue (holds risky decisions pending review)
- Budget manager per-agent, per-asset, per-day
- Risk scoring system

### 2. Runtime (Execution Engine)

**Responsibilities:**
- Execute jobs reliably with retries
- Checkpoint at step-level for safe resume
- Guarantee idempotency (safe to rerun)
- Manage tool adapters (web fetch, git ops, deploy, analytics)

**Deliverables:**
- Job runner with queue
- Step runner (each job is a sequence of steps)
- Standard job interface (inputs → steps → outputs)
- Failure taxonomy (network, permission, timeout, invalid data, etc.)
- Retry logic with exponential backoff

### 3. Registry (System Memory)

**Purpose:** Single source of truth for all configuration and state.

**Holds:**
- Asset catalog (all live and archived assets)
- Agent catalog (all available agents and permissions)
- Configuration database (versioned, immutable snapshots)
- Secrets references (not secrets themselves)
- Current health state
- Portfolio allocation state

**Deliverables:**
- Postgres schema for registry
- Versioned config snapshots
- Asset lifecycle states: draft → active → scaling → paused → retired
- Asset metadata (owner, ROI, last updated, risk score)

### 4. Observability (Admin Console)

**Purpose:** See the entire system without digging into logs.

**Core Screens:**
- **Dashboard:** Running jobs, queue depth, system health
- **Job History:** Status, duration, inputs/outputs, metrics
- **Failure Log:** Errors by type and frequency
- **Approvals Queue:** Pending decisions awaiting human judgment
- **Budget Status:** Spend vs. limit by agent, asset, day
- **Asset Catalog:** Full list with health and performance

**Key Features:**
- One-click system freeze (emergency stop)
- Disable individual agents without cascading failures
- Each job shows: input → steps → output → metrics → full audit trail

### Success Criteria (Gates)

- ✓ System can be paused/frozen instantly
- ✓ Any agent or asset can be disabled independently
- ✓ All job execution is observable in real time
- ✓ Budget enforcement is in effect (no spending outside limits)

---

## Phase 2: Agent Economy (Specialized Labor)

**Goal:** Populate the system with specialized agents, each with narrow permissions and clear responsibilities.

### Agent Types

| Agent | Purpose | Permissions |
|-------|---------|-------------|
| **Scout** | Find opportunities (keywords, niches, products, gaps) | Read web, read registry, propose jobs |
| **Builder** | Generate code, integrate templates, deploy code | Build, deploy, commit to repos |
| **Writer** | Generate/rewrite content, metadata, variants | Write to docs, create assets, publish drafts |
| **QA/Verifier** | Validate claims, check compliance, verify structure | Read all assets, flag violations, approve publishing |
| **Growth** | Run optimization: links, CTR, internal SEO, experiments | Update live assets, A/B test, minor changes |
| **Finance** | Forecast ROI, recommend budget shifts, kill candidates | Read analytics, propose budget changes |
| **Compliance** | Enforce affiliate rules, disclosures, forbidden content | Block violating assets, flag issues |

### Permission Model

Each agent has a permission envelope:
- **Tools allowed** (which APIs and functions they can call)
- **Budget ceiling** (max $ and compute per period)
- **Asset domains** (which asset categories they touch)
- **Actions** (read / write / deploy / pay / kill)

**Hard rule:** No agent can escalate its own permissions. Only Governor via explicit approval.

### Gates

- ✓ Agents cannot publish without QA/Verifier sign-off
- ✓ Agents cannot spend outside their budget envelope
- ✓ No agent has permissions to disable another agent
- ✓ All agent actions are traceable in the ledger

---

## Phase 3: Asset Factory (Rapid Production)

**Goal:** The system can reliably generate, test, and launch new revenue-generating assets at scale.

### Asset Types (Initial)

1. **Content Clusters** (blog + product roundups + affiliate links)
   - Scout finds high-intent keywords
   - Writer generates article + product tables
   - Builder sets up domain + hosting
   - Growth hooks it into internal link network

2. **Tool/Utility Sites** (calculators, comparators)
   - One-page utilities with affiliate or adsense revenue
   - Builder generates from templates
   - Growth drives traffic via SEO

3. **Lead Gen Pages** (email capture → nurture)
   - Compliance verifies disclosures
   - Growth optimizes conversion

### Factory Workflow

1. **Scout** proposes asset class (keyword research)
2. **Finance** estimates ROI
3. **Builder** generates code/content
4. **QA/Verifier** checks quality and compliance
5. **Growth** seeds initial traffic (internal links, promotion)
6. **System** measures: views, clicks, revenue, cost
7. **Finance** decides: scale, pause, or kill

### Success Criteria (Gates)

- ✓ System can launch a new asset (from Scout proposal to live) in < 48 hours
- ✓ Every asset has defined success metrics before launch
- ✓ Failed assets are retired and removed from compute allocation
- ✓ Cost per asset is tracked and attributed accurately

---

## Phase 4: Autonomous Scaling & Iteration

**Goal:** Assets improve themselves continuously based on performance data.

### Scaling Mechanism

Once an asset proves profitable:
- Growth automatically:
  - Adds related keywords/content
  - Builds supporting clusters
  - Replaces dying product affiliate links
  - Optimizes meta/snippets for SERP
  - Tests new CTAs and layouts

### Operational Loop

1. **Measure:** Pull analytics daily
2. **Analyze:** Calculate ROI, identify problems
3. **Improve:** Run autonomous growth jobs
4. **Report:** Update registry with new state
5. **Decide:** Continue, scale, or kill

### Success Criteria (Gates)

- ✓ Each asset runs an autonomous growth job on schedule
- ✓ Changes are versioned and rollback-capable
- ✓ Growth actions never break compliance rules
- ✓ ROI trending up for scaled assets

---

## Phase 5: Capital Allocation Engine

**Goal:** System allocates reinvestment, budgets, and resource based on financial data.

### Financial Model

**Tracks:**
- Revenue by asset (affiliate, ads, leads, products)
- Cost by asset (compute, domain, hosting, tools)
- Profit by asset
- Portfolio margin

**Default Allocation Policy:**
- **60%** reinvest into proven winners (more assets in same class)
- **30%** allocate to R&D (new asset classes, new rails)
- **10%** reserve buffer

### Automation

- Top performers automatically receive budget increases
- Underperformers receive budget cuts
- Expansion triggers when thresholds crossed (CPU, crawl queue, etc.)
- Diversification recommendations based on portfolio concentration

### Success Criteria (Gates)

- ✓ System generates monthly P&L automatically
- ✓ Every expense is attributed to an asset or overhead
- ✓ System never exceeds spending policy
- ✓ Budget allocation correlates to asset performance

---

## Phase 6: Control Center (Admin UI v2)

**Goal:** Run the entire empire from a single dashboard.

### Core Screens

1. **Portfolio Overview**
   - Revenue, cost, profit (30/90/365 day trends)
   - Asset status counts (active, scaling, paused, retired)
   - Capital allocation status

2. **Asset Detail View**
   - Lifecycle stage
   - Performance graphs (ROI, cost, traffic)
   - Recent changes and versions
   - Kill / scale controls
   - Full audit trail

3. **Agent Activity Log**
   - What each agent did (what, when, why)
   - Pending approvals
   - Recent failures

4. **Approvals Queue**
   - Budget raises over threshold
   - New asset class requests
   - Infrastructure purchases
   - Policy exceptions

5. **Compliance Console**
   - Disclosure health
   - Flagged pages
   - Policy violations by type

6. **Audit Trail**
   - Searchable event ledger
   - Filter by agent, asset, action, date

### Success Criteria (Gates)

- ✓ Any action taken in UI appears in audit ledger
- ✓ Kill switch works instantly
- ✓ Approvals are the only human dependency left
- ✓ No logs are only accessible via CLI

---

## Phase 7: Distributed Resilience (Multi-Server)

**Goal:** Empire scales beyond a single box and survives failure.

### Deployment Tiers

1. **Start:** Single server (all-in-one)
2. **Expand:** Dedicated crawler node (crawl doesn't block build)
3. **Build:** Dedicated build node(s) (code generation parallelized)
4. **Analytics:** Dedicated analytics node (data processing isolated)
5. **Redundancy:** Failover pairs + load balancing

### Orchestration

- Jobs assigned by resource requirements
- Auto-provision when thresholds crossed (CPU, disk, queue depth)
- Auto-failover rules (jobs resume from checkpoints on new nodes)
- Cross-node state synchronization via registry

### Success Criteria (Gates)

- ✓ Losing one node doesn't stop the system
- ✓ Jobs resume from checkpoints on different nodes
- ✓ Registry is replicated and consistent
- ✓ No single point of failure for critical operations

---

## Phase 8: New Monetization Rails

**Goal:** Diversify revenue beyond affiliate/ads to compound growth.

### Revenue Rails (Priority Order)

| Rail | Model | Build Effort | Margin |
|------|-------|--------------|--------|
| **Lead Gen** | Capture leads, sell to businesses | Medium | High (40%+) |
| **Data Products** | Niche datasets, subscription model | High | High (60%+) |
| **Micro-Tools** | Small SaaS utilities, monthly subscription | Medium | High (70%+) |
| **Marketplaces** | Programmatic, long-tail, low friction | Very High | Medium (30%) |

### Integration Requirements

**New rails must plug into:**
- Registry (for catalog, pricing, configuration)
- Runtime (for job orchestration)
- Ledger (for auditability)
- Capital engine (for ROI, allocation)
- Compliance (for rules enforcement)
- Admin UI (for visibility)

**No one-off implementations allowed.**

### Success Criteria (Gates)

- ✓ New rail is integrated with core systems before first transaction
- ✓ Revenue is measurable and attributed in P&L
- ✓ No separate operations or tools for new rail
- ✓ New rail can be paused or killed via Governor

---

## Phase 9: Self-Evolution (Controlled Improvement)

**Goal:** System improves itself without mission creep or permission expansion.

### Allowed Evolution

- Better scoring models (for asset quality, ROI, risk)
- Better templates (faster/better asset generation)
- Better growth tactics (new testing frameworks)
- Better allocation rules (portfolio optimization)
- New tool integrations (when proposed and approved)

### Forbidden Evolution

- Changing authority or governance rules
- Removing auditability features
- Expanding permissions silently
- Uncontrolled self-replication or autonomous expansion
- Removing the ability to freeze or kill

### Evolution Process

1. Agent **proposes** improvement
2. System **evaluates** impact and risk
3. Human **approves** (if risky or strategic)
4. Improvement **deployed** with automatic rollback
5. **Measured** for effectiveness after 30 days

### Success Criteria (Gates)

- ✓ All self-improvements are proposed, evaluated, and logged
- ✓ Rollback is automatic if metrics regress
- ✓ Forbidden evolution is impossible (enforced in Governor)

---

## Phase 10+: Long-Term Vision

Once Phases 0-9 are complete, the system has:

- **90% asset failure rate** (expected; tight ROI gate kills non-performers)
- **10% compounding winners** (assets that scale profitably)
- **Autonomous reinvestment** (profit → new shots → more winners)
- **Minimal human involvement** (approvals only, no operations)

The empire becomes a **living portfolio** where capital compounds over time.

---

## Execution Summary

| Phase | Timeline | Key Goal | Human Effort |
|-------|----------|----------|--------------|
| 0 | Month 1 | Auditability + logging | High |
| 1 | Months 2-3 | Core OS (Governor, Runtime, Registry) | High |
| 2 | Months 4-5 | Agent economy (Scout, Builder, Writer, etc.) | Medium |
| 3 | Months 6-7 | Asset factory (rapid production) | Medium |
| 4 | Months 8+ | Autonomous scaling | Low |
| 5 | Months 9+ | Capital allocation | Low |
| 6 | Months 10+ | Admin UI v2 | Low |
| 7 | Months 12+ | Multi-server resilience | Medium |
| 8 | Months 14+ | New revenue rails | Medium |
| 9 | Months 16+ | Self-evolution | Low |

---

## Decision Points

### Approval-Gated Decisions

1. **New asset approval** (especially new classes or high-spend)
2. **Capital reallocation** (shifting > 10% of budget between assets)
3. **Infrastructure expansion** (new servers, new tools, new integrations)
4. **Policy changes** (modifying governance rules, approval thresholds)
5. **Emergency overrides** (freezing system, killing major assets)

### Automated Decisions

1. Retiring low-ROI assets
2. Scaling proven winners
3. Optimizing content within assets
4. Budget shifts under thresholds
5. Daily job scheduling

---

## Success Metrics (Overall)

- **Capital Efficiency:** Profit per dollar spent
- **Asset ROI:** (Revenue - Cost) / Cost
- **Portfolio Health:** % of assets achieving ROI > 2.0
- **Autonomy:** % of decisions made without human approval
- **Reliability:** 99.9% uptime, 0 unattributable events
- **Auditability:** 100% of actions logged and reversible
