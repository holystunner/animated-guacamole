# Port Mismatch Evidence

## UI Code (src/admin_ui_frontend/src/components/EmpireHiveUIWorking.tsx)

Hardcoded API calls to port 8008:

- Line 143: `fetch('http://localhost:8008/api/system/state')`
- Line 294: `fetch('http://localhost:8008/api/audit/events')`
- Line 410: `fetch('http://localhost:8008/api/capital/ledger')`
- Line 436: `fetch('http://localhost:8008/api/telemetry/actions/execute')`
- Line 461: `fetch('http://localhost:8008/api/telemetry/hive/cells')`
- Line 482: `fetch('http://localhost:8008/api/audit/events')`

## Infrastructure (docker-compose.full.yml)

Backend service mapped to port 8000:

```yaml
  empire-ai:
    ports:
      - "8000:8000"
```

## Production Entry Point

Nginx serves UI on port 8081:

```yaml
  nginx:
    ports:
      - "8081:8081"
```

## Conclusion

The production UI served on 8081 will attempt to fetch from 8008. The backend is listening on 8000. All API calls will fail with connection refused.
