# Phase 8: Controlled Self-Evolution - Implementation Guide

## Overview

Phase 8 introduces a controlled, deterministic, and reversible self-improvement framework to the ATLAS EMPIRE system. The system gains the capability to propose, evaluate, approve, and apply evolutions to its decision-making, asset generation, and capital allocation logic—while maintaining strict guardrails on authority, permissions, mission, and audit trails.

## Architecture

### Core Components

1. **Growth Engine** (`src/growth_engine.py`)
   - Extended with evolution proposal generation
   - Analyzes system metrics to identify optimization opportunities
   - Validates proposals against permitted/forbidden domains

2. **Evaluation Engine** (`src/evaluation_engine.py`)
   - Sandbox evaluation with isolation guarantees
   - Deterministic criteria evaluation (safety, performance, quality)
   - Computes approval scores with transparent scoring

3. **Approval Engine** (`src/approval_engine.py`)
   - Autonomous approval for high-confidence proposals (≥0.80)
   - Governor review for medium-confidence (0.60-0.80)
   - Auto-rejection for low-confidence (<0.60)
   - Emergency override support with audit trails

4. **Evolution Engine** (`src/evolution_engine.py`)
   - Atomic application of approved evolutions
   - Version management with semantic versioning
   - Instant rollback capability to any prior version
   - State locking to prevent concurrent mutations

### Database Schema

The evolution audit trail is stored in dedicated tables (`infra/migrations/008_phase8_evolution_schema.sql`):

- `evolution_proposals` - All proposed evolutions
- `evolution_evaluations` - Evaluation results and metrics
- `evolution_approvals` - Approval decisions and rationale
- `evolution_applications` - Application details and state snapshots
- `evolution_monitoring` - Post-application monitoring results
- `evolution_rollbacks` - Rollback details and triggers
- `evolution_config_versions` - Versioned configuration history
- `evolution_audit_chain` - Immutable hash chain for integrity

## Evolution Domains

### Permitted Domains

1. **Prompt Templates & Instructions**
   - Modify system prompts and context templates
   - Evaluated for output quality and determinism

2. **Scoring Heuristics & Weights**
   - Adjust asset scoring parameters and thresholds
   - Constrained within ±5% of baseline

3. **Asset Generation Strategies**
   - Refine categories, filtering rules, and tactics
   - Evaluated on diversity and quality metrics

4. **Growth Tactics & Scheduling**
   - Adjust exploration vs exploitation balance
   - Optimize resource allocation priorities

5. **Capital Allocation Weights**
   - Rebalance portfolio across risk profiles
   - Enforced diversification rules

6. **Priority Scheduling & Queue Management**
   - Optimize task scheduling and resource usage
   - Maintain fairness constraints

### Forbidden Domains (Never Evolvable)

- Authority Expansion
- Permission & Privilege Systems
- Mission & Goals
- Ledger & Financial Records
- Audit & Observability
- Agent Self-Spawning
- Infrastructure Self-Provisioning
- Security Boundaries

## Evolution Lifecycle

### 1. Proposal Generation

```python
# Analyze metrics and generate proposals
metrics = {"hallucination_rate": 0.04, "precision": 0.78}
proposals = growth_engine.generate_evolution_proposals(metrics)

# Each proposal includes:
# - Domain and description
# - Specific changes (old/new values)
# - Rationale and expected impact
# - Content hash for integrity
```

### 2. Evaluation

```python
# Evaluate in sandbox with deterministic criteria
report = evaluation_engine.evaluate_proposal(
    proposal, 
    system_state, 
    metrics_baseline
)

# Evaluation criteria:
# - Safety verification (forbidden domains)
# - Determinism check (5 runs, identical output)
# - Audit completeness
# - Performance impact (<10% latency increase)
# - Quality impact (no degradation)
# - Consistency across states
```

### 3. Approval Decision

```python
# Automatic decision based on score
decision = approval_engine.make_approval_decision(
    proposal.proposal_id,
    evaluation_report
)

# Decision paths:
# - ≥0.80: Auto-approve
# - 0.60-0.80: Governor review
# - <0.60: Auto-reject
```

### 4. Application

```python
# Atomic application with version bump
result = evolution_engine.apply_evolution(
    proposal,
    approval_decision
)

# Includes:
# - Pre/post state snapshots
# - Version increment (semantic)
# - Rollback instructions
# - Monitoring activation
```

### 5. Monitoring & Rollback

```python
# Automatic monitoring for 1 hour
# Anomaly detection triggers rollback:
# - Error rate increase >2%
# - Latency p99 increase >20%
# - Throughput decrease >10%

# Manual rollback available
rollback_result = evolution_engine.rollback_evolution(
    application_id,
    target_version="7.0.0"
)
```

## API Reference

### Growth Engine Methods

```python
# Generate evolution proposals
generate_evolution_proposals(metrics_baseline: Dict[str, float]) -> List[EvolutionProposal]

# Retrieve specific proposal
get_proposal_by_id(proposal_id: str) -> Optional[EvolutionProposal]

# List pending proposals
list_pending_proposals() -> List[EvolutionProposal]
```

### Evaluation Engine Methods

```python
# Evaluate proposal against all criteria
evaluate_proposal(
    proposal: EvolutionProposal,
    system_state: Dict[str, Any],
    metrics_baseline: Dict[str, float]
) -> Dict[str, Any]
```

### Approval Engine Methods

```python
# Make approval decision
make_approval_decision(
    proposal_id: str,
    evaluation_report: Dict[str, Any]
) -> ApprovalDecision

# Governor manual approval
governor_approve(
    proposal_id: str,
    evaluation_report: Dict[str, Any],
    governor_id: str,
    rationale: str
) -> ApprovalDecision

# Emergency override
emergency_override(
    proposal_id: str,
    evaluation_report: Dict[str, Any],
    governor_id: str,
    proposed_change: Dict[str, Any],
    rationale: str
) -> ApprovalDecision
```

### Evolution Engine Methods

```python
# Apply approved evolution
apply_evolution(
    proposal: EvolutionProposal,
    approval: ApprovalDecision,
    request_id: str = None
) -> Dict[str, Any]

# Rollback evolution
rollback_evolution(
    application_id: str,
    target_version: str = None,
    governor_id: str = None,
    request_id: str = None
) -> Dict[str, Any]

# Get version history
get_version_history() -> List[Dict[str, Any]]
```

## Observability

### Structured Events

All evolution actions emit structured logs:

```json
{
  "timestamp": "2026-01-15T10:30:45.123Z",
  "level": "info",
  "message": "evolution_proposal_generated",
  "service": "growth_engine",
  "op": "evolution.propose",
  "proposal_id": "P-12345-67890",
  "domain": "scoring",
  "proposer_id": "system",
  "request_id": "req_xyz789"
}
```

### Key Metrics

- Evolution proposal rate (proposals/hour)
- Evaluation approval rate (%)
- Application success rate (%)
- Rollback frequency (rollbacks/month)
- Time from proposal to application (minutes)

## Security Considerations

### Forbidden Domain Enforcement

- Hard-coded validation in proposal generation
- Deep scan of proposed changes for forbidden keywords
- Immediate rejection with security alert on violations

### Audit Trail Integrity

- Append-only database tables
- Cryptographic hash chaining
- Immutable records with no delete/update
- Full provenance for all decisions

### Authority Validation

- Governor authority checked before manual actions
- Emergency overrides require explicit authority
- All decisions logged with decision maker

## Testing

### Test Coverage

- Unit tests for all components (>90% coverage)
- Integration tests for full pipeline
- Failure mode tests (rollback, anomalies)
- Security tests (forbidden domains)
- Performance tests (<5 second evaluation)

### Running Tests

```bash
# Run all evolution tests
python -m pytest tests/test_phase8_evolution.py -v

# Run with coverage
python -m pytest tests/test_phase8_evolution.py --cov=src --cov-report=html
```

## Troubleshooting

### Common Issues

1. **Proposal Rejected for Forbidden Domain**
   - Check proposed_change for forbidden keywords
   - Ensure domain is in permitted list
   - Review proposal validation logs

2. **Evaluation Timeout**
   - Check sandbox isolation
   - Verify system state complexity
   - Monitor resource utilization

3. **Application Failure**
   - Check state lock availability
   - Verify atomic operation
   - Review rollback triggers

4. **Rollback Failure**
   - Verify target version exists
   - Check state consistency
   - Manual intervention may be required

### Debug Commands

```python
# Check pending proposals
proposals = growth_engine.list_pending_proposals()

# Get evaluation details
report = evaluation_engine.evaluate_proposal(proposal, state, metrics)

# Check version history
history = evolution_engine.get_version_history()

# Verify audit chain
chain = audit_log.get_evolution_chain()
```

## Governor Operations

### Admin UI Features

The Admin UI provides:

- Evolution proposal dashboard
- Evaluation results and metrics
- Approval/rejection controls
- Rollback triggers
- Full audit trail per proposal
- Emergency override interface

### Emergency Procedures

1. **Immediate Rollback**
   - Navigate to Evolution → Rollback
   - Select application to rollback
   - Confirm and execute

2. **Emergency Override**
   - Requires emergency authority
   - Bypasses normal evaluation
   - Triggers aggressive monitoring

3. **System Freeze**
   - Disable proposal generation
   - Pin current version
   - Halt all evolutions

## Migration Guide

### From Phase 7

1. Run database migration:
   ```sql
   -- Execute 008_phase8_evolution_schema.sql
   ```

2. Update configuration:
   ```python
   # Enable evolution engine
   EVOLUTION_ENABLED = True
   EVOLUTION_AUTO_APPROVE_THRESHOLD = 0.80
   ```

3. Initialize components:
   ```python
   growth_engine = GrowthEngine(registry, audit_log)
   evaluation_engine = EvaluationEngine(audit_log)
   approval_engine = ApprovalEngine(audit_log)
   evolution_engine = EvolutionEngine(audit_log)
   ```

### Configuration

```yaml
evolution:
  enabled: true
  auto_approve_threshold: 0.80
  manual_review_min: 0.60
  monitoring_window_minutes: 60
  
  domains:
    permitted:
      - prompt
      - scoring
      - assets
      - tactics
      - capital
      - scheduling
    forbidden:
      - authority
      - permissions
      - mission
      - ledger
      - audit
      - agents
      - infrastructure
      - security
```

## Best Practices

1. **Start Small**
   - Begin with low-risk scoring changes
   - Monitor impact before larger changes
   - Use manual review for complex proposals

2. **Monitor Continuously**
   - Watch post-application metrics
   - Set up alerts for anomalies
   - Review rollback frequency

3. **Maintain Audit Trail**
   - Never disable audit logging
   - Regular backup of audit tables
   - Periodic integrity verification

4. **Governance**
   - Document all manual approvals
   - Quarterly review of emergency overrides
   - Annual audit of evolution effectiveness

## Future Enhancements

- Machine learning for proposal generation
- A/B testing framework for evaluations
- Cross-system evolution federation
- Advanced anomaly detection
- Automated rollback optimization
