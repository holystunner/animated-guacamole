# Phase 5 Engineer Guide

## Overview

Phase 5 Capital Engine is a deterministic financial management system that enables Atlas Empire to autonomously handle revenue attribution, cost allocation, profit calculation, and capital distribution. This guide explains the architecture, implementation details, and how to extend or modify the system.

## System Architecture

### Core Components

```
┌─────────────────────────────────────────────────────────────────┐
│                    Capital Engine Daemon                        │
│                 (src/capital_engine_daemon.py)              │
├─────────────────────────────────────────────────────────────────┤
│  Daily Cycle:                                              │
│  1. Health Check → 2. Portfolio Metrics → 3. Allocation     │
│  4. Ledger Log → 5. Budget Update                       │
├─────────────────────────────────────────────────────────────────┤
│  Hourly Cycle:                                             │
│  1. Health Check → 2. Status Log → 3. Alert if needed     │
├─────────────────────────────────────────────────────────────────┤
│  Monthly Cycle:                                            │
│  1. Generate P&L → 2. Export Report → 3. Archive         │
└─────────────────────────────────────────────────────────────────┘
```

### Data Flow

```
Revenue Events → Revenue Attribution Engine → Universal Ledger
     ↓
Cost Events → Cost Attribution Engine → Universal Ledger
     ↓
Both → Profit Calculator → Portfolio Metrics
     ↓
Portfolio Metrics → Capital Allocation Policy → Allocation Decision
     ↓
Allocation Decision → Budget Enforcement → Spend Control
     ↓
All Events → Financial Audit Trail → Reconciliation & Reporting
```

## Component Deep Dive

### 1. Revenue Attribution Engine

**Purpose**: Immutable recording of all revenue events with asset attribution

**Key Features**:
- Deduplication by transaction_id
- Hash-chained ledger entries
- Time-windowed queries
- Multi-currency support (fixed rates)

**Implementation Details**:

```python
class RevenueAttributionEngine:
    def record_revenue_event(self, asset_id, amount_cents, currency, 
                           channel, user_id, transaction_id, timestamp):
        # 1. Validate inputs
        # 2. Check for duplicates
        # 3. Create immutable ledger entry
        # 4. Return attribution details
        
    def get_asset_revenue(self, asset_id, start, end):
        # 1. Query ledger for asset in time window
        # 2. Sum amounts by channel
        # 3. Verify ledger integrity
        # 4. Return structured results
```

**Extension Points**:
- Add new revenue channels
- Implement currency conversion
- Add revenue recognition rules
- Implement revenue forecasting

### 2. Cost Attribution Engine

**Purpose**: Deterministic cost allocation with revenue-weighted overhead distribution

**Key Features**:
- Versioned cost models
- Revenue-weighted overhead allocation
- Multiple cost types (compute, storage, crawl, build)
- Conservative fallback behavior

**Cost Model Structure**:

```json
{
  "version": 1,
  "effective_date": "2026-01-15",
  "cpu_hour_cents": 500,
  "gb_day_cents": 100,
  "request_per_1000_cents": 5,
  "crawl_minute_cents": 10,
  "build_minute_cents": 20,
  "platform_daily_overhead_cents": 5000
}
```

**Overhead Allocation Algorithm**:

```python
def allocate_daily_overhead(self, date):
    # 1. Get total revenue for all assets in period
    # 2. Get platform overhead cost
    # 3. For each asset:
    #    a. If asset has revenue: overhead * (asset_revenue / total_revenue)
    #    b. If no revenue: overhead * (asset_cost / total_cost)
    #    c. Fallback: equal distribution
    # 4. Return allocation map
```

**Extension Points**:
- Add new cost types
- Implement dynamic cost models
- Add cost optimization algorithms
- Implement predictive costing

### 3. Profit & Margin Calculator

**Purpose**: Deterministic P&L calculation with rolling metrics

**Key Features**:
- Integer arithmetic for monetary values
- Rolling window calculations (7d, 30d, 90d)
- ROI calculation with cost basis
- Status classification (profitable, breakeven, loss)

**Calculation Rules**:

```python
def calculate_asset_profit(self, asset_id, start, end):
    # 1. Get revenue for period (from revenue engine)
    # 2. Get costs for period (from cost engine)
    # 3. Calculate: profit = revenue - cost
    # 4. Calculate: margin = (profit / revenue) * 100 if revenue > 0
    # 5. Classify status based on margin thresholds
    # 6. Verify ledger integrity
    # 7. Return structured result
```

**Status Classification**:
- **profitable**: margin > 0%
- **breakeven**: -1% ≤ margin ≤ 0%
- **loss**: margin < -1%

**Extension Points**:
- Add new metrics (CAC, LTV, churn)
- Implement predictive profit modeling
- Add cohort analysis
- Implement profit optimization

### 4. Capital Allocation Policy Engine

**Purpose**: Rules-based capital distribution with winner identification

**Key Features**:
- Versioned allocation policies
- Deterministic winner/underperformer classification
- Hard ceiling enforcement
- Policy compliance auditing

**Allocation Algorithm**:

```python
def calculate_allocation(self, portfolio_metrics, available_capital):
    # 1. Classify assets:
    #    winners: ROI > 20% AND margin > 10% AND revenue > $500
    #    underperformers: ROI < -10% for >7 days
    #    losers: ROI < -30% for >14 days (auto-freeze)
    
    # 2. Calculate pools:
    #    reinvest = available_capital * 60%
    #    exploratory = available_capital * 30%
    #    reserve = available_capital * 10%
    
    # 3. Distribute to winners (proportional to ROI):
    #    weight = winner.roi / sum(all_winner_roi)
    #    allocation = reinvest_pool * weight
    
    # 4. Apply hard ceilings:
    #    daily: sum(all spend) <= $1,000/day
    #    monthly: sum(all spend) <= $20,000/month
    #    per-asset: spend <= $5,000/month per asset
    
    # 5. Verify compliance and log decision
```

**Policy Structure**:

```json
{
  "version": 1,
  "reinvest_winners_percent": 60,
  "exploratory_budget_percent": 30,
  "reserve_percent": 10,
  "winner_criteria": {
    "min_roi_percent": 20,
    "min_revenue_cents": 50000,
    "min_profit_margin_percent": 10,
    "lookback_days": 30
  },
  "hard_ceilings": {
    "daily_spend_limit_cents": 100000,
    "monthly_spend_limit_cents": 2000000,
    "per_asset_monthly_limit_cents": 500000
  }
}
```

**Extension Points**:
- Implement machine learning-based allocation
- Add risk-adjusted returns
- Implement dynamic policy adjustment
- Add portfolio optimization algorithms

### 5. Budget Enforcement Engine

**Purpose**: Hard enforcement of spending limits with automatic freezes

**Key Features**:
- Real-time spend checking
- Multi-level ceiling enforcement (daily, monthly, per-asset)
- ROI-based auto-freeze logic
- Emergency freeze capabilities

**Enforcement Logic**:

```python
def check_spend_allowed(self, asset_id, requested_spend_cents, spend_type):
    # 1. Check emergency freeze status
    # 2. Check if asset is frozen
    # 3. Check daily ceiling
    # 4. Check monthly ceiling
    # 5. Check per-asset ceiling
    # 6. Check asset has allocation
    # 7. Check ROI-based freeze conditions
    # 8. Return decision with reasoning
```

**Auto-Freeze Triggers**:
- ROI < -30% for 14+ days → 7-day freeze
- Consecutive losses > 7 days → 7-day freeze
- Daily limit exceeded → queue excess
- Ledger corruption → emergency freeze

**Extension Points**:
- Add predictive spend analysis
- Implement dynamic limit adjustment
- Add spend optimization recommendations
- Implement anomaly detection

### 6. Financial Audit Trail

**Purpose**: Immutable transaction log with hash chaining and reconciliation

**Key Features**:
- SHA-256 hash chaining
- Dollar tracing capabilities
- Monthly reconciliation
- Export functionality

**Transaction Structure**:

```python
@dataclass
class FinancialTransaction:
    transaction_id: str
    asset_id: str
    amount_cents: int
    direction: str  # "in", "out"
    category: str   # "revenue", "cost", "allocation"
    description: str
    timestamp: datetime
    metadata: Dict[str, Any]
    transaction_hash: str
    previous_hash: str
```

**Hash Chaining**:

```python
def _calculate_hash(self):
    data = {
        "transaction_id": self.transaction_id,
        "asset_id": self.asset_id,
        "amount_cents": self.amount_cents,
        "direction": self.direction,
        "category": self.category,
        "description": self.description,
        "timestamp": self.timestamp.isoformat(),
        "metadata": self.metadata,
        "previous_hash": self.previous_hash
    }
    data_str = json.dumps(data, sort_keys=True, separators=(',', ':'))
    return hashlib.sha256(data_str.encode()).hexdigest()
```

**Extension Points**:
- Add transaction signing
- Implement multi-ledger support
- Add real-time audit streaming
- Implement anomaly detection

### 7. Financial Safety Monitor

**Purpose**: Hourly health checks with conservative failure handling

**Key Features**:
- Component health monitoring
- Ledger integrity verification
- Budget compliance checking
- Emergency stop triggering

**Health Check Categories**:

```python
def run_health_check(self):
    checks = {
        "ledger_integrity": self._check_ledger_integrity(),
        "budget_enforcement": self._check_budget_enforcement(),
        "allocation_compliance": self._check_allocation_compliance(),
        "revenue_attribution": self._check_revenue_attribution(),
        "cost_attribution": self._check_cost_attribution(),
        "profit_calculation": self._check_profit_calculation(),
        "audit_trail": self._check_audit_trail()
    }
    
    # Determine overall health and generate alerts
    return {
        "healthy": all(check["pass"] for check in checks.values()),
        "checks": checks,
        "alerts": alerts
    }
```

**Extension Points**:
- Add predictive health monitoring
- Implement automated healing
- Add performance metrics
- Implement distributed monitoring

### 8. Capital Engine Daemon

**Purpose**: Orchestration of all components with scheduled cycles

**Key Features**:
- Daily allocation cycles
- Hourly health monitoring
- Monthly report generation
- Manual allocation triggers

**Daemon Architecture**:

```python
class CapitalEngineDaemon:
    async def daily_cycle(self):
        # 1. Health check
        # 2. Portfolio metrics
        # 3. Calculate allocation
        # 4. Log decision
        # 5. Register allocation
        
    async def hourly_cycle(self):
        # 1. Health check
        # 2. Status logging
        # 3. Alert handling
        
    async def monthly_cycle(self):
        # 1. Generate P&L report
        # 2. Export and archive
```

**Extension Points**:
- Add real-time event processing
- Implement distributed coordination
- Add API endpoints
- Implement web dashboard

## Development Guidelines

### Code Organization

```
src/
├── revenue_attribution_engine.py      # Revenue tracking
├── cost_attribution_engine.py        # Cost allocation
├── profit_margin_calculator.py       # P&L calculations
├── capital_allocation_policy_engine.py # Allocation rules
├── budget_enforcement_engine.py      # Spend control
├── financial_audit_trail.py         # Transaction logging
├── financial_safety_monitor.py      # Health monitoring
└── capital_engine_daemon.py        # Orchestration
```

### Testing Strategy

1. **Unit Tests**: Each component tested in isolation
2. **Integration Tests**: End-to-end flows across components
3. **Acceptance Tests**: All 10 Phase 5 criteria verified
4. **Performance Tests**: Load testing and timing verification

### Configuration Management

```json
{
  "phase": 5,
  "effective_date": "2026-01-15",
  "revenue_attribution": {...},
  "cost_attribution": {...},
  "allocation_policy": {...},
  "budget_enforcement": {...},
  "safety": {...},
  "daemon": {...}
}
```

## Extension and Customization

### Adding New Revenue Channels

1. Update `RevenueAttributionEngine.record_revenue_event()` validation
2. Add channel to revenue attribution queries
3. Update cost model if channel has different costs
4. Add tests for new channel

### Modifying Allocation Policy

1. Update `config/allocation_policy_v1.json`
2. Modify `CapitalAllocationPolicyEngine.calculate_allocation()`
3. Add new policy rules and thresholds
4. Update policy compliance checking
5. Add tests for new policy

### Adding New Cost Types

1. Update cost model schema in `CostAttributionEngine`
2. Add cost type to recording and query methods
3. Update overhead allocation logic
4. Add tests for new cost type

### Implementing New Metrics

1. Add metric calculation to `ProfitMarginCalculator`
2. Update portfolio aggregation
3. Add metric to reporting and exports
4. Add tests for new metric

## Performance Considerations

### Database Optimization

- Use indexes on frequently queried columns
- Batch operations for bulk transactions
- Archive old data to maintain performance
- Monitor query execution times

### Memory Management

- Use generators for large result sets
- Implement pagination for queries
- Cache frequently accessed data
- Monitor memory usage patterns

### Concurrency Handling

- Use database transactions for consistency
- Implement proper locking for shared resources
- Handle concurrent spend requests
- Test under load conditions

## Security Considerations

### Data Protection

- Validate all input data
- Use parameterized queries
- Implement proper error handling
- Log security events

### Access Control

- Restrict database access
- Use environment variables for secrets
- Implement audit logging
- Regular security reviews

### Integrity Protection

- Hash chaining prevents tampering
- Regular integrity verification
- Immutable transaction log
- Emergency freeze on corruption

## Troubleshooting Guide

### Common Issues

1. **Ledger Integrity Failures**
   - Check database file permissions
   - Verify no concurrent writes
   - Review recent schema changes
   - Restore from backup if needed

2. **Allocation Not Running**
   - Check daemon status
   - Verify configuration files
   - Review component dependencies
   - Check system logs

3. **Budget Enforcement Issues**
   - Verify policy configuration
   - Check time zone handling
   - Review spend tracking logic
   - Test with known scenarios

### Debug Tools

```bash
# Component-specific debugging
python3 -c "
from src.revenue_attribution_engine import RevenueAttributionEngine
engine = RevenueAttributionEngine()
# Add debug code here
"

# System-wide debugging
python3 -c "
from src.financial_safety_monitor import FinancialSafetyMonitor
monitor = FinancialSafetyMonitor()
health = monitor.run_health_check()
print('Health Check Results:', health)
"

# Performance profiling
python3 -m cProfile -o profile.stats your_script.py
python3 -c "
import pstats
p = pstats.Stats('profile.stats')
p.sort_stats('cumulative').print_stats(20)
"
```

## Best Practices

### Code Quality

1. Follow deterministic patterns
2. Use integer arithmetic for money
3. Implement comprehensive error handling
4. Add structured logging
5. Write thorough tests

### Operational Excellence

1. Monitor all key metrics
2. Alert on threshold breaches
3. Document all procedures
4. Regular security reviews
5. Performance optimization

### System Design

1. Immutable data structures
2. Conservative failure handling
3. Comprehensive audit trails
4. Graceful degradation
5. Emergency procedures

This guide provides the foundation for understanding, extending, and maintaining the Phase 5 Capital Engine. For specific implementation questions, refer to the source code and test files.
