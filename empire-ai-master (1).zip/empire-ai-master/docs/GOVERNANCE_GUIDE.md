# Empire-AI: Governance System Guide

Welcome to Empire-AI! This repo uses a comprehensive production-grade governance system.

## Quick Start

### 1. Read the Master Guide
**Location:** `/home/lin/Documents/markenz/docs/guides/README.md`

This is the global master guide that applies to all repos, including this one.

### 2. Understand This Repo's Rules
**Location:** `./AGENTS.md` (in this repo root)

This file explains:
- Repo-specific tech stack (Node.js frontend + Python backend)
- Which skills to use
- How to run tests, lint, typecheck
- Security and observability requirements
- KAIZA-AUDIT block requirements

### 3. Choose Your Task
Pick one:
- **Implementing a feature** → Read `/home/lin/Documents/markenz/docs/guides/01_SKILLS_DEEP_DIVE.md`
- **Fixing a bug** → Use `/home/lin/Documents/markenz/docs/guides/03_EXAMPLE_SCENARIOS.md` (Scenario 2)
- **Refactoring code** → Load `@refactor-with-safety` skill
- **Production issue** → Load `@incident-triage-and-rca` skill

## Key Locations

### Global (Available everywhere)
```
~/.codeium/windsurf/skills/           # 11 reusable engineering skills
~/.codeium/windsurf/workflows/         # 6 operational workflows
~/.codeium/windsurf/rules/             # 3 non-negotiable governance rules
/home/lin/Documents/markenz/docs/guides/  # Comprehensive guides (2,652 lines)
```

### In This Repo
```
./AGENTS.md                            # Repo-specific configuration
./observability/                       # Logging schemas and conventions
./runbooks/                            # Incident response templates
./scripts/ci/                          # CI verification scripts
```

## Governance System Overview

**The system enforces:**
- ✓ Complete code (no stubs, TODOs, unimplemented!)
- ✓ Comprehensive testing (>80% coverage)
- ✓ Good documentation (purpose, invariants, failure modes)
- ✓ Security by default (validation, secrets from env, redaction)
- ✓ Observability (structured logs, correlation IDs)
- ✓ Auditability (KAIZA-AUDIT blocks)

**How it works:**
1. Load a skill or workflow for your task
2. Follow step-by-step instructions
3. Run verification gates (tests, lint, typecheck, scanners)
4. Produce a KAIZA-AUDIT block
5. Create PR with confidence

## Common Tasks

### I'm implementing a feature
```bash
# 1. Read the workflow guide
cat /home/lin/Documents/markenz/docs/guides/01_SKILLS_DEEP_DIVE.md

# 2. Load skills in sequence
@repo-understanding              # Understand the codebase
@no-placeholders-production-code # Write complete code
@test-engineering-suite          # Write tests
@audit-first-commentary          # Document code
@debuggable-by-default           # Add observability
@secure-by-default               # Harden security

# 3. Run verification gates
npm test                                              # Frontend tests
pytest                                               # Backend tests
npm run lint                                         # Linting
npm run typecheck                                    # Type checking
python3 scripts/ci/forbidden_markers_scan.py --root . # No TODOs
npm audit --audit-level=high                        # Dependency audit

# 4. Produce KAIZA-AUDIT block (see AGENTS.md Section 9)
# 5. Create PR with KAIZA-AUDIT in description
```

### I'm fixing a bug
```bash
# 1. Load the incident response skill
@incident-triage-and-rca
# OR for code fix:
@test-engineering-suite (write failing test first)
@no-placeholders-production-code (implement fix)

# 2. Follow the examples at:
cat /home/lin/Documents/markenz/docs/guides/03_EXAMPLE_SCENARIOS.md

# 3. Run all tests
npm test && pytest

# 4. Add regression test (test must fail without fix)

# 5. Produce KAIZA-AUDIT block
```

### Production is broken
```bash
# 1. Load incident response skill
@incident-triage-and-rca

# 2. Follow triage checklist
cat ./runbooks/triage.md

# 3. Gather evidence (logs, metrics, traces)

# 4. Conduct RCA
cat ./runbooks/rca_template.md

# 5. Implement fix + regression test

# 6. Document prevention gates
```

## Running Verification Gates Locally

Before merging, run all gates:

```bash
# Frontend (Node.js)
npm install                                          # Install deps
npm test -- --coverage                              # Tests + coverage
npm run lint                                         # ESLint
npm run typecheck                                    # TypeScript (if used)
npm run format:check                                 # Code format

# Backend (Python)
pip install -r requirements.txt                     # Install deps
pytest --cov=src                                    # Tests + coverage
pylint src/                                         # Linting
python -m mypy src/                                 # Type checking (if enabled)

# Shared
python3 scripts/ci/forbidden_markers_scan.py --root . # No TODOs/FIXME
npm audit --audit-level=high                       # Dependency vulnerabilities
```

If any gate fails, **stop and fix before continuing**.

## KAIZA-AUDIT Block (Required for Every PR)

Every PR must include a KAIZA-AUDIT block in the description:

```
KAIZA-AUDIT
Plan: [plan-name or feature-name]
Scope: [files/modules changed]
Intent: [what outcome is delivered]
Key Decisions: [why these choices]
Verification: [tests pass, gates pass, etc.]
Results: [PASS or FAIL with details]
Risk Notes: [remaining risks + mitigations]
Rollback: [how to revert safely]
KAIZA-AUDIT-END
```

Example:
```
KAIZA-AUDIT
Plan: implement-feature-auth
Scope: src/auth/handler.js, tests/auth.test.js, docs/AUTH.md
Intent: Add JWT authentication for user login
Key Decisions: Used HS256 (simpler than RS256); 1-hour expiry for security
Verification: npm test PASS (12 tests), npm run lint PASS, forbidden_markers PASS
Results: PASS - All gates pass
Risk Notes: No token refresh (future work); rate limiting needed on /login
Rollback: Revert commits; feature toggleable via JWT_ENABLED env var
KAIZA-AUDIT-END
```

## Skills Available

| Skill | When to Use | Read |
|-------|-------------|------|
| `@repo-understanding` | Starting work on new area | Skill docs |
| `@no-placeholders-production-code` | Writing any code | Skill docs |
| `@test-engineering-suite` | Writing tests | Skill docs |
| `@audit-first-commentary` | Documenting code | Skill docs |
| `@debuggable-by-default` | Adding observability | Skill docs |
| `@secure-by-default` | Handling input/secrets | Skill docs |
| `@refactor-with-safety` | Improving code | Skill docs |
| `@observability-pack-implementer` | Setting up logging | Skill docs |
| `@release-readiness` | Releasing to prod | Skill docs |
| `@incident-triage-and-rca` | Production issues | Skill docs |
| `@kaiza-mcp-ops` | All work (Kaiza mode) | Skill docs |

Load any skill: `@skill-name`

All skills are in: `~/.codeium/windsurf/skills/*/SKILL.md`

## Definition of Done

Code is "done" only when:
- ✓ It is fully implemented and integrated (no stubs)
- ✓ Tests cover all code paths (>80% coverage)
- ✓ Documentation includes purpose/invariants/failure modes
- ✓ Structured logging is added (request_id propagated)
- ✓ Input validation and secure defaults applied
- ✓ All verification gates pass locally
- ✓ KAIZA-AUDIT block is produced
- ✓ Ready for code review

## Redaction Policy (Quick)

**Never log:**
- Passwords, tokens, API keys
- Credit card numbers
- Raw email addresses or phone numbers
- Government IDs
- Secrets of any kind

**OK to log:**
- User IDs (internal identifiers)
- Hashed values
- Safe summaries (e.g., "auth successful", not the credentials)
- Operation names and durations

Full policy: `./observability/redaction_policy.md`

## Observability Requirements

All code must emit structured JSON logs:

**Required fields** (every log):
```json
{
  "timestamp": "2026-01-15T12:34:56.789Z",
  "level": "info",
  "message": "user authenticated",
  "service": "api",
  "env": "prod",
  "version": "1.0.0",
  "request_id": "r_abc123"
}
```

Full schema: `./observability/logging_schema.md`

## Getting Help

**Question:** | **Answer:**
---|---
How do I implement X? | Load the skill: `@skill-name` or read guides
What's required for my task? | Read `/home/lin/Documents/markenz/docs/guides/00_GETTING_STARTED.md`
How do I know I'm done? | Check Definition of Done (this file or AGENTS.md)
Show me an example | Read `/home/lin/Documents/markenz/docs/guides/03_EXAMPLE_SCENARIOS.md`
I need a quick reference | Check `/home/lin/Documents/markenz/docs/guides/04_QUICK_REFERENCE.md`
What are the rules? | Read `./AGENTS.md` (this repo) or `~/.codeium/windsurf/rules/`

## Files in This Repo

```
empire-ai/
├── AGENTS.md                     # Repo configuration (read this!)
├── observability/                # Logging schemas and reference code
│   ├── logging_schema.md
│   ├── redaction_policy.md
│   ├── tracing_conventions.md
│   ├── metrics_conventions.md
│   └── node/obs.js              # Reference logger (Node.js)
├── runbooks/                     # Incident response templates
│   ├── triage.md
│   ├── rca_template.md
│   ├── comms_template.md
│   └── rollback_checklist.md
├── scripts/ci/                   # CI verification scripts
│   ├── forbidden_markers_scan.py # Check for TODO/FIXME
│   ├── install_deps.sh
│   ├── run_if_present.sh
│   ├── node_audit.sh
│   └── ... more scripts
└── docs/
    └── GOVERNANCE_GUIDE.md       # This file
```

## Global Guides (Read These!)

All located at: `/home/lin/Documents/markenz/docs/guides/`

- **README.md** (255 lines) - Master index, learning paths
- **00_GETTING_STARTED.md** (266 lines) - Overview, concepts, quick start
- **01_SKILLS_DEEP_DIVE.md** (1088 lines) - Detailed instructions for each skill
- **03_EXAMPLE_SCENARIOS.md** (712 lines) - Real-world examples with exact prompts
- **04_QUICK_REFERENCE.md** (331 lines) - Cheat sheet for quick lookup

**Total: 2,652 lines of comprehensive documentation**

## Next Steps

1. **Read AGENTS.md** (this repo) to understand repo-specific rules
2. **Read `/home/lin/Documents/markenz/docs/guides/README.md`** (global master guide)
3. **Choose your task** and load the relevant skill or workflow
4. **Follow step-by-step instructions** from the guides
5. **Run verification gates** before merging
6. **Produce KAIZA-AUDIT block** and create PR

---

**You now have everything you need to work on Empire-AI with confidence!**

For more help, visit the guides: `/home/lin/Documents/markenz/docs/guides/`
