# Phase 1 API Reference

This document provides a complete reference for all Phase 1 APIs, including method signatures, parameters, return values, and examples.

## Table of Contents

- [Governor API](#governor-api)
- [Runtime API](#runtime-api)
- [Registry API](#registry-api)
- [Audit Engine API](#audit-engine-api)
- [Kill Switch API](#kill-switch-api)
- [Data Models](#data-models)
- [Error Codes](#error-codes)

---

## Governor API

### approve_request

Evaluate a request against policies and budget.

```python
def approve_request(
    self,
    actor: str,
    action: str,
    resource: str,
    budget: Dict[str, Any] = None
) -> Dict[str, Any]
```

**Parameters:**
- `actor` (str): ID of the agent making the request
- `action` (str): Action being requested (e.g., 'create_asset')
- `resource` (str): Resource identifier (e.g., 'asset_123')
- `budget` (dict, optional): Budget information
  - `resource_type` (str): Type of resource for budget check

**Returns:**
```python
{
    "decision": "APPROVE|DENY|HOLD_FOR_APPROVAL",
    "reasoning": "Explanation of decision",
    "policy_matched": "policy_id_or_null",
    "budget_status": {
        "status": "WITHIN_LIMIT|APPROACHING_LIMIT|EXCEEDED",
        "used": 100,
        "limit": 1000,
        "remaining": 900,
        "reset_at": "2026-01-16T00:00:00Z"
    },
    "request_id": "req_20260115_1234_5678"
}
```

**Example:**
```python
result = governor.approve_request(
    actor="scout_agent",
    action="create_asset",
    resource="content_123",
    budget={"resource_type": "api_calls"}
)

if result["decision"] == "APPROVE":
    print("Request approved")
else:
    print(f"Denied: {result['reasoning']}")
```

### check_budget

Check current budget usage for an agent.

```python
def check_budget(self, agent_id: str, resource_type: str) -> Dict[str, Any]
```

**Parameters:**
- `agent_id` (str): Agent to check budget for
- `resource_type` (str): Type of resource (api_calls, compute_hours, etc.)

**Returns:**
```python
{
    "status": "WITHIN_LIMIT|APPROACHING_LIMIT|EXCEEDED|RESET_NEEDED",
    "used": 850,
    "limit": 1000,
    "remaining": 150,
    "reset_at": "2026-01-16T00:00:00Z"
}
```

### get_policies

Get all active policies.

```python
def get_policies(self) -> List[Dict[str, Any]]
```

**Returns:** List of policy dictionaries sorted by priority (high to low)

### set_policy

Set a new policy (owner only).

```python
def set_policy(self, policy: Dict[str, Any]) -> Dict[str, Any]
```

**Parameters:**
```python
{
    "id": "unique_policy_id",
    "name": "Policy Name",
    "rule": "condition_expression",
    "decision": "APPROVE|DENY|HOLD_FOR_APPROVAL",
    "priority": 100,
    "enabled": True
}
```

**Returns:**
```python
{
    "success": True,
    "policy_id": 123
}
```

### get_policy

Get a specific policy by ID.

```python
def get_policy(self, policy_id: str) -> Optional[Dict[str, Any]]
```

**Parameters:**
- `policy_id` (str): ID of policy to retrieve

**Returns:** Policy dictionary or None if not found

### trigger_kill_switch

Trigger system kill switch (owner only).

```python
def trigger_kill_switch(self) -> Dict[str, Any]
```

**Returns:**
```python
{
    "success": True,
    "message": "Kill switch engaged"
}
```

### check_kill_switch

Check if kill switch is currently engaged.

```python
def check_kill_switch(self) -> bool
```

**Returns:** True if engaged, False otherwise

---

## Runtime API

### submit_job

Submit a new job to the queue.

```python
def submit_job(self, job: Dict[str, Any]) -> str
```

**Parameters:**
```python
{
    "job_name": "Human-readable name",
    "actor": "agent_id",
    "steps": [
        {
            "id": "unique_step_id",
            "name": "Step Name",
            "action": "create_asset|fetch_url|deploy|query_db",
            "parameters": {},
            "idempotent": True,
            "max_retries": 3
        }
    ],
    "timeout_seconds": 300
}
```

**Returns:** Job ID string

### execute_job

Execute a job from the queue.

```python
def execute_job(self, job_id: str) -> Dict[str, Any]
```

**Parameters:**
- `job_id` (str): ID of job to execute

**Returns:**
```python
{
    "success": True,
    "job_id": "job_20260115_1234_5678",
    "status": "succeeded",
    "duration": 45.2
}
```

### get_job_status

Get current status of a job.

```python
def get_job_status(self, job_id: str) -> Dict[str, Any]
```

**Returns:**
```python
{
    "success": True,
    "job_id": "job_20260115_1234_5678",
    "status": "pending|running|succeeded|failed|halted",
    "created_at": "2026-01-15T12:00:00Z",
    "started_at": "2026-01-15T12:00:05Z",
    "completed_at": "2026-01-15T12:00:50Z",
    "error_message": null
}
```

### list_jobs

List jobs with optional filtering.

```python
def list_jobs(self, filter: Dict[str, Any] = None) -> List[Dict[str, Any]]
```

**Parameters:**
- `filter` (dict, optional): Filter criteria
  - `status` (str): Filter by status
  - `actor` (str): Filter by actor

**Returns:** List of job dictionaries

### retry_job

Retry a failed job.

```python
def retry_job(self, job_id: str) -> Dict[str, Any]
```

**Returns:**
```python
{
    "success": True,
    "job_id": "job_20260115_1234_5678",
    "status": "pending"
}
```

### halt_job

Halt a running job.

```python
def halt_job(self, job_id: str) -> Dict[str, Any]
```

**Returns:**
```python
{
    "success": True,
    "job_id": "job_20260115_1234_5678",
    "status": "halted"
}
```

---

## Registry API

### Agent Management

#### set_agent

Store or update an agent definition.

```python
def set_agent(self, agent: Dict[str, Any]) -> Dict[str, Any]
```

**Parameters:**
```python
{
    "id": "unique_agent_id",
    "name": "Agent Name",
    "enabled": True,
    "permissions": ["action1", "action2"],
    "agent_type": "scout|builder|writer|...",
    "budget": {
        "resource_type": "api_calls",
        "limit": 1000,
        "period": "day"
    }
}
```

**Returns:**
```python
{
    "success": True,
    "version": 2
}
```

#### get_agent

Get an agent definition by ID.

```python
def get_agent(self, agent_id: str) -> Optional[Dict[str, Any]]
```

#### list_agents

List all agents.

```python
def list_agents(self) -> List[Dict[str, Any]]
```

### Policy Management

#### set_policy

Store or update a policy.

```python
def set_policy(self, policy: Dict[str, Any]) -> Dict[str, Any]
```

#### get_policy

Get a policy by ID.

```python
def get_policy(self, policy_id: str) -> Optional[Dict[str, Any]]
```

#### list_policies

List all policies sorted by priority.

```python
def list_policies(self) -> List[Dict[str, Any]]
```

### Asset Management

#### set_asset

Store or update asset metadata.

```python
def set_asset(self, asset: Dict[str, Any]) -> Dict[str, Any]
```

**Parameters:**
```python
{
    "id": "unique_asset_id",
    "name": "Asset Name",
    "owner": "agent_id",
    "status": "draft|active|scaling|paused|retired",
    "type": "content|tool|lead_gen|...",
    "metrics": {
        "roi": 0.15,
        "cost_accumulated": 100.0,
        "revenue_accumulated": 115.0,
        "health_status": "healthy"
    }
}
```

#### get_asset

Get asset metadata by ID.

```python
def get_asset(self, asset_id: str) -> Optional[Dict[str, Any]]
```

#### list_assets

List assets with optional filtering.

```python
def list_assets(self, filter: Dict[str, Any] = None) -> List[Dict[str, Any]]
```

### Configuration Management

#### set_config

Set a configuration value with versioning.

```python
def set_config(self, key: str, value: Any, version: int) -> bool
```

#### get_config

Get configuration value(s).

```python
def get_config(self, key: str = None) -> Any
```

- With `key`: Returns specific value
- Without `key`: Returns all configuration as dict

### State Management

#### get_state

Get current system state.

```python
def get_state(self) -> Dict[str, Any]
```

**Returns:**
```python
{
    "job_queue": [...],
    "current_metrics": {
        "budget_used_today": {...},
        "jobs_completed_today": 10,
        "jobs_failed_today": 2,
        "active_jobs": 1
    },
    "portfolio": {...}
}
```

#### set_state

Update system state.

```python
def set_state(self, state: Dict[str, Any]) -> Dict[str, Any]
```

---

## Audit Engine API

### Event Logging

#### log_event

Log an audit event.

```python
def log_event(self, event: Dict[str, Any]) -> str
```

**Parameters:**
```python
{
    "actor": "agent_id",
    "action": "action_name",
    "resource": "resource_id",
    "event_type": "category",
    "details": {...},
    "result": "success|failure",
    "error": "Error message if failed"
}
```

**Returns:** Event ID string

### Querying

#### query_events

Query audit events with filtering.

```python
def query_events(self, filter: Dict[str, Any] = None) -> List[Dict[str, Any]]
```

**Parameters:**
- `filter` (dict, optional):
  - `actor` (str): Filter by actor
  - `action` (str): Filter by action
  - `date_range` (tuple): (start_date, end_date)

#### get_event

Get a specific audit event by ID.

```python
def get_event(self, event_id: str) -> Optional[Dict[str, Any]]
```

#### search_events

Search by multiple criteria.

```python
def search_events(
    self,
    actor: str = None,
    action: str = None,
    date_range: Tuple[datetime, datetime] = None
) -> List[Dict[str, Any]]
```

### Export and Analysis

#### export_audit_trail

Export audit trail as JSON.

```python
def export_audit_trail(
    self,
    start_date: datetime = None,
    end_date: datetime = None
) -> bytes
```

**Returns:** JSON bytes of audit trail

#### verify_integrity

Verify audit trail integrity.

```python
def verify_integrity(self) -> bool
```

#### get_statistics

Get audit trail statistics.

```python
def get_statistics(self) -> Dict[str, Any]
```

**Returns:**
```python
{
    "total_events": 1000,
    "events_by_type": {...},
    "events_by_actor": {...},
    "events_by_result": {...},
    "last_verified": "2026-01-15T12:00:00Z"
}
```

### Convenience Methods

#### log_governor_decision

Log a governor decision event.

```python
def log_governor_decision(
    self,
    actor: str,
    action: str,
    resource: str,
    decision: str,
    reasoning: str,
    policy_matched: str = None
) -> str
```

#### log_runtime_event

Log a runtime event.

```python
def log_runtime_event(
    self,
    actor: str,
    job_id: str,
    event_type: str,
    details: Dict[str, Any]
) -> str
```

#### log_registry_change

Log a registry change event.

```python
def log_registry_change(
    self,
    actor: str,
    entity_type: str,
    entity_id: str,
    changes: Dict[str, Any]
) -> str
```

---

## Kill Switch API

### Control

#### engage

Engage the kill switch (halt all operations).

```python
def engage(self, triggered_by: str, reason: str = None) -> Dict[str, Any]
```

**Returns:**
```python
{
    "success": True,
    "engaged_at": "2026-01-15T12:00:00Z",
    "triggered_by": "owner",
    "reason": "Emergency stop"
}
```

#### disengage

Disengage the kill switch (resume operations).

```python
def disengage(self, released_by: str, reason: str = None) -> Dict[str, Any]
```

### Status

#### is_engaged

Check if kill switch is currently engaged.

```python
def is_engaged(self) -> bool
```

#### get_status

Get current kill switch status.

```python
def get_status(self) -> Dict[str, Any]
```

**Returns:**
```python
{
    "engaged": False,
    "last_engaged": {...},
    "checked_at": "2026-01-15T12:00:00Z"
}
```

### Emergency

#### force_emergency_stop

Force emergency stop (bypasses normal checks).

```python
def force_emergency_stop(self, reason: str = "CRITICAL: Force stop") -> Dict[str, Any]
```

### Integration

#### check_before_action

Check if action is allowed (not engaged).

```python
def check_before_action(self, actor: str, action: str) -> bool
```

#### require_disengaged

Raise exception if kill switch is engaged.

```python
def require_disengaged(self, operation: str = None) -> None
```

Raises:
- `RuntimeError`: If kill switch is engaged

---

## Data Models

### Decision Enum

```python
class Decision(Enum):
    APPROVE = "APPROVE"
    DENY = "DENY"
    HOLD_FOR_APPROVAL = "HOLD_FOR_APPROVAL"
```

### JobStatus Enum

```python
class JobStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    HALTED = "halted"
```

### StepStatus Enum

```python
class StepStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
```

### BudgetStatus Enum

```python
class BudgetStatus(Enum):
    WITHIN_LIMIT = "within_limit"
    APPROACHING_LIMIT = "approaching_limit"
    EXCEEDED = "exceeded"
    RESET_NEEDED = "reset_needed"
```

---

## Error Codes

### Governor Errors

| Error | Description |
|-------|-------------|
| `agent_not_found` | Agent ID not found in registry |
| `agent_disabled` | Agent is disabled |
| `permission_denied` | Agent lacks required permission |
| `budget_exceeded` | Budget limit exceeded |
| `kill_switch_engaged` | System is halted |

### Runtime Errors

| Error | Description |
|-------|-------------|
| `job_not_found` | Job ID not found |
| `job_already_running` | Job is already executing |
| `job_already_completed` | Job has finished |
| `job_not_failed` | Cannot retry non-failed job |
| `job_not_running` | Cannot halt non-running job |
| `timeout_exceeded` | Job exceeded time limit |
| `step_failed` | Step execution failed |

### Registry Errors

| Error | Description |
|-------|-------------|
| `missing_required_field` | Required field not provided |
| `entity_not_found` | Entity ID not found |
| `version_conflict` | Version conflict during update |
| `storage_error` | Database/storage error |

### Audit Errors

| Error | Description |
|-------|-------------|
| `event_not_found` | Event ID not found |
| `integrity_failed` | Audit trail integrity check failed |
| `export_failed` | Export operation failed |

### Kill Switch Errors

| Error | Description |
|-------|-------------|
| `already_engaged` | Kill switch already engaged |
| `already_disengaged` | Kill switch already disengaged |
| `unauthorized` | Non-owner attempted operation |

---

## Usage Patterns

### Complete Request Flow

```python
# 1. Check permissions
agent = registry.get_agent("agent_id")
if not agent or not agent["enabled"]:
    raise Exception("Agent not available")

# 2. Check budget
budget = governor.check_budget("agent_id", "api_calls")
if budget["status"] == "EXCEEDED":
    raise Exception("Budget exceeded")

# 3. Get approval
approval = governor.approve_request(
    actor="agent_id",
    action="create_asset",
    resource="asset_id",
    budget={"resource_type": "api_calls"}
)

# 4. Execute if approved
if approval["decision"] == "APPROVE":
    job_id = runtime.submit_job(job_definition)
    result = runtime.execute_job(job_id)
    
    # 5. Log completion
    audit.log_runtime_event(
        actor="agent_id",
        job_id=job_id,
        event_type="job_completed",
        details={"result": result}
    )
```

### Error Handling

```python
try:
    result = governor.approve_request(...)
except ValueError as e:
    # Validation error
    audit.log_event({
        "actor": "system",
        "action": "validation_error",
        "resource": "governor",
        "error": str(e),
        "result": "failure"
    })
    raise
except Exception as e:
    # Unexpected error
    audit.log_event({
        "actor": "system",
        "action": "unexpected_error",
        "resource": "governor",
        "error": str(e),
        "result": "failure"
    })
    raise
```

### Async Operations

```python
import threading
from concurrent.futures import ThreadPoolExecutor

def process_request(request_data):
    # Process request
    pass

# Process multiple requests concurrently
with ThreadPoolExecutor(max_workers=10) as executor:
    futures = [
        executor.submit(process_request, req)
        for req in requests
    ]
    
    results = [f.result() for f in futures]
```

---

*This API reference covers all public interfaces for Phase 1 components. For implementation details, see the source code.*
