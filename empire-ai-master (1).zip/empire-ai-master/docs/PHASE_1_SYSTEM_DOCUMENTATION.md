# Phase 1 System Documentation

## Overview

Phase 1 implements the core operating system for Empire AI, providing governance, runtime execution, registry services, audit capabilities, and emergency controls. This document describes the architecture, APIs, and usage patterns for all Phase 1 components.

## Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Governor      │    │    Runtime      │    │    Registry     │
│                 │    │                 │    │                 │
│ • Policy        │◄──►│ • Job Queue     │◄──►│ • Agents        │
│ • Budget        │    │ • Execution     │    │ • Policies      │
│ • Authority     │    │ • Retries       │    │ • Assets        │
│ • Kill Switch   │    │ • Timeouts      │    │ • Config        │
└─────────┬───────┘    └─────────┬───────┘    └─────────┬───────┘
          │                      │                      │
          └──────────────────────┼──────────────────────┘
                                 │
                    ┌─────────────▼─────────────┐
                    │      Audit Engine         │
                    │                           │
                    │ • Event Logging           │
                    │ • Query & Search          │
                    │ • Integrity Verification  │
                    └───────────────────────────┘
```

## Components

### 1. Governor (`src/governor/`)

The Governor enforces policies, manages budgets, and controls system access.

#### Key Methods

```python
# Evaluate a request
result = governor.approve_request(
    actor="agent_id",
    action="create_asset",
    resource="asset_123",
    budget={"resource_type": "api_calls"}
)

# Check budget status
budget = governor.check_budget("agent_id", "api_calls")

# Policy management
policies = governor.get_policies()
governor.set_policy(policy_dict)
policy = governor.get_policy("policy_id")

# Kill switch
governor.trigger_kill_switch()
is_engaged = governor.check_kill_switch()
```

#### Decision Types

- `APPROVE`: Request allowed
- `DENY`: Request blocked
- `HOLD_FOR_APPROVAL`: Requires manual review

#### Budget Status

- `WITHIN_LIMIT`: Normal operation
- `APPROACHING_LIMIT`: Warning threshold reached
- `EXCEEDED`: Budget exhausted
- `RESET_NEEDED`: Budget period expired

### 2. Runtime (`src/runtime/`)

The Runtime executes jobs deterministically with retry logic and timeout enforcement.

#### Key Methods

```python
# Job submission
job_id = runtime.submit_job({
    "job_name": "My Job",
    "actor": "agent_id",
    "steps": [...],
    "timeout_seconds": 300
})

# Job execution
result = runtime.execute_job(job_id)

# Job management
status = runtime.get_job_status(job_id)
jobs = runtime.list_jobs({"status": "pending"})
runtime.retry_job(job_id)
runtime.halt_job(job_id)
```

#### Job Structure

```python
job = {
    "job_name": "Required: Human-readable name",
    "actor": "Required: Agent submitting job",
    "steps": [
        {
            "id": "step_1",
            "name": "Step Name",
            "action": "create_asset|fetch_url|deploy|query_db",
            "parameters": {...},
            "idempotent": True,  # Can be retried?
            "max_retries": 3
        }
    ],
    "timeout_seconds": 300  # Hard limit
}
```

#### Step Types

- `fetch_url`: Retrieve content from URL
- `deploy`: Deploy asset to environment
- `query_db`: Execute database query
- `create_asset`: Create new asset

### 3. Registry (`src/registry.py`)

The Registry is the single source of truth for all system data.

#### Key Methods

```python
# Agent management
registry.set_agent(agent_dict)
agent = registry.get_agent("agent_id")
agents = registry.list_agents()

# Policy management
registry.set_policy(policy_dict)
policy = registry.get_policy("policy_id")
policies = registry.list_policies()

# Asset management
registry.set_asset(asset_dict)
asset = registry.get_asset("asset_id")
assets = registry.list_assets({"status": "active"})

# Configuration
registry.set_config("key", "value", version)
value = registry.get_config("key")
config = registry.get_config()  # All config

# State management
state = registry.get_state()
registry.set_state(state_dict)
```

#### Data Models

```python
# Agent
agent = {
    "id": "Unique identifier",
    "name": "Human-readable name",
    "enabled": True,
    "permissions": ["list", "of", "actions"],
    "budget": {
        "resource_type": "api_calls|compute_hours|...",
        "limit": 1000,
        "period": "day|week|month"
    }
}

# Policy
policy = {
    "id": "Unique identifier",
    "name": "Policy name",
    "rule": "Condition expression",
    "decision": "APPROVE|DENY|HOLD",
    "priority": 100,  # Higher = evaluated first
    "enabled": True
}

# Asset
asset = {
    "id": "Unique identifier",
    "name": "Asset name",
    "owner": "Agent ID",
    "status": "draft|active|scaling|paused|retired",
    "type": "content|tool|lead_gen|...",
    "metrics": {
        "roi": 0.15,
        "cost_accumulated": 100.0,
        "revenue_accumulated": 115.0,
        "health_status": "healthy"
    }
}
```

### 4. Audit Engine (`src/core/audit.py`)

The Audit Engine provides immutable logging and querying of all system events.

#### Key Methods

```python
# Event logging
event_id = audit.log_event({
    "actor": "agent_id",
    "action": "action_name",
    "resource": "resource_id",
    "event_type": "category",
    "details": {...},
    "result": "success|failure",
    "error": "Error message if failed"
})

# Querying
events = audit.query_events({"actor": "agent_id"})
event = audit.get_event("event_id")
events = audit.search_events(
    actor="agent_id",
    action="action_name",
    date_range=(start, end)
)

# Export and analysis
export_data = audit.export_audit_trail(start_date, end_date)
is_valid = audit.verify_integrity()
stats = audit.get_statistics()
```

#### Event Types

- `governor_decision`: Policy evaluations
- `runtime.*`: Job lifecycle events
- `registry_change`: Data modifications
- `system_frozen`: Kill switch engagement
- `emergency_stop`: Critical system halt

### 5. Kill Switch (`src/core/kill_switch.py`)

The Kill Switch provides emergency system halt capabilities.

#### Key Methods

```python
# Control
result = kill_switch.engage("actor", "Reason")
result = kill_switch.disengage("actor", "Reason")
is_engaged = kill_switch.is_engaged()
status = kill_switch.get_status()

# Emergency
kill_switch.force_emergency_stop("CRITICAL: System compromise")
kill_switch.require_disengaged("operation_name")
```

#### Usage Pattern

```python
# Before any critical operation
if not kill_switch.check_before_action(agent, action):
    raise RuntimeError("System halted by kill switch")

# Or use decorator
@kill_switch_aware("critical_operation")
def critical_function():
    # Will fail fast if kill switch engaged
    pass
```

## Configuration

### Default Configuration (`config/phase_1_defaults.json`)

```json
{
  "governance": {
    "default_deny": true,
    "kill_switch_engaged": false
  },
  "agents": {
    "scout": {...},
    "builder": {...},
    "writer": {...}
  },
  "policies": {
    "budget_enforcement": {...},
    "permission_check": {...},
    "owner_override": {...}
  },
  "runtime": {
    "max_concurrent_jobs": 10,
    "default_timeout_seconds": 300,
    "retry_policy": {...}
  },
  "audit": {
    "retention_days": 90,
    "integrity_check_interval_hours": 24
  }
}
```

## Usage Examples

### Basic Workflow

```python
from src.registry import Registry
from src.governor import Governor
from src.runtime import JobExecutor
from src.core.audit import AuditEngine
from src.core.kill_switch import KillSwitch

# Initialize system
registry = Registry("/path/to/data")
governor = Governor("/path/to/data")
runtime = JobExecutor(registry, ledger)
audit = AuditEngine(ledger)
kill_switch = KillSwitch(registry, audit)

# 1. Create agent
agent = {
    "id": "my_agent",
    "name": "My Agent",
    "enabled": True,
    "permissions": ["create_asset"],
    "agent_type": "custom"
}
registry.set_agent(agent)

# 2. Request approval
approval = governor.approve_request(
    actor="my_agent",
    action="create_asset",
    resource="my_asset"
)

if approval["decision"] == "APPROVE":
    # 3. Submit and execute job
    job = {
        "job_name": "Create My Asset",
        "actor": "my_agent",
        "steps": [
            {
                "id": "create",
                "name": "Create Asset",
                "action": "create_asset",
                "parameters": {"type": "content"},
                "idempotent": True,
                "max_retries": 3
            }
        ]
    }
    
    job_id = runtime.submit_job(job)
    result = runtime.execute_job(job_id)
    
    if result["success"]:
        print("Job completed successfully")
    else:
        print(f"Job failed: {result['error']}")
else:
    print(f"Request denied: {approval['reasoning']}")
```

### Policy Management

```python
# Create budget policy
budget_policy = {
    "id": "strict_budget",
    "name": "Strict Budget Enforcement",
    "rule": "budget_used >= limit",
    "decision": "DENY",
    "priority": 100,
    "enabled": True
}
governor.set_policy(budget_policy)

# Create time-based policy
time_policy = {
    "id": "business_hours",
    "name": "Business Hours Only",
    "rule": "hour < 9 or hour > 17",
    "decision": "HOLD_FOR_APPROVAL",
    "priority": 50,
    "enabled": True
}
governor.set_policy(time_policy)
```

### Audit Trail Analysis

```python
# Get all governor decisions in last hour
from datetime import datetime, timedelta

end = datetime.utcnow()
start = end - timedelta(hours=1)

decisions = audit.search_events(
    action="approve_request",
    date_range=(start, end)
)

# Analyze patterns
stats = audit.get_statistics()
print(f"Total events: {stats['total_events']}")
print(f"By actor: {stats['events_by_actor']}")
print(f"By result: {stats['events_by_result']}")

# Export for compliance
export = audit.export_audit_trail(start, end)
with open("audit_export.json", "wb") as f:
    f.write(export)
```

## Testing

### Running Tests

```bash
# Run all Phase 1 tests
python -m pytest tests/test_*_phase1.py -v

# Run specific test suites
python -m pytest tests/test_governor_phase1.py -v
python -m pytest tests/test_runtime_phase1.py -v
python -m pytest tests/test_registry_phase1.py -v
python -m pytest tests/test_audit_phase1.py -v
python -m pytest tests/test_integration_phase1.py -v
python -m pytest tests/test_system_phase1.py -v

# Run with coverage
python -m pytest tests/test_*_phase1.py --cov=src --cov-report=html
```

### Test Structure

- Unit tests: Test individual components in isolation
- Integration tests: Test component interactions
- System tests: Test full system behavior under load

## Monitoring and Observability

### Key Metrics

- Governor: Decision rates, policy matches, denials
- Runtime: Job throughput, success/failure rates, queue depth
- Registry: Entity counts, query performance
- Audit: Event volume, storage usage, integrity status

### Logging

All components use structured logging with:
- Service name
- Operation name
- Request/correlation IDs
- Key metrics and metadata

### Health Checks

```python
# System health
registry_consistency = registry.verify_consistency()
audit_integrity = audit.verify_integrity()
kill_switch_status = kill_switch.get_status()

# Component health
governor_policies = governor.get_policies()
runtime_jobs = runtime.list_jobs()
```

## Security Considerations

1. **Access Control**: Only owner can modify policies and configuration
2. **Audit Trail**: All actions are logged immutably
3. **Kill Switch**: Emergency halt capability
4. **Budget Enforcement**: Hard limits prevent overspending
5. **Input Validation**: All inputs validated before processing

## Troubleshooting

### Common Issues

1. **Requests Denied**
   - Check agent permissions
   - Verify budget status
   - Review policy matches
   - Check kill switch status

2. **Jobs Failing**
   - Check step definitions
   - Verify parameters
   - Review retry counts
   - Check timeout settings

3. **Performance Issues**
   - Monitor queue depth
   - Check query performance
   - Review audit volume
   - Verify resource limits

### Debug Mode

Enable debug logging:
```python
import logging
logging.getLogger("src").setLevel(logging.DEBUG)
```

## Migration Guide

### From Phase 0

Phase 1 builds on Phase 0 foundations:
- Ledger: Same append-only log
- Decision Engine: Integrated into Governor
- Registry: Enhanced with Phase 1 APIs
- New Components: Runtime, Audit, Kill Switch

### To Phase 2

Phase 1 establishes the foundation for:
- Agent economy (Phase 2)
- Asset runtime (Phase 3)
- Advanced governance (Phase 4+)

## API Reference

### Governor API

| Method | Parameters | Returns | Description |
|--------|------------|---------|-------------|
| `approve_request` | actor, action, resource, budget | Decision dict | Evaluate request |
| `check_budget` | agent_id, resource_type | Budget dict | Check usage |
| `get_policies` | - | Policy list | List all policies |
| `set_policy` | policy dict | Result dict | Add/update policy |
| `trigger_kill_switch` | - | Result dict | Emergency halt |

### Runtime API

| Method | Parameters | Returns | Description |
|--------|------------|---------|-------------|
| `submit_job` | job dict | Job ID | Queue job |
| `execute_job` | job_id | Result dict | Run job |
| `get_job_status` | job_id | Status dict | Check status |
| `list_jobs` | filter dict | Job list | List jobs |
| `retry_job` | job_id | Result dict | Retry failed |
| `halt_job` | job_id | Result dict | Stop job |

### Registry API

| Method | Parameters | Returns | Description |
|--------|------------|---------|-------------|
| `set_agent` | agent dict | Result dict | Store agent |
| `get_agent` | agent_id | Agent dict | Get agent |
| `list_agents` | - | Agent list | List all |
| `set_policy` | policy dict | Result dict | Store policy |
| `get_policy` | policy_id | Policy dict | Get policy |
| `set_asset` | asset dict | Result dict | Store asset |
| `get_config` | key (optional) | Value/dict | Get config |
| `set_config` | key, value, version | Bool | Set config |

### Audit API

| Method | Parameters | Returns | Description |
|--------|------------|---------|-------------|
| `log_event` | event dict | Event ID | Log event |
| `query_events` | filter dict | Event list | Query events |
| `get_event` | event_id | Event dict | Get event |
| `export_audit_trail` | start, end | Bytes | Export data |
| `verify_integrity` | - | Bool | Verify logs |

## Best Practices

1. **Always check Governor approval before acting**
2. **Use structured logging with correlation IDs**
3. **Set appropriate timeouts for jobs**
4. **Monitor budget usage and set alerts**
5. **Regularly verify audit integrity**
6. **Test kill switch procedures**
7. **Keep policies simple and deterministic**
8. **Use idempotent operations when possible**

## Support

For issues or questions:
1. Check audit trail for error details
2. Review system health status
3. Consult test cases for usage examples
4. Check configuration defaults

---

*This documentation covers Phase 1 of the Empire AI system. For later phases, see their respective documentation.*
