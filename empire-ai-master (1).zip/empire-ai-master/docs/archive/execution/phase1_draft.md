---
status: APPROVED
plan_id: PHASE_1_CORE_OS_KAIZA_EXECUTABLE
title: Phase 1 Core OS Completion (KAIZA Executable)
created_by: Antigravity (Planner)
created_date: 2026-01-12
source_inputs:
  - docs/plans/PHASE_1_CORE_OS_KAIZA_EXECUTABLE.md
  - docs/governance/EMPIRE_AI_CANONICAL_SPECIFICATION.md
  - docs/governance/MASTER_ROADMAP.md
authority:
  - /docs/governance/EMPIRE_AI_CANONICAL_SPECIFICATION.md (Layer 1 & 2)
  - KAIZA_COMPLETE_GUIDE.md
---

# PHASE 1: CORE OS COMPLETION (KAIZA-EXECUTABLE)

## 1. Header Block
**Phase ID:** PHASE_1_CORE_OS  
**Status:** APPROVED  
**Date:** 2026-01-12  
**Authority:** EMPIRE_AI_CANONICAL_SPECIFICATION.md v1.0, KAIZA_COMPLETE_GUIDE.md  
**Source Inputs:** docs/plans/PHASE_1_CORE_OS_KAIZA_EXECUTABLE.md  

## 2. Objective
Complete the Empire AI operating system kernel with strict governance enforcement. The repository must transition from a passive codebase to an active runtime where the Governor gates ALL execution, the Registry serves as the single source of truth, and the Ledger logs every decision. The system must refuse to execute any job without explicit Governor approval.

## 3. Scope Lock
**Allowed Paths:**
- `src/job_executor.py`
- `src/registry.py`
- `src/governor.py`
- `src/universal_ledger.py` (if modification needed)
- `src/kill_switch.py`
- `data/` (schemas/db files)
- `tests/`

**Forbidden Paths:**
- `src/agents/*` (Phase 2)
- `src/assets/*` (Phase 3)
- `src/web/*` (Phase 4)

*Touching forbidden paths = HARD FAIL.*

## 4. Hard Bans / Reality Lock
- **NO** `TODO`, `FIXME`, `pass`, `...` (placeholder)
- **NO** mock data or fake returns
- **NO** generic `except Exception: pass`
- **NO** bypassing the Governor for convenience
- **NO** stubs for "future phases" (implement full logic or raise NotImplementedError with specific phase reference)

*If any violations are introduced, the phase fails.*

## 5. Write Tool Law
- ALL file writes MUST be performed using `kaiza_mcp.write_file`.
- Writing code directly in chat is **FORBIDDEN**.
- Partial writes are **FORBIDDEN**.
- Each write must include audit metadata (role, purpose, failure modes).

## 6. Deliverables
1.  **Job Execution Engine (`src/job_executor.py`)**: Central router for all work, hard-wired to Governor.
2.  **System Registry (`src/registry.py`)**: Persistent SQL-based storage for all system state (assets, agents, config).
3.  **Kill Switch (`src/kill_switch.py`)**: Global freeze mechanism accessible to Governor and Owner.
4.  **Governor Integration**: Updated `src/governor.py` to intercept all jobs and log to Ledger.
5.  **Data Schemas**: SQLite schemas for `jobs.db`, `registry.db`, `kill_switch.db`.
6.  **Integration Tests**: Comprehensive test suite proving governance enforcement.

## 7. File-Level Write Set

| Path | Action | Purpose | Required Behaviors | Failure Modes | Tests |
|------|--------|---------|-------------------|---------------|-------|
| `src/job_executor.py` | CREATE | Central job routing | - `submit_job` calls `Governor.evaluate_action`<br>- `execute` runs only if approved<br>- Logs all steps to Ledger<br>- Handles `DENY` and `OVERRIDE_REQUIRED` | - Governor unavailable<br>- DB write fail<br>- Budget exceeded | `test_job_executor.py` |
| `src/registry.py` | CREATE | System State SoT | - Store/retrieve Assets/Agents<br>- Versioned Config storage<br>- Enforce valid state transitions | - DB locked<br>- Invalid transition | `test_registry.py` |
| `src/kill_switch.py` | CREATE | Emergency Stop | - atomic `activate`/`deactivate`<br>- Persistent state<br>- Logs to Ledger | - State inconsistency | `test_kill_switch.py` |
| `src/governor.py` | MODIFY | Policy Gates | - Integrate with Jobs/Ledger<br>- Add `freeze`/`unfreeze` methods | - Policy engine fail | `test_governor.py` |
| `tests/test_job_flow.py` | CREATE | E2E Verification | - Test Submit -> Govern -> Execute flow<br>- Verify Ledger entries | - N/A | `pytest` |
| `tests/test_registry.py` | CREATE | Registry Verify | - Test CRUD and Versioning<br>- Test State Transitions | - N/A | `pytest` |
| `tests/test_kill_switch.py` | CREATE | Safety Verify | - Test freeze stops execution<br>- Test activation logging | - N/A | `pytest` |

## 8. Data Flows & Control Loops

1.  **Job Submission**:
    `Agent/User` -> `JobExecutor.submit_job` -> `Governor.evaluate_action` -> `Ledger (Log)` -> `[Decision]`
2.  **Execution (Approved)**:
    `[Decision: ALLOW]` -> `JobExecutor.execute_job` -> `Registry (Read/Write)` -> `Ledger (Log)` -> `JobDB (Update)`
3.  **Execution (Denied)**:
    `[Decision: DENY]` -> `JobExecutor (Reject)` -> `Ledger (Log)` -> `Return Error`
4.  **Emergency Freeze**:
    `Owner/Governor` -> `KillSwitch.activate` -> `JobExecutor (Check Status)` -> `PAUSE ALL` -> `Ledger (Log)`

## 9. Determinism & Audit Guarantees
- **Replayability**: Every job input and outcome must be logged to `jobs.db` and Universal Ledger. Rerunning a job with same inputs (mocking time) should yield deterministic results (logic-wise).
- **No Silent Failures**: All exceptions in `JobExecutor` must be caught, logged to Ledger, and persisted in `jobs.db` with an error code.
- **Audit**: Every `write` operation to Registry or JobDB must have a corresponding Ledger entry.

## 10. Acceptance Criteria (BINARY)

- [ ] **Command**: `npm run test` (or `pytest`) passes with 100% success.
- [ ] **Command**: `grep -r "TODO" src/` returns 0 hits.
- [ ] **Invariant**: `JobExecutor` throws exception if instantiated without a Governor.
- [ ] **Invariant**: `Registry` successfully creates `data/registry.db` on init.
- [ ] **Invariant**: Submitted jobs appear in `data/jobs.db`.
- [ ] **Invariant**: Denied jobs DO NOT execute (verify via logs).

## 11. Stop Conditions
- If `Governor` logic fails (e.g., returns None/Error), system MUST HALT (Kill Switch Activate).
- If `Ledger` is unwritable, system MUST HALT.
- If `Registry` database is corrupt, system MUST HALT.

## 12. Non-Scope
- **No Agent Logic**: `JobExecutor` assumes simple jobs; complex agent behaviors are Phase 2.
- **No Real Assets**: No actual deployment to internet (Phase 3).
- **No Web UI**: CLI/API only (Phase 4).
