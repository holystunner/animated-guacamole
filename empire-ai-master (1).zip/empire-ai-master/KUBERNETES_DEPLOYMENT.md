# Empire AI Kubernetes Deployment Guide

This guide provides comprehensive instructions for deploying the Empire AI platform on Kubernetes using both raw Kubernetes manifests and Helm charts.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Architecture Overview](#architecture-overview)
3. [Deployment Methods](#deployment-methods)
4. [Configuration](#configuration)
5. [Security Considerations](#security-considerations)
6. [Monitoring and Logging](#monitoring-and-logging)
7. [Troubleshooting](#troubleshooting)
8. [Maintenance](#maintenance)

## Prerequisites

### Required Tools

- **Kubernetes Cluster** (v1.24+)
- **kubectl** configured to access your cluster
- **Helm 3** (for Helm-based deployment)
- **OpenSSL** (for TLS certificate generation)
- **Docker** (for building custom images)

### Cluster Requirements

- **Minimum Nodes**: 3 worker nodes
- **Node Resources**: 
  - CPU: 4 cores per node
  - Memory: 8GB RAM per node
  - Storage: 100GB SSD per node
- **Storage Classes**: 
  - `fast-ssd` (recommended for databases)
  - `standard` (for general use)

### Network Requirements

- **Ingress Controller**: NGINX Ingress Controller (recommended)
- **Load Balancer**: For external access
- **DNS**: Wildcard domain or individual host entries

## Architecture Overview

The Empire AI platform consists of the following components:

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Frontend      │    │     Backend     │    │   Identity      │
│   (Nginx)       │    │   (Python)      │    │  (Keycloak)     │
│   Port: 80/443  │    │   Port: 8000    │    │   Port: 8080    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         └───────────────────────┼───────────────────────┘
                                 │
         ┌─────────────────┐    ┌─────────────────┐
         │     Cache       │    │    Database     │
         │    (Redis)      │    │  (PostgreSQL)   │
         │   Port: 6379    │    │   Port: 5432    │
         └─────────────────┘    └─────────────────┘
```

### Component Details

#### Frontend (Nginx)
- Serves static React application
- Handles SSL termination
- Provides reverse proxy for API
- Includes rate limiting and security headers

#### Backend (Python/FastAPI)
- Main application logic
- RESTful API endpoints
- Authentication and authorization
- Business logic processing

#### Identity (Keycloak)
- User authentication and authorization
- OAuth2/OpenID Connect provider
- User management interface
- Role-based access control

#### Database (PostgreSQL)
- Primary data storage
- User data, configurations, audit logs
- Persistent volume for data durability

#### Cache (Redis)
- Session storage
- Caching layer
- Real-time data storage

## Deployment Methods

### Method 1: Direct Kubernetes Manifests

This method uses individual YAML files for each component.

#### Quick Start

```bash
# Clone the repository
git clone <repository-url>
cd empire-ai

# Deploy everything
./scripts/deploy-k8s.sh deploy

# Check status
./scripts/deploy-k8s.sh status
```

#### Manual Deployment Steps

1. **Create Namespace and RBAC**
   ```bash
   kubectl apply -f k8s/namespace.yaml
   ```

2. **Create Secrets and ConfigMaps**
   ```bash
   kubectl apply -f k8s/secrets.yaml
   kubectl apply -f k8s/configmaps.yaml
   ```

3. **Deploy Infrastructure**
   ```bash
   kubectl apply -f k8s/postgres.yaml
   kubectl apply -f k8s/redis.yaml
   kubectl apply -f k8s/keycloak.yaml
   ```

4. **Deploy Application**
   ```bash
   kubectl apply -f k8s/backend.yaml
   kubectl apply -f k8s/frontend.yaml
   kubectl apply -f k8s/services.yaml
   kubectl apply -f k8s/ingress.yaml
   ```

### Method 2: Helm Chart Deployment

This method uses Helm for easier management and customization.

#### Quick Start

```bash
# Deploy with Helm
./scripts/deploy-k8s.sh helm-deploy

# Or using Helm directly
helm install empire-ai ./helm/empire-ai \
  --namespace empire-ai \
  --create-namespace
```

#### Custom Values

Create a custom values file:

```yaml
# custom-values.yaml
empire-ai:
  replicaCount: 5
  resources:
    requests:
      memory: "2Gi"
      cpu: "1000m"
    limits:
      memory: "4Gi"
      cpu: "2000m"

ingress:
  hosts:
    main:
      host: "empire-ai.yourdomain.com"
    api:
      host: "api.empire-ai.yourdomain.com"
    keycloak:
      host: "auth.empire-ai.yourdomain.com"
```

Deploy with custom values:

```bash
helm upgrade --install empire-ai ./helm/empire-ai \
  --namespace empire-ai \
  --values custom-values.yaml
```

## Configuration

### Environment Variables

#### Backend Configuration

| Variable | Description | Default |
|----------|-------------|---------|
| `ENVIRONMENT` | Environment type | `production` |
| `LOG_LEVEL` | Logging level | `INFO` |
| `DATABASE_URL` | PostgreSQL connection string | - |
| `REDIS_URL` | Redis connection string | - |
| `JWT_SECRET` | JWT signing secret | - |
| `KEYCLOAK_ISSUER` | Keycloak issuer URL | - |

#### Frontend Configuration

| Variable | Description | Default |
|----------|-------------|---------|
| `VITE_API_URL` | Backend API URL | - |
| `VITE_KEYCLOAK_URL` | Keycloak URL | - |

### Secrets Management

#### Required Secrets

1. **Database Password**
   ```bash
   kubectl create secret generic empire-ai-secrets \
     --from-literal=DATABASE_PASSWORD=your-secure-password \
     --namespace empire-ai
   ```

2. **JWT Secret**
   ```bash
   kubectl create secret generic empire-ai-secrets \
     --from-literal=JWT_SECRET=your-jwt-secret \
     --namespace empire-ai
   ```

3. **TLS Certificates**
   ```bash
   kubectl create secret tls empire-ai-tls \
     --cert=path/to/tls.crt \
     --key=path/to/tls.key \
     --namespace empire-ai
   ```

### Storage Configuration

#### Persistent Volumes

The platform requires the following persistent volumes:

- **PostgreSQL**: 20Gi (fast SSD recommended)
- **PostgreSQL WAL**: 10Gi (fast SSD recommended)
- **Redis**: 5Gi
- **Backups**: 10Gi
- **Checkpoints**: 5Gi

#### Storage Classes

Configure appropriate storage classes in your values.yaml:

```yaml
global:
  storageClass: "fast-ssd"

empire-ai:
  persistence:
    backups:
      storageClass: "fast-ssd"
    checkpoints:
      storageClass: "standard"
```

## Security Considerations

### Network Security

1. **Network Policies**: Enable network policies to restrict traffic
   ```yaml
   security:
     networkPolicy:
       enabled: true
   ```

2. **Ingress Security**: Configure security headers and rate limiting
   ```yaml
   ingress:
     annotations:
       nginx.ingress.kubernetes.io/rate-limit: "100"
       nginx.ingress.kubernetes.io/ssl-redirect: "true"
   ```

### Pod Security

1. **Security Context**: Configure pod security contexts
   ```yaml
   empire-ai:
     podSecurityContext:
       runAsNonRoot: true
       runAsUser: 1000
       fsGroup: 2000
   ```

2. **Resource Limits**: Set appropriate resource limits
   ```yaml
   empire-ai:
     resources:
       requests:
         memory: "1Gi"
         cpu: "500m"
       limits:
         memory: "2Gi"
         cpu: "1000m"
   ```

### Secrets Management

1. **External Secrets**: Consider using external secret management
   - HashiCorp Vault
   - AWS Secrets Manager
   - Azure Key Vault

2. **Secret Rotation**: Implement secret rotation policies

## Monitoring and Logging

### Health Checks

All components include health checks:

```bash
# Check pod health
kubectl get pods -n empire-ai

# Check service endpoints
kubectl get endpoints -n empire-ai

# Run health check script
./scripts/deploy-k8s.sh health
```

### Logging

#### Application Logs

```bash
# View backend logs
kubectl logs -f deployment/empire-ai -n empire-ai

# View frontend logs
kubectl logs -f deployment/nginx -n empire-ai

# View database logs
kubectl logs -f statefulset/postgres -n empire-ai
```

#### System Logs

```bash
# View all logs in namespace
kubectl logs --all-containers=true -n empire-ai -f

# View previous logs
kubectl logs --previous -f deployment/empire-ai -n empire-ai
```

### Metrics

Enable Prometheus metrics:

```yaml
monitoring:
  enabled: true
  serviceMonitor:
    enabled: true
```

## Troubleshooting

### Common Issues

#### 1. Pods Not Starting

**Symptoms**: Pods stuck in `Pending` or `CrashLoopBackOff`

**Solutions**:
```bash
# Check pod events
kubectl describe pod <pod-name> -n empire-ai

# Check resource constraints
kubectl top nodes
kubectl top pods -n empire-ai

# Check logs
kubectl logs <pod-name> -n empire-ai
```

#### 2. Database Connection Issues

**Symptoms**: Backend pods can't connect to database

**Solutions**:
```bash
# Check database service
kubectl get service postgres-service -n empire-ai

# Check database endpoints
kubectl get endpoints postgres-service -n empire-ai

# Test database connection
kubectl exec -it postgres-0 -n empire-ai -- psql -U empire -d empire
```

#### 3. Ingress Issues

**Symptoms**: Can't access application via external URLs

**Solutions**:
```bash
# Check ingress controller
kubectl get pods -n ingress-nginx

# Check ingress resources
kubectl get ingress -n empire-ai

# Check ingress logs
kubectl logs -n ingress-nginx deployment/ingress-nginx-controller
```

#### 4. Certificate Issues

**Symptoms**: SSL/TLS certificate errors

**Solutions**:
```bash
# Check TLS secret
kubectl get secret empire-ai-tls -n empire-ai

# Check certificate validity
kubectl get secret empire-ai-tls -o yaml -n empire-ai

# Regenerate certificates
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout tls.key -out tls.crt \
  -subj "/CN=empire-ai.local"
```

### Debug Commands

```bash
# Port forward to local machine
kubectl port-forward service/empire-ai-service 8000:8000 -n empire-ai

# Execute into pod
kubectl exec -it <pod-name> -n empire-ai -- /bin/bash

# Check resource usage
kubectl top pods -n empire-ai
kubectl top nodes
```

## Maintenance

### Updates and Upgrades

#### Helm Upgrade

```bash
# Upgrade to new version
helm upgrade empire-ai ./helm/empire-ai \
  --namespace empire-ai \
  --values custom-values.yaml

# Rollback to previous version
helm rollback empire-ai 1 -n empire-ai
```

#### Manifest Updates

```bash
# Apply updated manifests
kubectl apply -f k8s/

# Check rollout status
kubectl rollout status deployment/empire-ai -n empire-ai
```

### Backup and Recovery

#### Database Backup

```bash
# Create database backup
kubectl exec postgres-0 -n empire-ai -- \
  pg_dump -U empire empire > backup.sql

# Restore database backup
kubectl exec -i postgres-0 -n empire-ai -- \
  psql -U empire empire < backup.sql
```

#### Persistent Volume Backup

```bash
# List PVCs
kubectl get pvc -n empire-ai

# Backup PVC data (using rsync)
kubectl exec -it <pod-name> -- tar czf /tmp/backup.tar.gz /data
kubectl cp <pod-name>:/tmp/backup.tar.gz ./backup.tar.gz
```

### Scaling

#### Horizontal Scaling

```bash
# Scale backend
kubectl scale deployment empire-ai --replicas=5 -n empire-ai

# Scale frontend
kubectl scale deployment nginx --replicas=3 -n empire-ai
```

#### Vertical Scaling

Update resource requests/limits in values.yaml or manifests:

```yaml
empire-ai:
  resources:
    requests:
      memory: "2Gi"
      cpu: "1000m"
    limits:
      memory: "4Gi"
      cpu: "2000m"
```

### Cleanup

```bash
# Remove entire deployment
./scripts/deploy-k8s.sh cleanup

# Or manually
kubectl delete namespace empire-ai
```

## Support

For additional support:

1. Check the [GitHub Issues](https://github.com/your-org/empire-ai/issues)
2. Review the [documentation](https://docs.empire-ai.local)
3. Contact the Empire AI team at team@empire-ai.local

## Contributing

To contribute to the Kubernetes deployment:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

---

**Note**: This deployment guide assumes a production-ready Kubernetes cluster. For development environments, consider using Minikube, kind, or k3d.
