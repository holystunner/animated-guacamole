
import sys
import os
sys.path.append(os.getcwd())

print("Importing db...", flush=True)
try:
    import src.db
    print("DB imported", flush=True)
except Exception as e:
    print(f"DB failed: {e}", flush=True)

print("Importing system_monitor...", flush=True)
try:
    import src.system_monitor
    print("Monitor imported", flush=True)
except Exception as e:
    print(f"Monitor failed: {e}", flush=True)

print("Importing approval_workflow...", flush=True)
try:
    import src.approval_workflow
    print("Approval imported", flush=True)
except Exception as e:
    print(f"Approval failed: {e}", flush=True)

print("Importing action_executor...", flush=True)
try:
    import src.action_executor
    print("Executor imported", flush=True)
except Exception as e:
    print(f"Executor failed: {e}", flush=True)

print("Importing hive_backend...", flush=True)
try:
    import src.hive_backend
    print("Hive imported", flush=True)
except Exception as e:
    print(f"Hive failed: {e}", flush=True)

print("Importing real_endpoints...", flush=True)
try:
    import src.real_endpoints
    print("Real Endpoints imported", flush=True)
except Exception as e:
    print(f"Real Endpoints failed: {e}", flush=True)

print("Importing main_api...", flush=True)
try:
    import src.main_api
    print("Main API imported", flush=True)
except Exception as e:
    print(f"Main API failed: {e}", flush=True)
