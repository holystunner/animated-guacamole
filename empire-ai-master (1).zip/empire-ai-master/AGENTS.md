# AGENTS.md — Empire-AI Agent Configuration & Scope

**Authority:** Windsurf Skill System + Global Governance  
**Status:** ACTIVE  
**Last Updated:** 2026-01-15  
**Repository:** empire-ai (Node.js/Python hybrid)

---

## Overview

This file configures:
1. **Global agent rules** (from `/home/lin/.codeium/windsurf/rules/`)
2. **Repository-specific rules** (for empire-ai only)
3. **Directory-scoped conventions**
4. **Canonical commands**

---

## SECTION 1: GLOBAL GOVERNANCE

All code in this repository follows global governance rules defined at:
- `~/.codeium/windsurf/rules/00-kaiza-global-rules.md`
- `~/.codeium/windsurf/rules/10-refusal-behavior.md`
- `~/.codeium/windsurf/rules/20-definition-of-done.md`

**In summary:**
- ✓ All code must be complete (no stubs, TODOs, unimplemented!)
- ✓ All changes must be tested
- ✓ All changes must be documented
- ✓ All changes must be auditable (KAIZA-AUDIT block required)

---

## SECTION 2: EMPIRE-AI SPECIFIC RULES

### Tech Stack

**Frontend (Node.js/React)**
- Framework: React
- Build: npm/webpack
- Tests: Jest
- Linter: ESLint
- Type checking: TypeScript (if applicable)

**Backend (Python)**
- Framework: Flask/FastAPI
- Testing: pytest
- Linter: pylint, flake8
- Type checking: mypy (if applicable)

### Directory Structure

```
empire-ai/
├── src/              # Source code (frontend + backend)
├── tests/            # Test files
├── docs/             # Documentation
├── scripts/          # Helper scripts
├── observability/    # Logging and monitoring configs
├── runbooks/         # Incident response procedures
└── scripts/ci/       # CI verification scripts
```

### Canonical Commands

**Frontend (Node.js)**
```bash
npm install                 # Install dependencies
npm run dev                 # Development server
npm run build               # Production build
npm test                    # Run tests
npm run lint                # Lint check
npm run typecheck           # TypeScript check (if applicable)
npm run format:check        # Code format check
```

**Backend (Python)**
```bash
pip install -r requirements.txt    # Install dependencies
python app.py                      # Run backend
pytest                             # Run tests
pylint src/                        # Linting
python -m mypy src/                # Type checking (if enabled)
```

**CI/Verification**
```bash
python3 scripts/ci/forbidden_markers_scan.py --root .  # Forbidden markers check
npm audit --audit-level=high                           # Dependency vulnerabilities
bash scripts/ci/run_if_present.sh lint                 # Run if script exists
bash scripts/ci/run_if_present.sh test                 # Run if script exists
```

---

## SECTION 3: SKILLS TO USE

When working on empire-ai, use these skills from `~/.codeium/windsurf/skills/`:

### For Any Code Change
```
@repo-understanding           # Understand the codebase
@no-placeholders-production-code    # Write complete code
@test-engineering-suite       # Write tests
@audit-first-commentary       # Document code
```

### For Boundary Code (HTTP handlers, APIs)
```
@debuggable-by-default        # Add observability
@secure-by-default            # Input validation, secrets management
```

### For Refactoring
```
@refactor-with-safety         # Incremental, safe refactoring
```

### For Production Issues
```
@incident-triage-and-rca      # Incident response and root cause analysis
```

### For Releases
```
@release-readiness            # Release safety and artifact integrity
```

---

## SECTION 4: OBSERVABILITY REQUIREMENTS

All code must emit structured logs and observability data:

**Required for:**
- HTTP endpoint handlers
- Database operations
- External API calls
- Error cases

**Schema:** See `observability/logging_schema.md`

**Example log:**
```json
{
  "timestamp": "2026-01-15T12:34:56.789Z",
  "level": "info",
  "message": "user authenticated",
  "service": "api",
  "request_id": "r_abc123",
  "op": "auth.login",
  "duration_ms": 45
}
```

**Redaction Policy:** See `observability/redaction_policy.md`
- Never log: passwords, tokens, API keys, PII
- OK to log: user IDs, hashed values, safe summaries

---

## SECTION 5: TESTING REQUIREMENTS

### Coverage Targets
- Global minimum: 80% statement coverage
- Critical paths (auth, payment, data processing): 90%+

### Test Types
1. **Unit tests**: Pure function logic
2. **Integration tests**: API endpoints, database operations
3. **Contract tests**: External API integrations
4. **Error path tests**: Failure handling

### Commands
```bash
npm test                    # Frontend tests
npm test -- --coverage      # With coverage report
pytest                      # Backend tests
pytest --cov=src            # With coverage report
```

---

## SECTION 6: SECURITY REQUIREMENTS

All code must follow `@secure-by-default` skill:

- ✓ Input validation at all boundaries
- ✓ Secrets from environment variables (never hardcoded)
- ✓ Password hashing (bcrypt, not plain text)
- ✓ SQL injection prevention (parameterized queries)
- ✓ Path traversal prevention
- ✓ HTTPS enforcement (production)
- ✓ Rate limiting on sensitive endpoints
- ✓ CSRF protection (for state-changing operations)

**Verification:**
```bash
npm audit --audit-level=high          # Dependency vulnerabilities
pip install safety && safety check    # Python dependencies (if backend)
grep -r "password=\|api_key=" src/    # No hardcoded secrets
```

---

## SECTION 7: CI VERIFICATION GATES

Before merging, all these must pass:

```bash
# 1. Forbidden markers (no TODO/FIXME in code)
python3 scripts/ci/forbidden_markers_scan.py --root .

# 2. Tests
npm test
pytest

# 3. Linting
npm run lint
pylint src/

# 4. Type checking (if applicable)
npm run typecheck

# 5. Dependency audit
npm audit --audit-level=high
pip install safety && safety check

# 6. Format check (if applicable)
npm run format:check
```

---

## SECTION 8: INCIDENT RESPONSE

When production issues occur:

1. Use `@incident-triage-and-rca` skill
2. Follow procedures in `runbooks/triage.md`
3. Conduct RCA using `runbooks/rca_template.md`
4. Use `runbooks/comms_template.md` for stakeholder updates

---

## SECTION 9: KAIZA-AUDIT BLOCK

**MANDATORY** for every PR/merge:

```
KAIZA-AUDIT
Plan: [plan-name or feature-name]
Scope: [files changed]
Intent: [what was accomplished]
Key Decisions: [why these choices]
Verification: [tests pass, gates pass, etc.]
Results: [PASS or FAIL with details]
Risk Notes: [any remaining concerns]
Rollback: [how to revert]
KAIZA-AUDIT-END
```

**Example:**
```
KAIZA-AUDIT
Plan: implement-user-auth
Scope: src/auth.js, src/middleware.js, tests/auth.test.js
Intent: Add JWT authentication for user login
Key Decisions: Used HS256 for simplicity; 1-hour token expiry for security
Verification: npm test PASS (15 tests), npm run lint PASS, forbidden_markers PASS
Results: PASS - All gates pass, ready for review
Risk Notes: Tokens do not auto-refresh (future work); rate limiting needed on /login
Rollback: Revert commits; feature can be toggled via JWT_ENABLED env var
KAIZA-AUDIT-END
```

---

## SECTION 10: COMPREHENSIVE GUIDES

Learn how to use all skills and governance:

📍 Location: `/home/lin/Documents/markenz/docs/guides/`

**Start here:**
- `README.md` - Master index and learning paths

**Learn skills:**
- `00_GETTING_STARTED.md` - Overview (5 min read)
- `01_SKILLS_DEEP_DIVE.md` - Detailed instructions with examples
- `03_EXAMPLE_SCENARIOS.md` - Real-world examples and exact prompts
- `04_QUICK_REFERENCE.md` - Cheat sheet for quick lookup

**These guides are global** - available from any repo on this machine.

---

## SECTION 11: DIRECTORY-SCOPED RULES

### `/src` (Source code)
- Follow `@no-placeholders-production-code`
- Follow `@audit-first-commentary`
- All functions documented
- No stubs or incomplete implementations

### `/tests` (Test files)
- Use `@test-engineering-suite` patterns
- Arrange-Act-Assert structure
- Deterministic (no random data, fixed seeds)
- >80% coverage globally

### `/observability` (Logging/monitoring)
- All changes must follow `observability/logging_schema.md`
- All new fields must be documented
- Redaction policy enforced

### `/docs` (Documentation)
- Must stay in sync with code
- Must include examples where applicable
- Must include links to skills/workflows when teaching

---

## SECTION 12: QUESTIONS?

**"How do I...?"** → Look in `~/.codeium/windsurf/skills/` for that skill  
**"What's required for my task?"** → Check `/home/lin/Documents/markenz/docs/guides/`  
**"Is my code done?"** → Check Definition of Done: `~/.codeium/windsurf/rules/20-definition-of-done.md`  
**"What are the rules?"** → Check `~/.codeium/windsurf/rules/00-kaiza-global-rules.md`

---

**Authority hierarchy (strictest wins):**
1. Global rules (`~/.codeium/windsurf/rules/`)
2. This file (AGENTS.md)
3. Directory-scoped AGENTS.md (if present)
4. Skills guidance

