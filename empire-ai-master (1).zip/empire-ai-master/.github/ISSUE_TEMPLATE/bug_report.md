---
name: Bug Report
description: File a bug report to help us improve Empire AI
title: "[BUG]: "
labels: ["bug", "triage"]
assignees: []

---

## Bug Description

A clear and concise description of what the bug is.

## Expected Behavior

What you expected to happen.

## Actual Behavior

What actually happened. Include screenshots if applicable.

## Steps to Reproduce

1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

## Environment

**Empire AI Version:**
- Operating System: [e.g. Windows 11, macOS 13.0, Ubuntu 22.04]
- Browser: [e.g. Chrome 108.0, Firefox 107.0, Safari 16.0]
- Backend Version: [e.g. v1.0.0]
- Frontend Version: [e.g. v1.0.0]

**Configuration:**
- Python Version: [e.g. 3.9.0]
- Node.js Version: [e.g. 18.0.0]
- Database: [e.g. SQLite 3.39.0]

## Logs

**Backend Logs:**
```
Paste relevant backend logs here
```

**Frontend Console:**
```
Paste relevant browser console errors here
```

**System Logs:**
```
Paste any relevant system logs here
```

## Additional Context

Add any other context about the problem here.

## Severity

- [ ] Critical - System unusable or data loss
- [ ] High - Major functionality broken
- [ ] Medium - Some functionality affected
- [ ] Low - Minor issue or cosmetic problem

## Workaround

Is there a workaround for this issue? If so, please describe it.

## Related Issues

List any related issues or pull requests.

## Checklist

- [ ] I have searched existing issues for duplicates
- [ ] I have provided all requested information
- [ ] I have included relevant logs and screenshots
- [ ] I have checked that this is a genuine bug and not user error
