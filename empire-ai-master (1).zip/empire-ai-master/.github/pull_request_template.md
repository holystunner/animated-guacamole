## Pull Request Description

<!-- Describe your changes in detail -->

### What type of PR is this?

- [ ] 🐛 Bug fix
- [ ] ✨ New feature
- [ ] 💄 UI/UX update
- [ ] ♻️ Refactoring
- [ ] 📝 Documentation
- [ ] 🔧 Configuration
- [ ] 🚀 Performance
- [ ] 🔒 Security
- [ ] 🧪 Testing
- [ ] Other (please specify)

### What does this PR do?

<!-- A clear and concise description of the purpose of this PR -->

### Why is this change needed?

<!-- Explain the problem this PR solves or the improvement it provides -->

### How was this change tested?

<!-- Describe how you tested this change -->

### Screenshots (if applicable)

<!-- Add screenshots to show your changes -->

## Checklist

### Code Quality
- [ ] My code follows the project's coding standards
- [ ] I have performed a self-review of my own code
- [ ] I have made corresponding changes to the documentation
- [ ] My changes generate no new warnings

### Testing
- [ ] I have added tests that prove my fix is effective or that my feature works
- [ ] New and existing unit tests pass locally with my changes
- [ ] I have tested edge cases and error conditions
- [ ] I have tested on multiple platforms/browsers if applicable

### Documentation
- [ ] I have updated relevant documentation
- [ ] I have added or updated API documentation
- [ ] I have included examples in the documentation
- [ ] I have updated the changelog if required

### Security & Performance
- [ ] I have considered the security implications of my changes
- [ ] I have assessed the performance impact of my changes
- [ ] I have validated input and handled errors appropriately
- [ ] I have not hardcoded secrets or sensitive information

### Review Process
- [ ] I have tagged appropriate reviewers
- [ ] I have provided clear steps for reviewers
- [ ] I have linked relevant issues or documentation
- [ ] I am ready for feedback and iteration

## Breaking Changes

### Does this PR introduce breaking changes?

- [ ] No breaking changes
- [ ] Yes, breaking changes (describe below)

### If yes, please describe:

<!-- Describe any breaking changes and migration steps -->

## Dependencies

### Does this PR add new dependencies?

- [ ] No new dependencies
- [ ] Yes, new dependencies (list below)

### New Dependencies:
<!-- List any new dependencies added -->

## Performance Impact

### What is the performance impact of this change?

- [ ] No performance impact
- [ ] Improved performance
- [ ] Minor performance degradation
- [ ] Significant performance impact

### Details:
<!-- Describe performance impact with measurements if possible -->

## Security Considerations

### Have you considered security implications?

- [ ] Yes, security reviewed
- [ ] No security implications
- [ ] Requires security review

### Security Notes:
<!-- Describe any security considerations -->

## Deployment Notes

### Any special deployment considerations?

- [ ] No special deployment requirements
- [ ] Database migrations required
- [ ] Configuration changes needed
- [ ] Environment variables required
- [ ] Other (please specify)

### Deployment Steps:
<!-- List any special deployment steps -->

## Rollback Plan

### How can this change be rolled back if needed?

<!-- Describe rollback procedure -->

## Additional Context

<!-- Add any other context, screenshots, or information about this PR -->

## Related Issues

<!-- Link any related issues or pull requests -->
- Closes #
- Related to #

## KAIZA-AUDIT

<!-- Required for all PRs to Empire AI -->

```
KAIZA-AUDIT
Plan: [plan-name-or-feature-name]
Scope: [files-changed]
Intent: [what-was-accomplished]
Key Decisions: [why-these-choices]
Verification: [tests-pass-gates-pass-etc]
Results: [PASS-or-FAIL-with-details]
Risk Notes: [any-remaining-concerns]
Rollback: [how-to-revert]
KAIZA-AUDIT-END
```

---

**Thank you for contributing to Empire AI!** 🚀
